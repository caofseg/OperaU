/*
 * PowerPC (big-endian) simulation harness: boots the Opera core, hashes the
 * frames and checks the save-state replay, then prints the same numbers the
 * x86 self test prints. Compare the two to prove the PPC build is correct.
 */
#include "cdtest.h"
#include "common.h"
#include "config.h"
#include "core.h"
#include "coretest.h"
#include "deeptest.h"
#include "platform.h"

#include "libopera/opera_prof.h"

static void nullv(const void *d, unsigned w, unsigned h, size_t p, core_pixel_format_t f) { (void)d; (void)w; (void)h; (void)p; (void)f; }
static size_t nulla(const int16_t *f, size_t n) { (void)f; return n; }

int main(int argc, char **argv)
{
    core_sink_t sink = {nullv, nulla};
    coretest_result_t r;
    const union { uint32_t u; uint8_t b[4]; } probe = {0x01020304u};
    int bad = 0;

    printf("host byte order: %s\n", probe.b[0] == 1 ? "BIG endian" : "little endian");
    config_load();
    if (!core_init(&sink)) {
        printf("core_init failed\n");
        return 2;
    }
#ifdef OPERA_ARM_TRACE
    if (argc >= 5 && !strcmp(argv[1], "armtrace")) { /* harness armtrace FILE FROM TO */
        printf("armtrace frames %d..%d -> %s: %s\n", atoi(argv[3]), atoi(argv[4]), argv[2],
               coretest_armtrace(NULL, atoi(argv[3]), atoi(argv[4]), argv[2]) ? "ok" : "FAILED");
        core_deinit();
        return 0;
    }
#endif
    if (argc >= 3 && !strcmp(argv[1], "mem")) { /* harness mem PREFIX [frames] */
        int n = argc >= 4 ? atoi(argv[3]) : CORETEST_REF_FRAMES;
        printf("mem %d frames -> %s.{dram,vram}: %s\n", n, argv[2], coretest_dump_mem(NULL, n, argv[2]) ? "ok" : "FAILED");
        core_deinit();
        return 0;
    }
    if (argc >= 3 && !strcmp(argv[1], "trace")) { /* harness trace FILE [frames] */
        int n = argc >= 4 ? atoi(argv[3]) : CORETEST_REF_FRAMES;
        printf("trace %d frames -> %s: %s\n", n, argv[2], coretest_trace(NULL, n, argv[2]) ? "ok" : "FAILED");
        core_deinit();
        return 0;
    }
    if (argc >= 3 && !strcmp(argv[1], "dump")) { /* harness dump FILE [frames] */
        int n = argc >= 4 ? atoi(argv[3]) : CORETEST_REF_FRAMES;
        printf("dump %d frames -> %s: %s\n", n, argv[2], coretest_dump_frame(NULL, n, argv[2]) ? "ok" : "FAILED");
        core_deinit();
        return 0;
    }
    if (argc >= 3 && !strcmp(argv[1], "diag")) { /* harness diag SCRATCH_DIR: the path the on-console diagnostic takes */
        bool ok;

        core_diag_enter(argv[2]); /* default options, no input, scratch save / system directory */
        ok = coretest_run(NULL, CORETEST_REF_FRAMES, &r);
        core_diag_leave();
        printf("diag: run %s, boot hash %s the x86 reference, state %s, replay %s\n", ok ? "ok" : "FAILED",
               coretest_matches_reference(&r) ? "equals" : "DIFFERS FROM", r.state_ok ? "ok" : "FAILED",
               r.deterministic ? "identical" : "DIFFERENT");
        printf("diag: video %08x%08x audio %08x%08x\n", (unsigned)(r.video_hash >> 32), (unsigned)r.video_hash,
               (unsigned)(r.audio_hash >> 32), (unsigned)r.audio_hash);
        core_deinit();
        return (ok && coretest_matches_reference(&r) && r.state_ok && r.deterministic) ? 0 : 2;
    }
    if (argc >= 3 && !strcmp(argv[1], "cdhash")) { /* harness cdhash PATH: read every sector, print the hashes */
        bool ok = cdtest_hash(argv[2]);
        core_deinit();
        return ok ? 0 : 2;
    }
    if (argc >= 3 && !strcmp(argv[1], "deep")) { /* harness deep arm|dsp|cel|all [trials] [seed] */
        int n = argc >= 4 ? atoi(argv[3]) : 1000;
        uint32_t seed = argc >= 5 ? (uint32_t)strtoul(argv[4], NULL, 0) : 12345u;
        bool ok = deeptest_run(argv[2], seed, n);
        core_deinit();
        return ok ? 0 : 2;
    }
    if (argc >= 3 && !strcmp(argv[1], "image")) { /* harness image PATH [frames]: print the hashes only */
        int n = argc >= 4 ? atoi(argv[3]) : 120;
        if (!coretest_run(argv[2], n, &r) || !r.loaded) {
            printf("coretest_run failed: %s\n", r.error);
            return 2;
        }
        printf("image %s: %d frames: video %08x%08x audio %08x%08x nonzero %llu audio frames %u\n", argv[2], n,
               (unsigned)(r.video_hash >> 32), (unsigned)r.video_hash, (unsigned)(r.audio_hash >> 32),
               (unsigned)r.audio_hash, (unsigned long long)r.nonzero_pixels, r.audio_frames);
        core_deinit();
        return 0;
    }
    if (argc >= 2 && !strcmp(argv[1], "prof")) { /* harness prof: boot with the timing hooks on; they must change nothing */
        bool ok;

        opera_prof_enabled = 1;
        ok = coretest_run(NULL, CORETEST_REF_FRAMES, &r) && coretest_matches_reference(&r) && r.state_ok && r.deterministic;
        opera_prof_enabled = 0;
        printf("prof: boot hash with the hooks on %s the x86 reference (video %08x%08x audio %08x%08x)\n",
               ok ? "equals" : "DIFFERS from", (unsigned)(r.video_hash >> 32), (unsigned)r.video_hash, (unsigned)(r.audio_hash >> 32),
               (unsigned)r.audio_hash);
        printf("prof: frames %llu, internal steps %llu, DSP runs %llu, video lines %llu, cel lists %llu\n",
               (unsigned long long)opera_prof.frames, (unsigned long long)opera_prof.internal_calls,
               (unsigned long long)opera_prof.dsp_calls, (unsigned long long)opera_prof.vdl_calls,
               (unsigned long long)opera_prof.cel_calls);
        printf("prof: ticks: internal %llu, dsp %llu, vdl %llu, cel %llu, audio %llu, picture %llu\n",
               (unsigned long long)opera_prof.internal, (unsigned long long)opera_prof.dsp, (unsigned long long)opera_prof.vdl,
               (unsigned long long)opera_prof.cel, (unsigned long long)opera_prof.audio_up, (unsigned long long)opera_prof.video_cb);
        core_deinit();
        return ok ? 0 : 1;
    }
    if (!coretest_run(NULL, CORETEST_REF_FRAMES, &r)) {
        printf("coretest_run failed: %s\n", r.error);
        return 2;
    }
    printf("size %ux%u  fps %.2f  audio %.0f Hz  audio frames %u\n", r.width, r.height, r.fps, r.sample_rate, r.audio_frames);
    printf("boot hash after %d frames: video %08x%08x audio %08x%08x\n", r.frames, (unsigned)(r.video_hash >> 32),
           (unsigned)r.video_hash, (unsigned)(r.audio_hash >> 32), (unsigned)r.audio_hash);
    printf("expected (x86)           : video %08x%08x audio %08x%08x\n", (unsigned)(CORETEST_REF_VIDEO_HASH >> 32),
           (unsigned)CORETEST_REF_VIDEO_HASH, (unsigned)(CORETEST_REF_AUDIO_HASH >> 32), (unsigned)CORETEST_REF_AUDIO_HASH);
    printf("state size %u  save/load %s  replay %s\n", (unsigned)r.state_size, r.state_ok ? "ok" : "FAILED",
           r.deterministic ? "bit exact" : "DIFFERS");
    if (!coretest_matches_reference(&r)) {
        printf("RESULT: boot hash DIFFERS from the x86 reference\n");
        bad = 1;
    }
    if (!r.state_ok || !r.deterministic)
        bad = 1;
    if (!bad)
        printf("RESULT: PowerPC build matches the x86 reference bit for bit\n");
    core_deinit();
    return bad;
}
