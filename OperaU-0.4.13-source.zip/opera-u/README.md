# Opera U — emulador de 3DO para Wii U (Aroma)

[English version](README.en.md)

Opera U é um emulador de 3DO que roda como aplicativo **Aroma** (`.wuhb`) no Wii U. Ele usa o núcleo
[Opera](https://github.com/libretro/opera-libretro) (projeto libretro, derivado do 4DO e do FreeDO), compilado
junto com um front-end próprio escrito para o Wii U: vídeo via SDL2/GX2, áudio, controles, menu, estados salvos,
opções por jogo e um diagnóstico do núcleo que roda no próprio console.

> **Estado do projeto.** O Opera U foi escrito e verificado em um servidor Linux (sem console e sem jogos) e vem sendo
> testado, versão por versão, em um Wii U de verdade por quem o encomendou. Confirmado no console até agora: o app abre
> pelo Aroma, o **Diagnóstico do núcleo passa** (hashes de vídeo e de áudio iguais aos do PC), uma BIOS original
> funciona e jogos iniciam. Em ajuste: as cores da imagem (corrigidas nesta versão, **ainda a confirmar no console**
> com o **Teste de imagem**) e a velocidade (jogos pesados rodaram a ~33 quadros por segundo na versão anterior). O que
> foi verificado e o que **não** foi está em [Verificação](#verificação-o-que-foi-e-o-que-não-foi-testado). Se algo
> falhar, **Configurações > Sistema > Diagnóstico do núcleo**, **Configurações > Vídeo > Teste de imagem** e a pasta
> `wiiu/OperaU/logs` ajudam a descobrir o motivo.

Uso **não comercial** apenas (licença do núcleo; veja [Licenças](#licenças)). Nenhuma BIOS nem jogo acompanha o app.

## Capturas de tela

Geradas no PC pelo teste automático da interface (`--selftest-ui`); a interface é a mesma do Wii U, mas **não são
capturas de um console**.

| | |
| --- | --- |
| ![Configurações](docs/screenshots/04-settings.png) | ![Opções do núcleo](docs/screenshots/05-coreopts.png) |
| ![Ajuda e créditos](docs/screenshots/08-about.png) | ![Menu de pausa](docs/screenshots/11-pause.png) |
| ![Diagnóstico em andamento](docs/screenshots/13-diag-running.png) | ![Resultado do diagnóstico](docs/screenshots/14-diag-result.png) |
| ![Teste de imagem: barras de cor](docs/screenshots/15-testpat-colours.png) | ![Teste de imagem: geometria](docs/screenshots/16-testpat-geometry.png) |

## Instalação

1. Copie `dist/OperaU-<versão>.wuhb` (ou o `OperaU.wuhb` que você gerar com `make`; a soma SHA-256 está em
   `dist/SHA256SUMS.txt`) para `sd:/wiiu/apps/` (cartão SD do Wii U com o Aroma instalado). Se já havia um
   `OperaU.wuhb` de uma versão anterior, apague-o: os dados ficam em `sd:/wiiu/OperaU/` e não se perdem.
2. Abra o **Opera U** pelo menu do Aroma. A versão aparece no nome do item do Aroma (a partir da 0.2.1), no canto
   superior direito do app e em **Ajuda e créditos**; o `diagnostic.txt` e o log começam com ela.
3. Na primeira execução o app cria a pasta `sd:/wiiu/OperaU/` com estas subpastas:

| Pasta | Conteúdo |
| --- | --- |
| `roms/` | pasta de jogos sugerida (a tecla **Y** do navegador vai para ela) |
| `bios/` | BIOS originais, opcionais (veja abaixo) |
| `saves/` | memória interna do 3DO (NVRAM), gravada automaticamente |
| `states/` | estados salvos (10 slots por jogo + um automático) |
| `shots/` | capturas de tela |
| `config/` | configurações do app, das opções do núcleo e por jogo |
| `logs/` | log de execução (útil para relatar problemas) |

Tudo fica dentro de `wiiu/OperaU`; apagar essa pasta devolve o app ao estado inicial. (A subpasta `diag/` aparece só
durante o diagnóstico e é apagada ao fim.)

## Jogos: CHD, ISO e disco

O app abre imagens de disco **CHD, ISO e BIN+CUE** (para BIN+CUE, abra o arquivo `.cue`). Copie as imagens para o
cartão SD (ou um disco USB, se o seu ambiente o expuser ao app) e use **Abrir jogo** para navegar até elas.

* **CHD** (v5): os compressores comuns de CD do `chdman` são aceitos (`cdlz`, `cdzl`, `cdzs`, além de LZMA, zlib,
  zstd e FLAC para trilhas de áudio). Sem dependência externa: o leitor faz parte do núcleo.
* **ISO** (2048 bytes por setor) e **BIN+CUE** (2352 bytes por setor, com o `.cue` descrevendo as trilhas).
* **Disco original no drive do Wii U: não é possível.** O drive óptico do Wii U só lê discos Nintendo e não oferece
  acesso direto aos setores de outros discos; nenhum aplicativo consegue ler um disco 3DO por ele. É uma limitação do
  hardware e do sistema, não do emulador. O que o app faz no lugar: navegar por SD/USB e abrir a imagem do seu disco.

Como obter a imagem do disco que você possui (no PC):

```sh
# 1) gere um par .bin/.cue com qualquer programa de ripagem de CD (ex.: cdrdao, ImgBurn, dd + cue manual)
# 2) converta para CHD (menor e mais rápido de ler):
chdman createcd -i jogo.cue -o jogo.chd
```

Depois copie `jogo.chd` para o SD (por exemplo `sd:/wiiu/OperaU/roms/`).

## BIOS

O app inclui o **Opera Boot** (BIOS livre, GPL-2.0, projeto [opera-boot](https://github.com/trapexit/opera-boot)),
então já inicia sem arquivos extras, mas a compatibilidade com ele pode ser parcial. Para melhor compatibilidade,
coloque BIOS originais **que você possui** em `sd:/wiiu/OperaU/bios/` (nomes como `panafz10.bin`; a lista de nomes
aceitos está no README do núcleo) e escolha-as em **Configurações > Opções do núcleo > BIOS**. Alguns jogos japoneses
pedem também uma ROM de fonte (kanji) na mesma pasta.

## Controles

Mapeamento padrão (pode ser alterado em **Configurações > Controles**; há remapeamento por controle e troca de portas):

| 3DO | Wii U |
| --- | --- |
| Direcional | Direcional |
| A / B / C | B / A / ZL |
| L / R | Y / ZR |
| P (play/pause) | X |
| X (stop) | + |

Atalhos durante o jogo: **L + R ao mesmo tempo** abre ou fecha o menu (dá para desligar em Configurações > Controles se
algum jogo usar L + R juntos); **segundo analógico (direito) para a direita** avança rápido enquanto estiver empurrado;
**ZL e ZR são botões do jogo** (C e R do 3DO), e os ombros **L e R do Wii U ficam livres** para o atalho do menu; o botão **HOME é do console** e abre o menu do próprio Wii U, o app não o usa. Segurando **−** e pressionando: **+** (menu), **R** (salvar estado), **L**
(carregar estado), **←/→** (trocar de slot), **A** (capturar a tela em PNG, em `wiiu/OperaU/shots`), **Y** (reiniciar o
console); **−** + **X** segurado também avança rápido (para controles sem o segundo analógico). O mesmo texto aparece em
**Ajuda e créditos** dentro do app.

O app usa os controles que a porta SDL2 do Wii U expõe (GamePad, Pro Controller e, conforme a porta, Wii Remote com
extensões), até 8 portas, e a tela de toque do GamePad navega pelos menus. Nada disso pôde ser testado no console.

## Configurações

Vídeo (proporção, filtro, VSync, contador de FPS, **ordem dos canais de cor** e o **Teste de imagem**), áudio (volume,
latência), **núcleo da CPU usado pela emulação** (automático, 0, 1 ou 2; o padrão é 2) e o **medidor de desempenho**,
controles, idioma (português/inglês), estado automático ao sair, log por UDP e as **opções do núcleo Opera** (BIOS, resolução alta dos CELs, motor de matrizes, região, velocidade do
CD, memória, ...). As opções do núcleo valem para todos os jogos, e cada jogo pode ter as suas próprias no menu de
pausa.

## Teste de imagem (cores e geometria)

**Configurações > Vídeo > Teste de imagem** (só na tela inicial, sem jogo aberto) mostra imagens sintéticas que seguem
exatamente o caminho das imagens de um jogo (conversão para 32 bits, textura, tela). Logo acima das barras de cor há
quadrados de referência desenhados pelo próprio menu: **se a barra tem a mesma cor do quadrado, as cores estão certas**.

* Página 1: barras de cor (inteiras e em meia intensidade), rampas de vermelho, verde, azul e cinza, arco-íris e três
  quadrados (vermelho, verde, azul), em 16 bits (0RGB1555, o formato do núcleo).
* Página 2: geometria: grade 4×4, círculos (devem ser redondos em 4:3), diagonais, borda branca inteira, cantos
  vermelho / verde / azul / amarelo e um **F** (para notar espelhamento ou rotação).
* Página 3: o mesmo em alta resolução (640×480), com listras de 1 pixel para ver o efeito do filtro.
* Página 4: as barras de novo, enviadas em 32 bits (XRGB8888). Se estiverem certas aqui e erradas na página 1, o
  problema está só no caminho de 16 bits.

**A** ou **→** avança de página, **←** volta, **X** troca a **ordem dos canais de cor** (RGB, BGR, RBG, GRB, GBR, BRG;
vale para todos os jogos e fica salva), **Y** troca o filtro e **B** sai. A ordem normal (RGB) é a certa; as outras
existem só para corrigir uma troca de canais caso a saída de vídeo do console a produza. As capturas PNG (− + A) são
sempre salvas com as cores exatas que o núcleo produziu, qualquer que seja essa opção.

## Desempenho

* No PC (x86-64) a BIOS parada roda cerca de 14× mais rápido que o tempo real. No Wii U, o diagnóstico da versão
  anterior mediu 9,8 ms por quadro com a BIOS parada (1,7× o tempo real) e jogos pesados rodaram a ~33 quadros por
  segundo (≈ 55% da velocidade). Esta versão traz otimizações **exatas** (mesmos resultados bit a bit, verificados no
  PC e no PowerPC simulado) e um medidor para guiar as próximas.
* **Medidor de desempenho** (Configurações > Desempenho; ligado por padrão): a cada 5 segundos grava no log
  (`wiiu/OperaU/logs`) quantos milissegundos por quadro cada parte do emulador gasta (processador ARM, motor de
  gráficos / CELs, DSP de áudio, linhas de vídeo, temporizadores, cópia de áudio e imagem), quantos CELs, texels e
  pixels por quadro e quantas vezes o DSP roda. Com **Mostrar FPS** ligado, um resumo aparece numa segunda linha da tela.
  É assim que se descobre se o gargalo de um jogo é o ARM, os gráficos ou o áudio. O custo de medir é pequeno (algumas
  centenas de leituras do contador de tempo por quadro) e é descontado do que aparece.
* Ative **Mostrar FPS** para ver a velocidade da emulação durante o jogo, e use **Diagnóstico do núcleo** para medir
  a velocidade da BIOS parada (limite superior do que um jogo consegue).
* Se estiver pesado: deixe **HiRes CEL Rendering** desativado, mantenha o formato de pixel padrão e tente outro
  **núcleo da CPU** (automático, 0, 1 ou 2) em Configurações.

## Diagnóstico do núcleo (teste no próprio Wii U)

**Configurações > Sistema > Diagnóstico do núcleo** (só na tela inicial, sem jogo aberto). Ele roda 240 quadros da BIOS
embutida, calcula um hash de cada imagem e de cada amostra de áudio, salva um estado, repete 60 quadros duas vezes
(a repetição tem que ser idêntica) e mede a velocidade. Depois roda treze **baterias de carga** com entradas aleatórias
(interpretador ARM, DSP, programas do DSP que nunca terminam, motor de CELs em três formas, FIFOs de áudio, matrizes,
SPORT, VDL, temporizadores, laços do ARM e o ARM em todas as classes de instrução e modos). Todos os hashes são comparados com os medidos no PC; como o
Wii U é big-endian e o PC é little-endian, essa é a prova mais direta de que a versão do Wii U calcula o mesmo que o
original. Por fim desenha oito sprites com forma de jogo e mede **quantos nanossegundos custa cada pixel** no seu
console (bloco `cel sprites` do relatório): é o número que permite comparar o motor de células entre versões.
A última etapa (bloco `DSP thread`) toca quatro roteiros — ticks do DSP e, entre eles, o que o código de som de um
jogo faz com ele — duas vezes: com o DSP dentro do quadro, que tem que dar o resultado do PC, e com o DSP na thread
própria (a opção **Threaded DSP**), que tem que dar o mesmo de novo. É a única parte do diagnóstico que depende das
threads e do processador do console, e por isso só ele pode respondê-la. A mesma etapa mede quanto custa, no seu
console, a CPU esperar por essa thread.
O teste usa as opções padrão e uma pasta temporária, então não mexe nos seus saves nem nas suas configurações.

O resultado aparece na tela e é gravado em `wiiu/OperaU/diagnostic.txt`. A primeira linha do arquivo diz **qual versão
rodou** (`Opera U 0.2.2 core diagnostic`) e a segunda, a hora da compilação. O arquivo é criado assim que o teste começa
(o relatório antigo é apagado) e atualizado antes de cada bateria: enquanto ele diz `result: RUNNING` o teste não
terminou, e a linha `stage:` mostra em que etapa está. Se o app fechar ou travar, esse texto é o que sobra. Envie-o a
quem mantém o projeto, junto com o log (`wiiu/OperaU/logs/operau.log`; o da execução anterior fica em
`operau.old.log`). Se aparecer **REPROVADO**, o procedimento é o mesmo.

## Verificação: o que foi e o que não foi testado

Tudo abaixo foi executado em um servidor Linux. O Wii U é um PowerPC 750-derivado **big-endian**; o núcleo Opera foi
escrito para CPUs little-endian, então a conversão exigiu correções (listadas em
[`third_party/patches/README.md`](third_party/patches/README.md)). Para verificá-las sem o console, o mesmo código C é
compilado para x86 e para PowerPC com o devkitPPC (mesmos flags do Wii U), a versão PowerPC roda no QEMU (`qemu-ppc`,
CPU 750) e os resultados são comparados:

* BIOS embutida: hashes por quadro de vídeo, áudio, DRAM e VRAM idênticos entre x86 e PowerPC; boot a partir de ISO e
  de CHD e repetição de estado salvo também.
* 194 verificações de layout de campos de bits (a causa mais provável de erros em big-endian), com um controle
  negativo que prova que o teste pega o erro.
* Testes diferenciais com entradas aleatórias: interpretador ARM (até 6000 programas por semente), DSP (5 × 5000),
  motor de CELs com CELs compactados (2 × 4000), FIFOs de áudio do CLIO (3 × 3000), motor de matrizes, SPORT, VDL,
  temporizadores do CLIO, um benchmark de laços do ARM e o ARM em todas as classes de instrução e modos (programas
  aleatórios que também acessam o MADAM e o CLIO): dez baterias com os mesmos hashes nas duas arquiteturas. Esses
  testes acharam cinco bugs reais (carry do ROR, um `#include` ausente que deixava os acessadores de memória
  little-endian, uma variável não inicializada no DSP e duas leituras fora do limite nos registradores do MADAM e do
  CLIO), todos corrigidos.
* Otimizações de desempenho **exatas** (temporizadores do CLIO resolvidos em lote e lista compacta de dispositivos do
  XBUS): cerca de 17% menos tempo por quadro no PC, com o hash do boot e os de todas as baterias idênticos nos dois
  processadores (a bateria dos temporizadores foi criada para isso e comprovadamente pega erros: três defeitos
  plantados de propósito mudam o hash).
* Tela de teste de imagem: no PC, o teste automático (`--selftest-video`) lê os pixels reais da tela e confere cada
  barra, rampa e quadrado nas 4 páginas × 6 ordens de canais, nos caminhos de 16 e 32 bits, e uma imagem no formato de
  jogo; com controle negativo (dois defeitos plantados, incluindo vermelho/azul trocados na tabela de 15 bits, são
  pegos).
* Pacote `.wuhb` (`tools/check_wuhb.py`, também no CI): abre o pacote como o Aroma faz e confere o nome com a versão, o
  autor, o ícone, as duas telas de abertura e se o programa lá dentro tem a mesma versão. Ele existe porque até a
  0.2.0 o pacote saía com nome genérico, sem versão e sem ícone sem que nada avisasse; rodado no pacote da 0.2.0, ele
  acusa exatamente esses defeitos.
* Leitura de disco: 14 imagens (ISO, BIN+CUE com setores de 2048 e de 2352 bytes e 11 variantes de CHD: `cdlz`,
  `cdzl`, `cdzs`, LZMA, zlib, zstd, hunks mistos, sem ECC, hunks grandes, com subcódigo) lidas nas duas arquiteturas
  dão exatamente os bytes da fonte (`tools/test_chd_codecs.py`).
* Teste de ponta a ponta no host (`--selftest-run`): abrir jogo, estado salvo, reiniciar, fechar, arquivos inválidos
  (mostram erro e voltam ao menu), diagnóstico e cancelamento do diagnóstico.

**Confirmado pelo usuário no console** (versões anteriores): o app abre e roda, o Diagnóstico do núcleo passa com os
hashes iguais aos do PC, uma BIOS original funciona e jogos iniciam.

**Ainda não verificado**: a correção das cores no console (a causa foi achada lendo o código da porta SDL2 do Wii U, que
trata a textura de 16 bits ARGB1555 com os canais trocados; a correção, uma textura de 32 bits, está testada no PC mas
**precisa do Teste de imagem no console**), o áudio do Wii U além de "toca", o caminho de USB, o menu HOME (ProcUI), a
velocidade em jogos depois das otimizações desta versão, a compatibilidade ampla com jogos, as trilhas de áudio de CD em
FLAC (`cdfl`) em big-endian e os caminhos do motor de matrizes/VDL além do que a BIOS, a simulação dos CELs e os testes
diferenciais exercitam.

## Histórico de versões

O número aparece no canto superior direito do app, no nome do pacote no menu do Aroma, no cabeçalho do
`diagnostic.txt` e na primeira linha de cada log (junto com a hora da compilação).

* **0.4.13** — o ritmo do próprio jogo passa a ser medido, e a velocidade do motor de células vira opção.
  O relato que motivou: na abertura do Super Street Fighter II Turbo o som segue no tempo certo e a imagem
  fica para trás; depois o jogo anda normal. Som no tempo quer dizer que o emulador está entregando os 60
  campos por segundo — é o *jogo* que mostra menos imagens do que campos, e isso se decide dentro da máquina
  emulada, não na velocidade do Wii U. Lá dentro um jogo espera por três coisas, e o `perf.txt` passa a medir
  as três (bloco `the game`):
  * **Imagens por segundo do jogo** (`pictures a second`): quantos campos mostraram um quadro diferente do
    anterior. Aparece também na tela, ao lado dos percentuais (`game 30/s`), com "Mostrar FPS" ligado.
  * **Motor de células ocupado** (`cel engine busy`): depois de desenhar uma lista, o motor emulado se declara
    ocupado por um tempo proporcional ao que desenhou, e o jogo espera. O núcleo usa 9 milhões de pixels por
    segundo; a especificação publicada do 3DO diz de 9 a 16 milhões. Com 9, um jogo que desenha mais de 150 mil
    pixels por campo não consegue mostrar uma imagem por campo — e a música, que o DSP toca no tempo, passa na
    frente. Se a abertura do Street Fighter mostrar esse número perto de 100%, é isso.
  * **Disco** (`disc`): setores lidos por segundo, quanto custou ler e a leitura mais demorada. É o que separa
    CHD de ISO: a leitura acontece na thread da emulação, e uma leitura lenta é uma pausa no jogo.

  **Opção nova: CEL Engine Speed** (Configurações → Opções do núcleo, ou só para um jogo em Opções do jogo):
  9 milhões de pixels por segundo (padrão, o valor do núcleo), 12, 16, ou sem limite (o motor nunca fica
  ocupado, como nas versões antigas do núcleo; alguns jogos então correm demais). No padrão nada muda: os
  hashes de todas as cargas e do boot são os mesmos. Uma bateria nova, `celt`, confere que o tempo ocupado é
  exatamente o da regra em cada velocidade, que a contagem do relatório é esse mesmo tempo, e que a imagem é
  idêntica em todas — a velocidade muda o *quando*, nunca o *quê*. Ela achou um erro na minha contagem (uma
  lista desenhada no ciclo zero não era contada) antes de sair.

  **O `perf.txt` agora é gravado quando o jogo é pausado ou fechado**, com os cinco segundos anteriores. Antes
  ele era gravado a cada vinte segundos e podia ter até vinte segundos de idade: "feche o jogo no meio da cena"
  media outra cena. A gravação periódica continua (é ela que deixa registro quando o jogo trava), mas saiu da
  thread da emulação: gravar dois arquivos no cartão leva dezenas de milissegundos, e eram milissegundos de
  jogo parado. O arquivo diz quanto a última gravação levou.

  **O log também.** O medidor escreve umas nove linhas no log a cada cinco segundos, e o buffer padrão da
  biblioteca C é de um bloco ou dois: cada vez que enchia era uma escrita no cartão, feita pela thread da
  emulação. O log passa a ter um buffer de 32 KB e a ir para o cartão pela mesma thread que grava o relatório
  (a cada vinte segundos) ou quando o jogo é pausado; avisos e erros continuam indo na hora. O `perf.txt`
  mostra quanto escrever no log custou (`the log`): o esperado é uma fração de milissegundo. E a primeira
  execução de todas, quando as pastas ainda não existem, passa a ter log.

  O `logs/operau.log` guarda essas mesmas medidas **da sessão inteira**, uma leva a cada cinco segundos: é o
  arquivo que mostra a abertura e a luta do mesmo jogo, sem precisar pausar na hora certa.
* **0.4.12** — o DSP em thread própria (**Threaded DSP**) deixa de travar o jogo e passa a fazer exatamente o
  que o DSP dentro do quadro faz; e, no caminho, apareceu que **esquerda e direita do som estavam trocadas no
  Wii U**, em todos os jogos e desde a primeira versão.
  * **O jogo que parava em tela preta.** No Yu Yu Hakusho, com a opção ligada, o jogo parava depois de uma luta e
    o console precisava ser reiniciado. O `perf.txt` desse momento mostrou a thread do DSP parada, a emulação a
    109 quadros por segundo e nenhum som. Reproduzi no PC: um programa do DSP que não chega à instrução de dormir
    prendia a thread para sempre. O jogo ficava esperando um DSP que não respondia; o emulador, que acerta o
    passo pelo som, ficava sem passo; e fechar o jogo esperava a thread terminar, o que nunca acontecia. Um jogo
    não escreve programas assim, mas reescreve o programa com o DSP rodando, e a thread — que corre até algumas
    dezenas de ticks atrás da CPU — podia pegá-lo pela metade. Num 3DO de verdade isso custa um tick: o relógio
    de amostras recomeça o programa do início a cada amostra. O interpretador agora faz o mesmo (desiste de uma
    execução depois de 1024 instruções, ou ao sair da memória do programa), e um quadro que não entrega som
    nenhum passa a ser cadenciado pelo relógio, não pelo som.
  * **A thread passa a fazer o que o quadro faz.** Dois defeitos que a leitura do código apontou e os testes
    confirmaram. As interrupções que o DSP gera eram escritas pela thread na mesma palavra que a emulação escreve
    do outro lado, sem proteção: uma podia se perder — e um jogo que espera o fim de um som fica esperando. Agora
    a thread só anota o pedido e é a emulação que levanta a interrupção. E as escritas da CPU no programa do DSP,
    nos FIFOs de áudio, na partida/parada e no semáforo caíam onde a thread estivesse: no meio de um tick, ou
    antes de ticks que ainda iam rodar. Agora cada uma espera a thread terminar o que recebeu, e cai entre os
    mesmos dois ticks em que cairia com o DSP dentro do quadro. Ficam de fora, de propósito, os *knobs* (uma
    palavra cada, escritos o tempo todo) e as leituras que a CPU faz do DSP, que enxergam o DSP alguns ticks
    atrás. E a emulação não se adianta mais que um quadro de ticks em relação à thread: no avanço rápido ela
    entregava ticks mais depressa do que um DSP carregado consegue rodar, sem limite, e o DSP — e o som — ficavam
    segundos para trás.
  * **Esquerda e direita.** O núcleo devolve cada amostra como uma palavra com a esquerda na metade baixa e a
    direita na alta, e a entrega como dois números em sequência. Num PC a metade baixa vem primeiro na memória;
    num PowerPC, a alta. O Wii U tocava a direita na esquerda. O teste novo acusou isso porque compara o som
    valor a valor entre as duas arquiteturas com programas que escrevem coisas diferentes em cada canal — a BIOS
    do teste de boot escreve o mesmo nos dois, então o hash dela nunca viu.
  * **Atraso do som.** A fila de som padrão cai de 80 para 50 ms (Configurações → Áudio → Buffer de áudio; quem
    tinha 80 por ser o padrão antigo passa para 50, quem escolheu outro valor fica com ele). Pela conta dos
    buffers — não é uma medida — o som saía cerca de 95 ms depois da imagem e passa para cerca de 65. Se
    aparecerem estalos durante carregamentos, volte para 80.

  **Como foi conferido.** Uma bateria nova, `dspt`, toca o mesmo roteiro duas vezes numa máquina recém-carregada:
  ticks do DSP e, entre eles, o que o código de som de um jogo faz (reescrever o programa, partir, parar, reiniciar,
  apontar FIFOs, ligar e desligar canais, semáforo, interrupções respondidas). Compara cada amostra de som, o
  estado do DSP, o do CLIO, a memória que o DSP escreveu e o que a CPU leu de volta. Com as proteções no lugar,
  24 roteiros de 185 a 290 mil ticks dão o mesmo dos dois jeitos, e o detector de corridas (ThreadSanitizer) não
  acusa nada nos dez que rodei sob ele. Retirei as proteções uma a uma, 17 ao todo. Quinze mudam o resultado toda
  vez que a bateria roda. As outras duas são corridas de verdade, que dependem do acaso: sem a espera antes do
  reset o resultado mudou em algumas execuções e não em outras (um reset entre dois ticks não altera nada,
  porque todo tick começa com um; só importa o que cai no meio de um), e sem a anotação das interrupções mudou
  em 1 roteiro de 12 numa execução, 4 de 24 em outra e nenhum numa terceira — escritas de fato perdidas na
  palavra de interrupções, num PC. O detector de corridas acusa as duas em todas as vezes. A bateria `dspr` roda
  programas que não terminam, e virou a décima terceira carga do diagnóstico. Recolocando o defeito antigo de
  propósito, o emulador agora fica a 59,9 quadros por segundo onde antes disparava para 316 a 745 no PC.

  **O que só o console responde**, e por isso entrou no diagnóstico: se a thread dá o mesmo resultado com as
  threads e o processador do Wii U (bloco `DSP thread`), e quanto custa cada espera lá. O `perf.txt` ganhou as
  linhas `waited for` (quantas esperas por quadro e quantos milissegundos) e `DSP runs given up on`.

  **O que esta versão não resolve.** A queda de quadros na luta do Yu Yu Hakusho: o único `perf.txt` de luta
  que tenho é da 0.4.8, e o da 0.4.11 foi sobrescrito pela tela preta. E a falta de sincronia na abertura do
  Super Street Fighter II Turbo não tem causa provada: esta versão trata duas possíveis (interrupções perdidas
  com a thread ligada e o atraso do som), e se nenhuma for a verdadeira é o `perf.txt` da abertura que vai dizer
  onde procurar.
* **0.4.11** — o motor de células deixa de refazer a mesma conta. Três mudanças, todas exatas:
  * **Pixel pronto por valor de origem.** Numa célula que não enxerga o frame buffer, tudo o que acontece entre
    os bits lidos da origem e o pixel escrito — decodificador, processador de pixel, projetor — depende só desses
    bits. Uma célula de 4 bits tem 16 valores e milhares de texels, e a conta inteira rodava para cada texel.
    Agora cada valor passa pela conta na primeira vez que aparece e fica guardado; depois disso um texel custa
    a leitura dos bits e uma consulta. Imagens de 16 bits com cores demais para isso valer a pena são detectadas
    nos primeiros 512 texels e voltam ao caminho anterior.
  * **Células misturadas com o fundo** (sombras, transparências, fades — as que leem o frame buffer). Eram as
    mais caras, porque a conta inteira rodava a cada pixel, e são de quase nada a 90% dos pixels conforme o jogo.
    Cada canal da resposta depende só do mesmo canal dos dois pixels, cinco bits cada: uma tabela de 32 × 32. Ela
    é montada a partir de poucos valores (meia palavra PIXC e duas flags), e um jogo mistura de poucas maneiras
    que repete o tempo todo — então as tabelas ficam guardadas de uma célula para a outra e de um frame para o
    outro.
  * **Leitura dos bits e preenchimento.** Ler os bits de cada texel era uma chamada a outro arquivo que buscava
    byte a byte; passou a ser três bytes e um recorte, dentro do laço. E uma célula ampliada preenche o bloco de
    cada texel de uma vez, recortado na borda da tela, em vez de testar pixel por pixel.

  Instruções por pixel no PC, 0.4.10 → 0.4.11: sprite de 4 ou 6 bits em tamanho original 160 → 83; sprite de
  8 bits sombreado por texel (o modo que no Yu Yu Hakusho carrega cerca de 70% dos pixels) 319 → 116; imagem de
  16 bits 251 → 129;
  sprite ampliado 97 → 63; sprite misturado com o fundo 311 → 218; sprite girado 277 → 225. O número do console
  sai do diagnóstico desta versão, que mede esses mesmos oito sprites com a tabela desligada e ligada.

  **Como foi conferido — e uma falha que apareceu.** As baterias de células sorteavam sempre posições
  fracionárias, e o motor só usa o caminho de linha — o do sprite em tamanho original, que é a maior parte do que
  um jogo 2D desenha — quando a posição é um pixel inteiro. Esse caminho nunca tinha sido exercitado por elas, nem
  células saindo pelo topo ou pela esquerda da tela. A bateria nova, `celu`, cobre isso, mais o que um jogo repete
  de uma célula para a outra, e confere também a contagem de pixels do motor. Na primeira execução ela acusou um
  erro meu nesta versão (um quarto lugar onde a conta era feita, que eu não tinha visto), corrigido antes de sair.
  O motor das versões 0.4.9 e 0.4.10 foi passado por ela depois: estava correto. A referência agora é o motor
  **original, sem nenhuma das mudanças deste projeto**: 21 execuções de 2500 células e os oito sprites dão o
  mesmo resultado nele, no 0.4.10 e nesta versão; e esta versão dá o mesmo no x86 e no PowerPC. E para saber se
  as baterias enxergam um
  erro, plantei 26 de propósito no código novo: todos são acusados, e nove deles passam despercebidos pelas duas
  baterias antigas. Nove
  mudanças que não podem alterar nada (numeração de células dando a volta, duas tabelas em vez de 32, quatro
  posições em vez de 1024) de fato não alteram.

  **Sobre a GPU.** Comecei esta versão para a GPU desenhar as células. Lendo o caminho de desenho para levá-lo ao
  shader, a conta fechou contra: o que o shader calcularia por pixel é uma função pura do valor de origem, e a CPU
  resolve isso com uma consulta, sem os 0,18 ms que cada troca de mãos com a GPU custa neste console e sem tirar
  o frame buffer da memória, de onde o resto do 3DO o lê. Um caminho de GPU para as células ficaria mais lento que
  este. A sonda do shader continua no diagnóstico; o `perf.txt` troca o bloco "a GPU poderia desenhá-las" por
  "como o motor as desenhou", que diz quantos pixels ainda passam pela conta longa.
* **0.4.10** — as tabelas do processador de pixel passam a cobrir o modo de escala por texel (`ms == 1`). Elas
  deixavam esse modo de fora porque o multiplicador muda a cada texel, e então cada pixel dele rodava a conta
  inteira; no Yu Yu Hakusho esse modo carrega cerca de 70% dos pixels. Como só existem oito multiplicadores por
  canal, há agora uma tabela por multiplicador, montada na primeira vez que um texel a pede e só depois de a
  célula ter desenhado 64 pixels pelo caminho longo, para que células pequenas não paguem por tabelas que não vão
  usar. É exato — o corpo da tabela é o que já existia, com o multiplicador trocado — e foi conferido contra o
  caminho antigo em 14 execuções de 2500 células, que exercitam esse modo: hashes idênticos.
  Resultado do 0.4.9 no console: o custo por pixel do Yu Yu Hakusho caiu de 276 para 234 ns.
* **0.4.9** — as células que não enxergam o frame buffer deixam de pagar o processador de pixel a cada pixel.
  Lendo o caminho de desenho para levá-lo à GPU, apareceu o motivo de um pixel custar de 90 a 277 ns: os três
  caminhos (linha, escala e arbitrário) liam o frame buffer debaixo de cada pixel e rodavam de novo o processador
  de pixel e o projetor sempre que esse valor mudava — o que, sobre um cenário, é em todo pixel — para chegar
  sempre à mesma resposta, porque nessas células a cor depende só do texel de origem. Agora a cor é calculada uma
  vez por texel e os pixels são apenas escritos. Nos jogos medidos no console essas células são de 46 a 100% das
  desenhadas. É exato por construção, e foi conferido compilando o caminho antigo (`-DOPERA_NO_FB_FREE`) e
  comparando 14 execuções de 2500 células: hashes idênticos. No PC, o motor de células executa 14,9% menos
  instruções na bateria com forma de jogo; o ganho real no console aparece na linha "pixels ... ns each".
  Resultado do teste da thread do DSP no console, com a opção ligada: Yu Yu Hakusho foi de 22,5 para 27,2 fps e
  Samurai Shodown de 40,8 para 58,7, sem nenhuma amostra de som perdida em cinco jogos.
  Corrige também um número que eu rotulei errado no 0.4.8: "ran dry N times since the game started" contava desde
  a abertura do app, somando todos os jogos e menus. Passa a contar só os últimos cinco segundos.
* **0.4.8** — a thread do DSP funcionou no console: no Road Rash ela trabalhou 8,15 ms por frame fora do tempo do
  frame, sem perder amostra e ficando no máximo 33 ticks atrás. Duas coisas ficaram por esclarecer e esta versão
  as mede. O relatório mostrava a thread nos núcleos 0, 1 e 2, mas esse número era acumulado desde o início e não
  dizia onde ela estava rodando agora; passa a valer só para os últimos cinco segundos, e a fixação de núcleo
  agora cede o processador na hora e registra no log se o sistema aceitou. E com um jogo enfim em velocidade
  cheia apareceu atraso entre som e imagem: o `perf.txt` passa a dizer quanto som está esperando para tocar,
  o limite configurado e quantas vezes o buffer secou. Um jogo lento nunca enche o buffer — o som sai picado, mas
  não atrasado — então esse atraso só aparece quando o jogo passa a rodar rápido.
* **0.4.7** — o DSP pode sair do frame. O núcleo original já traz uma opção, desligada por padrão e marcada como
  experimental, que roda o DSP numa thread própria; no Wii U isso significa usar um dos dois núcleos que ficam
  ociosos, e o DSP custa de 5 a 9 ms de cada frame no único núcleo que a emulação usa. Esta versão não liga a
  opção sozinha — ela a torna mensurável e segura de usar: a thread é fixada no núcleo livre (a interface fica no
  1, a emulação no 2, o DSP vai para o 0), presta contas do próprio trabalho, termina o que recebeu antes de um
  estado ser salvo ou carregado, e é encerrada antes de a máquina ser destruída, não depois.
  O `perf.txt` passa a dizer se a thread está ligada, em que núcleo rodou, quantos milissegundos por frame ela
  trabalhou fora do tempo do frame, quantas amostras de som se perderam e o quanto ela chegou a ficar atrás da
  emulação. Sem isso, medir com a opção ligada mostraria o DSP como gratuito e não diria se ele acompanhou.
  O que muda na exatidão: os gráficos não mudam; o instante em que o DSP enxerga o que a CPU escreveu deixa de
  ser idêntico a cada execução. O diagnóstico roda sempre com a opção desligada, então os hashes continuam valendo.
  Para ligar: Configurações → Opções do núcleo → "Threaded DSP" → enabled.
* **0.4.6** — build jogável, sem mudança visual e sem ganho de velocidade ainda: ele mede o que decide se uma
  arquitetura híbrida é possível. A pergunta não é quantas células a GPU poderia desenhar, e sim **como elas estão
  arranjadas**. O frame buffer do 3DO não pode sair da memória da CPU, então células desenhadas pela GPU e pela
  CPU precisam chegar nele na ordem certa, e cada troca de mãos custa a espera medida em 0,178 ms no console. Um
  frame cujas células elegíveis venham em poucos blocos longos precisa de poucas esperas; um que alterne precisa
  de centenas, e a 353 células por frame isso é muito mais que o frame inteiro.
  O `perf.txt` passa a trazer, em três níveis de exigência, quantas células e quantos pixels a GPU poderia tomar,
  quantos blocos por frame eles formam e quanto as esperas custariam. E traz também a pergunta que pode tornar os
  blocos irrelevantes: **quantas listas de células inteiras** a GPU poderia desenhar sozinha. Decidir por lista em
  vez de por célula elimina a mistura — ou a lista vai inteira para a GPU, ou fica inteira na CPU — e aí o frame
  paga uma espera só, a mesma que já paga para o hardware de vídeo ler o frame buffer.
  Traz também os contadores do DSP, que estavam prontos desde o 0.3.9 e ainda não tinham ido para as suas mãos.
* **0.4.5** — **a sonda deu exata.** Zero diferenças em 5120 pixels, nas 20 configurações, pelos dois caminhos de
  textura: a GPU do Wii U calcula o processador de pixel do 3DO bit a bit igual à CPU, incluindo truncamento para
  8 bits com sinal, deslocamento aritmético, o limite de 0 a 31, a tabela PSCALAR e a extensão de sinal. Com a
  entrega de volta medida em 0,178 ms, as duas objeções que podiam matar o caminho de GPU caíram.
  O que isso ainda não responde é o que esta versão mede. Uma passada de tela cheia não é a forma de um motor de
  células: cada célula é um desenho com geometria e ajustes próprios, e os jogos dividem esse trabalho de maneiras
  muito diferentes — o Yu Yu Hakusho desenha cerca de 11 células de ~8000 pixels por frame, o Super Street Fighter
  2 Turbo cerca de 353 de ~220. Muitos desenhos pequenos são justamente onde uma GPU devolve a vantagem. Então o
  diagnóstico passa a cronometrar quatro formas de frame, com uma escrita de registrador por desenho, para
  comparar direto com os 24,55 ms e 9,25 ms que a CPU gasta nesses dois jogos.
* **0.4.4** — com os uniformes chegando, o 0.4.3 finalmente mediu o que estava atrás deles, e três coisas passaram
  de uma vez: **`coords` 0 de 320**, **`table` 0 de 320** e a seleção de modo. Coordenadas, leitura de textura de
  um canal e escolha de caminho estão corretas. Os dois que restaram falhavam por motivos distintos, e os dois
  foram achados pelo próprio relatório.
  O primeiro é ordem de bytes: escrevi `0x0007` na textura de 16 bits e o shader leu `0x0700`. A GPU lê um texel
  de 16 bits na ordem oposta à que um PowerPC escreve. A troca agora é feita no shader, onde custa nada, e não é
  detalhe da sonda: o frame buffer do 3DO guarda pixels de 16 bits na ordem da CPU, então qualquer caminho que um
  dia entregue esses pixels à GPU encontra exatamente o mesmo problema.
  O segundo é erro meu: apliquei o mapa de componentes de uma textura de **um** canal também na de **quatro**, o
  que mandava o verde ler zero sempre. A textura da tabela, que realmente tem um canal, lia perfeitamente com esse
  mapa — foi o contraste entre as duas que denunciou.
* **0.4.3** — achado: `GX2SetPixelUniformReg` com `count = 1` **não escreve nada**. O teste de seis caminhos do
  0.4.2 mediu isso no console sem ambiguidade: as duas rotas que passavam um `vec4` chegaram (`got 42 want 42`,
  `got 43 want 43`) e todas as que passavam uma palavra só deixaram o shader lendo zero. A contagem é em palavras
  mas o hardware escreve registradores inteiros, então um `count` de 1 arredonda para nada. Não era a unidade do
  offset, que foi onde eu procurei duas vezes.
  Agora cada uniforme é escrito como um registrador completo, quatro palavras. Como cada um ocupa um registrador
  só para si (os offsets compilados são 0, 4, 8 … 52), preencher as quatro componentes não atrapalha nada — o
  shader lê a primeira.
  Com os uniformes chegando, tudo o que estava atrás deles passa a significar alguma coisa pela primeira vez: a
  seleção de modo, a leitura das duas texturas, as coordenadas e as oito formas da aritmética. O teste de seis
  caminhos fica no lugar, como guarda contra regressão e como registro de qual rota funciona nesta máquina.
* **0.4.2** — o farol do 0.4.0 estreitou o problema até o osso: **0 de 6400 pixels sem a constante do shader**, ou
  seja, o shader roda e a saída chega ao alvo. E mesmo assim todos os uniformes continuam valendo zero, com
  contagens idênticas às do 0.3.9 — o `GX2SetShaderMode` não era a causa, e a documentação do CafeGLSL explica por
  quê: *"GX2 uses GX2_SHADER_MODE_UNIFORM_REGISTER by default"*. A chamada era redundante.
  Olhando o `.gsh` compilado por dentro, os offsets gravados são 0, 4, 8 … 52 (cada uniforme no seu próprio
  registrador) e o modo é 0, registrador, sem bloco. O que o código do compilador não resolve é em que unidade a
  função do sistema espera esse número, e eu já errei duas vezes deduzindo isso.
  Então esta versão para de deduzir. O shader ganhou um uniforme cujo único trabalho é voltar no canal alfa, onde
  nada mais é escrito, e a sonda escreve nele por **seis caminhos diferentes**, cada um com um valor distinto.
  Qualquer que seja o que chegue, ele se identifica sozinho, sem precisar zerar entre as tentativas. O
  `diagnostic.txt` lista os seis e marca o que funcionou. Se nenhum funcionar, isso também é resposta: os
  uniformes não chegam de jeito nenhum neste caminho, e a saída é mudar para blocos de uniforme.
* **0.4.1** — ícone e telas de abertura com a marca do projeto: um "O" e um "U" entrelaçados com um arco de disco
  atrás, em vermelho, azul e amarelo chapados. Desenho feito para este projeto, sem degradê, porque o ícone é lido
  a 48 pixels no menu do console e o que sobrevive nesse tamanho é contraste, não detalhe. O nome e o número da
  versão continuam no ícone — foi o que permitiu descobrir, lá no 0.2.x, que o console estava abrindo um arquivo
  antigo esquecido no cartão. Nada mais mudou: a sonda de GPU é idêntica à do 0.4.0.
* **0.4.0** — a sonda não acusava erro de aritmética: ela estava calculando com **nada**, e os seus dados do
  0.3.9 provaram isso sem margem. O modo `coords` devolve uma constante escrita dentro do shader, sem ler textura
  nenhuma, e veio zero — logo aquele ramo nunca executou, logo o `u_mode` chegou zerado. Reproduzi a hipótese "a
  saída é identicamente zero" contra as oito formas da aritmética e ela bate exatamente, uma por uma: `negated`
  dando "0 de 320 erradas" não era acerto, é que essa forma espera zero em toda coluna; e os números estranhos
  317 e 274 são precisamente a quantidade de colunas em que a CPU também espera zero. Todos os uniformes chegavam
  em zero.
  A causa é uma exigência documentada do CafeGLSL que eu deixei passar: o GX2 usa **um** modo de uniforme para o
  shader de vértice e o de pixel de cada desenho, e é preciso escolhê-lo antes de desenhar. O shader foi compilado
  para ler uniformes de registrador e o contexto da sonda não estava nesse modo, então toda escrita de registrador
  foi ignorada. Agora `GX2SetShaderMode(GX2_SHADER_MODE_UNIFORM_REGISTER)` é chamado antes dos desenhos.
  Para que esse tipo de engano não volte a se disfarçar de erro de conta, o shader passa a escrever uma constante
  no canal alfa que não depende de uniforme nem de textura. Se ela chegar, o shader rodou e a saída alcançou o
  alvo, e o que estiver zerado está zerado mais acima no caminho. O `diagnostic.txt` reporta essa linha.
* **0.3.9** — o shader estava lendo **zero** das texturas, e a sonda do 0.3.8 provou isso em uma rodada.
  A linha `first differs read source x=0 src=0007 got 00 00 00 want 00 07 00` diz que o valor lido foi zero, e a
  contagem da tabela confirma: 310 de 320 erradas, com as 10 certas sendo exatamente as colunas onde o valor
  esperado também é zero. O `never drawn 0` descartou o resto — o desenho cobriu o alvo inteiro. E como o modo
  "origem" e o modo "tabela" deram contagens diferentes, os uniformes chegam e o shader troca de ramo: o defeito
  está só em levar os dados da textura até a GPU.
  Esta versão ataca as duas causas possíveis de uma vez. Primeira: avisar explicitamente que a CPU escreveu uma
  textura (`GX2Invalidate` com `CPU_TEXTURE`) depois de cada escrita — sem isso a GPU lê memória velha, que é
  exatamente o que zeros parecem. Segunda: os mesmos pixels passam também numa textura comum de 8 bits, com o byte
  alto no vermelho e o baixo no verde, porque textura inteira é o jeito natural de entregar números a um shader mas
  pode não ser lida por esta GPU.
  Além disso o `diagnostic.txt` passa a listar **uma linha por configuração** em vez de só agregados, e há um modo
  novo que não lê textura nenhuma — devolve apenas a coordenada do pixel e uma constante — para separar de vez
  "coordenada errada" de "leitura errada". As oito formas da aritmética rodam duas vezes, uma com cada textura, de
  modo que qualquer que seja o caminho que funcione, a mesma rodada já diz se a conta sobre ele está certa.
  Traz também os contadores do DSP no `perf.txt`: instruções por frame, nanossegundos por instrução, controle
  contra ALU, operandos e escrita de resultado. O tempo da bateria `dsp` do diagnóstico não serve para isso —
  medido com contador de instruções, mais da metade dela é o arcabouço de teste, não o DSP. E o perfil do
  interpretador é achatado (nenhuma linha passa de 0,3%), então o que vale mudar depende do que os jogos executam.
  Os contadores ficam em variáveis locais e são entregues uma vez por execução, atrás de uma condição lida uma só
  vez: 1% do laço, contra os 4% que custava contando sem condição.
* **0.3.8** — a sonda de GPU passa a dizer *onde* erra, e dois erros meus foram corrigidos.
  O 0.3.7 mediu o que importava — a entrega GPU→CPU custa **0,18 ms** e um desenho de tela cheia custa 0,415 ms,
  contra 24,36 ms das células na CPU no Yu Yu Hakusho — mas a comparação de exatidão acusou 2191 de 2560 pixels
  diferentes, e isso não é arredondamento: era defeito meu. A textura de origem tinha 320×1 pixel e o shader a
  lia em 240 linhas; fora da primeira, `texelFetch` não limita o acesso e lê o que estiver na memória. Agora ela
  tem altura completa. O mapa de componentes das texturas de um só canal também estava apontando para canais que
  o formato não tem, e a malha virou faixa de triângulos sem descarte de face, para que o sentido do desenho não
  possa decidir se algo foi desenhado.
  Para não trocar um palpite por outro, a sonda agora separa as três etapas: ela devolve **o valor cru que leu**
  da textura de origem, **o valor que leu** da tabela, e só então a conta — e marca a linha do alvo antes de
  desenhar, de modo que "nada foi desenhado" não possa se passar por erro de aritmética. O `diagnostic.txt` traz
  as três linhas e o primeiro pixel divergente com o que veio e o que era esperado.
* **0.3.7** — o caminho da GPU deixa de ser palpite. Esta versão não acelera nada: ela mede as duas coisas que
  decidem se o motor de células (24,68 dos 45,6 ms de um frame no Yu Yu Hakusho) pode ser desenhado pela GPU.
  - **A matemática.** Os shaders do Wii U normalmente têm de ser escritos no assembly da GPU e montados por uma
    ferramenta de emulador; o CafeGLSL compila GLSL, aqui no PC, e o resultado vai embutido no RPX (nada de
    biblioteca extra no console). O `shaders/pprobe.frag` é uma cópia linha a linha do processador de pixel do
    3DO, em termos do C: truncamento para `int8_t`, deslocamento com propagação de sinal, limite entre 0 e 31. O
    diagnóstico roda oito formas diferentes do processador e compara **todos** os pixels com a CPU fazendo a mesma
    conta. Se bater, a GPU pode fazer o trabalho sem abrir mão da exatidão pela qual o emulador inteiro é testado.
  - **O custo da entrega.** O frame buffer do 3DO não pode sair da memória principal: o ARM lê e escreve nele como
    memória comum, o SPORT o copia com `memcpy` e o hardware de vídeo o lê para montar a imagem. Então a GPU teria
    de devolver cada frame e a CPU teria de esperar. A sonda cronometra um desenho sozinho e depois um desenho mais
    essa espera; a diferença é o preço da entrega. Em 60 fps há 16,7 ms para tudo.
  - A sonda roda no seu próprio contexto de GX2, para que nada que ela ajusta fique guardado no estado do
    renderizador — foi assim que as cores quebraram depois do diagnóstico numa versão anterior.
  - Também corrige a medição das células no `perf.txt`: o formato delas agora é medido na **mesma janela de cinco
    segundos** dos tempos acima dele, e não mais na média desde que o jogo começou. E há um número novo, "reads the
    frame buffer": a fração de células que lê o pixel já gravado. É ela que decide se as células podem ir em lote
    para a GPU, porque ler o destino obriga o desenho a parar e esperar o que veio antes.
* **0.3.6** — o diagnóstico passa a cronometrar cada bateria, e isso conserta um erro de método meu.
  Eu vinha comparando o tempo das células entre versões usando medições tiradas **enquanto um jogo rodava**, e
  elas não são comparáveis: um trecho diferente do mesmo jogo desenha uma mistura de células completamente
  diferente, e isso mexe nos números muito mais do que qualquer otimização. No Yu Yu Hakusho, três medições deram
  24,74, 22,82 e 24,68 ms, com a proporção de células usando AV variando de 13% a 84% — eram cenas diferentes, não
  versões melhores ou piores. As baterias do diagnóstico, ao contrário, fazem exatamente o mesmo trabalho sempre,
  em qualquer versão. Agora cada uma vem com seu tempo no `diagnostic.txt`, e é por aí que o efeito real de uma
  otimização deve ser medido no console.
* **0.3.5** — relatório do disco. Sempre que um jogo é aberto, o app grava `wiiu/OperaU/disc.txt` com o que a
  imagem realmente contém: quantos blocos, se o primeiro setor pôde ser lido, e o cabeçalho de volume que todo
  disco 3DO de verdade tem no primeiro setor (tipo de registro 1, cinco bytes 0x5A, e o comentário e o rótulo do
  próprio disco), além de leituras de prova espalhadas pela imagem. Um jogo que abre e não desenha nada é idêntico,
  na tela, a um jogo que não abriu — e a diferença é justamente entre a imagem e o emulador.
* **0.3.4** — a tabela por célula passa a ser construída só quando um pixel precisa dela.
  A bateria de doze jogos mostrou que muitas células são processadas e **não desenham nada**: 74% delas em um dos
  jogos. A 0.3.2 construía a tabela para todas, inclusive essas, e uma célula que desenha poucos pixels também não
  compensava o custo. Agora a tabela é construída na primeira vez que um pixel a pede, e só a metade de PIXC que
  aquele pixel usa. Na bateria aleatória o motor caiu de 333,3 para 330,2 milhões de instruções; nos jogos com
  muitas células descartadas o ganho é maior. O relatório também passa a trazer quantas células, texels e pixels
  há por quadro, em número absoluto.
* **0.3.3** — um arquivo de medição por jogo. Até aqui, jogar dois jogos na mesma sessão **somava os dois** no mesmo
  `perf.txt`, e a mistura levaria a conclusões erradas sobre como as células são configuradas. Agora os totais são
  zerados quando outro jogo é aberto, e além do `perf.txt` (sempre o último jogo) é gravado um `perf-<jogo>.txt`
  para cada um. Assim dá para medir vários jogos numa sessão só.
* **0.3.2** — a tabela por célula passa a cobrir quase tudo, graças ao segundo jogo medido.
  O `perf.txt` de um jogo diferente mostrou uma forma que a 0.3.1 não cobria: 13% das células usavam AV, 9% tiravam
  a cor 1 do quadro e 7% usavam outro modo de escala. A regra geral é mais simples do que eu tinha escrito: a
  tabela vale sempre que **todos os valores que a indexam vierem da mesma fonte**. Com isso ela passou a cobrir AV
  ligado, a cor 1 vinda do quadro e os modos de escala 2 e 3. A cobertura na bateria aleatória subiu de 5,4% para
  **39,1%** dos pixels, e chega a 100% na bateria com a forma de jogo. O motor caiu mais 3,7% na bateria aleatória
  (346,3 para 333,3 milhões de instruções) e mantém os 13,8% na forma de jogo. 28 comparações contra a versão sem
  o caminho rápido deram todas iguais, no PC e no PowerPC.
* **0.3.1** — o maior ganho de desempenho até agora, e ele veio do seu arquivo `perf.txt`.
  * **O processador de pixels passa a ser pré-calculado por célula.** Os números do jogo real mostraram que quase
    toda célula usa esse processador de um jeito só: AV desligado em 100% delas, `s1` sempre 0, `ms` igual a 0 em
    98% e a cor 2 vindo de qualquer lugar menos do quadro em 98%. Nessa forma, **cada canal de saída depende apenas
    dos cinco bits do mesmo canal do pixel de origem** e de valores fixos para a célula inteira. Então a resposta
    para os 32 valores possíveis é calculada uma vez por célula, e desenhar cada pixel passa a custar três consultas
    a tabela em vez de todo o encadeamento. Medido na carga com a forma do jogo: o trabalho do motor caiu de 148,7
    para 128,2 milhões de instruções, **13,8% a menos**.
  * **Bateria nova: `celg`.** Descobri que a bateria antiga de células sorteia todas as configurações e só produz a
    forma dos jogos reais em 5,4% dos pixels — ou seja, ela mal testaria o caminho rápido acima. A `celg` gera as
    células exatamente como um jogo as usa. O valor de referência dela foi medido com o caminho rápido **desligado**,
    e o caminho rápido reproduz esse valor; além disso, 20 comparações entre as duas versões (10 sementes × 2
    baterias) deram todas iguais, no PC e no PowerPC. São onze baterias agora, e ela também roda no console.
* **0.3.0** — as medidas de desempenho saem agora num arquivo próprio.
  * **`wiiu/OperaU/perf.txt`.** As mesmas informações que já iam para o log passam a ser gravadas também nesse
    arquivo, na mesma pasta do `diagnostic.txt`: quadros por segundo, quanto cada parte do emulador consome e,
    acumulado desde que o jogo abriu, como as células estão configuradas e qual das três rotinas as desenha. Ele é
    reescrito no máximo a cada vinte segundos, para que a própria gravação não atrapalhe a medição. Procurar linha
    dentro do log era trabalhoso e fácil de errar; este arquivo é pequeno e direto.
* **0.2.9** — completa a rodada das células.
  * **Caminho escalado também integrado.** A 0.2.8 integrou o rasterizador do caminho *arbitrário*; este faz o mesmo
    para o caminho *escalado*. Era importante porque eu não sabia qual dos dois os jogos usam: se usarem o
    escalado, a 0.2.8 sozinha não renderia nada no console. Medido: 1% a menos no teste de células inteiro (16,8
    milhões de instruções), com resultado idêntico no PC e no PowerPC.
  * **O log agora diz qual caminho é usado.** Faltava justamente isso na 0.2.8: o medidor passa a registrar como
    cada célula está guardada (compactada, LR ou literal) e qual das três rotinas a desenhou (linha, escalada ou
    arbitrária). É o primeiro dado a olhar antes de otimizar, porque as três custam coisas muito diferentes.
* **0.2.8** — segunda rodada de desempenho, no motor de células (40% do quadro nos seus testes).
  * **Rasterizador integrado.** A rotina que converte cada texel em pixels é chamada 1,4 milhão de vezes no teste de
    células, e quase todo o custo dela é preparação. Os dois pontos de chamada passam o modo de resolução como
    constante, então integrá-la deixa o compilador eliminar oito deslocamentos variáveis e vários desvios: aquele
    caminho caiu de 152,5 para 128,5 milhões de instruções, **16% a menos**.
  * **Estatísticas de células no log.** O medidor passa a registrar, uma vez por célula (custo desprezível), como
    cada uma está configurada: se usa AV, se precisa da correção de preto, de onde vêm as cores e quantos bits por
    pixel. A BIOS quase não desenha células, então **só um jogo de verdade pode dizer** o que vale especializar;
    essas linhas no log são a medição que falta para a próxima otimização.
  * **O que foi tentado e descartado**, para registro: reescrever o processador de pixels com aritmética escalar em
    vez das uniões de bytes (ganho zero no x86 e código maior no PowerPC), integrar o acessador de memória do DSP
    (0,9%) e trocar as divisões do rasterizador por deslocamentos — 98,3% delas são por ±1 ou ±2, e a substituição
    é provadamente exata (120 milhões de comparações), mas custa cerca de 20 instruções para evitar uma divisão,
    o que não compensa. Nenhuma delas entrou.
* **0.2.7** — mapeamento de botões novo e o primeiro ganho de desempenho no interpretador ARM.
  * **Botões (padrão novo).** A do 3DO no **B**, B no **A**, C no **ZL**, L no **Y**, R no **ZR**, P no **X** e X
    (stop) no **+**. Isso deixa os ombros **L e R do Wii U livres**, que é o que o atalho do menu usa. Quem já tinha
    configuração salva recebe o padrão novo automaticamente; quem remapear depois mantém a sua escolha.
  * **Desempenho.** O caso mais comum de todos — operando de registrador sem deslocamento ("LSL #0") — não precisa
    passar pelo deslocador nem reescrever o bit de carry por cima dele mesmo. Esse atalho foi medido com o
    callgrind: **6,4% menos trabalho** na inicialização inteira (8,23 para 7,71 bilhões de instruções), sendo 5,7%
    dentro do interpretador. O resultado continua idêntico ao do interpretador antigo: as dez baterias batem no PC
    e no PowerPC, e 24 comparações extras (12 sementes × 2 baterias de ARM, 4000 testes cada) contra o binário da
    versão anterior deram todas iguais.
* **0.2.6** — conserta dois problemas que a 0.2.5 trouxe, achados no console:
  * **Imagem azulada.** A ampliação em duas etapas da 0.2.5 desenhava numa textura no formato ARGB8888. O Wii U
    guarda todo formato de 32 bits na mesma superfície e **reordena os canais na leitura**; a escrita ignora esse
    reordenamento, então a imagem voltava com os canais girados. A textura passou a usar o formato nativo do
    desenhador. Além disso, o app agora **confere as cores em tempo de execução**: ele desenha quatro cores
    conhecidas por esse mesmo caminho e lê de volta; se não baterem, volta sozinho para a ampliação em uma etapa.
    Assim um erro de palpite meu custa um pouco de nitidez, nunca a cor da imagem.
  * **Botão HOME.** Ele não é um botão de controle: quem abre aquele menu sobre o app é o próprio console. O app
    passa a desligar esse menu (`OSEnableHomeButtonMenu`), então o HOME não faz mais nada. O menu do Opera U é
    **L + R**, e para sair use "Sair" no próprio menu.
* **0.2.5** — três correções vindas de testes no console:
  * **Cores erradas depois do diagnóstico.** A bateria de vídeo do diagnóstico reconfigurava o processador de vídeo
    do 3DO e o deixava no último formato que usou; o núcleo só aplica esse formato uma vez, na inicialização, então
    o jogo seguinte era desenhado em um formato e lido em outro. Era o que fazia as cores voltarem a errar depois do
    diagnóstico (e o segundo diagnóstico sair "reprovado"), até fechar e reabrir o app. O formato passou a ser
    reafirmado a cada carregamento, e um teste novo (`--selftest-diagstate`) prova que o diagnóstico não deixa mais
    estado para trás.
  * **Botão HOME.** Ele não abre mais o menu do app: HOME é do console e abre o menu do próprio Wii U. O menu do
    Opera U continua em **L + R** (ou **−** e **+** juntos).
  * **Esticar na tela (16:9) sem perder nitidez.** A imagem passa a ser ampliada em duas etapas: primeiro por um
    número inteiro, sem filtro nenhum, e só depois ajustada ao destino. Em 320×240 numa tela de 1280×720 a primeira
    etapa já cai exata (4× e 3×), então o resultado é pixel a pixel. Um teste lê a tela e exige que nenhum pixel
    seja mistura de dois; com o caminho antigo, 500 de 500 pixels conferidos eram misturas.
* **0.2.4** — **corrige o ícone**, que impedia o console de reconhecer o app ("aplicativo não reconhecido", com
  interrogação). As imagens do pacote (ícone e telas de abertura) saíam sem o rodapé de 26 bytes do formato TGA 2.0,
  que o leitor do menu do Wii U exige; a ferramenta oficial de empacotamento o escreve através da biblioteca
  FreeImage, e a versão compilada aqui sem essa biblioteca não escrevia (e ainda cortava o fim do arquivo). Agora o
  ícone gerado é idêntico em estrutura ao ícone padrão do próprio Aroma, e `tools/check_wuhb.py` passou a exigir o
  rodapé, de modo que o erro não volta despercebido. Também existe `make NOART=1`, que monta o mesmo programa sem
  ícone nem telas de abertura.
* **0.2.3** — a versão aparece **no ícone e na tela de abertura** (antes mesmo de o app carregar). Ao iniciar, o app
  grava `wiiu/OperaU/version.txt` (qual programa rodou por último) e procura cópias do Opera U em `wiiu/apps`: se
  houver mais de uma, avisa na tela e lista os arquivos, porque cada cópia vira um item no menu do Aroma e a antiga
  continua abrindo a versão antiga.
* **0.2.2** — não deixa dúvida sobre qual versão está rodando: a versão e a hora da compilação (UTC) aparecem em
  "Ajuda e créditos", na tela de progresso do diagnóstico, na primeira linha do log e no `diagnostic.txt`. O
  diagnóstico agora **grava o `diagnostic.txt` assim que começa** (apagando qualquer relatório antigo, que podia ser
  confundido com o resultado da versão nova) e **antes de cada teste**, com o texto `RUNNING` e a etapa atual: se o app
  fechar ou travar no meio, o arquivo mostra a versão que rodou e onde parou. O log é gravado linha a linha durante o
  diagnóstico, e um diagnóstico cancelado também deixa seu relatório (`result: cancelled`).
* **0.2.1** — o pacote `.wuhb` agora leva o nome **"Opera U 0.2.1"**, o ícone e as telas de abertura (até a 0.2.0 saía
  com o nome padrão "OperaU", autor "Built with devkitPPC & wut", sem ícone e sem versão). Duas leituras fora do limite
  nos registradores do MADAM e do CLIO foram corrigidas (podiam derrubar o app se um jogo lesse esses endereços). Novo
  teste do ARM em todas as classes de instrução, que também roda no diagnóstico do console.
* **0.2.0** — cores corrigidas (textura de 32 bits), Teste de imagem, medidor de desempenho, temporizadores ~17% mais
  rápidos.
* **0.1.0** — primeira versão.

## Compilar

Wii U (precisa do [devkitPro](https://devkitpro.org) com devkitPPC, wut e a porta SDL2 do Wii U):

```sh
export DEVKITPRO=/opt/devkitpro DEVKITPPC=/opt/devkitpro/devkitPPC
export PATH=$DEVKITPRO/portlibs/wiiu/bin:$DEVKITPRO/tools/bin:$DEVKITPPC/bin:$PATH
make -j4          # gera OperaU.wuhb (e OperaU.rpx / OperaU.elf)
make NOART=1 -j4  # o mesmo programa sem ícone nem telas de abertura (para testar se o console
                  # recusa a arte do pacote, e não o programa)
```

PC (Linux; SDL2 instalado), para os testes automáticos:

```sh
make -f Makefile.host -j4
export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy OPERAU_HOME=$(mktemp -d)
./build-host/operau-host --selftest-core        # boot da BIOS, estado salvo, hash contra a referência x86
./build-host/operau-host --selftest-run         # aplicativo completo, incluindo o diagnóstico
./build-host/operau-host --selftest-ui DIR      # capturas de todas as telas em DIR
```

A simulação PowerPC (layout de campos de bits, testes diferenciais, leitura de discos) está descrita em
[`tools/ppcsim/README.md`](tools/ppcsim/README.md). A pasta `.github/workflows` tem um fluxo de CI que compila o
`.wuhb` e roda os testes do host (escrito, mas não executado no ambiente onde o projeto foi feito).

Nota sobre o wuhbtool: o `wuhbtool` usado na compilação aceita TGA sem compressão; `tools/wut-tools-tga-only.patch` (que também escreve o rodapé do TGA 2.0 exigido pelo menu do Wii U)
mostra a pequena alteração feita no wut-tools para compilar sem FreeImage. No devkitPro oficial isso não é necessário.

## Estrutura

```
src/                 front-end (app, ui, vídeo, áudio, entrada, sessão, configuração, testes)
third_party/opera-libretro/   núcleo Opera (libretro) com o patch big-endian de third_party/patches/
third_party/stb/     stb_truetype (fontes)
assets/              ícone, telas de abertura, fonte DejaVu Sans
shaders/             shaders GLSL, o .gsh compilado pelo CafeGLSL e o C gerado que o RPX carrega
tools/               geradores de assets e de imagens de teste, verificador do pacote .wuhb, harness PowerPC, patch do wut-tools
mk/opera_core.mk     lista de fontes e flags do núcleo (compartilhada por Wii U e host)
Makefile             compilação Wii U (.wuhb)       Makefile.host   compilação para PC (testes)
```

## Licenças

O núcleo Opera/FreeDO é licenciado sob **LGPL modificada**: o uso não comercial é permitido com os créditos completos;
o uso comercial é proibido sem aprovação dos donos. Por isso este aplicativo é gratuito e **somente para uso não
comercial**. O Opera Boot embutido é GPL-2.0. O código do front-end está sob a licença MIT (veja `LICENSE`), mas o
conjunto distribuído (o `.wuhb`) segue as condições do núcleo. Créditos, avisos e textos completos: [`NOTICE.md`](NOTICE.md)
e a pasta [`licenses/`](licenses/). 3DO é marca de seus respectivos donos; este projeto não é afiliado a eles.
