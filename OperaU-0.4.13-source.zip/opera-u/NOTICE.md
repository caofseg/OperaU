# Notices, credits and licenses

*(Resumo em português: o aplicativo contém o núcleo Opera/FreeDO, licenciado sob LGPL modificada — uso não comercial
permitido com os créditos completos, uso comercial proibido sem aprovação dos donos — e a BIOS livre Opera Boot, GPL-2.0.
Não há BIOS originais nem jogos neste pacote. Os textos completos das licenças estão na pasta `licenses/`.)*

Opera U is made of the pieces below. The complete license texts are in the [`licenses/`](licenses/) folder.

**Not included in this package:** no 3DO BIOS dump of any manufacturer, no font ROM and no game. Users must supply
their own images of discs they own.

## 1. Opera / 4DO / FreeDO emulation core — modified LGPL, non-commercial use only

* Location: `third_party/opera-libretro/` (upstream: <https://github.com/libretro/opera-libretro>, commit
  `54fe4f3754e9b69c83ff50b5def5d6c60fef06ce`, see `UPSTREAM.txt`), linked statically into the application.
* Opera is a libretro core derived from 4DO, itself derived from **FreeDO** (<http://www.freedo.org>, "the first working
  3DO multiplayer emulator"). FreeDO project authors: **Alexander Troosh, Maxim Grishin, Allen Wright, John Sammons,
  Felix Lazarev**. Credit also goes to the 4DO project and to the contributors of the libretro Opera core.
* License: *"The FreeDO licensed under modified GNU LGPL, with following notes:*
  * *The owners and original authors of the FreeDO have full right to develop closed source derivative work.*
  * *Any non-commercial uses of the FreeDO sources or any knowledge obtained by studying or reverse engineering of the
    sources, or any other material published by FreeDO have to be accompanied with full credits.*
  * *Any commercial uses of FreeDO sources or any knowledge obtained by studying or reverse engineering of the sources,
    or any other material published by FreeDO is strictly forbidden without owners approval.*

  *The above notes are taking precedence over GNU LGPL in conflicting situations."*
  (verbatim from the headers of the source files; the GNU LGPL is in [`licenses/LGPL-2.1.txt`](licenses/LGPL-2.1.txt)).
* **Consequence for this project: it is free of charge and for non-commercial use only. Do not sell it, bundle it in a
  paid product or use it commercially without the approval of the FreeDO owners.** Any redistribution must keep these
  credits.
* **Local modifications.** Six files of the core were changed to run correctly on the Wii U's big-endian PowerPC CPU and
  to remove two undefined-behaviour cases (details, rationale and verification in
  [`third_party/patches/README.md`](third_party/patches/README.md); the patch itself is
  `third_party/patches/0001-opera-libretro-big-endian-and-portability.patch`). The changed files are
  `libopera/opera_arm.c`, `opera_dsp.c`, `opera_madam.c`, `opera_mem.h`, `opera_vdlp.c` and `opera_vdlp_i.h`; each change
  is marked in the source as a local modification. The complete source of the application and of the core is
  provided, so anyone can rebuild and relink it (see the build instructions in the README).

## 2. Opera Boot (built-in BIOS) — GPL-2.0-only

* The core embeds a compressed copy of **Opera Boot**, a free replacement 3DO boot ROM
  (`third_party/opera-libretro/opera_boot.h`, 131072 bytes, SHA-256
  `6cbd0664c36e64c315b699b43dfc27c176597ef8f393279f199986fa5b6ba3bb`).
* Project and **corresponding source code**: <https://github.com/trapexit/opera-boot> (maintained by the GitHub user
  trapexit and contributors). License: GNU General Public License version 2 only ([`licenses/GPL-2.0.txt`](licenses/GPL-2.0.txt)).
* It is a separate program that only runs inside the emulated 3DO; it is shipped as data and is not linked with the
  application's code. Anyone who receives this package may obtain its source from the address above.

## 3. libretro-common — MIT

* Location: `third_party/opera-libretro/libretro-common/`. Copyright (C) 2010–2026 The RetroArch team
  ([`licenses/libretro-common-MIT.txt`](licenses/libretro-common-MIT.txt)). It includes the CHD reader used for disc
  images (`rchd.c` and its inflate/LZMA/zstd/FLAC decoders). Files that carry their own notice keep it: `rflac.c` is a
  fork of dr_flac by David Reid (public domain or MIT-0) and `r7z_lzma.c` derives from the public-domain LZMA SDK by
  Igor Pavlov.

## 4. SDL2 (Wii U port) — zlib license

* Linked statically from the devkitPro Wii U SDL2 port (<https://github.com/devkitPro/SDL>). Copyright (C) 1997–2025
  Sam Lantinga and contributors, with the Wii U port by the devkitPro and Wii U homebrew community
  ([`licenses/SDL2-zlib.txt`](licenses/SDL2-zlib.txt)).

## 5. wut (Wii U Toolchain) — zlib-style license

* Libraries and headers linked into the application: <https://github.com/devkitPro/wut>. Copyright (c) 2015–present
  devkitPro, wut Authors ([`licenses/wut-zlib.txt`](licenses/wut-zlib.txt)).

## 6. Build tools (not part of the distributed application)

* **devkitPPC** (GCC, binutils, newlib) from [devkitPro](https://devkitpro.org). The compiler runtime libraries linked into
  the program are under the GCC Runtime Library Exception; newlib is under BSD-style licenses.
* **wut-tools** (`elf2rpl`, `wuhbtool`): GPL-2.0 (<https://github.com/devkitPro/wut-tools>, a build tool only; its output
  is not a derivative work of it). `tools/wut-tools-tga-only.patch` is a small patch for that tool and is distributed under
  the same GPL-2.0 ([`licenses/GPL-2.0.txt`](licenses/GPL-2.0.txt)).
* **Aroma** (<https://github.com/wiiu-env/Aroma>) is the homebrew environment that loads the `.wuhb`; the `.wuhb` format
  and loader are by Maschell and the wiiu-env contributors. Nothing from Aroma is included here.

## 7. Fonts and image libraries

* **stb_truetype** by Sean Barrett (<https://github.com/nothings/stb>), MIT or public domain
  ([`licenses/stb_truetype.txt`](licenses/stb_truetype.txt)), in `third_party/stb/`.
* **DejaVu Sans** (`assets/DejaVuSans.ttf`): Bitstream Vera license with public-domain DejaVu changes
  ([`licenses/DejaVu-fonts.txt`](licenses/DejaVu-fonts.txt)).

## 8. The Opera U front end — MIT

* Everything under `src/`, `tools/`, `mk/`, the Makefiles, the CI workflow and the documentation is MIT-licensed
  ([`LICENSE`](LICENSE)). The compiled `OperaU.wuhb` contains the core from item 1 and is therefore subject to its
  non-commercial condition.
* The icon and splash images in `assets/` were generated by `tools/make_assets.py` for this project.

## Trademarks

3DO and related names are trademarks of their respective owners. This project is not affiliated with, endorsed by or
sponsored by them, by Nintendo, or by any of the projects named above.
