/*
 * Application shell: start-up, the main loop (one app_frame() per displayed
 * frame), dispatch of menu actions and hotkeys, and tear-down.
 *
 * main.c is a thin wrapper; the headless self tests (selftest.c) drive the
 * very same functions.
 */
#ifndef OPERAU_APP_H
#define OPERAU_APP_H

#include "common.h"
#include "ui.h"

bool app_init(void);
/* Runs one iteration of the main loop; returns false once the app should
 * exit (HOME menu "Close", Exit entry, window closed). */
bool app_frame(void);
void app_shutdown(void);

/* Same code path the menu uses; also called by the self tests. */
void app_dispatch(const ui_action_t *a);
/* Same code path the hotkeys use (HK_* flags from input.h). */
void app_hotkeys(unsigned hk);

typedef enum {
    APP_HOME = 0,   /* main menu, no game */
    APP_PLAYING,    /* game running, no menu */
    APP_PAUSED,     /* game loaded, pause menu on top */
    APP_DIAG,       /* core diagnostic running on its worker thread */
    APP_TESTPAT,    /* picture test (colour bars, geometry) */
} app_mode_t;
app_mode_t app_mode(void);

#endif
