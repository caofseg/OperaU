#include "log.h"
#include "platform.h"

#include <stdarg.h>
#include <time.h>
#include <unistd.h>

#ifdef __WIIU__
#include <whb/log.h>
#include <whb/log_udp.h>
#endif

static FILE *g_file;
static log_level_t g_level = LOG_INFO;
static bool g_udp;
static uint32_t g_sync; /* atomic: flush every line */

/*
 * The log's own buffer. The C library's default is a block or two, and the performance report alone writes more
 * than that every five seconds - from the emulation thread, where each time the buffer fills is a write to the
 * card and a game standing still while it lasts. With this much room the lines of twenty seconds fit several
 * times over, and the card is written by whoever calls log_flush(): the thread that writes the performance
 * report (perf.c), or the emulation thread when the game is paused.
 */
static char g_iobuf[32768];

/* What writing lines cost their callers, for the performance report: microseconds since last asked, and the
 * longest single line. Atomic; lines can come from any thread. */
static uint32_t g_cost_us, g_cost_max_us;

void log_cost_take(uint32_t *total_us, uint32_t *longest_us)
{
    *total_us = __atomic_exchange_n(&g_cost_us, 0u, __ATOMIC_ACQ_REL);
    *longest_us = __atomic_exchange_n(&g_cost_max_us, 0u, __ATOMIC_ACQ_REL);
}

static const char *const k_tag[] = {"D", "I", "W", "E"};

void log_set_level(log_level_t lvl)
{
    g_level = lvl;
}

void log_set_udp(bool enable)
{
#ifdef __WIIU__
    if (enable && !g_udp)
        WHBLogUdpInit();
    else if (!enable && g_udp)
        WHBLogUdpDeinit();
#endif
    g_udp = enable;
}

void log_open(const char *data_dir)
{
    char dir[512], path[600], old[600];

    if (g_file || !data_dir)
        return;
    snprintf(dir, sizeof(dir), "%s/logs", data_dir);
    snprintf(path, sizeof(path), "%s/operau.log", dir);
    snprintf(old, sizeof(old), "%s/operau.old.log", dir);
    platform_mkdirs(dir); /* the very first start, when nothing has made the folders yet, used to go unlogged */
    /* keep one previous run for post-mortem debugging */
    remove(old);
    rename(path, old);
    g_file = fopen(path, "w");
    if (g_file)
        setvbuf(g_file, g_iobuf, _IOFBF, sizeof(g_iobuf));
}

void log_flush(void)
{
    if (!g_file)
        return;
    fflush(g_file);
#ifdef __WIIU__
    fsync(fileno(g_file)); /* hand the data to the card, not just to the file system's cache */
#endif
}

void log_set_sync(bool on)
{
    __atomic_store_n(&g_sync, on ? 1u : 0u, __ATOMIC_RELEASE);
    if (on)
        log_flush();
}

void log_close(void)
{
    if (g_file) {
        fclose(g_file);
        g_file = NULL;
    }
#ifdef __WIIU__
    if (g_udp) {
        WHBLogUdpDeinit();
        g_udp = false;
    }
#endif
}

void log_write(log_level_t lvl, const char *fmt, ...)
{
    char msg[768];
    va_list ap;
    uint64_t t0;
    uint32_t dt, longest;

    if (lvl < g_level)
        return;
    t0 = platform_time_us();
    va_start(ap, fmt);
    vsnprintf(msg, sizeof(msg), fmt, ap);
    va_end(ap);

    /* strip trailing newlines (cores usually add their own) */
    size_t n = strlen(msg);
    while (n && (msg[n - 1] == '\n' || msg[n - 1] == '\r'))
        msg[--n] = '\0';

    fprintf(stdout, "[%s] %s\n", k_tag[lvl], msg);
    if (g_file) {
        fprintf(g_file, "[%s] %s\n", k_tag[lvl], msg);
        /* errors are flushed immediately so they survive a crash (and every line while sync mode is on) */
        if (lvl >= LOG_WARN || __atomic_load_n(&g_sync, __ATOMIC_ACQUIRE))
            fflush(g_file);
    }
#ifdef __WIIU__
    if (g_udp)
        WHBLogPrintf("[%s] %s", k_tag[lvl], msg);
#endif
    dt = (uint32_t)(platform_time_us() - t0);
    __atomic_fetch_add(&g_cost_us, dt, __ATOMIC_RELAXED);
    longest = __atomic_load_n(&g_cost_max_us, __ATOMIC_RELAXED);
    while (dt > longest && !__atomic_compare_exchange_n(&g_cost_max_us, &longest, dt, true, __ATOMIC_RELAXED, __ATOMIC_RELAXED))
        ;
}
