/*
 * Audio output: SDL device at 48 kHz, lock-free ring buffer, cubic resampler
 * from the core's 44.1 kHz. The audio clock paces the emulation (see
 * audio_wait_for_room), which keeps video, sound and game speed in step.
 */
#ifndef OPERAU_AUDIO_H
#define OPERAU_AUDIO_H

#include "common.h"

bool audio_init(int latency_ms);
void audio_shutdown(void);
bool audio_available(void);        /* false when no device could be opened */

void audio_set_input_rate(double hz);
void audio_set_volume(int percent);   /* 0..100 */
void audio_set_latency(int ms);

/* Emulation thread: resamples and queues `n` stereo frames. Returns n. */
size_t audio_push(const int16_t *frames, size_t n);

/* Frames waiting to be played (output rate) and the level we try to hold. */
int audio_buffered_frames(void);
int audio_target_frames(void);
/* Blocks (sleeping in 1 ms steps, at most max_ms) until the buffer dropped
 * below the target. Returns false if it gave up waiting. */
bool audio_wait_for_room(int max_ms);

void audio_pause(bool paused);
void audio_flush(void);
unsigned audio_underruns(void);

#endif
