/*
  www.freedo.org
  The first working 3DO multiplayer emulator.

  The FreeDO licensed under modified GNU LGPL, with following notes:

  *   The owners and original authors of the FreeDO have full right to
  *   develop closed source derivative work.

  *   Any non-commercial uses of the FreeDO sources or any knowledge
  *   obtained by studying or reverse engineering of the sources, or
  *   any other material published by FreeDO have to be accompanied
  *   with full credits.

  *   Any commercial uses of FreeDO sources or any knowledge obtained
  *   by studying or reverse engineering of the sources, or any other
  *   material published by FreeDO is strictly forbidden without
  *   owners approval.

  The above notes are taking precedence over GNU LGPL in conflicting
  situations.

  Project authors:
  *  Alexander Troosh
  *  Maxim Grishin
  *  Allen Wright
  *  John Sammons
  *  Felix Lazarev
  */

#include "boolean.h"
#include "endianness.h"
#include "flags.h"
#include "inline.h"
#include "opera_arm.h"
#include "opera_bitop.h"
#include "opera_clio.h"
#include "opera_clock.h"
#include "opera_core.h"
#include "opera_madam.h"
#include "opera_mem.h"
#include "opera_pbus.h"
#include "opera_prof.h"
#include "opera_state.h"
#include "opera_vdlp.h"

#include <assert.h>
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

/* Local modification for OperaU: for the rare branch of something that runs once per texel or per pixel, so that
   the common branch is what gets compiled into the loop. */
#if defined(__GNUC__)
#define OPERA_NOINLINE __attribute__((noinline))
#else
#define OPERA_NOINLINE
#endif

static struct BitReaderBig bitoper;

#define MakeRGB15(r,g,b)  (((uint32_t)(r)<<10)|((uint32_t)(g)<<5)|(uint32_t)(b))
#define RGB15_BLACK       MakeRGB15(0,0,0)
#define RGB15_NEAR_BLACK  MakeRGB15(1,0,0)
#define RGB15_MAGENTA     MakeRGB15(0x1b,0,0x1b)
#define IS_RGB15_BLACK(P) (((P)&0x7FFF) == RGB15_BLACK)

/* === CCB control word flags === */
#define CCB_SKIP        0x80000000
#define CCB_LAST        0x40000000
#define CCB_NPABS       0x20000000
#define CCB_SPABS       0x10000000
#define CCB_PPABS       0x08000000
#define CCB_LDSIZE      0x04000000
#define CCB_LDPRS       0x02000000
#define CCB_LDPPMP      0x01000000
#define CCB_LDPLUT      0x00800000
#define CCB_CCBPRE      0x00400000
#define CCB_YOXY        0x00200000
#define CCB_ACSC        0x00100000
#define CCB_ALSC        0x00080000
#define CCB_ACW         0x00040000
#define CCB_ACCW        0x00020000
#define CCB_TWD         0x00010000
#define CCB_LCE         0x00008000
#define CCB_ACE         0x00004000
#define CCB_reserved13  0x00002000
#define CCB_MARIA       0x00001000
#define CCB_PXOR        0x00000800
#define CCB_USEAV       0x00000400
#define CCB_PACKED      0x00000200
#define CCB_POVER_MASK  0x00000180
#define CCB_PLUTPOS     0x00000040
#define CCB_BGND        0x00000020
#define CCB_NOBLK       0x00000010
#define CCB_PLUTA_MASK  0x0000000F

#define CCB_POVER_SHIFT  7
#define CCB_PLUTA_SHIFT  0

#define PMODE_PDC   ((0x00000000)<<CCB_POVER_SHIFT) /* Normal */
#define PMODE_ZERO  ((0x00000002)<<CCB_POVER_SHIFT)
#define PMODE_ONE   ((0x00000003)<<CCB_POVER_SHIFT)

/* === CECONTROL flags === */
#define B15POS_MASK   0xC0000000
#define B0POS_MASK    0x30000000
#define SWAPHV        0x08000000
#define ASCALL        0x04000000
#define CECONTROL_u25 0x02000000
#define CFBDSUB       0x01000000
#define CFBDLSB_MASK  0x00C00000
#define PDCLSB_MASK   0x00300000

#define B15POS_SHIFT  30
#define B0POS_SHIFT   28
#define CFBD_SHIFT    22
#define PDCLSB_SHIFT  20

/* B15POS_MASK definitions */
#define B15POS_0    0x00000000
#define B15POS_1    0x40000000
#define B15POS_PDC  0xC0000000

/* B0POS_MASK definitions */
#define B0POS_0     0x00000000
#define B0POS_1     0x10000000
#define B0POS_PPMP  0x20000000
#define B0POS_PIXC  B0POS_PPMP
#define B0POS_PDC   0x30000000

/* CFBDLSB_MASK definitions */
#define CFBDLSB_0      0x00000000
#define CFBDLSB_CFBD0  0x00400000
#define CFBDLSB_CFBD4  0x00800000
#define CFBDLSB_CFBD5  0x00C00000

/* PDCLSB_MASK definitions */
#define PDCLSB_0     0x00000000
#define PDCLSB_PDC0  0x00100000
#define PDCLSB_PDC4  0x00200000
#define PDCLSB_PDC5  0x00300000

/* === Cel first preamble word flags === */
#define PRE0_LITERAL    0x80000000
#define PRE0_BGND       0x40000000
#define PREO_reservedA  0x30000000
#define PRE0_SKIPX_MASK 0x0F000000
#define PREO_reservedB  0x00FF0000
#define PRE0_VCNT_MASK  0x0000FFC0
#define PREO_reservedC  0x00000020
#define PRE0_LINEAR     0x00000010
#define PRE0_REP8       0x00000008
#define PRE0_BPP_MASK   0x00000007

#define PRE0_SKIPX_SHIFT 24
#define PRE0_VCNT_SHIFT  6
#define PRE0_BPP_SHIFT   0

/* PRE0_BPP_MASK definitions */
#define PRE0_BPP_RESERVED_0 0x00000000
#define PRE0_BPP_1          0x00000001
#define PRE0_BPP_2          0x00000002
#define PRE0_BPP_4          0x00000003
#define PRE0_BPP_6          0x00000004
#define PRE0_BPP_8          0x00000005
#define PRE0_BPP_16         0x00000006
#define PRE0_BPP_RESERVED_7 0x00000007

#define PRE0_SKIPX(pre0_) (((pre0_) & PRE0_SKIPX_MASK) >> PRE0_SKIPX_SHIFT)

/* Subtract this value from the actual vertical source line count */
#define PRE0_VCNT_PREFETCH    1

/* === Cel second preamble word flags === */
#define PRE1_WOFFSET8_MASK   0xFF000000
#define PRE1_WOFFSET10_MASK  0x03FF0000
#define PRE1_NOSWAP          0x00004000
#define PRE1_TLLSB_MASK      0x00003000
#define PRE1_LRFORM          0x00000800
#define PRE1_TLHPCNT_MASK    0x000007FF

#define PRE1_WOFFSET8_SHIFT   24
#define PRE1_WOFFSET10_SHIFT  16
#define PRE1_TLLSB_SHIFT      12
#define PRE1_TLHPCNT_SHIFT    0

#define PRE1_TLLSB_0     0x00000000
#define PRE1_TLLSB_PDC0  0x00001000 /* Normal */
#define PRE1_TLLSB_PDC4  0x00002000
#define PRE1_TLLSB_PDC5  0x00003000

/* Subtract this value from the actual word offset */
#define PRE1_WOFFSET_PREFETCH 2
/* Subtract this value from the actual pixel count */
#define PRE1_TLHPCNT_PREFETCH 1

/* === Packed cel data control tokens === */
#define PACK_EOL          0x00000000
#define PACK_LITERAL      0x00000001
#define PACK_TRANSPARENT  0x00000002
#define PACK_PACKED       0x00000003

#define PPMP_0_SHIFT 0
#define PPMP_1_SHIFT 16

#define PPMPC_1S_MASK  0x00008000
#define PPMPC_MS_MASK  0x00006000
#define PPMPC_MF_MASK  0x00001C00
#define PPMPC_SF_MASK  0x00000300
#define PPMPC_2S_MASK  0x000000C0
#define PPMPC_AV_MASK  0x0000003E
#define PPMPC_2D_MASK  0x00000001

#define PPMPC_MS_SHIFT  13
#define PPMPC_MF_SHIFT  10
#define PPMPC_SF_SHIFT  8
#define PPMPC_2S_SHIFT  6
#define PPMPC_AV_SHIFT  1

/* PPMPC_1S_MASK definitions */
#define PPMPC_1S_PDC   0x00000000
#define PPMPC_1S_CFBD  0x00008000

/* PPMPC_MS_MASK definitions */
#define PPMPC_MS_CCB         0x00000000
#define PPMPC_MS_PIN         0x00002000
#define PPMPC_MS_PDC         0x00004000
#define PPMPC_MS_PDC_MFONLY  0x00006000

/* PPMPC_MF_MASK definitions */
#define PPMPC_MF_1  0x00000000
#define PPMPC_MF_2  0x00000400
#define PPMPC_MF_3  0x00000800
#define PPMPC_MF_4  0x00000C00
#define PPMPC_MF_5  0x00001000
#define PPMPC_MF_6  0x00001400
#define PPMPC_MF_7  0x00001800
#define PPMPC_MF_8  0x00001C00

/* PPMPC_SF_MASK definitions */
#define PPMPC_SF_2   0x00000100
#define PPMPC_SF_4   0x00000200
#define PPMPC_SF_8   0x00000300
#define PPMPC_SF_16  0x00000000

/* PPMPC_2S_MASK definitions */
#define PPMPC_2S_0     0x00000000
#define PPMPC_2S_CCB   0x00000040
#define PPMPC_2S_CFBD  0x00000080
#define PPMPC_2S_PDC   0x000000C0

/* PPMPC_2D_MASK definitions */
#define PPMPC_2D_1  0x00000000
#define PPMPC_2D_2  0x00000001

#define ALIGNED_24BIT_MASK (0x00FFFFFFu & ~3u)

#pragma pack(push,1)

/*
  Bit-field layout.

  These structs decode pixel words and PIXC halves that live in the low
  bits of the 32-bit `raw` member of the unions below. They are written
  for the little-endian rule "first declared field = least significant
  bits"; GCC/Clang on big-endian targets (e.g. the Wii U's PowerPC)
  allocate bit-fields from the most significant bit instead. On
  big-endian hosts every struct is therefore declared with its fields in
  reverse order, preceded by an unnamed pad that pushes the used bits
  into the low end of the 32-bit word, so a given field covers the same
  bits of `raw` on every host.
  (Local modification for OperaU, see third_party/patches/.)
*/

struct cp1btag_s
{
#if IS_BIG_ENDIAN
  uint32_t :16;
  uint32_t pad:15;
  uint32_t c:1;
#else
  uint16_t c:1;
  uint16_t pad:15;
#endif
};

typedef struct cp1btag_s cp1btag_t;

struct cp2btag_s
{
#if IS_BIG_ENDIAN
  uint32_t :16;
  uint32_t pad:14;
  uint32_t c:2;
#else
  uint16_t c:2;
  uint16_t pad:14;
#endif
};

typedef struct cp2btag_s cp2btag_t;

struct cp4btag_s
{
#if IS_BIG_ENDIAN
  uint32_t :16;
  uint32_t pad:12;
  uint32_t c:4;
#else
  uint16_t c:4;
  uint16_t pad:12;
#endif
};

typedef struct cp4btag_s cp4btag_t;

struct cp6btag_s
{
#if IS_BIG_ENDIAN
  uint32_t :16;
  uint32_t pad:10;
  uint32_t pw:1;
  uint32_t c:5;
#else
  uint16_t c:5;
  uint16_t pw:1;
  uint16_t pad:10;
#endif
};

typedef struct cp6btag_s cp6btag_t;

struct cp8btag_s
{
#if IS_BIG_ENDIAN
  uint32_t :16;
  uint32_t pad:8;
  uint32_t m:2;
  uint32_t mpw:1;
  uint32_t c:5;
#else
  uint16_t c:5;
  uint16_t mpw:1;
  uint16_t m:2;
  uint16_t pad:8;
#endif
};

typedef struct cp8btag_s cp8btag_t;

struct cp16btag_s
{
#if IS_BIG_ENDIAN
  uint32_t :16;
  uint32_t pw:1;
  uint32_t pad:1;
  uint32_t mr:3;
  uint32_t mg:3;
  uint32_t mb:3;
  uint32_t c:5;
#else
  uint16_t c:5;
  uint16_t mb:3;
  uint16_t mg:3;
  uint16_t mr:3;
  uint16_t pad:1;
  uint16_t pw:1;
#endif
};

typedef struct cp16btag_s cp16btag_t;

struct up8btag_s
{
#if IS_BIG_ENDIAN
  uint32_t :16;
  uint32_t pad:8;
  uint32_t r:3;
  uint32_t g:3;
  uint32_t b:2;
#else
  uint16_t b:2;
  uint16_t g:3;
  uint16_t r:3;
  uint16_t pad:8;
#endif
};

typedef struct up8btag_s up8btag_t;

struct up16btag_s
{
#if IS_BIG_ENDIAN
  uint32_t :16;
  uint32_t p:1;
  uint32_t r:5;
  uint32_t g:5;
  uint32_t b:4;
  uint32_t bw:1;
#else
  uint16_t bw:1;
  uint16_t b:4;
  uint16_t g:5;
  uint16_t r:5;
  uint16_t p:1;
#endif
};

typedef struct up16btag_s up16btag_t;

struct res16btag_s
{
#if IS_BIG_ENDIAN
  uint32_t :16;
  uint32_t p:1;
  uint32_t r:5;
  uint32_t g:5;
  uint32_t b:5;
#else
  uint16_t b:5;
  uint16_t g:5;
  uint16_t r:5;
  uint16_t p:1;
#endif
};

typedef struct res16btag_s res16btag_t;

union pdeco_u
{
  uint32_t    raw;
  cp1btag_t   c1b;
  cp2btag_t   c2b;
  cp4btag_t   c4b;
  cp6btag_t   c6b;
  cp8btag_t   c8b;
  cp16btag_t  c16b;
  up8btag_t   u8b;
  up16btag_t  u16b;
  res16btag_t r16b;
};

typedef union pdeco_u pdeco_t;

struct avtag_s
{
#if IS_BIG_ENDIAN
  uint32_t :24;
  uint32_t pad:3;
  uint32_t dv3:2;
  uint32_t nCLIP:1;
  uint32_t XTEND:1;
  uint32_t NEG:1;
#else
  uint8_t NEG:1;
  uint8_t XTEND:1;
  uint8_t nCLIP:1;
  uint8_t dv3:2;
  uint8_t pad:3;
#endif
};

typedef struct avtag_s avtag_t;

union AVS_u
{
  avtag_t  avsignal;
  uint32_t raw;
};

typedef union AVS_u AVS_t;

struct pixctag_s
{
#if IS_BIG_ENDIAN
  uint32_t :16;
  uint32_t s1:1;
  uint32_t ms:2;
  uint32_t mxf:3;
  uint32_t dv1:2;
  uint32_t s2:2;
  uint32_t av:5;
  uint32_t dv2:1;
#else
  uint8_t dv2:1;
  uint8_t av:5;
  uint8_t s2:2;
  uint8_t dv1:2;
  uint8_t mxf:3;
  uint8_t ms:2;
  uint8_t s1:1;
#endif
};

typedef struct pixctag_s pixctag_t;

union PXC_u
{
  pixctag_t meaning;
  uint32_t  raw;
};

typedef union PXC_u PXC_t;

#define MADAM_REGISTER_COUNT        2048
#define MADAM_REGISTER_EXTRA_COUNT  64
#define MADAM_REGISTER_SAVE_COUNT   (MADAM_REGISTER_COUNT + MADAM_REGISTER_EXTRA_COUNT)
#define MADAM_PLUT_COUNT            32

#define MADAM_REG_ID          0x000
#define MADAM_REG_MSYSBITS    0x004
#define MADAM_REG_MCTL        0x008
#define MADAM_REG_STATBITS    0x028

#define MADAM_REG_CLIO_FIFO_FIRST  0x400
#define MADAM_REG_CLIO_FIFO_LAST   0x53F

#define MADAM_REG_DMA8_DEST      0x570
#define MADAM_REG_DMA8_LEN       0x574
#define MADAM_REG_DMA8_PROGRESS  0x578
#define MADAM_DMA8_IDLE_LEN      0xFFFFFFFC

#define MADAM_REG_VDL_HEAD  0x580

#define MADAM_REG_SPRSTRT   0x100
#define MADAM_REG_SPRSTOP   0x104
#define MADAM_REG_SPRCNTU   0x108
#define MADAM_REG_SPRPAUS   0x10C

#define MADAM_REG_CECONTROL  0x110
#define MADAM_REG_REGCTL0    0x130
#define MADAM_REG_REGCTL1    0x134
#define MADAM_REG_REGCTL2    0x138
#define MADAM_REG_REGCTL3    0x13C
#define MADAM_REG_XYPOSH     0x140
#define MADAM_REG_XYPOSL     0x144
#define MADAM_REG_LINEDXYH   0x148
#define MADAM_REG_LINEDXYL   0x14C
#define MADAM_REG_DXYH       0x150
#define MADAM_REG_DXYL       0x154
#define MADAM_REG_DDXYL      0x158
#define MADAM_REG_DDXYH      0x15C

#define MADAM_REG_CURRENTCCB  0x5A0
#define MADAM_REG_NEXTCCB     0x5A4
#define MADAM_REG_PLUTDATA    0x5A8
#define MADAM_REG_PDATA       0x5AC
#define MADAM_REG_ENGAFETCH   0x5B0
#define MADAM_REG_ENGALEN     0x5B4
#define MADAM_REG_ENGBFETCH   0x5B8
#define MADAM_REG_ENGBLEN     0x5BC

#define MADAM_REG_MATRIX_INPUT     0x600
#define MADAM_REG_MATRIX_VECTOR    0x640
#define MADAM_REG_MATRIX_OUTPUT    0x660
#define MADAM_REG_MATRIX_NFRAC_HI  0x680
#define MADAM_REG_MATRIX_NFRAC_LO  0x684
#define MADAM_REG_MATRIX_CONTROL   0x7FC

#define MADAM_MATRIX_ROW_STRIDE      0x10
#define MADAM_MATRIX_REGISTER_STRIDE 0x04
#define MADAM_MATRIX_INPUT_REG(ROW,COL)                         \
  (MADAM_REG_MATRIX_INPUT + ((ROW) * MADAM_MATRIX_ROW_STRIDE) + \
   ((COL) * MADAM_MATRIX_REGISTER_STRIDE))
#define MADAM_MATRIX_VECTOR_REG(IDX)                                    \
  (MADAM_REG_MATRIX_VECTOR + ((IDX) * MADAM_MATRIX_REGISTER_STRIDE))
#define MADAM_MATRIX_OUTPUT_REG(IDX)                                    \
  (MADAM_REG_MATRIX_OUTPUT + ((IDX) * MADAM_MATRIX_REGISTER_STRIDE))

#define MADAM_SYSBITS_RED 0x20

#pragma pack(pop)

struct madam_s
{
  uint32_t mregs[MADAM_REGISTER_SAVE_COUNT];
  uint16_t PLUT[MADAM_PLUT_COUNT];
  int32_t  rmod;
  int32_t  wmod;
  int32_t  clipx;
  int32_t  clipy;
  uint32_t FSM;
};

typedef struct madam_s madam_t;

#define ME_MODE_HARDWARE 0
#define ME_MODE_SOFTWARE 1
#define MADAM_ID_RED_HARDWARE   0x01000000
#define MADAM_ID_GREEN_HARDWARE 0x01020000
#define MADAM_GREENWW           0x01020001
#define MADAM_ID_GREEN_SOFTWARE MADAM_GREENWW

static madam_t MADAM;
static int KPRINT  = 0;
static int ME_MODE = ME_MODE_HARDWARE;

/*
  The CEL engine renders about 9 million pixels per second ("The actual
  limit is based on the number of rendered pixels and is approximately
  9 million rendered pixels per second", Opera Specification, CEL engine
  chapter): the engine pixel slots are what the CPU sees as rendering
  time.

  A surface mapped (arbitrary quad) cel walks its source one texel at a
  time, evaluating and clipping each texel's quad, so those cels cost
  per source texel rather than per written pixel. AutoBahn Tokio's
  attract demo draws about 430k such texels per list (only about 150k of
  them land on screen): texel counting paces its ten phases over the
  demo's attract window (635 phase frames in about 24 seconds, ~24 fps),
  where written-pixel counting finishes them in about 10 seconds and
  leaves a still end card for the rest of the demo.

  Fetching and decoding each SCoB adds a small fixed cost on top.
*/
#define MADAM_CEL_PIXELS_PER_SECOND 9000000ULL
#define MADAM_CEL_SETUP_CYCLES      64ULL

static uint64_t g_CEL_PIXELS_DRAWN  = 0;
/* Local modification for OperaU, see third_party/patches/: the count above when the cel being drawn started,
   while the front end is profiling, so that the pixels of one cel can be told from those of the list. */
static uint64_t g_CEL_PX_BEFORE     = 0;

/*
  Local modification for OperaU, see third_party/patches/: true while the cel being drawn cannot see the frame
  buffer - neither half of its PIXC takes colour 1 from it (s1) or colour 2 from it (s2 == 2), which are the only
  two places PPROC() reads the pixel already there, and PPROJ_OUTPUT() does not read it at all.

  For such a cel the colour written depends on the source texel alone. The drawing paths used to read the frame
  buffer under every pixel all the same, and run the pixel processor again each time that value changed - which,
  over a background, is every pixel. One texel stretched over a run or a block of pixels therefore paid for the
  whole pipeline once per pixel to arrive at the same answer each time. With this flag the texel leaves TEXEL()
  as the finished pixel and the drawing paths only write it. Measured on the console, from half to all of the cels
  a game draws are of this kind; the others are mixed with the frame buffer, see g_pp2d.
*/
static bool     g_CEL_FB_FREE       = false;

/*
  Local modification for OperaU, see third_party/patches/: the finished pixel for each source value of the cel
  being drawn.

  For a cel that cannot see the frame buffer (g_CEL_FB_FREE), everything between the bits read from the source
  and the pixel written is a function of those bits alone: the decoder looks them up in the PLUT, the pixel
  processor scales and mixes the result with values fixed for the cel, the projector sets the two control bits
  from the decoder's output and from registers. Nothing in that chain reads a position, a neighbour or the frame
  buffer. So the answer for a source value is the same every time it turns up in the cel, and a source of eight
  bits or fewer has at most 256 values while a cel may have thousands of texels. Each value is put through the
  chain the first time it is seen and remembered; after that a texel costs the read of its bits and one lookup.

  A source of eight bits or fewer has a slot for each of its values. A 16-bit source shares the slots, each
  remembering which value it holds, so a value that lands on a slot held by another simply takes it over. That
  only pays if values come back, and a 16-bit picture may be thousands of colours that hardly ever do; so such a
  cel starts on trial (see g_CEL_TEXEL_MODE), and one that finds too little in the table stops looking.

  What a slot holds belongs to one cel. Rather than wipe the slots for every cel, each cel takes the next number
  and a slot counts as filled only if it carries that number: the key is the cel's number in the top half and the
  source value, which is never wider than 16 bits, in the bottom half. Number zero is never given to a cel, so
  slots that were never written match nothing, and the slots are wiped when the numbers run out.
*/
#define CEL_TC_SLOTS 1024
typedef struct cel_tc_s cel_tc_t;
struct cel_tc_s
{
  uint32_t key;   /* (the cel's number << 16) | the source value */
  uint32_t value; /* the finished pixel, with bit 16 set if the value draws nothing at all */
};
static cel_tc_t g_CEL_TC[CEL_TC_SLOTS];
static uint32_t g_CEL_TC_CEL = 0; /* the number of the cel being drawn, already shifted into the top half */
static int      g_CEL_TC_ON  = 1; /* off only while a front end times the engine without it, see below */
/*
  How TEXEL() treats the cel being drawn. A cel that reads the frame buffer is only decoded there, as it always
  was. The others leave TEXEL() as finished pixels, by one of three routes: looked up; worked out every time,
  which is what the engine did before the table and what it goes back to when the table would not pay; or looked
  up while counting how often that works, until there is enough to choose between the first two.
*/
#define CEL_TEXEL_DECODE 0
#define CEL_TEXEL_LOOKUP 1
#define CEL_TEXEL_CHAIN  2
#define CEL_TEXEL_TRIAL  3
static int      g_CEL_TEXEL_MODE = CEL_TEXEL_DECODE;
/*
  The trial. A lookup that fails costs a little more than no lookup, and one that succeeds costs a tenth of the
  chain, so the table pays as soon as about one texel in eight is found in it. After this many texels the cel is
  held to that.
*/
#define CEL_TC_TRIAL_TEXELS 512
static uint32_t g_CEL_TC_FOUND  = 0;
static uint32_t g_CEL_TC_MISSED = 0;
static uint64_t g_CEL_TEXELS_WALKED = 0;
static uint64_t g_CEL_LIST_CELS     = 0;
static uint64_t g_CEL_BUSY_UNTIL    = 0;
static bool     g_CEL_DRAW_PENDING  = false;

/*
  Local modification for OperaU, see third_party/patches/: the engine's speed can be set from outside, and the
  time it is busy is counted.

  The figure above is upstream's and is the default, so nothing changes unless a front end asks. But the
  machine's published figure is a range, 9 to 16 million pixels a second, and a game that draws more than
  150,000 pixels a field is held to fewer pictures than fields by the lower end of it alone - with its music,
  which the DSP plays on time, running ahead of the picture. Whether that is what a game is waiting for can
  now be read off (opera_prof.cel_busy) and tried (opera_madam_cel_rate_set()). 0 means the engine is never
  busy, which is how this core behaved before it modelled the engine's time.
*/
static uint64_t g_CEL_RATE      = MADAM_CEL_PIXELS_PER_SECOND;
static uint64_t g_CEL_BUSY_FROM = 0;     /* profiling only: the cycle the busy period being counted started at */
static bool     g_CEL_BUSY_OPEN = false; /* profiling only: there is such a period */

void
opera_madam_cel_rate_set(const uint32_t pixels_per_second_)
{
  g_CEL_RATE = pixels_per_second_;
}

uint32_t
opera_madam_cel_rate_get(void)
{
  return (uint32_t)g_CEL_RATE;
}

/* Profiling only: the busy period that was open ends at cycle `at_`. */
static
INLINE
void
madam_cel_busy_count(const uint64_t at_)
{
  if(g_CEL_BUSY_OPEN)
    {
      if(opera_prof_enabled && (at_ > g_CEL_BUSY_FROM))
        opera_prof.cel_busy += (at_ - g_CEL_BUSY_FROM);
      g_CEL_BUSY_OPEN = false;
    }
}

static
void
madam_cel_busy_start(void)
{
  uint64_t work;
  const uint64_t now = opera_clock_cpu_get_cycles();

  work = (g_CEL_TEXELS_WALKED > g_CEL_PIXELS_DRAWN) ?
         g_CEL_TEXELS_WALKED : g_CEL_PIXELS_DRAWN;

  if(g_CEL_RATE == 0)
    g_CEL_BUSY_UNTIL = now;
  else
    g_CEL_BUSY_UNTIL = now +
      ((work * (uint64_t)opera_clock_cpu_get_freq()) /
       g_CEL_RATE) +
      (g_CEL_LIST_CELS * MADAM_CEL_SETUP_CYCLES);

  /* a period still open is replaced by this one: it was busy up to now */
  madam_cel_busy_count(now);
  if(opera_prof_enabled)
    {
      g_CEL_BUSY_FROM = now;
      g_CEL_BUSY_OPEN = true;
    }

  g_CEL_DRAW_PENDING = false;
}

/*
  Local modification for OperaU, see g_CEL_TC: lets a front end draw the same cels with and without the table of
  finished pixels, to time the two on the machine it runs on and to check that they write the same picture. With
  it off every texel goes through the whole chain, as it did before the table existed. Nothing else changes, so
  this is not for normal use.
*/
void
opera_madam_cel_value_cache(const int on_)
{
  g_CEL_TC_ON = (on_ != 0);
}

/* Local modification for OperaU: what the last cel list cost - the two numbers the engine's busy time is worked
   out from - so a front end can time the engine per pixel. */
void
opera_madam_cel_last_work(uint64_t *pixels_,
                          uint64_t *texels_)
{
  if(pixels_)
    *pixels_ = g_CEL_PIXELS_DRAWN;
  if(texels_)
    *texels_ = g_CEL_TEXELS_WALKED;
}

void
opera_madam_cel_tick(void)
{
  // This runs before every ARM instruction; keep the state check local.
  if(MADAM.FSM != FSM_INPROCESS)
    return;

  if(g_CEL_DRAW_PENDING)
    {
      OPERA_PROF_BEGIN(prof_cel);
      opera_madam_cel_handle();
      OPERA_PROF_END(prof_cel,cel,cel_calls);
      if(opera_prof_enabled)
        {
          opera_prof.cel_cels   += g_CEL_LIST_CELS;
          opera_prof.cel_texels += g_CEL_TEXELS_WALKED;
          opera_prof.cel_pixels += g_CEL_PIXELS_DRAWN;
        }
      return;
    }

  if(opera_clock_cpu_get_cycles() >= g_CEL_BUSY_UNTIL)
    {
      MADAM.FSM = FSM_IDLE;
      madam_cel_busy_count(g_CEL_BUSY_UNTIL); /* Local modification for OperaU: profiling only */
    }
}

void
opera_madam_kprint_enable(void)
{
  KPRINT = 1;
}

void
opera_madam_kprint_disable(void)
{
  KPRINT = 0;
}

void
opera_madam_me_mode_hardware(void)
{
  ME_MODE = ME_MODE_HARDWARE;
}

void
opera_madam_me_mode_software(void)
{
  ME_MODE = ME_MODE_SOFTWARE;
}

uint32_t
opera_madam_fsm_get(void)
{
  return MADAM.FSM;
}

uint32_t
opera_madam_mctl(void)
{
  return MADAM.mregs[MADAM_REG_MCTL];
}

void
opera_madam_fsm_set(uint32_t val_)
{
  MADAM.FSM = val_;
}

uint32_t
opera_madam_state_size_v1(void)
{
  return opera_state_save_size(sizeof(madam_t));
}

static
bool
madam_state_write_payload(opera_state_writer_t *writer_,
                          madam_t const        *state_)
{
  return (opera_state_write_u32_array(writer_,state_->mregs,MADAM_REGISTER_SAVE_COUNT) &&
          opera_state_write_u16_array(writer_,state_->PLUT,MADAM_PLUT_COUNT) &&
          opera_state_write_i32(writer_,state_->rmod) &&
          opera_state_write_i32(writer_,state_->wmod) &&
          opera_state_write_i32(writer_,state_->clipx) &&
          opera_state_write_i32(writer_,state_->clipy) &&
          opera_state_write_u32(writer_,state_->FSM) &&
          opera_state_write_u32(writer_,g_CEL_DRAW_PENDING) &&
          opera_state_write_u64(writer_,g_CEL_BUSY_UNTIL));
}

static
uint32_t
madam_state_payload_size(void)
{
  opera_state_writer_t writer;

  opera_state_writer_init(&writer,NULL,UINT32_MAX);
  madam_state_write_payload(&writer,&MADAM);

  return opera_state_writer_used(&writer);
}

uint32_t
opera_madam_state_size(void)
{
  return opera_state_chunk_size(madam_state_payload_size());
}

uint32_t
opera_madam_state_save(void *buf_)
{
  uint32_t payload_size;
  opera_state_writer_t writer;

  payload_size = madam_state_payload_size();
  opera_state_writer_init(&writer,buf_,opera_state_chunk_size(payload_size));
  opera_state_write_chunk_header(&writer,"MDAM",payload_size);
  madam_state_write_payload(&writer,&MADAM);

  return opera_state_writer_ok(&writer) ? opera_state_writer_used(&writer) : 0;
}

uint32_t
opera_madam_state_load_v1(const void     *buf_,
                          uint32_t const  size_)
{
  uint32_t used;

  used = opera_state_load_sized(&MADAM,"MDAM",buf_,size_,sizeof(MADAM));
  if(used == 0)
    return 0;

  g_CEL_DRAW_PENDING = ((MADAM.FSM == FSM_INPROCESS) ||
                        (MADAM.FSM == FSM_SUSPENDED));
  g_CEL_BUSY_UNTIL = 0;
  g_CEL_BUSY_OPEN  = false;
  return used;
}

static
bool
madam_state_read_payload(opera_state_reader_t *reader_,
                         madam_t              *state_)
{
  return (opera_state_read_u32_array(reader_,state_->mregs,MADAM_REGISTER_SAVE_COUNT) &&
          opera_state_read_u16_array(reader_,state_->PLUT,MADAM_PLUT_COUNT) &&
          opera_state_read_i32(reader_,&state_->rmod) &&
          opera_state_read_i32(reader_,&state_->wmod) &&
          opera_state_read_i32(reader_,&state_->clipx) &&
          opera_state_read_i32(reader_,&state_->clipy) &&
          opera_state_read_u32(reader_,&state_->FSM));
}

uint32_t
opera_madam_state_load(const void     *buf_,
                       uint32_t const  size_)
{
  madam_t state;
  uint32_t pending;
  uint64_t busy_until;
  opera_state_reader_t reader;
  opera_state_reader_t payload;

  opera_state_reader_init(&reader,buf_,size_);
  if(!opera_state_read_chunk(&reader,"MDAM",&payload) ||
     !madam_state_read_payload(&payload,&state))
    return 0;

  // Chunks without timing fields use the legacy pending-list convention.
  pending = ((state.FSM == FSM_INPROCESS) || (state.FSM == FSM_SUSPENDED));
  busy_until = 0;
  if(opera_state_reader_remaining(&payload) != 0)
    {
      if(!opera_state_read_u32(&payload,&pending) ||
         !opera_state_read_u64(&payload,&busy_until) ||
         (pending > 1))
        return 0;
    }

  if(!opera_state_reader_finished(&payload))
    return 0;

  if(opera_state_validating())
    return opera_state_reader_used(&reader);

  MADAM = state;
  g_CEL_DRAW_PENDING = (pending != 0);
  // The clock chunk restores the same absolute CPU-cycle timebase.
  g_CEL_BUSY_UNTIL = busy_until;
  g_CEL_BUSY_OPEN  = false;

  return opera_state_reader_used(&reader);
}

#define PACKED   true
#define UNPACKED false

static bool    TestInitVisual(bool const packed);
static bool    InitLineMap(void);
static void    InitScaleMap(void);
static void    InitArbitraryMap(void);
static void    TexelDrawLine(uint16_t CURPIX, uint16_t LAMV, int32_t xcur, int32_t ycur, int32_t cnt);
static int32_t TexelDrawScale(uint16_t CURPIX, uint16_t LAMV, int32_t xcur, int32_t ycur, int32_t deltax, int32_t deltay);
static int32_t TexelDrawArbitrary(uint16_t CURPIX, uint16_t LAMV, int32_t xA, int32_t yA, int32_t xB, int32_t yB, int32_t xC, int32_t yC, int32_t xD, int32_t yD);
static void    pp_invalidate_luts(void); /* OperaU: the pixel pipeline worked out per cel, see its definition */
static void    DrawPackedCel(void);
static void    DrawLiteralCel(void);
static void    DrawLRCel(void);
static void    HandleDMA8(void);
static void    DMAPBus(void);

static struct
{
  uint32_t plutaCCBbits;
  uint32_t pixelBitsMask;
  uint32_t rawVHBits;
} pdec;

static struct
{
  uint32_t pmode;
  uint32_t pmodeORmask;
  uint32_t pmodeANDmask;
  int      Transparent;
} pproj;

static uint32_t  CCBFLAGS;
static uint32_t  PIXC;
static uint32_t  PRE0;
static uint32_t  PRE1;
static int32_t   SPRWI;
static int32_t   SPRHI;
static uint32_t  PXOR1;
static uint32_t  PXOR2;

static uint32_t const BPP[8] = {1,1,2,4,6,8,16,1};

static uint8_t PSCALAR[8][4][32];

static uint16_t MAPu8b[256+64];
static uint16_t MAPc8bAMV[256+64];
static uint16_t MAPc16bAMV[8*8*8+64];

/*
  See section "Spryte Rendering Process" of patent
  WO09410642A1 - Method For Controlling A Spryte Rendering Processor
*/

// CelEngine STATBits
#define STATBITS	MADAM.mregs[MADAM_REG_STATBITS]

#define SPRON		0x10
#define SPRPAU		0x20

// CelEngine Registers
#define CECONTROL	MADAM.mregs[MADAM_REG_CECONTROL]
#define REGCTL0		MADAM.mregs[MADAM_REG_REGCTL0]
#define REGCTL1		MADAM.mregs[MADAM_REG_REGCTL1]
#define REGCTL2		MADAM.mregs[MADAM_REG_REGCTL2]
#define REGCTL3		MADAM.mregs[MADAM_REG_REGCTL3]
#define XYPOSH          MADAM.mregs[MADAM_REG_XYPOSH]
#define XYPOSL          MADAM.mregs[MADAM_REG_XYPOSL]
#define LINEDXYH        MADAM.mregs[MADAM_REG_LINEDXYH]
#define LINEDXYL        MADAM.mregs[MADAM_REG_LINEDXYL]
#define DXYH            MADAM.mregs[MADAM_REG_DXYH]
#define DXYL            MADAM.mregs[MADAM_REG_DXYL]
#define DDXYH           MADAM.mregs[MADAM_REG_DDXYH]
#define DDXYL           MADAM.mregs[MADAM_REG_DDXYL]

#define CURRENTCCB	MADAM.mregs[MADAM_REG_CURRENTCCB]
#define NEXTCCB		MADAM.mregs[MADAM_REG_NEXTCCB]
#define PLUTDATA	MADAM.mregs[MADAM_REG_PLUTDATA]
#define PDATA		MADAM.mregs[MADAM_REG_PDATA]
#define ENGAFETCH	MADAM.mregs[MADAM_REG_ENGAFETCH]
#define ENGALEN		MADAM.mregs[MADAM_REG_ENGALEN]
#define	ENGBFETCH	MADAM.mregs[MADAM_REG_ENGBFETCH]
#define ENGBLEN		MADAM.mregs[MADAM_REG_ENGBLEN]

static
INLINE
const
int32_t
PDV(const int32_t x_)
{
  return (((x_ - 1) & 3) + 1);
}

static
INLINE
int32_t
DecodeREGCTLMod(uint32_t val_)
{
  int32_t mod;

  /* REGCTL MOD bits encode pixel-width groups; XY2OFF needs byte stride. */
  mod = 0;
  if(val_ & 0x01)
    mod += (32 << 2);
  if(val_ & 0x02)
    mod += (512 << 2);
  if(val_ & 0x04)
    mod += (256 << 2);
  if(val_ & 0x08)
    mod += (1024 << 2);
  if(val_ & 0x10)
    mod += (64 << 2);
  if(val_ & 0x20)
    mod += (128 << 2);
  if(val_ & 0x40)
    mod += (256 << 2);
  if(val_ & 0x80)
    mod += (1024 << 2);

  return mod;
}

static
INLINE
const
int32_t
XY2OFF(const int32_t x_,
       const int32_t y_,
       const int32_t m_)
{
  return (((y_ >> 1) * m_) + ((y_ & 1) << 1) + (x_ << 2));
}

static
INLINE
const
bool
clipping(const int32_t x_,
         const int32_t y_)
{
  return (((uint32_t)x_ > MADAM.clipx) ||
          ((uint32_t)y_ > MADAM.clipy));
}

uint32_t
opera_madam_peek(uint32_t addr_)
{
  /*
    The CPU can read the whole 1 MB window of the chip but the registers end at
    0x7FF: anything above ran off the end of the register array (a crash on
    the Wii U). Unmapped space reads like the rest of it.
    (Local modification for OperaU, see third_party/patches/.)
  */
  if(addr_ >= MADAM_REGISTER_COUNT)
    return 0xBADACCE5;

  /* we need to return actual fifo status */
  if((addr_ >= MADAM_REG_CLIO_FIFO_FIRST) && (addr_ <= MADAM_REG_CLIO_FIFO_LAST))
    return opera_clio_fifo_read(addr_);

  /* status of CEL */
  if(addr_ == MADAM_REG_STATBITS)
    {
      switch(MADAM.FSM)
        {
        case FSM_IDLE:
          return 0x00;
        case FSM_SUSPENDED:
          return SPRON | SPRPAU;
        case FSM_INPROCESS:
          return SPRON;
        }
    }

  return MADAM.mregs[addr_];
}

/* Matrix engine macros */
/* input */
#define MI00 ((int64_t)(int32_t)MADAM.mregs[MADAM_MATRIX_INPUT_REG(0,0)])
#define MI01 ((int64_t)(int32_t)MADAM.mregs[MADAM_MATRIX_INPUT_REG(0,1)])
#define MI02 ((int64_t)(int32_t)MADAM.mregs[MADAM_MATRIX_INPUT_REG(0,2)])
#define MI03 ((int64_t)(int32_t)MADAM.mregs[MADAM_MATRIX_INPUT_REG(0,3)])
#define MI10 ((int64_t)(int32_t)MADAM.mregs[MADAM_MATRIX_INPUT_REG(1,0)])
#define MI11 ((int64_t)(int32_t)MADAM.mregs[MADAM_MATRIX_INPUT_REG(1,1)])
#define MI12 ((int64_t)(int32_t)MADAM.mregs[MADAM_MATRIX_INPUT_REG(1,2)])
#define MI13 ((int64_t)(int32_t)MADAM.mregs[MADAM_MATRIX_INPUT_REG(1,3)])
#define MI20 ((int64_t)(int32_t)MADAM.mregs[MADAM_MATRIX_INPUT_REG(2,0)])
#define MI21 ((int64_t)(int32_t)MADAM.mregs[MADAM_MATRIX_INPUT_REG(2,1)])
#define MI22 ((int64_t)(int32_t)MADAM.mregs[MADAM_MATRIX_INPUT_REG(2,2)])
#define MI23 ((int64_t)(int32_t)MADAM.mregs[MADAM_MATRIX_INPUT_REG(2,3)])
#define MI30 ((int64_t)(int32_t)MADAM.mregs[MADAM_MATRIX_INPUT_REG(3,0)])
#define MI31 ((int64_t)(int32_t)MADAM.mregs[MADAM_MATRIX_INPUT_REG(3,1)])
#define MI32 ((int64_t)(int32_t)MADAM.mregs[MADAM_MATRIX_INPUT_REG(3,2)])
#define MI33 ((int64_t)(int32_t)MADAM.mregs[MADAM_MATRIX_INPUT_REG(3,3)])

/* output */
#define MO0 MADAM.mregs[MADAM_MATRIX_OUTPUT_REG(0)]
#define MO1 MADAM.mregs[MADAM_MATRIX_OUTPUT_REG(1)]
#define MO2 MADAM.mregs[MADAM_MATRIX_OUTPUT_REG(2)]
#define MO3 MADAM.mregs[MADAM_MATRIX_OUTPUT_REG(3)]

/* vector */
#define MV0 ((int64_t)(int32_t)MADAM.mregs[MADAM_MATRIX_VECTOR_REG(0)])
#define MV1 ((int64_t)(int32_t)MADAM.mregs[MADAM_MATRIX_VECTOR_REG(1)])
#define MV2 ((int64_t)(int32_t)MADAM.mregs[MADAM_MATRIX_VECTOR_REG(2)])
#define MV3 ((int64_t)(int32_t)MADAM.mregs[MADAM_MATRIX_VECTOR_REG(3)])

static int64_t tmpMO0;
static int64_t tmpMO1;
static int64_t tmpMO2;
static int64_t tmpMO3;

#define Nfrac16 (((int64_t)MADAM.mregs[MADAM_REG_MATRIX_NFRAC_HI]<<32) | \
                 (uint32_t)MADAM.mregs[MADAM_REG_MATRIX_NFRAC_LO])

static
INLINE
void
madam_matrix_copy(void)
{
  MO0 = tmpMO0;
  MO1 = tmpMO1;
  MO2 = tmpMO2;
  MO3 = tmpMO3;
}

/*
  multiply a 3x3 matrix of 16.16 values by a vector of 16.16 values
*/
static
INLINE
void
madam_matrix_mul3x3(void)
{
  madam_matrix_copy();

  tmpMO0 = (((MI00 * MV0) +
             (MI01 * MV1) +
             (MI02 * MV2)) >> 16);
  tmpMO1 = (((MI10 * MV0) +
             (MI11 * MV1) +
             (MI12 * MV2)) >> 16);
  tmpMO2 = (((MI20 * MV0) +
             (MI21 * MV1) +
             (MI22 * MV2)) >> 16);
}

/*
  multiply a 3x3 matrix of 16.16 values by multiple
  vectors, then multiply x and y by n/z

  return the result vectors {x*n/z, y*n/z, z}
*/
static
INLINE
void
madam_matrix_mul3x3_nz(void)
{
  int64_t M;

  madam_matrix_copy();

  M = Nfrac16;

  tmpMO2 = (((MI20 * MV0) +
             (MI21 * MV1) +
             (MI22 * MV2)) >> 16);

  if(tmpMO2 != 0)
    M /= (int64_t)tmpMO2;

  tmpMO0 = (((MI00 * MV0) +
             (MI01 * MV1) +
             (MI02 * MV2)) >> 16);
  tmpMO1 = (((MI10 * MV0) +
             (MI11 * MV1) +
             (MI12 * MV2)) >> 16);

  tmpMO0 = ((tmpMO0 * M) >> 32);
  tmpMO1 = ((tmpMO1 * M) >> 32);
}

/*
  multiply a 4x4 matrix of 16.16 values by a vector of 16.16 values
*/
static
INLINE
void
madam_matrix_mul4x4(void)
{
  madam_matrix_copy();

  tmpMO0 = (((MI00 * MV0) +
             (MI01 * MV1) +
             (MI02 * MV2) +
             (MI03 * MV3)) >> 16);
  tmpMO1 = (((MI10 * MV0) +
             (MI11 * MV1) +
             (MI12 * MV2) +
             (MI13 * MV3)) >> 16);
  tmpMO2 = (((MI20 * MV0) +
             (MI21 * MV1) +
             (MI22 * MV2) +
             (MI23 * MV3)) >> 16);
  tmpMO3 = (((MI30 * MV0) +
             (MI31 * MV1) +
             (MI32 * MV2) +
             (MI33 * MV3)) >> 16);
}

void
opera_madam_poke(uint32_t addr_,
                 uint32_t val_)
{
  if((addr_ >= MADAM_REG_CLIO_FIFO_FIRST) && (addr_ <= MADAM_REG_CLIO_FIFO_LAST))
    {
      opera_clio_fifo_write(addr_,val_);
      return;
    }

  switch(addr_)
    {
    case MADAM_REG_ID:
      if(KPRINT)
        fputc(val_,stderr);
      return;
    case MADAM_REG_MSYSBITS:
      /* readonly */
      break;
    case MADAM_REG_MCTL:
      MADAM.mregs[MADAM_REG_MCTL] = val_;
      HandleDMA8();
      break;
    case MADAM_REG_VDL_HEAD:
      opera_vdlp_set_vdl_head(val_);
      return;
    case MADAM_REG_SPRSTRT:
      /*
        A start while the engine is still rendering (and the list has
        already been drawn) replaces the pending busy period: software
        that does not poll STATBITS keeps its old, unthrottled cadence
        while software that does poll waits for the current list like it
        would on hardware.
      */
      if(MADAM.FSM == FSM_IDLE)
        MADAM.FSM = FSM_INPROCESS;
      g_CEL_DRAW_PENDING = true;
      return;
    case MADAM_REG_SPRSTOP:
      MADAM.FSM = FSM_IDLE;
      NEXTCCB = 0;
      g_CEL_DRAW_PENDING = false;
      madam_cel_busy_count(opera_clock_cpu_get_cycles()); /* Local modification for OperaU: profiling only */
      return;
    case MADAM_REG_SPRCNTU:
      if(MADAM.FSM == FSM_SUSPENDED)
        MADAM.FSM = FSM_INPROCESS;
      return;
    case MADAM_REG_SPRPAUS:
      if(MADAM.FSM == FSM_INPROCESS)
        MADAM.FSM = FSM_SUSPENDED;
      return;

      /* Matrix engine */
    case MADAM_REG_MATRIX_CONTROL:
      switch(val_)
        {
        case 0:
          madam_matrix_copy();
          return;
        case 1:
          madam_matrix_mul4x4();
          return;
        case 2:
          madam_matrix_mul3x3();
          return;
        case 3:
          madam_matrix_mul3x3_nz();
          return;
        default:
          return;
        }
      break;

      /* REGCTL0 */
    case MADAM_REG_REGCTL0:
      REGCTL0 = val_;
      MADAM.rmod = DecodeREGCTLMod(val_ & 0xFF);
      MADAM.wmod = DecodeREGCTLMod((val_ >> 8) & 0xFF);
      break;

      /* REGCTL1 */
    case MADAM_REG_REGCTL1:
      REGCTL1 = val_;
      MADAM.clipx = ((val_ >>  0) & 0x3FF);
      MADAM.clipy = ((val_ >> 16) & 0x3FF);
      break;

    default:
      MADAM.mregs[addr_] = val_;
      break;
    }
}

enum texel_draw_func_e
  {
    TEXEL_DRAW_FUNC_LINE,
    TEXEL_DRAW_FUNC_SCALE,
    TEXEL_DRAW_FUNC_ARBITRARY
  };
typedef enum texel_draw_func_e texel_draw_func_e;

static int32_t  HDDX1616;
static int32_t  HDDY1616;
static int32_t  HDX1616;
static int32_t  HDY1616;
static int32_t  VDX1616;
static int32_t  VDY1616;
static int32_t  XPOS1616;
static int32_t  YPOS1616;
static uint32_t CEL_ORIGIN_VH_VALUE;
static texel_draw_func_e TEXEL_DRAW_FUNC;
static int32_t  TEXTURE_WI_START;
static int32_t  TEXTURE_HI_START;
static int32_t  TEXEL_INCX;
static int32_t  TEXEL_INCY;
static int32_t  TEXTURE_WI_LIM;
static int32_t  TEXTURE_HI_LIM;

static
INLINE
void
LoadXYPosFromRegisters(void)
{
  XPOS1616 = (int32_t)((XYPOSH & 0xFFFF0000) | ((XYPOSL >> 16) & 0xFFFF));
  YPOS1616 = (int32_t)(((XYPOSH & 0x0000FFFF) << 16) | (XYPOSL & 0xFFFF));
}

static
INLINE
void
StoreXYPosToRegisters(int32_t const x_,
                      int32_t const y_)
{
  XYPOSH   = (((uint32_t)x_ & 0xFFFF0000) | (((uint32_t)y_ >> 16) & 0xFFFF));
  XYPOSL   = ((((uint32_t)x_ & 0xFFFF) << 16) | ((uint32_t)y_ & 0xFFFF));
  XPOS1616 = x_;
  YPOS1616 = y_;
}

static
INLINE
void
StoreXYPosFromDrawHeight(int32_t const x_,
                         int32_t const y_,
                         int32_t const vdx_,
                         int32_t const vdy_,
                         int32_t const height_)
{
  StoreXYPosToRegisters((int32_t)((uint32_t)x_ + ((uint32_t)vdx_ * (uint32_t)height_)),
                        (int32_t)((uint32_t)y_ + ((uint32_t)vdy_ * (uint32_t)height_)));
}

static
void
LoadPLUT(uint32_t pnt_,
         int32_t  n_)
{
  int i;

  for(i = 0; i < n_; i++)
    MADAM.PLUT[i] = opera_mem_read16((((pnt_ >> 1) + i)) << 1);
}

void
opera_madam_cel_handle(void)
{
  CCBFLAGS = 0;
  set_flag(STATBITS,SPRON);

  g_CEL_PIXELS_DRAWN  = 0;
  g_CEL_TEXELS_WALKED = 0;
  g_CEL_LIST_CELS     = 0;

  /*
    When the CPU writes to the SPRSTRT address, after
    the spryte engine gains control of the system data bus
    118, 120, the DMA engine of Figs. 3 and 4 loads in the
    first six words from the first SCoB beginning from the
    system memory address specified in the NEXT SCOB
    register in the DMA stack 312.
  */
  while(NEXTCCB && flag_is_clr(CCBFLAGS,CCB_LAST))
    {
      g_CEL_LIST_CELS++;
      /*
        To accomplish this, the address of the first word to load is
        read out of the NEXT SCOB register and provided to the memory
        address lines via source multiplexer 314. The address is also
        incremented by adder/clipper 320 and written back via
        multiplexer 310 into the CURRENT SCOB register in DMA stack
        312. All six words are read from memory in this manner, the
        CURRENT SCOB register maintaining the address of each next
        word to load.
      */
      CURRENTCCB = (NEXTCCB & ALIGNED_24BIT_MASK);
      if(CURRENTCCB >= RAM_SIZE)
        break;

      /*
        The first SCoB word read, FLAGS, is written into a 32-bit
        hardware register in address manipulator chip 106.
      */
      CCBFLAGS = opera_mem_read32(CURRENTCCB);
      CURRENTCCB += 4;

      /*
        The next SCoB word read, NEXTPTR, is written into the NEXT
        SCOB register in DMA stack 312.
      */
      NEXTCCB = (opera_mem_read32(CURRENTCCB) & ALIGNED_24BIT_MASK);
      if(flag_is_clr(CCBFLAGS,CCB_NPABS))
        NEXTCCB += (CURRENTCCB + 4);
      CURRENTCCB += 4;

      /*
        SOURCEPTR is written into the SPRYTE DATA ADDRESS register of
        DMA stack 312,
      */
      PDATA = (opera_mem_read32(CURRENTCCB) & ALIGNED_24BIT_MASK);
      if(flag_is_clr(CCBFLAGS,CCB_SPABS))
        PDATA += (CURRENTCCB + 4);
      CURRENTCCB += 4;

      /*
        and PIPPTR is written into the PIP ADDRESS register in DMA
        stack 312.
      */
      PLUTDATA = (opera_mem_read32(CURRENTCCB) & ALIGNED_24BIT_MASK);
      if(flag_is_clr(CCBFLAGS,CCB_PPABS))
        PLUTDATA += (CURRENTCCB + 4);
      CURRENTCCB += 4;

      /*
        XPOS and YPOS are written to two memory mapped hardware
        registers XYPOSH and XYPOSL, each having the format of
        x,y. That is, the high-order 16 bits from XPOS and the
        high-order 16 bits from YPOS are written to the high- and
        low-order half words, respectively, of XYPOSH, and the
        low-order 16 bits of XPOS and the low-order 16 bits of YPOS
        are written to the high and low half words, respectively, of
        XYPOSL.

        Note that if the SKIP bit of the FLAGS word equals one,
        indicating that the present SCoB is to he skipped, or if the
        YOXY bit is zero, then the X and Y values are not written to
        the hardware.
      */
      if(flag_is_clr(CCBFLAGS,CCB_SKIP))
        {
          if(flag_is_set(CCBFLAGS,CCB_YOXY))
            StoreXYPosToRegisters(opera_mem_read32(CURRENTCCB + 0),
                                  opera_mem_read32(CURRENTCCB + 4));
          else
            LoadXYPosFromRegisters();
        }

      CURRENTCCB += 8;

      if(flag_is_set(CCBFLAGS,CCB_PXOR))
        {
          PXOR1 = 0;
          PXOR2 = 0x1F1F1F1F;
        }
      else
        {
          PXOR1 = 0xFFFFFFFF;
          PXOR2 = 0;
        }

      /*
        Get the VH value for this cel. This is done in case the
        cel later decides to use the position as the source of
        its VH values in the projector.
      */
      CEL_ORIGIN_VH_VALUE = ((XPOS1616 & 0x1) | ((YPOS1616 & 0x1) << 15));

      if(flag_is_set(CCBFLAGS,CCB_LDSIZE))
        {
          HDX1616     = ((int32_t)opera_mem_read32(CURRENTCCB)) >> 4;
          CURRENTCCB += 4;
          HDY1616     = ((int32_t)opera_mem_read32(CURRENTCCB)) >> 4;
          CURRENTCCB += 4;
          VDX1616     = opera_mem_read32(CURRENTCCB);
          CURRENTCCB += 4;
          VDY1616     = opera_mem_read32(CURRENTCCB);
          CURRENTCCB += 4;
        }

      if(flag_is_set(CCBFLAGS,CCB_LDPRS))
        {
          HDDX1616    = ((int32_t)opera_mem_read32(CURRENTCCB)) >> 4;
          CURRENTCCB += 4;
          HDDY1616    = ((int32_t)opera_mem_read32(CURRENTCCB)) >> 4;
          CURRENTCCB += 4;
        }

      if(flag_is_set(CCBFLAGS,CCB_LDPPMP))
        {
          PIXC        = opera_mem_read32(CURRENTCCB);
          CURRENTCCB += 4;
        }

      if(flag_is_set(CCBFLAGS,CCB_CCBPRE))
        {
          PRE0        = opera_mem_read32(CURRENTCCB);
          CURRENTCCB += 4;
          if(flag_is_clr(CCBFLAGS,CCB_PACKED))
            {
              PRE1        = opera_mem_read32(CURRENTCCB);
              CURRENTCCB += 4;
            }
        }
      else
        {
          PRE0   = opera_mem_read32(PDATA);
          PDATA += 4;
          if(flag_is_clr(CCBFLAGS,CCB_PACKED))
            {
              PRE1   = opera_mem_read32(PDATA);
              PDATA += 4;
            }
        }

      /* Local modification for OperaU, see third_party/patches/: the tables that hold everything the pixel
         processor will do for this cel are dropped here and rebuilt when a pixel first needs them. */
      pp_invalidate_luts();
      {
        PXC_t fl;
        PXC_t fh;

        fl.raw = (PIXC & 0xFFFF);
        fh.raw = (PIXC >> 16);
        g_CEL_FB_FREE = !(fl.meaning.s1 || (fl.meaning.s2 == 2) ||
                          fh.meaning.s1 || (fh.meaning.s2 == 2));
#ifdef OPERA_NO_FB_FREE
        g_CEL_FB_FREE = false; /* build with this to get the old per-pixel path, to compare the two */
#endif
        g_CEL_TEXEL_MODE = CEL_TEXEL_DECODE;
        if(g_CEL_FB_FREE && !g_CEL_TC_ON)
          {
            g_CEL_TEXEL_MODE = CEL_TEXEL_CHAIN;
          }
        else if(g_CEL_FB_FREE)
          {
            g_CEL_TC_CEL += 0x00010000;
            if(g_CEL_TC_CEL == 0)
              {
                memset(g_CEL_TC,0,sizeof(g_CEL_TC));
                g_CEL_TC_CEL = 0x00010000;
              }

            g_CEL_TEXEL_MODE = CEL_TEXEL_LOOKUP;
            if((PRE0 & PRE0_BPP_MASK) == PRE0_BPP_16)
              {
                g_CEL_TEXEL_MODE = CEL_TEXEL_TRIAL;
                g_CEL_TC_FOUND   = 0;
                g_CEL_TC_MISSED  = 0;
              }
          }
      }

      /* Local modification for OperaU, see third_party/patches/: one count per cel, only while the front end is
         profiling, so that the shape of a real game's cel work can be read off the log. */
      if(opera_prof_enabled)
        {
          PXC_t pl, ph;

          pl.raw = (PIXC & 0xFFFF);
          ph.raw = (PIXC >> 16);
          opera_prof.cel_useav    += (flag_is_set(CCBFLAGS,CCB_USEAV) != 0);
          opera_prof.cel_blackfix += (flag_is_clr(CCBFLAGS,CCB_NOBLK) != 0);
          opera_prof.cel_twopixc  += (pl.raw != ph.raw);
          opera_prof.cel_s1       += pl.meaning.s1;
          opera_prof.cel_s2[pl.meaning.s2]++;
          /* either half can be the one a pixel picks, so a read of the frame buffer in either half counts */
          opera_prof.cel_fbread   += (pl.meaning.s1 || (pl.meaning.s2 == 2)
                                      || ph.meaning.s1 || (ph.meaning.s2 == 2));
          opera_prof.cel_ms[pl.meaning.ms]++;
          opera_prof.cel_bpp[PRE0 & PRE0_BPP_MASK]++;

          g_CEL_PX_BEFORE = g_CEL_PIXELS_DRAWN;
        }

      /* PDEC data compute */
      {
        /* pdec.mode = PRE0 & PRE0_BPP_MASK; */
        switch(PRE0 & PRE0_BPP_MASK)
          {
            /*
              WO1994010642A1 describes BPP=0 in the low-bit-depth PIP load
              group with BPP=1 and BPP=2, rather than as a CEL no-op.
            */
          case PRE0_BPP_RESERVED_0:
          case PRE0_BPP_1:
            pdec.plutaCCBbits  = ((CCBFLAGS & 0x0F) * 4);
            pdec.pixelBitsMask = 1; /* 1 bit */
            break;
          case PRE0_BPP_RESERVED_7:
            continue;
          case PRE0_BPP_2:
            pdec.plutaCCBbits  = ((CCBFLAGS & 0x0E) * 4);
            pdec.pixelBitsMask = 3; /* 2 bit */
            break;
          case PRE0_BPP_4:
          default:
            pdec.plutaCCBbits  = ((CCBFLAGS & 0x08) * 4);
            pdec.pixelBitsMask = 15; /* 4 bit */
            break;
          }

        pproj.pmode        = (CCBFLAGS & CCB_POVER_MASK);
        pproj.pmodeORmask  = ((pproj.pmode == PMODE_ONE ) ? 0x8000 : 0x0000);
        pproj.pmodeANDmask = ((pproj.pmode != PMODE_ZERO) ? 0xFFFF : 0x7FFF);
      }

      if(flag_is_set(CCBFLAGS,CCB_LDPLUT))
        {
          switch(PRE0 & PRE0_BPP_MASK)
            {
            case PRE0_BPP_RESERVED_0:
            case PRE0_BPP_1:
              LoadPLUT(PLUTDATA,2);
              break;
            case PRE0_BPP_2:
              LoadPLUT(PLUTDATA,4);
              break;
            case PRE0_BPP_4:
              LoadPLUT(PLUTDATA,16);
              break;
            default:
              LoadPLUT(PLUTDATA,32);
            };
        }

      if(flag_is_set(CCBFLAGS,CCB_SKIP))
        continue;

      /* Local modification for OperaU, see third_party/patches/: which of the three kinds of cel this was and
         which of the three texel paths drew it. Read after the call, where TEXEL_DRAW_FUNC holds what was used.
         One count per cel, only while profiling: this is the first thing to know before optimising the engine,
         because the three paths cost very different amounts and the BIOS exercises almost none of them. */
      if(flag_is_set(CCBFLAGS,CCB_PACKED))
        {
          DrawPackedCel();
          if(opera_prof_enabled)
            opera_prof.cel_type[0]++;
        }
      else if(flag_is_set(PRE1,PRE1_LRFORM) && (BPP[PRE0 & PRE0_BPP_MASK] == 16))
        {
          DrawLRCel();
          if(opera_prof_enabled)
            opera_prof.cel_type[1]++;
        }
      else
        {
          DrawLiteralCel();
          if(opera_prof_enabled)
            opera_prof.cel_type[2]++;
        }

      if(opera_prof_enabled && (uint32_t)TEXEL_DRAW_FUNC < 3)
        opera_prof.cel_draw[TEXEL_DRAW_FUNC]++;
      if(opera_prof_enabled)
        opera_prof.cel_route[(g_CEL_TEXEL_MODE == CEL_TEXEL_DECODE) ? 2 :
                             (g_CEL_TEXEL_MODE == CEL_TEXEL_CHAIN)  ? 1 : 0]++;

      /* Local modification for OperaU, see third_party/patches/: the pixels of the cels that are mixed with the
         frame buffer, which cost several times the others. */
      if(opera_prof_enabled && !g_CEL_FB_FREE)
        opera_prof.cel_fbread_px += (g_CEL_PIXELS_DRAWN - g_CEL_PX_BEFORE);
    }

  clr_flag(STATBITS,SPRON);

  /*
    The list is done, but the engine stays busy (and SPRON stays set)
    while it renders, so the CPU that polls STATBITS is paced like the
    hardware instead of racing ahead.
  */
  madam_cel_busy_start();
}

static
void
HandleDMA8(void)
{
  /* pbus transfer */
  if(MADAM.mregs[MADAM_REG_MCTL] & MADAM_MCTL_PLAYXEN)
    {
      DMAPBus();
      MADAM.mregs[MADAM_REG_MCTL] &= ~MADAM_MCTL_PLAYXEN; /* dma done */
      opera_clio_fiq_generate(0,1);
    }
}

static
void
DMAPBus(void)
{
  uint32_t *pbus_buf;
  int32_t   pbus_size;

  if((int32_t)MADAM.mregs[MADAM_REG_DMA8_LEN] < 0)
    return;

  opera_pbus_pad();

  /*
    Portfolio OS src/app/oper/ControlPort.c, EnableControlPort(), sets
    RAMtofrPLAYER[1] = cpDMASize - 4. The first DMA word is control-port
    sludge; Length counts bytes after it.
  */
  opera_io_write(MADAM.mregs[MADAM_REG_DMA8_DEST],0xFFFFFFFF);
  MADAM.mregs[MADAM_REG_DMA8_DEST] += 4;
  MADAM.mregs[MADAM_REG_DMA8_PROGRESS] += 4;

  pbus_buf  = opera_pbus_buf();
  pbus_size = opera_pbus_size();
  while(((int32_t)MADAM.mregs[MADAM_REG_DMA8_LEN] > 0) && (pbus_size > 0))
    {
      opera_io_write(MADAM.mregs[MADAM_REG_DMA8_DEST],
                     swap32_if_little_endian(*pbus_buf));
      pbus_buf++;
      pbus_size          -= 4;
      MADAM.mregs[MADAM_REG_DMA8_LEN] -= 4;
      MADAM.mregs[MADAM_REG_DMA8_DEST] += 4;
      MADAM.mregs[MADAM_REG_DMA8_PROGRESS] += 4;
    }

  while((int32_t)MADAM.mregs[MADAM_REG_DMA8_LEN] > 0)
    {
      opera_io_write(MADAM.mregs[MADAM_REG_DMA8_DEST],0xFFFFFFFF);
      MADAM.mregs[MADAM_REG_DMA8_LEN] -= 4;
      MADAM.mregs[MADAM_REG_DMA8_DEST] += 4;
      MADAM.mregs[MADAM_REG_DMA8_PROGRESS] += 4;
    }

  MADAM.mregs[MADAM_REG_DMA8_LEN] = MADAM_DMA8_IDLE_LEN;
}

void
opera_madam_init()
{
  int32_t i;
  int32_t j;
  int32_t n;

  opera_madam_reset();

  bitoper.bitset = 1;

  MADAM.FSM = FSM_IDLE;

  MADAM.mregs[MADAM_REG_ID] = ((ME_MODE == ME_MODE_HARDWARE) ?
                               MADAM_ID_GREEN_HARDWARE :
                               MADAM_ID_GREEN_SOFTWARE);

  /* DRAM dux init */
  MADAM.mregs[MADAM_REG_MSYSBITS] = opera_mem_madam_red_sysbits(MADAM_SYSBITS_RED);
  MADAM.mregs[MADAM_REG_DMA8_LEN] = MADAM_DMA8_IDLE_LEN;

  for(i = 0; i < 32; i++)
    for(j = 0; j < 8; j++)
      for(n = 0; n < 4; n++)
        PSCALAR[j][n][i] = ((i * (j + 1)) >> PDV(n));

  for(i = 0; i < 256; i++)
    {
      pdeco_t  pix1;
      pdeco_t  pix2;
      uint16_t pres;
      uint16_t resamv;

      pix1.raw     = i;
      pix2.r16b.b  = (pix1.u8b.b << 3) + (pix1.u8b.b << 1) + (pix1.u8b.b >> 1);
      pix2.r16b.g  = (pix1.u8b.g << 2) + (pix1.u8b.g >> 1);
      pix2.r16b.r  = (pix1.u8b.r << 2) + (pix1.u8b.r >> 1);
      pres         = pix2.raw;
      pres        &= 0x7fff;
      MAPu8b[i]    = pres;

      resamv       = ((pix1.c8b.m << 1) + pix1.c8b.mpw);
      resamv       = ((resamv << 6) + (resamv << 3) + resamv);
      MAPc8bAMV[i] = resamv;
    }

  for(i = 0; i < (8*8*8); i++)
    {
      pdeco_t pix1;

      pix1.raw = i << 5;
      MAPc16bAMV[i] = ((pix1.c16b.mr << 6) + (pix1.c16b.mg << 3) + pix1.c16b.mb);
    }
}

/*
  https://3dodev.com?do=search&id=start&q=UNCLSB
  https://3dodev.com?do=search&id=start&q=PDCLSB
*/
static
uint16_t
PDEC_SubstituteBlueLSB(const uint16_t pixel_,
                       const uint32_t mode_)
{
  uint16_t blueLSB;

  switch(mode_ & 0x3)
    {
    default:
    case 0:
      blueLSB = 0;
      break;
    case 1:
      blueLSB = (pixel_ & 0x1);
      break;
    case 2:
      blueLSB = ((pixel_ >> 4) & 0x1);
      break;
    case 3:
      blueLSB = ((pixel_ >> 5) & 0x1);
      break;
    }

  return ((pixel_ & ~0x1) | blueLSB);
}

static
uint32_t
PDEC(const uint32_t  pixel_,
     uint16_t       *amv_)
{
  pdeco_t pix1;
  uint16_t resamv;
  uint16_t pres;

  pix1.raw = pixel_;

  switch(PRE0 & PRE0_BPP_MASK)
    {
    default:
    case PRE0_BPP_RESERVED_0:
    case PRE0_BPP_1:
    case PRE0_BPP_2:
    case PRE0_BPP_4:
      pres   = MADAM.PLUT[(pdec.plutaCCBbits + ((pix1.raw & pdec.pixelBitsMask) * 2)) >> 1];
      resamv = 0x49;
      break;

    case PRE0_BPP_6:
      /* pmode = pix1.c6b.pw; ??? */
      pres   = MADAM.PLUT[pix1.c6b.c];
      pres   = (pres & 0x7FFF) + (pix1.c6b.pw << 15);
      resamv = 0x49;
      break;

    case PRE0_BPP_8:
      if(flag_is_set(PRE0,PRE0_LINEAR))
        {
          pres   = MAPu8b[pix1.raw & 0xFF];
          resamv = 0x49;
        }
      else
        {
          pres   = MADAM.PLUT[pix1.c8b.c];
          resamv = MAPc8bAMV[pix1.raw & 0xFF];
        }
      break;

    case PRE0_BPP_16:
    case PRE0_BPP_RESERVED_7:
      if(flag_is_set(PRE0,PRE0_LINEAR))
        {
          pres   = pix1.raw;
          resamv = 0x49;
        }
      else
        {
          pres   = MADAM.PLUT[pix1.c16b.c];
          pres   = ((pres & 0x7FFF) | (pixel_ & 0x8000));
          resamv = MAPc16bAMV[(pix1.raw >> 5) & 0x1FF];
        }

      break;
    }

  *amv_ = resamv;

  /* Saving bit 0 (blue lsb) and bit 15 (p-mode) */
  pdec.rawVHBits = (pres & 0x8001);

  /* Transparency is determined before projector blue-LSB substitution. */
  pproj.Transparent = (flag_is_clr(CCBFLAGS,CCB_BGND) &&
                       IS_RGB15_BLACK(pres));

  if(flag_is_clr(CCBFLAGS,CCB_PACKED))
    pres = PDEC_SubstituteBlueLSB(pres,((PRE1 & PRE1_TLLSB_MASK) >> PRE1_TLLSB_SHIFT));
  else
    pres = PDEC_SubstituteBlueLSB(pres,((CECONTROL & PDCLSB_MASK) >> PDCLSB_SHIFT));

  /* conceptual end of decoder */

  /*
    TODO: Do PROJECTOR functions now?
    They'll be done before using the PROCESSOR.

    if(!(PRE1&PRE1_NOSWAP) && (CECONTROL&(1<<27)))
    pres = (pres&0x7ffe)|((pres&0x8000)>>15)|((pres&1)<<15);

    if(!(CECONTROL & 0x80000000))
    pres = (pres&0x7fff)|((CECONTROL>>15)&0x8000);

    pres=(pres|pdec.pmodeORmask)&pdec.pmodeANDmask;
  */

  return pres;
}

static
INLINE
uint8_t
BitReaderBig_ReadLRByte(const struct BitReaderBig *bit_,
                        const uint32_t             point_)
{
  return opera_mem_read8(bit_->buf + ((point_ & 1) + ((point_ >> 1) << 2)));
}

static
uint32_t
BitReaderBig_ReadLRForm(struct BitReaderBig *bit_,
                        const uint8_t        bits_)
{
  uint32_t i;
  uint32_t retval;

  retval = 0;
  BitReaderBig_SetBitRate(bit_,bits_);

  if(!bit_->buf)
    return retval;

  for(i = 0; i < (uint32_t)bit_->bitset; i++)
    {
      retval <<= 1;
      retval  |= ((BitReaderBig_ReadLRByte(bit_,bit_->point) >> (7 - bit_->bitpoint)) & 1);

      bit_->bitpoint++;
      if(bit_->bitpoint == 8)
        {
          bit_->bitpoint = 0;
          bit_->point++;
        }
    }

  return retval;
}

static
uint32_t
PPROJ_OUTPUT(uint32_t pproc_output_,
             uint32_t pframe_input_)
{
  int32_t  b15mode;
  int32_t  b0mode;
  uint32_t VHOutput;

  /*
    CCB_PLUTPOS flag
    Determine projector's originating source of VH values.
  */

  if(flag_is_set(CCBFLAGS,CCB_PLUTPOS)) /* Use pixel decoder output. */
    VHOutput = pdec.rawVHBits;
  else /* Use VH values determined from the CEL's origin. */
    VHOutput = CEL_ORIGIN_VH_VALUE;

  /*
    SWAPHV flag
    Swap the H and V values now if requested.
  */
  if(flag_is_set(CECONTROL,SWAPHV))
    {
      /* TODO: I have read that PRE1 is only set for unpacked CELs.
         So... should this be ignored if using packed CELs? I don't
         know. */
      if(flag_is_clr(PRE1,PRE1_NOSWAP))
        VHOutput = ((VHOutput >> 15) | ((VHOutput & 1) << 15));
    }

#if 0
  /*
    CFBDSUB flag
    Substitute the VH values from the frame buffer if requested.
  */
  if(flag_is_set(CECONTROL,CFBDSUB))
    {
      /* TODO: This should be re-enabled sometime. However, it currently
         causes the wing commander 3 movies to screw up again! There
         must be some missing mbehavior elsewhere. */
      VHOutput = (pframe_input & 0x8001);
    }
#endif

  /*
    B15POS_MASK settings
    Substitute the V value explicitly if requested.
  */
  b15mode = (CECONTROL & B15POS_MASK);
  switch(b15mode)
    {
    case B15POS_PDC:
    default:
      /* do nothing */
      break;
    case B15POS_0:
      VHOutput = (VHOutput & ~0x8000);
      break;
    case B15POS_1:
      VHOutput |= 0x8000;
      break;
    }

  /*
    B15POS_MASK settings
    Substitute the H value explicitly if requested.
  */
  b0mode = (CECONTROL & B0POS_MASK);
  switch(b0mode)
    {
    case B0POS_PDC:
      /* do nothing  */
      break;
    case B0POS_PIXC:
      /* Use LSB from pixel processor output. */
      VHOutput = ((VHOutput & ~0x1) | (pproc_output_ & 0x1));
      break;
    case B0POS_0:
      VHOutput = (VHOutput & ~0x1);
      break;
    case B0POS_1:
      VHOutput |= 0x01;
      break;
    }

  return ((pproc_output_ & 0x7FFE) | VHOutput);
}

#ifndef MAX
#define MAX(a, b) ((a) > (b) ? (a) : (b))
#endif

#ifndef MIN
#define MIN(a, b) ((a) < (b) ? (a) : (b))
#endif

#ifndef CLAMP
#define CLAMP(x, a, b) (MIN(b,MAX(x,a)))
#endif

static
OPERA_FORCEINLINE
int8_t
clamp_i8(const int8_t x_,
         const int8_t min_,
         const int8_t max_)
{
  return CLAMP(x_,min_,max_);
}

/*
  Local modification for OperaU, see third_party/patches/.

  Nearly every cel a game draws uses the pixel processor in one narrow way, and a real game says how narrow:
  measured over 1.7 million cels of a running game, CCB_USEAV was never set, s1 was always 0, ms was 0 for 98% of
  them and the colour-2 source was anything other than the frame buffer for 98%.

  In that shape each output channel depends only on the five bits of the same channel of the source pixel, and on
  values that are fixed for the whole cel. So the answer for all 32 possible values is worked out once per cel,
  here, and PPROC() then costs three table lookups instead of the whole pipeline.

  A table is built for each half of PIXC - the source pixel's top bit chooses between them - and a half that does
  not fit the shape above is marked unusable, so those pixels take the ordinary path, which is left as it was.
  The lanes sit in PXOR1/PXOR2 as R in the low byte, then B, then G, the same order the unions in PPROC() use.
*/
static uint8_t g_pp_lut[2][3][32];  /* [PIXC half][0 = R, 1 = G, 2 = B][source value] */
static int8_t  g_pp_lut_state[2];   /* -1 = not built for this cel, 0 = unusable, 1 = usable, 2 = usable per AMV,
                                        3 = two pixels in, 4 = two pixels in per AMV: see g_pp2d */
static bool    g_pp_lut_fpix[2];    /* the tables are indexed by the frame buffer pixel, not the source pixel */
/*
  The same tables for the one scale mode the ones above leave out: ms 1, where the multiplier of each channel
  comes from the AMV the pixel decoder hands over with the texel. There are only eight multipliers, so there is a
  table per multiplier, built the first time a texel asks for it. State 2 in g_pp_lut_state means "use these".
  On the console this mode carries about 70% of the pixels of the heaviest game measured, which the tables above
  therefore never served.
*/
static uint8_t g_pp_lut_amv[2][8][3][32]; /* [PIXC half][multiplier][0 = R, 1 = G, 2 = B][source value] */
static uint8_t g_pp_lut_amv_built[2];     /* one bit per multiplier already built for this cel */
/*
  A table costs 96 runs of one channel of the pipeline to build, and a small cel may ask for several multipliers
  and then draw a dozen pixels. So the first calls for each half go down the long path, and the tables are only
  started once the cel has shown it is big enough to pay for them. Both paths give the same answer; this only
  chooses the cheaper.

  The plain tables wait the same way in a cel that cannot see the frame buffer. Such a cel comes to PPROC() once
  for each source value it uses, not once for each pixel (see TEXEL()), and most cels use fewer values than a
  table has entries: sixteen for a 4-bit sprite. Building the table for them was the largest cost left per cel.
*/
#define PP_LUT_WARMUP 64
static uint8_t g_pp_lut_calls[2]; /* calls PPROC() has had for each half of PIXC in this cel, up to the above */

/*
  The tables above cover a pixel processor that reads one pixel. The shapes they leave out read two - the source
  pixel and the one already in the frame buffer - which is how a cel is mixed into the picture behind it: a
  shadow, a pane of glass, a fade. Those went down the whole pipeline for every pixel, at several times the cost
  of the rest, and in the games measured on the console they are anything from none to nine tenths of the pixels.

  Each output channel still depends only on the same channel of the two pixels, five bits each, and on values
  fixed for the cel. So there is a table of 32 x 32 answers. It is ten times the size of the ones above and a cel
  cannot pay for building it, but what it is built from is small - one half of PIXC, two flags of the CCB and,
  for ms 1, the multiplier - and a game mixes in a handful of ways that it keeps using. So the tables are kept
  from one cel to the next and from one frame to the next, found again by those values, and one is only built
  once the pipeline has run a few hundred times for the same values without it. Until then the pipeline runs as
  before, and the table is asked for again only every so many pixels, so that waiting for one costs next to
  nothing.

  The three channels use the same table: PXOR1 and PXOR2, the only values here that are stored per channel, hold
  the same byte in each. That is checked when a table is built, and a cel for which it did not hold would simply
  keep to the pipeline.
*/
#define PP2D_TABLES 32
#define PP2D_WANTED 256 /* runs of the pipeline for the same values before a table is built for them */
#define PP2D_STRIDE 16  /* and how many of those runs go by between one look for the table and the next */
typedef struct pp2d_s pp2d_t;
struct pp2d_s
{
  uint32_t key;       /* what the table was built from, 0 = empty: see pp2d_key() */
  uint32_t used;      /* g_pp2d_clock when it was last handed out: the smallest goes when room is needed */
  uint8_t  out[1024]; /* [(source channel << 5) | frame buffer channel] */
};
static pp2d_t         g_pp2d[PP2D_TABLES];
static uint32_t       g_pp2d_clock     = 0;
static uint32_t       g_pp2d_cel_clock = 0; /* the clock when the cel being drawn started: later ones are in use */
static const uint8_t *g_pp2d_now[2][8];     /* the tables in hand for this cel, per half of PIXC and multiplier */
static uint8_t        g_pp2d_have[2];       /* one bit per multiplier: the pointer above is good for this cel */
static uint8_t        g_pp2d_wait[2];       /* runs of the pipeline still to go before the table is asked for again */
static struct
{
  uint32_t key;
  uint32_t count;
} g_pp2d_wanted[16];                        /* how often the pipeline ran for values that have no table yet */
static uint32_t       g_pp2d_wanted_next = 0; /* the entry above that the next new set of values takes over */

/* Called once per cel. The tables themselves are built only when a pixel actually needs them: many cels are
   clipped away and draw nothing at all (74% of them in one game measured), and a cel that draws a handful of
   pixels would not repay building a 96-entry table up front. Only the half of PIXC a pixel asks for is built. */
static
void
pp_invalidate_luts(void)
{
  g_pp_lut_state[0] = -1;
  g_pp_lut_state[1] = -1;
  g_pp_lut_calls[0] = 0;
  g_pp_lut_calls[1] = 0;
  g_pp2d_have[0]    = 0;
  g_pp2d_have[1]    = 0;
  g_pp2d_wait[0]    = 0;
  g_pp2d_wait[1]    = 0;
  g_pp2d_cel_clock  = g_pp2d_clock;
}

static
void
pp_build_lut_half(const uint32_t h)
{
  static const int lane_shift[3] = {0, 16, 8}; /* R, G, B inside PXOR1/PXOR2 */

    {
      AVS_t    AV;
      PXC_t    pixc;
      uint32_t lane;

      g_pp_lut_state[h] = 0;

      pixc.raw = (h ? (PIXC >> 16) : (PIXC & 0xFFFF));

      /*
        The tables hold the answer for all 32 values of one 5-bit colour field, so they can only be built when
        every value the pipeline reads comes from that same field. Colour 1 reads the source pixel or the frame
        buffer pixel, depending on s1; the other reads have to agree with it:
          - ms 1 reads the AMV, which changes per texel: not these tables, but g_pp_lut_amv below
          - ms 2 and 3 read the source pixel, so they need colour 1 to read it too (s1 = 0)
          - s2 2 reads the frame buffer pixel (s1 = 1), s2 3 reads the source pixel (s1 = 0)
          - s2 0 and 1 read no pixel at all, so they fit either way
        Everything else here - the AV signals, PXOR1/PXOR2, dv1, dv2, mxf - is fixed for the whole cel.
      */
      if(((pixc.meaning.ms >= 2) && pixc.meaning.s1)  ||
         ((pixc.meaning.s2 == 2) && !pixc.meaning.s1) ||
         ((pixc.meaning.s2 == 3) && pixc.meaning.s1))
        {
          /* two pixels in: not these tables, but g_pp2d */
#ifndef OPERA_NO_PP_2D
          g_pp_lut_state[h] = ((pixc.meaning.ms == 1) ? 4 : 3);
#endif
          return;
        }
      if(pixc.meaning.ms == 1)
        {
          /* The AMV changes per texel but takes only eight values per channel: see g_pp_lut_amv. */
#ifndef OPERA_NO_PP_LUT_AMV
          g_pp_lut_amv_built[h] = 0;
          g_pp_lut_fpix[h]      = (pixc.meaning.s1 != 0);
          g_pp_lut_state[h]     = 2;
#endif
          return;
        }

      if(flag_is_set(CCBFLAGS,CCB_USEAV))
        {
          AV.raw = pixc.meaning.av;
        }
      else
        {
          AV.raw            = 0;
          AV.avsignal.dv3   = 0;
          AV.avsignal.nCLIP = 0;
          AV.avsignal.XTEND = 0;
          AV.avsignal.NEG   = 0;
        }

      for(lane = 0; lane < 3; lane++)
        {
          const int8_t px1 = (int8_t)(PXOR1 >> lane_shift[lane]);
          const int8_t px2 = (int8_t)(PXOR2 >> lane_shift[lane]);
          uint32_t     v;

          for(v = 0; v < 32; v++)
            {
              int8_t c1;
              int8_t c2;
              int8_t aop;
              int8_t bop;
              int8_t o;

              switch(pixc.meaning.ms)
                {
                case 0:
                  c1 = (int8_t)PSCALAR[pixc.meaning.mxf][pixc.meaning.dv1][v];
                  break;
                case 2:
                  c1 = (int8_t)PSCALAR[v >> 2][v & 3][v];
                  break;
                default: /* case 3 */
                  c1 = (int8_t)PSCALAR[v >> 2][pixc.meaning.dv1][v];
                  break;
                }

              switch(pixc.meaning.s2)
                {
                case 0:
                  c2 = 0;
                  break;
                case 1:
                  c2 = (int8_t)(pixc.meaning.av >> AV.avsignal.dv3);
                  break;
                default: /* cases 2 and 3: colour 2 is the same pixel colour 1 reads */
                  c2 = (int8_t)(v >> AV.avsignal.dv3);
                  break;
                }

              aop = (int8_t)(c1 & px1);
              c1  = (int8_t)(c1 & px2);
              bop = (int8_t)(AV.avsignal.NEG ? (c2 ^ (int8_t)0xFF) : (c2 ^ c1));

              if(AV.avsignal.XTEND)
                bop = (int8_t)(((int)bop << 3) >> 3); /* in `int`, so this gives the value straight back */

              o = (int8_t)((aop + bop + AV.avsignal.NEG) >> pixc.meaning.dv2);
              if(!AV.avsignal.nCLIP)
                o = clamp_i8(o,0,31);

              g_pp_lut[h][lane][v] = (uint8_t)(o & 0x1F);
            }
        }

      g_pp_lut_fpix[h]  = (pixc.meaning.s1 != 0);
      g_pp_lut_state[h] = 1;
    }
}

/*
  One multiplier's worth of the tables for ms 1. The body is pp_build_lut_half()'s, line for line, with the one
  difference that colour 1 is scaled by the multiplier given instead of by the cel's own.
*/
static
void
pp_build_lut_amv(const uint32_t h,
                 const uint32_t m)
{
  static const int lane_shift[3] = {0, 16, 8}; /* R, G, B inside PXOR1/PXOR2 */
  AVS_t    AV;
  PXC_t    pixc;
  uint32_t lane;

  pixc.raw = (h ? (PIXC >> 16) : (PIXC & 0xFFFF));

  if(flag_is_set(CCBFLAGS,CCB_USEAV))
    {
      AV.raw = pixc.meaning.av;
    }
  else
    {
      AV.raw            = 0;
      AV.avsignal.dv3   = 0;
      AV.avsignal.nCLIP = 0;
      AV.avsignal.XTEND = 0;
      AV.avsignal.NEG   = 0;
    }

  for(lane = 0; lane < 3; lane++)
    {
      const int8_t px1 = (int8_t)(PXOR1 >> lane_shift[lane]);
      const int8_t px2 = (int8_t)(PXOR2 >> lane_shift[lane]);
      uint32_t     v;

      for(v = 0; v < 32; v++)
        {
          int8_t c1;
          int8_t c2;
          int8_t aop;
          int8_t bop;
          int8_t o;

          c1 = (int8_t)PSCALAR[m][pixc.meaning.dv1][v];

          switch(pixc.meaning.s2)
            {
            case 0:
              c2 = 0;
              break;
            case 1:
              c2 = (int8_t)(pixc.meaning.av >> AV.avsignal.dv3);
              break;
            default: /* cases 2 and 3: colour 2 is the same pixel colour 1 reads */
              c2 = (int8_t)(v >> AV.avsignal.dv3);
              break;
            }

          aop = (int8_t)(c1 & px1);
          c1  = (int8_t)(c1 & px2);
          bop = (int8_t)(AV.avsignal.NEG ? (c2 ^ (int8_t)0xFF) : (c2 ^ c1));

          if(AV.avsignal.XTEND)
            bop = (int8_t)(((int)bop << 3) >> 3);

          o = (int8_t)((aop + bop + AV.avsignal.NEG) >> pixc.meaning.dv2);
          if(!AV.avsignal.nCLIP)
            o = clamp_i8(o,0,31);

          g_pp_lut_amv[h][m][lane][v] = (uint8_t)(o & 0x1F);
        }
    }

  g_pp_lut_amv_built[h] |= (uint8_t)(1u << m);
}

/* What a table in g_pp2d is built from, and so what finds it again. Never zero. */
static
OPERA_FORCEINLINE
uint32_t
pp2d_key(const uint32_t h,
         const uint32_t m)
{
  return (0x80000000 |
          (m << 18) |
          (flag_is_set(CCBFLAGS,CCB_PXOR)  ? 0x00020000 : 0) |
          (flag_is_set(CCBFLAGS,CCB_USEAV) ? 0x00010000 : 0) |
          (h ? (PIXC >> 16) : (PIXC & 0xFFFF)));
}

/*
  One channel of PPROC()'s pipeline, for source value v_ and frame buffer value f_ of that channel and multiplier
  m_ (which only ms 1 uses). Statement for statement what PPROC() does below, with the casts written out.
*/
static
uint8_t
pp2d_channel(const PXC_t    pixc,
             const AVS_t    AV,
             const int8_t   px1,
             const int8_t   px2,
             const uint32_t v_,
             const uint32_t f_,
             const uint32_t m_)
{
  const uint32_t in1 = (pixc.meaning.s1 ? f_ : v_);
  int8_t c1;
  int8_t c2;
  int8_t aop;
  int8_t bop;
  int8_t o;

  switch(pixc.meaning.ms)
    {
    case 0:
      c1 = (int8_t)PSCALAR[pixc.meaning.mxf][pixc.meaning.dv1][in1];
      break;
    case 1:
      c1 = (int8_t)PSCALAR[m_][pixc.meaning.dv1][in1];
      break;
    case 2:
      c1 = (int8_t)PSCALAR[v_ >> 2][v_ & 3][in1];
      break;
    default: /* case 3 */
      c1 = (int8_t)PSCALAR[v_ >> 2][pixc.meaning.dv1][in1];
      break;
    }

  switch(pixc.meaning.s2)
    {
    case 0:
      c2 = 0;
      break;
    case 1:
      c2 = (int8_t)(pixc.meaning.av >> AV.avsignal.dv3);
      break;
    case 2:
      c2 = (int8_t)(f_ >> AV.avsignal.dv3);
      break;
    default: /* case 3 */
      c2 = (int8_t)(v_ >> AV.avsignal.dv3);
      break;
    }

  aop = (int8_t)(c1 & px1);
  c1  = (int8_t)(c1 & px2);
  bop = (int8_t)(AV.avsignal.NEG ? (c2 ^ (int8_t)0xFF) : (c2 ^ c1));

  if(AV.avsignal.XTEND)
    bop = (int8_t)(((int)bop << 3) >> 3); /* in `int`, so this gives the value straight back */

  o = (int8_t)((aop + bop + AV.avsignal.NEG) >> pixc.meaning.dv2);
  if(!AV.avsignal.nCLIP)
    o = clamp_i8(o,0,31);

  return (uint8_t)(o & 0x1F);
}

/*
  Puts the table for half h_ of PIXC and multiplier m_ in hand for the cel being drawn: found among those kept,
  or built if the pipeline has run often enough without it. False means there is none yet, and the caller runs
  the pipeline.
*/
static
OPERA_NOINLINE
bool
pp2d_fetch(const uint32_t h_,
           const uint32_t m_)
{
  const uint32_t key = pp2d_key(h_,m_);
  pp2d_t  *t;
  uint32_t i;

  t = NULL;
  for(i = 0; i < PP2D_TABLES; i++)
    {
      if(g_pp2d[i].key == key)
        {
          t = &g_pp2d[i];
          break;
        }
    }

  if(t == NULL)
    {
      PXC_t    pixc;
      AVS_t    AV;
      uint32_t v;
      uint32_t f;
      uint32_t w;

      /* Not kept. The caller will have run the pipeline PP2D_STRIDE times by the time it asks again, so that is
         what this call counts for. A set of values seen for the first time takes the place of the one that has
         been waiting longest. */
      for(w = 0; w < 16; w++)
        {
          if(g_pp2d_wanted[w].key == key)
            break;
        }
      if(w == 16)
        {
          w = g_pp2d_wanted_next;
          g_pp2d_wanted_next       = ((g_pp2d_wanted_next + 1) & 15);
          g_pp2d_wanted[w].key     = key;
          g_pp2d_wanted[w].count   = 0;
        }
      g_pp2d_wanted[w].count += PP2D_STRIDE;
      if(g_pp2d_wanted[w].count < PP2D_WANTED)
        return false;
      g_pp2d_wanted[w].key = 0;

      /* one table for three channels: only if the values kept per channel are the same in each */
      if((((PXOR1 >> 8) ^ PXOR1) & 0xFFFF) || (((PXOR2 >> 8) ^ PXOR2) & 0xFFFF))
        return false;

      /* the table that has gone longest without being handed out makes room, unless this cel holds it */
      t = &g_pp2d[0];
      for(i = 1; i < PP2D_TABLES; i++)
        {
          if(g_pp2d[i].used < t->used)
            t = &g_pp2d[i];
        }
      if(t->key && (t->used > g_pp2d_cel_clock))
        return false;

      pixc.raw = (h_ ? (PIXC >> 16) : (PIXC & 0xFFFF));
      if(flag_is_set(CCBFLAGS,CCB_USEAV))
        {
          AV.raw = pixc.meaning.av;
        }
      else
        {
          AV.raw            = 0;
          AV.avsignal.dv3   = 0;
          AV.avsignal.nCLIP = 0;
          AV.avsignal.XTEND = 0;
          AV.avsignal.NEG   = 0;
        }

      for(v = 0; v < 32; v++)
        {
          for(f = 0; f < 32; f++)
            t->out[(v << 5) | f] = pp2d_channel(pixc,AV,(int8_t)PXOR1,(int8_t)PXOR2,v,f,m_);
        }
      t->key = key;
      if(opera_prof_enabled)
        opera_prof.pp2d_built++;
    }

  g_pp2d_clock++;
  if(g_pp2d_clock == 0)
    {
      /* the clock went round: start the ages again, and let go of what this cel holds so nothing it still
         points at can be given away under it */
      for(i = 0; i < PP2D_TABLES; i++)
        g_pp2d[i].used = 0;
      g_pp2d_cel_clock = 0;
      g_pp2d_have[0]   = 0;
      g_pp2d_have[1]   = 0;
      g_pp2d_clock     = 1;
    }
  t->used = g_pp2d_clock;

  g_pp2d_now[h_][m_]  = t->out;
  g_pp2d_have[h_]    |= (uint8_t)(1u << m_);

  return true;
}

static
uint32_t
PPROC(uint32_t pixel_,
      uint32_t fpix_,
      uint32_t amv_)
{
  AVS_t AV;
  PXC_t pixc;

  pdeco_t input1;
  pdeco_t out;
  pdeco_t pix1;

#pragma pack(push,1)
  /*
    `raw` is masked as a packed value (PXOR1/PXOR2, 0x00FFFFFF), so the
    byte lanes must line up the same way on every host: `R` is always
    the least significant byte. (Local modification for OperaU.)
  */
  union
  {
    uint32_t raw;
    struct
    {
#if IS_BIG_ENDIAN
      int8_t a;
      int8_t G;
      int8_t B;
      int8_t R;
#else
      int8_t R;
      int8_t B;
      int8_t G;
      int8_t a;
#endif
    };
  } color1, color2, AOP, BOP;
#pragma pack(pop)

  /*
    Set PMODE according to the values set up in the CCBFLAGS word.
    (This merely uses masks here because it's faster).
    This is a duty of the PROJECTOR, but we'll do it here because its
    easier.
  */
  pixel_ = ((pixel_ | pproj.pmodeORmask) & pproj.pmodeANDmask);

  /* The whole pipeline below, already worked out for this cel: see pp_build_luts(). */
  {
    const uint32_t h = ((pixel_ & 0x8000) ? 1u : 0u);

    if(g_pp_lut_state[h] < 0)
      {
        /* see PP_LUT_WARMUP: with the state left at "not built" this call takes the long path below */
        if(g_CEL_FB_FREE && (g_pp_lut_calls[h] < PP_LUT_WARMUP))
          g_pp_lut_calls[h]++;
        else
          pp_build_lut_half(h);
      }

    if(g_pp_lut_state[h] == 1)
      {
        const uint32_t v = (g_pp_lut_fpix[h] ? fpix_ : pixel_);
        uint32_t o;

        o = (((uint32_t)g_pp_lut[h][0][((v >> 10) & 0x1F)] << 10) |
             ((uint32_t)g_pp_lut[h][1][((v >>  5) & 0x1F)] <<  5) |
             ((uint32_t)g_pp_lut[h][2][( v        & 0x1F)]      ));

        if(flag_is_clr(CCBFLAGS,CCB_NOBLK) && IS_RGB15_BLACK(o))
          o = RGB15_NEAR_BLACK;

        return o;
      }

    if((g_pp_lut_state[h] == 2) && (g_pp_lut_calls[h] < PP_LUT_WARMUP))
      {
        g_pp_lut_calls[h]++;
      }
    else if(g_pp_lut_state[h] == 2)
      {
        /* ms 1: the same lookup, in the table of the multiplier the AMV names for each channel. */
        const uint32_t v    = (g_pp_lut_fpix[h] ? fpix_ : pixel_);
        const uint32_t mr   = ((amv_ >> 6) & 7);
        const uint32_t mg   = ((amv_ >> 3) & 7);
        const uint32_t mb   = ( amv_       & 7);
        const uint32_t need = ((1u << mr) | (1u << mg) | (1u << mb));
        uint32_t o;

        if((g_pp_lut_amv_built[h] & need) != need)
          {
            if(!(g_pp_lut_amv_built[h] & (1u << mr)))
              pp_build_lut_amv(h,mr);
            if(!(g_pp_lut_amv_built[h] & (1u << mg)))
              pp_build_lut_amv(h,mg);
            if(!(g_pp_lut_amv_built[h] & (1u << mb)))
              pp_build_lut_amv(h,mb);
          }

        o = (((uint32_t)g_pp_lut_amv[h][mr][0][((v >> 10) & 0x1F)] << 10) |
             ((uint32_t)g_pp_lut_amv[h][mg][1][((v >>  5) & 0x1F)] <<  5) |
             ((uint32_t)g_pp_lut_amv[h][mb][2][( v        & 0x1F)]      ));

        if(flag_is_clr(CCBFLAGS,CCB_NOBLK) && IS_RGB15_BLACK(o))
          o = RGB15_NEAR_BLACK;

        return o;
      }

    if(g_pp_lut_state[h] >= 3)
      {
        /* two pixels in: the answer for each channel is in a table of (source, frame buffer), see g_pp2d. For
           ms 1 there is one table per multiplier, and the AMV names the one for each channel. */
        const uint32_t mr   = ((g_pp_lut_state[h] == 4) ? ((amv_ >> 6) & 7) : 0);
        const uint32_t mg   = ((g_pp_lut_state[h] == 4) ? ((amv_ >> 3) & 7) : 0);
        const uint32_t mb   = ((g_pp_lut_state[h] == 4) ? ( amv_       & 7) : 0);
        const uint32_t need = ((1u << mr) | (1u << mg) | (1u << mb));

        if(g_pp2d_wait[h])
          {
            /* a table was missing a moment ago: the pipeline, below, until it is time to look again */
            g_pp2d_wait[h]--;
          }
        else if(((g_pp2d_have[h] & need) != need) &&
                !(((g_pp2d_have[h] & (1u << mr)) || pp2d_fetch(h,mr)) &&
                  ((g_pp2d_have[h] & (1u << mg)) || pp2d_fetch(h,mg)) &&
                  ((g_pp2d_have[h] & (1u << mb)) || pp2d_fetch(h,mb))))
          {
            g_pp2d_wait[h] = (PP2D_STRIDE - 1);
          }
        else
          {
            uint32_t o;

            o = (((uint32_t)g_pp2d_now[h][mr][((pixel_ >> 5) & 0x3E0) | ((fpix_ >> 10) & 0x1F)] << 10) |
                 ((uint32_t)g_pp2d_now[h][mg][( pixel_       & 0x3E0) | ((fpix_ >>  5) & 0x1F)] <<  5) |
                 ((uint32_t)g_pp2d_now[h][mb][((pixel_ << 5) & 0x3E0) | ( fpix_        & 0x1F)]      ));

            if(flag_is_clr(CCBFLAGS,CCB_NOBLK) && IS_RGB15_BLACK(o))
              o = RGB15_NEAR_BLACK;

            return o;
          }
      }
  }

  /* Local modification for OperaU: from here on it is the pipeline as it always was, for what no table covers. */
  if(opera_prof_enabled)
    opera_prof.pp_long++;

  pixc.raw = (PIXC & 0xFFFF);
  if(pixel_ & 0x8000)
    pixc.raw = (PIXC >> 16);

  /*
    now let's select the sources
    1. av
    2. input1
    3. input2
    pixc.raw = 0;
  */

  if(flag_is_set(CCBFLAGS,CCB_USEAV))
    {
      AV.raw = pixc.meaning.av;
    }
  else
    {
      AV.avsignal.dv3   = 0;
      AV.avsignal.nCLIP = 0;
      AV.avsignal.XTEND = 0;
      AV.avsignal.NEG   = 0;
    }

  if(!pixc.meaning.s1)
    input1.raw = pixel_;
  else
    input1.raw = fpix_;

  switch(pixc.meaning.s2)
    {
    case 0:
      color2.raw = 0;
      break;
    case 1:
      color2.R = color2.G = color2.B = (pixc.meaning.av >> AV.avsignal.dv3);
      break;
    case 2:
      pix1.raw = fpix_;
      color2.R = ((pix1.r16b.r) >> AV.avsignal.dv3);
      color2.G = ((pix1.r16b.g) >> AV.avsignal.dv3);
      color2.B = ((pix1.r16b.b) >> AV.avsignal.dv3);
      break;
    case 3:
      pix1.raw = pixel_;
      color2.R = (pix1.r16b.r >> AV.avsignal.dv3);
      color2.G = (pix1.r16b.g >> AV.avsignal.dv3);
      color2.B = (pix1.r16b.b >> AV.avsignal.dv3);
      break;
    }

  switch(pixc.meaning.ms)
    {
    case 0:
      color1.R = PSCALAR[pixc.meaning.mxf][pixc.meaning.dv1][input1.r16b.r];
      color1.G = PSCALAR[pixc.meaning.mxf][pixc.meaning.dv1][input1.r16b.g];
      color1.B = PSCALAR[pixc.meaning.mxf][pixc.meaning.dv1][input1.r16b.b];
      break;
    case 1:
      color1.R = PSCALAR[(amv_ >> 6) & 7][pixc.meaning.dv1][input1.r16b.r];
      color1.G = PSCALAR[(amv_ >> 3) & 7][pixc.meaning.dv1][input1.r16b.g];
      color1.B = PSCALAR[(amv_ >> 0) & 7][pixc.meaning.dv1][input1.r16b.b];
      break;
    case 2:
      pix1.raw = pixel_;
      color1.R = PSCALAR[pix1.r16b.r >> 2][pix1.r16b.r & 3][input1.r16b.r];
      color1.G = PSCALAR[pix1.r16b.g >> 2][pix1.r16b.g & 3][input1.r16b.g];
      color1.B = PSCALAR[pix1.r16b.b >> 2][pix1.r16b.b & 3][input1.r16b.b];
      break;
    case 3:
      pix1.raw = pixel_;
      color1.R = PSCALAR[pix1.r16b.r >> 2][pixc.meaning.dv1][input1.r16b.r];
      color1.G = PSCALAR[pix1.r16b.g >> 2][pixc.meaning.dv1][input1.r16b.g];
      color1.B = PSCALAR[pix1.r16b.b >> 2][pixc.meaning.dv1][input1.r16b.b];
      break;
    }

  /* Use this to render magenta for testing. */
#if 0
  return RGB15_MAGENTA;
#endif

  /*
    ok -- we got the sources -- now RGB processing
  */

  /* AOP/BOP calculation */
  AOP.raw     = (color1.raw & PXOR1);
  color1.raw &= PXOR2;

  if(AV.avsignal.NEG)
    BOP.raw = (color2.raw ^ 0x00FFFFFF);
  else
    BOP.raw = (color2.raw ^ color1.raw);

  if(AV.avsignal.XTEND)
    {
      BOP.R = ((BOP.R << 3) >> 3);
      BOP.B = ((BOP.B << 3) >> 3);
      BOP.G = ((BOP.G << 3) >> 3);
    }

  color2.R = ((AOP.R + BOP.R + AV.avsignal.NEG) >> pixc.meaning.dv2);
  color2.G = ((AOP.G + BOP.G + AV.avsignal.NEG) >> pixc.meaning.dv2);
  color2.B = ((AOP.B + BOP.B + AV.avsignal.NEG) >> pixc.meaning.dv2);

  if(!AV.avsignal.nCLIP)
    {
      color2.R = clamp_i8(color2.R,0,31);
      color2.G = clamp_i8(color2.G,0,31);
      color2.B = clamp_i8(color2.B,0,31);
    }

  out.raw    = 0;
  out.r16b.r = color2.R;
  out.r16b.g = color2.G;
  out.r16b.b = color2.B;

  /* TODO: Is this something the PROJECTOR should do? */
  if(flag_is_clr(CCBFLAGS,CCB_NOBLK) && IS_RGB15_BLACK(out.raw))
    out.raw = RGB15_NEAR_BLACK;

  /*
    if(!(PRE1 & PRE1_NOSWAP) && (CECONTROL & (1 << 27)))
    out.raw = ((out.raw & 0x7FFE) |
    ((out.raw & 0x8000) >> 15) |
    ((out.raw & 1) << 15));
  */

  /*
    if(!(CECONTROL & 0x80000000))
    out.raw = ((out.raw & 0x7FFF) | ((CECONTROL >> 15) & 0x8000));
  */

  return out.raw;
}


/* Local modification for OperaU, see g_CEL_TC: where a source value's finished pixel is kept. Values of up to
   eight bits each get a slot of their own among the first 256; wider ones are spread over all of them. */
#define CEL_TC_SLOT(raw_) (&g_CEL_TC[((raw_) ^ ((raw_) >> 6) ^ ((raw_) >> 12)) & (CEL_TC_SLOTS - 1)])

/*
  Local modification for OperaU, see g_CEL_TEXEL_MODE: a texel taken through the decoder, the pixel processor and
  the projector, as every texel used to be, for a cel that cannot see the frame buffer. Kept out of line: the
  lookup that usually stands in for it is what the drawing loops should be made of.
*/
static
OPERA_NOINLINE
uint32_t
TEXEL_chain(const uint32_t  raw_,
            uint16_t       *amv_)
{
  uint32_t p;

  p = PDEC(raw_,amv_);
  if(!pproj.Transparent)
    {
      p = PPROC(p,0,*amv_);
      p = PPROJ_OUTPUT(p,0);
    }

  return (p & 0xFFFF);
}

/* Local modification for OperaU, see g_CEL_TC: a source value the cel being drawn has not shown before. */
static
OPERA_NOINLINE
uint32_t
TEXEL_first_seen(const uint32_t  raw_,
                 uint16_t       *amv_)
{
  const uint32_t p = TEXEL_chain(raw_,amv_);

  if(raw_ <= 0xFFFF)
    {
      cel_tc_t *const slot = CEL_TC_SLOT(raw_);

      slot->key   = (g_CEL_TC_CEL | raw_);
      slot->value = (p | (pproj.Transparent ? 0x10000 : 0));
    }

  return p;
}

/* Local modification for OperaU, see CEL_TC_TRIAL_TEXELS: the lookup, counted, for a cel still on trial. */
static
OPERA_NOINLINE
uint32_t
TEXEL_trial(const uint32_t  raw_,
            uint16_t       *amv_)
{
  const cel_tc_t *const slot = CEL_TC_SLOT(raw_);
  uint32_t p;

  if(slot->key == (g_CEL_TC_CEL | raw_))
    {
      g_CEL_TC_FOUND++;
      pproj.Transparent = (int)(slot->value >> 16);
      p = (slot->value & 0xFFFF);
    }
  else
    {
      g_CEL_TC_MISSED++;
      p = TEXEL_first_seen(raw_,amv_);
    }

  if((g_CEL_TC_FOUND + g_CEL_TC_MISSED) >= CEL_TC_TRIAL_TEXELS)
    g_CEL_TEXEL_MODE = (((g_CEL_TC_FOUND * 8) >= CEL_TC_TRIAL_TEXELS) ? CEL_TEXEL_LOOKUP : CEL_TEXEL_CHAIN);

  return p;
}

/*
  Local modification for OperaU, see g_CEL_TC: what every texel goes through in place of a bare PDEC().

  It leaves pproj.Transparent as PDEC() would, so the callers are unchanged. What it returns differs by the kind
  of cel: for one that reads the frame buffer it is PDEC()'s output, as before, and the drawing functions take it
  through the pixel processor and the projector per pixel; for one that cannot see the frame buffer it is the
  finished pixel, and the drawing functions only write it. The drawing functions tell the two apart by
  g_CEL_FB_FREE, which is false exactly when the mode here is CEL_TEXEL_DECODE, so every texel of a cel has to
  come through here.
*/
static
OPERA_FORCEINLINE
uint32_t
TEXEL(const uint32_t  raw_,
      uint16_t       *amv_)
{
  const int mode = g_CEL_TEXEL_MODE;

  if(mode == CEL_TEXEL_LOOKUP)
    {
      const cel_tc_t *const slot = CEL_TC_SLOT(raw_);

      if(slot->key == (g_CEL_TC_CEL | raw_))
        {
          const uint32_t v = slot->value;

          pproj.Transparent = (int)(v >> 16);
          return (v & 0xFFFF);
        }

      return TEXEL_first_seen(raw_,amv_);
    }

  if(mode == CEL_TEXEL_DECODE)
    return PDEC(raw_,amv_);

  if(mode == CEL_TEXEL_CHAIN)
    return TEXEL_chain(raw_,amv_);

  return TEXEL_trial(raw_,amv_);
}

static
OPERA_FORCEINLINE
void
process_pixel(int32_t x_,
              int32_t y_,
              uint32_t curpix_,
              uint32_t lawv_)
{
  int32_t p;
  int32_t fp;

  /* Local modification for OperaU, see TEXEL(): the pixel arrives finished. */
  if(g_CEL_FB_FREE)
    {
      opera_mem_write16(REGCTL3 + XY2OFF(x_,y_,MADAM.wmod),curpix_);
      g_CEL_PIXELS_DRAWN++;
      return;
    }

  fp = opera_mem_read16(REGCTL2 + XY2OFF(x_,y_,MADAM.rmod));
  p  = PPROC(curpix_,fp,lawv_);
  p  = PPROJ_OUTPUT(p,fp);
  opera_mem_write16(REGCTL3 + XY2OFF(x_,y_,MADAM.wmod),p);
  g_CEL_PIXELS_DRAWN++;
}

uint32_t*
opera_madam_registers(void)
{
  return MADAM.mregs;
}

/*
  Local modification for OperaU, see third_party/patches/: BitReaderBig_Read() for the widths the cel engine asks
  for, 1 to 16 bits, written here so that it is compiled into the loops that call it once per texel. With the
  finished pixel now a lookup (see TEXEL()), reading the texel's bits through a call into another file, which
  fetched them a byte at a time behind three tests, had become the larger half of a texel's cost.

  It returns the same bits and leaves the reader at the same place. A read of up to 16 bits starting at any of
  the eight positions in a byte lies inside three bytes, so those three are fetched and the wanted bits cut out
  of them. That fetches up to two bytes the original did not; they are masked off, and the memory they sit in is
  allocated with room to spare for exactly this (see opera_mem_init()).
*/
static
OPERA_FORCEINLINE
uint32_t
cel_bits(const uint32_t bits_)
{
  const uint32_t addr = (bitoper.buf + bitoper.point);
  uint32_t pos;
  uint32_t v;

  if(!bitoper.buf)
    return 0;

  pos = (uint32_t)bitoper.bitpoint;
  v   = (((uint32_t)opera_mem_read8(addr)     << 16) |
         ((uint32_t)opera_mem_read8(addr + 1) <<  8) |
         ((uint32_t)opera_mem_read8(addr + 2)));
  v   = ((v >> (24 - pos - bits_)) & ((1u << bits_) - 1));

  pos += bits_;
  bitoper.point    += (pos >> 3);
  bitoper.bitpoint  = (int32_t)(pos & 7);

  return v;
}

static
INLINE
uint32_t
PackedSkipPixels(const uint32_t  type_,
                 const uint32_t  pixel_count_,
                 uint32_t       *skip_pixels_,
                 const uint32_t  bpp_)
{
  uint32_t skipped;

  if((*skip_pixels_ == 0) || (pixel_count_ == 0) || (type_ == PACK_EOL))
    return pixel_count_;

  skipped = (*skip_pixels_ < pixel_count_) ? *skip_pixels_ : pixel_count_;

  switch(type_)
    {
    case PACK_LITERAL:
      BitReaderBig_Skip(&bitoper,bpp_ * skipped);
      break;
    case PACK_PACKED:
      if(skipped == pixel_count_)
        BitReaderBig_Skip(&bitoper,bpp_);
      break;
    default:
      break;
    }

  *skip_pixels_ -= skipped;

  return pixel_count_ - skipped;
}

static
void
DrawPackedCel(void)
{
  int row;
  bool eor;
  uint16_t CURPIX;
  uint16_t LAMV;
  int32_t lastaddr;
  int32_t xcur;
  int32_t ycur;
  int32_t xvert;
  int32_t yvert;
  int32_t xdown;
  int32_t ydown;
  int32_t hdx;
  int32_t hdy;
  int32_t origin_x;
  int32_t origin_y;
  int32_t origin_vdx;
  int32_t origin_vdy;
  uint32_t bpp;
  uint32_t type;
  uint32_t pdata;
  uint32_t nrows;
  uint32_t offset;
  uint32_t offsetl;
  uint32_t skipx;

  pdata   = PDATA;
  nrows   = ((PRE0 & PRE0_VCNT_MASK) >> PRE0_VCNT_SHIFT);
  bpp     = BPP[PRE0 & PRE0_BPP_MASK];
  offsetl = ((bpp < 8) ? 1 : 2);
  skipx   = PRE0_SKIPX(PRE0);
  SPRHI   = nrows + 1;

  origin_x   = XPOS1616;
  origin_y   = YPOS1616;
  origin_vdx = VDX1616;
  origin_vdy = VDY1616;

  if(TestInitVisual(PACKED))
    {
      StoreXYPosFromDrawHeight(origin_x,origin_y,origin_vdx,origin_vdy,SPRHI);
      return;
    }

  xvert = XPOS1616;
  yvert = YPOS1616;

  switch(TEXEL_DRAW_FUNC)
    {
    case TEXEL_DRAW_FUNC_LINE:
      {
        uint32_t pixel_count;
        for(row = 0; row < TEXTURE_HI_LIM; row++)
          {
            int wcnt;
            int scipw;
            uint32_t src_skip;

            BitReaderBig_AttachBuffer(&bitoper,pdata);
            offset = cel_bits((offsetl << 3));

            lastaddr  = (pdata + ((offset + 2) << 2));
            eor       = false;
            xcur      = xvert;
            ycur      = yvert;
            xvert    += VDX1616;
            yvert    += VDY1616;

            if(TEXTURE_HI_START)
              {
                TEXTURE_HI_START--;
                pdata = lastaddr;
                continue;
              }

            src_skip = skipx;
            scipw = TEXTURE_WI_START;
            wcnt  = scipw;

            /* while not end of row */
            while(!eor)
              {
                type = cel_bits(2);
                if((int32_t)(bitoper.point + pdata) >= (lastaddr))
                  type = PACK_EOL;

                pixel_count = cel_bits(6) + 1;

                if(src_skip)
                  {
                    pixel_count = PackedSkipPixels(type,pixel_count,&src_skip,bpp);
                    if(!pixel_count)
                      continue;
                  }

                if(scipw)
                  {
                    if(type == PACK_EOL)
                      break;
                    if(scipw >= (int32_t)(pixel_count))
                      {
                        scipw -= (pixel_count);
                        if(HDX1616)
                          xcur += (HDX1616 * pixel_count);
                        if(HDY1616)
                          ycur += (HDY1616 * pixel_count);
                        if(type == PACK_LITERAL)
                          BitReaderBig_Skip(&bitoper,bpp*pixel_count);
                        else if(type == PACK_PACKED)
                          BitReaderBig_Skip(&bitoper,bpp);
                        continue;
                      }
                    else
                      {
                        if(HDX1616)
                          xcur += (HDX1616 * scipw);
                        if(HDY1616)
                          ycur += (HDY1616 * scipw);
                        pixel_count -= scipw;
                        if(type == PACK_LITERAL)
                          BitReaderBig_Skip(&bitoper,bpp*scipw);
                        scipw = 0;
                      }
                  }

                /*
                  if(wcnt >= TEXTURE_WI_LIM)
                  break;
                */
                wcnt += pixel_count;
                if(wcnt > TEXTURE_WI_LIM)
                  {
                    pixel_count -= (wcnt - TEXTURE_WI_LIM);
                    /*
                      if(pixel_count >> 31)
                      break;
                    */
                  }

                switch(type)
                  {
                  case PACK_EOL:
                    eor = true;
                    break;
                  case PACK_LITERAL:
                    {
                      int pix;
                      for(pix = 0; pix < pixel_count; pix++)
                        {
                          CURPIX = TEXEL(cel_bits(bpp),&LAMV);
                          if(!pproj.Transparent)
                            process_pixel(xcur >> 16,ycur >> 16,CURPIX,LAMV);

                          xcur += HDX1616;
                          ycur += HDY1616;
                        }
                    }
                    break;
                  case PACK_TRANSPARENT:
                    if(HDX1616)
                      xcur += (HDX1616 * pixel_count);
                    if(HDY1616)
                      ycur += (HDY1616 * pixel_count);
                    break;
                  case PACK_PACKED:
                    CURPIX = TEXEL(cel_bits(bpp),&LAMV);

                    if(!pproj.Transparent)
                      TexelDrawLine(CURPIX,LAMV,xcur,ycur,pixel_count);

                    if(HDX1616)
                      xcur += (HDX1616 * pixel_count);
                    if(HDY1616)
                      ycur += (HDY1616 * pixel_count);
                    break;
                  }

                if(wcnt >= TEXTURE_WI_LIM)
                  break;
              }

            pdata = lastaddr;
          }
      }
      break;
    case TEXEL_DRAW_FUNC_SCALE:
      {
        int row;
        uint32_t src_skip;

        for(row = 0; row < SPRHI; row++)
          {
            BitReaderBig_AttachBuffer(&bitoper,pdata);
            offset = cel_bits((offsetl << 3));

            lastaddr = (pdata + ((offset + 2) << 2));

            eor = false;

            src_skip = skipx;
            xcur   = xvert;
            ycur   = yvert;
            xvert += VDX1616;
            yvert += VDY1616;

            /* while not end of row */
            while(!eor)
              {
                int32_t pixel_count;

                type = cel_bits(2);
                if((bitoper.point + pdata) >= lastaddr)
                  type = PACK_EOL;

                pixel_count = (cel_bits(6) + 1);

                if(src_skip)
                  {
                    pixel_count = (int32_t)PackedSkipPixels(type,(uint32_t)pixel_count,&src_skip,bpp);
                    if(!pixel_count)
                      continue;
                  }

                switch(type)
                  {
                  case PACK_EOL:
                    eor = true;
                    break;
                  case PACK_LITERAL:
                    while(pixel_count)
                      {
                        pixel_count--;
                        CURPIX = TEXEL(cel_bits(bpp),&LAMV);

                        if(!pproj.Transparent)
                          {
                            if(TexelDrawScale(CURPIX,
                                              LAMV,
                                              xcur >> 16,
                                              ycur >> 16,
                                              ((xcur + (HDX1616 + VDX1616)) >> 16),
                                              ((ycur + (HDY1616 + VDY1616)) >> 16)))
                              break;
                          }

                        xcur += HDX1616;
                        ycur += HDY1616;
                      }
                    break;
                  case PACK_TRANSPARENT:
                    xcur  += (HDX1616 * pixel_count);
                    ycur  += (HDY1616 * pixel_count);
                    pixel_count  = 0;
                    break;
                  case PACK_PACKED:
                    CURPIX = TEXEL(cel_bits(bpp),&LAMV);
                    if(!pproj.Transparent)
                      {
                        if(flag_is_set(CCBFLAGS,CCB_MARIA))
                          {
                            while(pixel_count)
                              {
                                if(TexelDrawScale(CURPIX,
                                                  LAMV,
                                                  xcur >> 16,
                                                  ycur >> 16,
                                                  ((xcur + HDX1616 + VDX1616) >> 16),
                                                  ((ycur + HDY1616 + VDY1616) >> 16)))
                                  break;

                                pixel_count--;
                                xcur += HDX1616;
                                ycur += HDY1616;
                              }
                            break;
                          }
                        else
                          {
                            if(TexelDrawScale(CURPIX,
                                              LAMV,
                                              xcur >> 16,
                                              ycur >> 16,
                                              ((xcur + (HDX1616 * pixel_count) + VDX1616) >> 16),
                                              ((ycur + (HDY1616 * pixel_count) + VDY1616) >> 16)))
                              break;
                          }

                      }

                    xcur += (HDX1616 * pixel_count);
                    ycur += (HDY1616 * pixel_count);
                    pixel_count = 0;
                    break;
                  }

                if(pixel_count)
                  break;
              }

            pdata = lastaddr;
          }
      }
      break;
    case TEXEL_DRAW_FUNC_ARBITRARY:
      {
        int row;
        uint32_t pixel_count;
        uint32_t src_skip;
        for(row = 0; row < SPRHI; row++)
          {
            BitReaderBig_AttachBuffer(&bitoper,pdata);
            offset = cel_bits((offsetl << 3));

            lastaddr = (pdata + ((offset + 2) << 2));

            eor = false;

            src_skip = skipx;
            xcur = xvert;
            ycur = yvert;
            hdx  = HDX1616;
            hdy  = HDY1616;

            xvert   += VDX1616;
            yvert   += VDY1616;
            HDX1616 += HDDX1616;
            HDY1616 += HDDY1616;

            xdown = xvert;
            ydown = yvert;

            /* while not end of row */
            while(!eor)
              {
                type = cel_bits(2);
                if((bitoper.point + pdata) >= lastaddr)
                  type = PACK_EOL;

                pixel_count = (cel_bits(6) + 1);

                if(src_skip)
                  {
                    pixel_count = PackedSkipPixels(type,pixel_count,&src_skip,bpp);
                    if(!pixel_count)
                      continue;
                  }

                switch(type)
                  {
                  case PACK_EOL:
                    eor = true;
                    break;
                  case PACK_LITERAL:
                    while(pixel_count)
                      {
                        CURPIX = TEXEL(cel_bits(bpp),&LAMV);
                        pixel_count--;

                        if(!pproj.Transparent)
                          {
                            if(TexelDrawArbitrary(CURPIX,
                                                  LAMV,
                                                  xcur,
                                                  ycur,
                                                  xcur + hdx,
                                                  ycur + hdy,
                                                  xdown + HDX1616,
                                                  ydown + HDY1616,
                                                  xdown,
                                                  ydown))
                              break;
                          }

                        xcur  += hdx;
                        ycur  += hdy;
                        xdown += HDX1616;
                        ydown += HDY1616;
                      }
                    break;
                  case PACK_TRANSPARENT:
                    xcur  += (hdx * pixel_count);
                    ycur  += (hdy * pixel_count);
                    xdown += (HDX1616 * pixel_count);
                    ydown += (HDY1616 * pixel_count);
                    pixel_count = 0;
                    break;
                  case PACK_PACKED:
                    CURPIX = TEXEL(cel_bits(bpp),&LAMV);

                    if(!pproj.Transparent)
                      {
                        while(pixel_count)
                          {
                            pixel_count--;
                            if(TexelDrawArbitrary(CURPIX,
                                                  LAMV,
                                                  xcur,
                                                  ycur,
                                                  xcur + hdx,
                                                  ycur + hdy,
                                                  xdown + HDX1616,
                                                  ydown + HDY1616,
                                                  xdown,
                                                  ydown))
                              break;
                            xcur  += hdx;
                            ycur  += hdy;
                            xdown += HDX1616;
                            ydown += HDY1616;
                          }
                      }
                    else
                      {
                        xcur  += (hdx * pixel_count);
                        ycur  += (hdy * pixel_count);
                        xdown += (HDX1616 * pixel_count);
                        ydown += (HDY1616 * pixel_count);
                        pixel_count = 0;
                      }
                    break;
                  }

                if(pixel_count)
                  break;
              }

            pdata = lastaddr;
          }
      }
      break;
    }

  SPRWI++;

  StoreXYPosFromDrawHeight(origin_x,origin_y,origin_vdx,origin_vdy,SPRHI);
}

static
void
DrawLiteralCel(void)
{
  int32_t xcur;
  int32_t ycur;
  int32_t xvert;
  int32_t yvert;
  int32_t xdown;
  int32_t ydown;
  int32_t hdx;
  int32_t hdy;
  int32_t origin_x;
  int32_t origin_y;
  int32_t origin_vdx;
  int32_t origin_vdy;
  uint16_t CURPIX;
  uint16_t LAMV;
  bool     lrform;
  uint32_t bpp;
  uint32_t offset;
  uint32_t offsetl;
  uint32_t row_bytes;
  uint32_t skipx;
  uint32_t source_base;
  uint32_t source_width;

  bpp     = BPP[PRE0 & PRE0_BPP_MASK];
  lrform  = flag_is_set(PRE1,PRE1_LRFORM);
  offsetl = ((bpp < 8) ? 1 : 2);
  offset  = ((offsetl == 1) ?
             ((PRE1 & PRE1_WOFFSET8_MASK) >> PRE1_WOFFSET8_SHIFT):
             ((PRE1 & PRE1_WOFFSET10_MASK) >> PRE1_WOFFSET10_SHIFT));
  row_bytes = ((offset + 2) << 2);
  skipx        = PRE0_SKIPX(PRE0);
  source_base  = PDATA;
  source_width = (1 + (PRE1 & PRE1_TLHPCNT_MASK));

  SPRHI = (1 + ((PRE0 & PRE0_VCNT_MASK) >> PRE0_VCNT_SHIFT));
  /* LRFORM describes source row-pair layout, not just pixel depth. AITD2
     uses a 1-bpp LRFORM CEL as a priority mask over LR-format bitmap data. */
  if(lrform)
    SPRHI <<= 1;

  origin_x   = XPOS1616;
  origin_y   = YPOS1616;
  origin_vdx = VDX1616;
  origin_vdy = VDY1616;

  /* TLHPCNT includes SKIPX.  The first unskipped source pixel maps to
     the original destination edge, and exhausted spans draw nothing. */
  if(skipx >= source_width)
    {
      SPRWI = 0;
      HDX1616 = (int32_t)((uint32_t)HDX1616 +
                          ((uint32_t)HDDX1616 * (uint32_t)SPRHI));
      HDY1616 = (int32_t)((uint32_t)HDY1616 +
                          ((uint32_t)HDDY1616 * (uint32_t)SPRHI));
      StoreXYPosFromDrawHeight(origin_x,origin_y,origin_vdx,origin_vdy,SPRHI);
      return;
    }

  SPRWI = (int32_t)(source_width - skipx);

  if(TestInitVisual(UNPACKED))
    {
      StoreXYPosFromDrawHeight(origin_x,origin_y,origin_vdx,origin_vdy,SPRHI);
      return;
    }

  xvert = XPOS1616;
  yvert = YPOS1616;

  switch(TEXEL_DRAW_FUNC)
    {
    case TEXEL_DRAW_FUNC_LINE:
      {
        uint32_t i;

        xvert += (TEXTURE_HI_START * VDX1616);
        yvert += (TEXTURE_HI_START * VDY1616);

        if(SPRWI > TEXTURE_WI_LIM)
          SPRWI = TEXTURE_WI_LIM;

        for(i = TEXTURE_HI_START; i < TEXTURE_HI_LIM; i++)
          {
            uint32_t j;

            BitReaderBig_AttachBuffer(&bitoper,
                                      source_base + (lrform ?
                                                     XY2OFF(0,i,row_bytes) :
                                                     (row_bytes * i)));
            xcur = (xvert + TEXTURE_WI_START * HDX1616);
            ycur = (yvert + TEXTURE_WI_START * HDY1616);
            BitReaderBig_Skip(&bitoper,(bpp * skipx));
            if(TEXTURE_WI_START)
              BitReaderBig_Skip(&bitoper,(bpp * TEXTURE_WI_START));

            xvert += VDX1616;
            yvert += VDY1616;

            for(j = TEXTURE_WI_START; j < SPRWI; j++)
              {
                CURPIX = TEXEL(lrform ?
                              BitReaderBig_ReadLRForm(&bitoper,bpp) :
                              cel_bits(bpp),&LAMV);

                if(!pproj.Transparent)
                  process_pixel(xcur >> 16,ycur >> 16,CURPIX,LAMV);

                xcur += HDX1616;
                ycur += HDY1616;
              }
          }
      }
      break;
    case TEXEL_DRAW_FUNC_SCALE:
      {
        uint32_t i;
        uint32_t j;

        for(i = 0; i < SPRHI; i++)
          {
            BitReaderBig_AttachBuffer(&bitoper,
                                      source_base + (lrform ?
                                                     XY2OFF(0,i,row_bytes) :
                                                     (row_bytes * i)));
            xcur   = xvert;
            ycur   = yvert;
            xvert += VDX1616;
            yvert += VDY1616;
            BitReaderBig_Skip(&bitoper,(bpp * skipx));

            for(j = 0; j < SPRWI; j++)
              {
                CURPIX = TEXEL(lrform ?
                              BitReaderBig_ReadLRForm(&bitoper,bpp) :
                              cel_bits(bpp),&LAMV);

                if(!pproj.Transparent)
                  {
                    if(TexelDrawScale(CURPIX,
                                      LAMV,
                                      xcur >> 16,
                                      ycur >> 16,
                                      ((xcur + HDX1616 + VDX1616) >> 16),
                                      ((ycur + HDY1616 + VDY1616) >> 16)))
                      break;
                  }

                xcur += HDX1616;
                ycur += HDY1616;
              }
          }
      }
      break;
    case TEXEL_DRAW_FUNC_ARBITRARY:
    default:
      {
        uint32_t i;
        uint32_t j;

        for(i = 0; i < SPRHI; i++)
          {
            BitReaderBig_AttachBuffer(&bitoper,
                                      source_base + (lrform ?
                                                     XY2OFF(0,i,row_bytes) :
                                                     (row_bytes * i)));

            xcur = xvert;
            ycur = yvert;
            hdx  = HDX1616;
            hdy  = HDY1616;

            xvert   += VDX1616;
            yvert   += VDY1616;
            HDX1616 += HDDX1616;
            HDY1616 += HDDY1616;

            BitReaderBig_Skip(&bitoper,(bpp * skipx));

            xdown = xvert;
            ydown = yvert;

            for(j = 0; j < SPRWI; j++)
              {
                CURPIX = TEXEL(lrform ?
                              BitReaderBig_ReadLRForm(&bitoper,bpp) :
                              cel_bits(bpp),&LAMV);

                if(!pproj.Transparent)
                  {
                    if(TexelDrawArbitrary(CURPIX,
                                          LAMV,
                                          xcur,
                                          ycur,
                                          xcur + hdx,
                                          ycur + hdy,
                                          xdown + HDX1616,
                                          ydown + HDY1616,
                                          xdown,
                                          ydown))
                      break;
                  }

                xcur  += hdx;
                ycur  += hdy;
                xdown += HDX1616;
                ydown += HDY1616;
              }
          }
      }
      break;
    }

  StoreXYPosFromDrawHeight(origin_x,origin_y,origin_vdx,origin_vdy,SPRHI);
}

static
void
DrawLRCel(void)
{
  int32_t i;
  int32_t j;
  int32_t xcur;
  int32_t ycur;
  int32_t xvert;
  int32_t yvert;
  int32_t xdown;
  int32_t ydown;
  int32_t hdx;
  int32_t hdy;
  int32_t origin_x;
  int32_t origin_y;
  int32_t origin_vdx;
  int32_t origin_vdy;
  uint16_t CURPIX;
  uint16_t LAMV;
  uint32_t bpp;
  uint32_t offset;
  uint32_t offsetl;

  bpp      = BPP[PRE0 & PRE0_BPP_MASK];
  offsetl  = ((bpp < 8) ? 1 : 2);
  offset   = ((offsetl == 1) ?
              ((PRE1 & PRE1_WOFFSET8_MASK)  >> PRE1_WOFFSET8_SHIFT) :
              ((PRE1 & PRE1_WOFFSET10_MASK) >> PRE1_WOFFSET10_SHIFT));
  offset  += 2;

  SPRWI = (1 + (PRE1 & PRE1_TLHPCNT_MASK));
  SPRHI = ((((PRE0 & PRE0_VCNT_MASK) >> PRE0_VCNT_SHIFT) << 1) + 2); /* doom fix */

  origin_x   = XPOS1616;
  origin_y   = YPOS1616;
  origin_vdx = VDX1616;
  origin_vdy = VDY1616;

  if(TestInitVisual(UNPACKED))
    {
      StoreXYPosFromDrawHeight(origin_x,origin_y,origin_vdx,origin_vdy,SPRHI);
      return;
    }

  xvert = XPOS1616;
  yvert = YPOS1616;

  switch(TEXEL_DRAW_FUNC)
    {
    case TEXEL_DRAW_FUNC_LINE:
      xvert += (TEXTURE_HI_START * VDX1616);
      yvert += (TEXTURE_HI_START * VDY1616);
      /*
        if(SPRHI > TEXTURE_HI_LIM)
        SPRHI = TEXTURE_HI_LIM;
      */

      if(SPRWI > TEXTURE_WI_LIM)
        SPRWI = TEXTURE_WI_LIM;

      for(i = TEXTURE_HI_START; i < TEXTURE_HI_LIM; i++)
        {
          xcur   = (xvert + TEXTURE_WI_START * HDX1616);
          ycur   = (yvert + TEXTURE_WI_START * HDY1616);
          xvert += VDX1616;
          yvert += VDY1616;

          for(j = TEXTURE_WI_START; j < SPRWI; j++)
            {
              CURPIX = TEXEL(opera_mem_read16((PDATA + XY2OFF(j,i,offset << 2))),&LAMV);

              /* Local modification for OperaU, see TEXEL(): this was process_pixel() written out in place, and has
                 to be the function itself now that the function knows when the texel arrives finished. */
              if(!pproj.Transparent)
                process_pixel(xcur >> 16,ycur >> 16,CURPIX,LAMV);

              xcur += HDX1616;
              ycur += HDY1616;
            }
        }
      break;
    case TEXEL_DRAW_FUNC_SCALE:
      {
        for(i = 0; i < SPRHI; i++)
          {
            xcur   = xvert;
            ycur   = yvert;
            xvert += VDX1616;
            yvert += VDY1616;

            for(j = 0; j < SPRWI; j++)
              {
                CURPIX = TEXEL(opera_mem_read16((PDATA+XY2OFF(j,i,offset<<2))),&LAMV);

                if(!pproj.Transparent)
                  {
                    if(TexelDrawScale(CURPIX,
                                      LAMV,
                                      xcur >> 16,
                                      ycur >> 16,
                                      ((xcur+HDX1616+VDX1616)>>16),
                                      ((ycur+HDY1616+VDY1616)>>16)))
                      break;
                  }

                xcur += HDX1616;
                ycur += HDY1616;
              }
          }
      }
      break;
    case TEXEL_DRAW_FUNC_ARBITRARY:
    default:
      for(i = 0; i < SPRHI; i++)
        {
          xcur     = xvert;
          ycur     = yvert;
          xvert   += VDX1616;
          yvert   += VDY1616;
          xdown    = xvert;
          ydown    = yvert;
          hdx      = HDX1616;
          hdy      = HDY1616;
          HDX1616 += HDDX1616;
          HDY1616 += HDDY1616;

          for(j = 0; j < SPRWI; j++)
            {
              CURPIX = TEXEL(opera_mem_read16((PDATA+XY2OFF(j,i,offset<<2))),&LAMV);

              if(!pproj.Transparent)
                {
                  if(TexelDrawArbitrary(CURPIX,
                                        LAMV,
                                        xcur,
                                        ycur,
                                        xcur + hdx,
                                        ycur + hdy,
                                        xdown + HDX1616,
                                        ydown + HDY1616,
                                        xdown,
                                        ydown))
                    break;
                }

              xcur  += hdx;
              ycur  += hdy;
              xdown += HDX1616;
              ydown += HDY1616;
            }
        }
      break;
    }

  StoreXYPosFromDrawHeight(origin_x,origin_y,origin_vdx,origin_vdy,SPRHI);
}

void
opera_madam_reset(void)
{
  memset(&MADAM,0,sizeof(MADAM));
  memset(&bitoper,0,sizeof(bitoper));

  g_CEL_BUSY_UNTIL   = 0;
  g_CEL_BUSY_OPEN    = false;
  g_CEL_DRAW_PENDING = false;
}

void
opera_madam_soft_reset(void)
{
  /* Soft reset stops the CEL and clears its documented status bits. */
  MADAM.mregs[MADAM_REG_STATBITS] &= ~0xF1;
  MADAM.FSM = FSM_IDLE;
}

static
INLINE
uint32_t
TexelCCWTest(int64_t hdx, int64_t hdy, int64_t vdx, int64_t vdy)
{
  if (((hdx + vdx) * (hdy - vdy) + vdx * vdy - hdx * hdy) < 0)
    return CCB_ACCW;
  return CCB_ACW;
}

static
bool
QuadCCWTest(int32_t wdt_)
{
  float wdt;
  uint32_t tmp;

  if(flag_is_set(CCBFLAGS,CCB_ACCW) && flag_is_set(CCBFLAGS,CCB_ACW))
    return false;

  wdt = (float)wdt_;
  tmp = TexelCCWTest(HDX1616, HDY1616, VDX1616, VDY1616);
  if (tmp != TexelCCWTest(HDX1616, HDY1616, VDX1616 + HDDX1616*wdt, VDY1616 + HDDY1616*wdt))
    return false;
  if (tmp != TexelCCWTest(HDX1616 + HDDX1616*SPRHI, HDY1616 + HDDY1616*SPRHI, VDX1616, VDY1616))
    return false;
  if (tmp != TexelCCWTest(HDX1616 + HDDX1616*SPRHI, HDY1616 + HDDY1616*SPRHI, VDX1616 + HDDX1616*SPRHI * wdt, VDY1616 + HDDY1616*SPRHI * wdt))
    return false;
  if(tmp == (CCBFLAGS & (CCB_ACCW | CCB_ACW)))
    return true;
  return false;
}

static
OPERA_FORCEINLINE
int32_t
ABS(const int32_t val_)
{
  return ((val_ > 0) ? val_ : -val_);
}

static
bool
TestInitVisual(bool const packed_)
{
  int32_t xpoints[4];
  int32_t ypoints[4];

  if(flag_is_clr(CCBFLAGS,CCB_ACCW) && flag_is_clr(CCBFLAGS,CCB_ACW))
    return true;

  if(packed_)
    {
      xpoints[0] = (XPOS1616 >> 16);
      xpoints[1] = ((XPOS1616 + VDX1616 * SPRHI) >> 16);
      if((xpoints[0] < 0) &&
         (xpoints[1] < 0) &&
         (HDX1616   <= 0) &&
         (HDDX1616  <= 0))
        return true;
      if((xpoints[0] > MADAM.clipx) &&
         (xpoints[1] > MADAM.clipx) &&
         (HDX1616   >= 0)           &&
         (HDDX1616  >= 0))
        return true;

      ypoints[0] = (YPOS1616 >> 16);
      ypoints[1] = ((YPOS1616 + VDY1616 * SPRHI) >> 16);
      if((ypoints[0] < 0) &&
         (ypoints[1] < 0) &&
         (HDY1616   <= 0) &&
         (HDDY1616  <= 0))
        return true;
      if((ypoints[0] > MADAM.clipy) &&
         (ypoints[1] > MADAM.clipy) &&
         (HDY1616   >= 0)           &&
         (HDDY1616  >= 0))
        return true;
    }
  else
    {
      xpoints[0] = (XPOS1616 >> 16);
      xpoints[1] = (XPOS1616+HDX1616*SPRWI)>>16;
      xpoints[2] = (XPOS1616+VDX1616*SPRHI)>>16;
      xpoints[3] = ((XPOS1616+VDX1616*SPRHI+
                     (HDX1616+HDDX1616*SPRHI)*SPRWI) >> 16);
      if((xpoints[0] < 0) &&
         (xpoints[1] < 0) &&
         (xpoints[2] < 0) &&
         (xpoints[3] < 0))
        return true;
      if((xpoints[0] > MADAM.clipx) &&
         (xpoints[1] > MADAM.clipx) &&
         (xpoints[2] > MADAM.clipx) &&
         (xpoints[3] > MADAM.clipx))
        return true;

      ypoints[0] = (YPOS1616 >> 16);
      ypoints[1] = ((YPOS1616+HDY1616*SPRWI) >> 16);
      ypoints[2] = ((YPOS1616+VDY1616*SPRHI) >> 16);
      ypoints[3] = ((YPOS1616+VDY1616*SPRHI+
                     (HDY1616+HDDY1616*SPRHI)*SPRWI) >> 16);
      if((ypoints[0] < 0) &&
         (ypoints[1] < 0) &&
         (ypoints[2] < 0) &&
         (ypoints[3] < 0))
        return true;
      if((ypoints[0] > MADAM.clipy) &&
         (ypoints[1] > MADAM.clipy) &&
         (ypoints[2] > MADAM.clipy) &&
         (ypoints[3] > MADAM.clipy))
        return true;
    }

  if((HDDX1616 == 0) && (HDDY1616 == 0))
    {
      if((HDX1616 == 0) && (VDY1616 == 0))
        {
          if(((HDY1616 < 0) && (VDX1616 > 0)) ||
             ((HDY1616 > 0) && (VDX1616 < 0)))
            {
              if(flag_is_set(CCBFLAGS,CCB_ACW))
                {
                  if((ABS(HDY1616) == 0x10000) &&
                     (ABS(VDX1616) == 0x10000) &&
                     !((YPOS1616|XPOS1616)&0xffff))
                    {
                      return InitLineMap();
                    }
                  else
                    {
                      InitScaleMap();
                      return false;
                    }
                }
            }
          else
            {
              if(flag_is_set(CCBFLAGS,CCB_ACCW))
                {
                  if((ABS(HDY1616) == 0x10000) &&
                     (ABS(VDX1616) == 0x10000) &&
                     !((YPOS1616|XPOS1616)&0xffff))
                    {
                      return InitLineMap();
                    }
                  else
                    {
                      InitScaleMap();
                      return false;
                    }
                }
            }

          return true;
        }
      else if((HDY1616 == 0) && (VDX1616 == 0))
        {
          if(((HDX1616 < 0) && (VDY1616 > 0)) ||
             ((HDX1616 > 0) && (VDY1616 < 0)))
            {
              if(flag_is_set(CCBFLAGS,CCB_ACCW))
                {
                  if((ABS(HDX1616) == 0x10000) &&
                     (ABS(VDY1616) == 0x10000) &&
                     !((YPOS1616|XPOS1616)&0xffff))
                    {
                      return InitLineMap();
                    }
                  else
                    {
                      InitScaleMap();
                      return false;
                    }
                }
            }
          else
            {
              if(flag_is_set(CCBFLAGS,CCB_ACW))
                {
                  if((ABS(HDX1616) == 0x10000) &&
                     (ABS(VDY1616) == 0x10000) &&
                     !((YPOS1616|XPOS1616)&0xffff))
                    {
                      return InitLineMap();
                    }
                  else
                    {
                      InitScaleMap();
                      return false;
                    }
                }
            }

          return true;
        }
    }

  if(QuadCCWTest(packed_ ? 2048 : SPRWI))
    return true;

  InitArbitraryMap();

  return false;
}

static
bool
InitLineMap(void)
{
  TEXEL_DRAW_FUNC  = TEXEL_DRAW_FUNC_LINE;
  TEXTURE_WI_START = 0;
  TEXTURE_HI_START = 0;
  TEXTURE_HI_LIM   = SPRHI;

  if((HDX1616 < 0) || (VDX1616 < 0))
    XPOS1616 -= 0x8000;
  if((HDY1616 < 0) || (VDY1616 < 0))
    YPOS1616 -= 0x8000;

  if(VDX1616 < 0)
    {
      if(((XPOS1616 - ((SPRHI - 1) << 16)) >> 16) < 0)
        TEXTURE_HI_LIM = ((XPOS1616 >> 16) + 1);
      if(TEXTURE_HI_LIM > SPRHI)
        TEXTURE_HI_LIM = SPRHI;
    }
  else if(VDX1616 > 0)
    {
      if(((XPOS1616 + (SPRHI << 16)) >> 16) > MADAM.clipx)
        TEXTURE_HI_LIM = (MADAM.clipx - (XPOS1616>>16) + 1);
    }

  if(VDY1616 < 0)
    {
      if(((YPOS1616 - ((SPRHI - 1) << 16)) >> 16) < 0)
        TEXTURE_HI_LIM = ((YPOS1616 >> 16) + 1);
      if(TEXTURE_HI_LIM > SPRHI)
        TEXTURE_HI_LIM = SPRHI;
    }
  else if(VDY1616 > 0)
    {
      if(((YPOS1616 + (SPRHI << 16)) >> 16) > MADAM.clipy)
        TEXTURE_HI_LIM = (MADAM.clipy - (YPOS1616 >> 16) + 1);
    }

  if(HDX1616 < 0)
    TEXTURE_WI_LIM = ((XPOS1616 >> 16) + 1);
  else if(HDX1616 > 0)
    TEXTURE_WI_LIM = (MADAM.clipx - (XPOS1616 >> 16) + 1);

  if(HDY1616 < 0)
    TEXTURE_WI_LIM = ((YPOS1616 >> 16) + 1);
  else if(HDY1616 > 0)
    TEXTURE_WI_LIM = (MADAM.clipy - (YPOS1616 >> 16) + 1);

  if(XPOS1616 < 0)
    {
      if(HDX1616 < 0)
        return true;
      else if(HDX1616 > 0)
        TEXTURE_WI_START = -(XPOS1616 >> 16);

      if(VDX1616 < 0)
        return true;
      else if(VDX1616 > 0)
        TEXTURE_HI_START = -(XPOS1616 >> 16);
    }
  else if((XPOS1616 >> 16) > MADAM.clipx)
    {
      if(HDX1616 > 0)
        return true;
      else if(HDX1616 < 0)
        TEXTURE_WI_START = ((XPOS1616 >> 16) - MADAM.clipx);

      if(VDX1616 > 0)
        return true;
      else if(VDX1616 < 0)
        TEXTURE_HI_START = ((XPOS1616 >> 16) - MADAM.clipx);
    }

  if(YPOS1616 < 0)
    {
      if(HDY1616 < 0)
        return true;
      else if(HDY1616 > 0)
        TEXTURE_WI_START = -(YPOS1616 >> 16);

      if(VDY1616 < 0)
        return true;
      else if(VDY1616 > 0)
        TEXTURE_HI_START = -(YPOS1616 >> 16);
    }
  else if((YPOS1616 >> 16) > MADAM.clipy)
    {
      if(HDY1616 > 0)
        return true;
      else if(HDY1616 < 0)
        TEXTURE_WI_START = ((YPOS1616 >> 16) - MADAM.clipy);

      if(VDY1616 > 0)
        return true;
      else if(VDY1616 < 0)
        TEXTURE_HI_START = ((YPOS1616 >> 16) - MADAM.clipy);
    }

  /*
    if(TEXTURE_WI_START<((PRE0>>24)&0xf))
    TEXTURE_WI_START=((PRE0>>24)&0xf);
    TEXTURE_WI_START+=(PRE0>>24)&0xf;
    if(TEXTURE_WI_START<0)TEXTURE_WI_START=0;
    if(TEXTURE_HI_START<0)TEXTURE_HI_START=0;
    if(TEXTURE_HI_LIM>SPRHI)TEXTURE_HI_LIM=SPRHI;
  */

  if(TEXTURE_WI_LIM <= 0)
    return true;

  return false;
}

static
INLINE
void
InitScaleMap(void)
{
  int32_t deltax;
  int32_t deltay;

  TEXEL_DRAW_FUNC = TEXEL_DRAW_FUNC_SCALE;

  if((HDX1616 < 0) || (VDX1616 < 0))
    XPOS1616 -= 0x8000;
  if((HDY1616 < 0) || (VDY1616 < 0))
    YPOS1616 -= 0x8000;

  deltax = (HDX1616 + VDX1616);
  deltay = (HDY1616 + VDY1616);

  TEXEL_INCX = ((deltax < 0) ? -1 : 1);
  TEXEL_INCY = ((deltay < 0) ? -1 : 1);

  TEXTURE_WI_START = 0;
  TEXTURE_HI_START = 0;
}

static
INLINE
void
InitArbitraryMap(void)
{
  TEXEL_DRAW_FUNC  = TEXEL_DRAW_FUNC_ARBITRARY;
  TEXTURE_WI_START = 0;
  TEXTURE_HI_START = 0;
}

static
void
TexelDrawLine(uint16_t CURPIX_,
              uint16_t LAMV_,
              int32_t  xcur_,
              int32_t  ycur_,
              int32_t  cnt_)
{
  int32_t i;
  uint32_t curr;
  uint32_t pixel;

  xcur_ >>= 16;
  ycur_ >>= 16;
  curr = 0xFFFFFFFF;
  g_CEL_PIXELS_DRAWN += (cnt_ > 0) ? (uint64_t)cnt_ : 0;

  /* Local modification for OperaU, see g_CEL_FB_FREE and TEXEL(): the run is one finished pixel, so only the
     writes are left. */
  if(g_CEL_FB_FREE)
    {
      if(cnt_ > 0)
        {
          const int32_t dx = (HDX1616 >> 16);
          const int32_t dy = (HDY1616 >> 16);

          pixel = CURPIX_; /* finished already: see TEXEL() */
          for(i = 0; i < cnt_; i++, xcur_ += dx, ycur_ += dy)
            opera_mem_write16(REGCTL3 + XY2OFF(xcur_,ycur_,MADAM.wmod),pixel);
        }
      return;
    }

  for(i = 0; i < cnt_; i++, xcur_ += (HDX1616 >> 16), ycur_ += (HDY1616 >> 16))
    {
      uint32_t next;

      next = opera_mem_read16(REGCTL2 + XY2OFF(xcur_,ycur_,MADAM.rmod));
      if(next != curr)
        {
          curr  = next;
          pixel = PPROC(CURPIX_,next,LAMV_);
          pixel = PPROJ_OUTPUT(pixel,next);
        }

      opera_mem_write16(REGCTL3 + XY2OFF(xcur_,ycur_,MADAM.wmod),pixel);
    }
}

static
INLINE
uint16_t
readPIX(int32_t x_,
        int32_t y_)
{
  uint32_t src = REGCTL2;

  if(HIRESMODE)
    {
      src += XY2OFF(x_ >> 1,y_ >> 1,MADAM.rmod);
      src += ((((y_ & 1) << 1) + (x_ & 1)) * VRAM_SIZE);
    }
  else
    {
      src += XY2OFF(x_,y_,MADAM.rmod);
    }

  return opera_mem_read16(src);
}

static
INLINE
void
writePIX(int32_t  x_,
         int32_t  y_,
         uint16_t p_)
{
  uint32_t src = REGCTL3;

  if(HIRESMODE)
    {
      src += XY2OFF(x_ >> 1,y_ >> 1,MADAM.wmod);
      src += ((((y_ & 1) << 1) + (x_ & 1)) * VRAM_SIZE);
    }
  else
    {
      src += XY2OFF(x_,y_,MADAM.wmod);
    }

  opera_mem_write16_base(src,p_);
}

/* Local modification for OperaU, see third_party/patches/: inlined for the same reason as the arbitrary path
   below - it is called once per texel and its callers pass the resolution mode as a constant. Which of the two
   paths a game actually uses is what the per-cel counters in opera_prof.h are there to tell us. */
static
OPERA_FORCEINLINE
int32_t
TexelDrawScale(uint16_t CURPIX_,
               uint16_t LAMV_,
               int32_t  xcur_,
               int32_t  ycur_,
               int32_t  deltax_,
               int32_t  deltay_)
{
  int32_t x;
  int32_t y;

  if((HDX1616 < 0) && (deltax_ < 0) && (xcur_ < 0))
    return -1;
  else if((HDY1616 < 0) && (deltay_ < 0) && (ycur_ < 0))
    return -1;
  else if((HDX1616 > 0) && (deltax_ > MADAM.clipx) && (xcur_ > MADAM.clipx))
    return -1;
  else if((HDY1616 > 0) && (deltay_ > MADAM.clipy) && (ycur_ > MADAM.clipy))
    return -1;

  if(xcur_ == deltax_)
    return 0;

  /*
    Local modification for OperaU, see g_CEL_FB_FREE and TEXEL(): the texel arrives as a finished pixel, so its
    block is a fill. The two loops below visit x from xcur_ up to but not including deltax_, in steps of
    TEXEL_INCX, and y likewise; every pixel inside the clip box gets the same value and is counted once. That is
    the rectangle clipped to the box, so it is filled as one, row by row, without testing each pixel - the
    address of a pixel is linear in x, four bytes apart. Two cases keep the loops as they are: MARIA, which stops
    after the first pixel the loops reach, so their order matters; and a block whose far edge lies behind its
    near one, which the loops would only leave by wrapping round.
  */
  if(g_CEL_FB_FREE)
    {
      const bool forward_x = (TEXEL_INCX > 0);
      const bool forward_y = (TEXEL_INCY > 0);

      if(flag_is_clr(CCBFLAGS,CCB_MARIA) &&
         (forward_x ? (deltax_ > xcur_) : (deltax_ < xcur_)) &&
         (forward_y ? (deltay_ >= ycur_) : (deltay_ <= ycur_)))
        {
          int32_t x0 = (forward_x ? xcur_ : (deltax_ + 1));
          int32_t x1 = (forward_x ? (deltax_ - 1) : xcur_);
          int32_t y0 = (forward_y ? ycur_ : (deltay_ + 1));
          int32_t y1 = (forward_y ? (deltay_ - 1) : ycur_);

          if(x0 < 0)
            x0 = 0;
          if(y0 < 0)
            y0 = 0;
          if(x1 > (int32_t)MADAM.clipx)
            x1 = (int32_t)MADAM.clipx;
          if(y1 > (int32_t)MADAM.clipy)
            y1 = (int32_t)MADAM.clipy;

          if((x0 <= x1) && (y0 <= y1))
            {
              const int32_t w = (x1 - x0 + 1);

              for(y = y0; y <= y1; y++)
                {
                  uint32_t addr = (REGCTL3 + XY2OFF(x0,y,MADAM.wmod));

                  for(x = 0; x < w; x++, addr += 4)
                    opera_mem_write16(addr,CURPIX_);
                }
              g_CEL_PIXELS_DRAWN += ((uint64_t)w * (uint64_t)(y1 - y0 + 1));
            }

          return 0;
        }

      for(y = ycur_; y != deltay_; y += TEXEL_INCY)
        {
          for(x = xcur_; x != deltax_; x += TEXEL_INCX)
            {
              if(clipping(x,y))
                continue;

              opera_mem_write16(REGCTL3 + XY2OFF(x,y,MADAM.wmod),CURPIX_);
              g_CEL_PIXELS_DRAWN++;
              if(flag_is_set(CCBFLAGS,CCB_MARIA))
                return 0;
            }
        }

      return 0;
    }

  for(y = ycur_; y != deltay_; y += TEXEL_INCY)
    {
      for(x = xcur_; x != deltax_; x += TEXEL_INCX)
        {
          if(clipping(x,y))
            continue;

          process_pixel(x,y,CURPIX_,LAMV_);
          if(flag_is_set(CCBFLAGS,CCB_MARIA))
            return 0;
        }
    }

  return 0;
}

/* Local modification for OperaU, see third_party/patches/: inlined because it is called once per texel - 1.4
   million times in the cel test alone - and both call sites pass `hires_` as a constant, so inlining turns eight
   variable shifts and a handful of branches into nothing. */
static
OPERA_FORCEINLINE
int32_t
_rasterize_arbitrary(uint16_t curpix_,
                     uint16_t lamv_,
                     int32_t  xA_,
                     int32_t  yA_,
                     int32_t  xB_,
                     int32_t  yB_,
                     int32_t  xC_,
                     int32_t  yC_,
                     int32_t  xD_,
                     int32_t  yD_,
                     bool     hires_,
                     bool     draw_)
{
  int32_t x;
  int32_t y;
  int32_t miny;
  int32_t maxy;
  int32_t maxx;
  int32_t maxxt;
  int32_t maxyt;
  int32_t tmp;
  uint32_t curr;
  uint32_t next;
  uint32_t pixel;
  int32_t xpoints[4];
  int32_t updowns[4];
  const bool fb_free = g_CEL_FB_FREE;

  curr = -1;
  /* Local modification for OperaU, see TEXEL(): for a cel that cannot see the frame buffer the texel arrives as
     a finished pixel. `next` is held at zero for it below, so starting `curr` there means the pipeline is never
     run and this pixel is what gets written. */
  if(fb_free)
    {
      curr  = 0;
      pixel = curpix_;
    }
  xA_ >>= (16 - hires_);
  xB_ >>= (16 - hires_);
  xC_ >>= (16 - hires_);
  xD_ >>= (16 - hires_);
  yA_ >>= (16 - hires_);
  yB_ >>= (16 - hires_);
  yC_ >>= (16 - hires_);
  yD_ >>= (16 - hires_);

  if((xA_ == xB_) && (xB_ == xC_) && (xC_ == xD_))
    return 0;

  maxxt = ((MADAM.clipx + 1) << hires_);
  maxyt = ((MADAM.clipy + 1) << hires_);

  if((HDX1616 < 0) && (HDDX1616 < 0))
    {
      if((xA_ < 0) && (xB_ < 0) && (xC_ < 0) && (xD_ < 0))
        return -1;
    }

  if((HDX1616 > 0) && (HDDX1616 > 0))
    {
      if((xA_ >= maxxt) && (xB_ >= maxxt) && (xC_ >= maxxt) && (xD_ >= maxxt))
        return -1;
    }

  if((HDY1616 < 0) && (HDDY1616 < 0))
    {
      if((yA_ < 0) && (yB_ < 0) && (yC_ < 0) && (yD_ < 0))
        return -1;
    }

  if((HDY1616 > 0) && (HDDY1616 > 0))
    {
      if((yA_ >= maxyt) && (yB_ >= maxyt) && (yC_ >= maxyt) && (yD_ >= maxyt))
        return -1;
    }

  miny = maxy = yA_;

  if(miny > yB_)
    miny = yB_;
  if(miny > yC_)
    miny = yC_;
  if(miny > yD_)
    miny = yD_;
  if(maxy < yB_)
    maxy = yB_;
  if(maxy < yC_)
    maxy = yC_;
  if(maxy < yD_)
    maxy = yD_;

  y = miny;
  if(y < 0)
    y = 0;
  if(maxy < maxyt)
    maxyt = maxy;

  for(; y < maxyt; y++)
    {
      int cnt_cross = 0;
      if((y < yB_) && (y >= yA_))
        {
          xpoints[cnt_cross] = (int32_t)((((xB_-xA_)*(y-yA_))/(yB_-yA_))+xA_);
          updowns[cnt_cross++] = 1;
        }
      else if((y >= yB_) && (y < yA_))
        {
          xpoints[cnt_cross] = (int32_t)((((xA_-xB_)*(y-yB_))/(yA_-yB_))+xB_);
          updowns[cnt_cross++] = 0;
        }

      if((y < yC_) && (y >= yB_))
        {
          xpoints[cnt_cross] = (int32_t)((((xC_-xB_)*(y-yB_))/(yC_-yB_))+xB_);
          updowns[cnt_cross++] = 1;
        }
      else if((y >= yC_) && (y < yB_))
        {
          xpoints[cnt_cross] = (int32_t)((((xB_-xC_)*(y-yC_))/(yB_-yC_))+xC_);
          updowns[cnt_cross++] = 0;
        }

      if((y < yD_) && (y >= yC_))
        {
          xpoints[cnt_cross] = (int32_t)((((xD_-xC_)*(y-yC_))/(yD_-yC_))+xC_);
          updowns[cnt_cross++] = 1;
        }
      else if((y >= yD_) && (y < yC_))
        {
          xpoints[cnt_cross] = (int32_t)((((xC_-xD_)*(y-yD_))/(yC_-yD_))+xD_);
          updowns[cnt_cross++] = 0;
        }

      if(cnt_cross & 1)
        {
          if((y < yA_) && (y >= yD_))
            {
              xpoints[cnt_cross] = (int32_t)((((xA_-xD_)*(y-yD_))/(yA_-yD_))+xD_);
              updowns[cnt_cross] = 1;
            }
          else if((y >= yA_) && (y < yD_))
            {
              xpoints[cnt_cross] = (int32_t)((((xD_-xA_)*(y-yA_))/(yD_-yA_))+xA_);
              updowns[cnt_cross] = 0;
            }
        }

      if(cnt_cross != 0)
        {
          if(xpoints[0] > xpoints[1])
            {
              xpoints[1] += xpoints[0];
              xpoints[0]  = xpoints[1] - xpoints[0];
              xpoints[1]  = xpoints[1] - xpoints[0];

              tmp        = updowns[0];
              updowns[0] = updowns[1];
              updowns[1] = tmp;
            }

          if(cnt_cross > 2)
            {
              if((flag_is_set(CCBFLAGS,CCB_ACW)  && (updowns[2] == 0)) ||
                 (flag_is_set(CCBFLAGS,CCB_ACCW) && (updowns[2] == 1)))
                {
                  x = xpoints[2];
                  if(x < 0)
                    x = 0;

                  maxx = xpoints[3] + 1;
                  if(maxx > maxxt)
                    maxx = maxxt;

                  if((x < maxx) && !hires_)
                    g_CEL_PIXELS_DRAWN += flag_is_set(CCBFLAGS,CCB_MARIA) ?
                      1 : (uint64_t)(maxx - x);

                  if(!draw_)
                    {
                      if((x < maxx) && flag_is_set(CCBFLAGS,CCB_MARIA))
                        return 0;
                      x = maxx;
                    }

                  for(; x < maxx; x++)
                    {
                      /* Local modification for OperaU, see g_CEL_FB_FREE: a constant here means the
                         pipeline runs for the first pixel of the texel and never again. */
                      next = (fb_free ? 0 : readPIX(x,y));
                      if(next != curr)
                        {
                          curr  = next;
                          pixel = PPROC(curpix_,next,lamv_);
                          pixel = PPROJ_OUTPUT(pixel,next);
                        }
                      writePIX(x,y,pixel);
                      if(flag_is_set(CCBFLAGS,CCB_MARIA))
                        return 0;
                    }
                }
            }

          if((flag_is_set(CCBFLAGS,CCB_ACW)  && (updowns[0] == 0)) ||
             (flag_is_set(CCBFLAGS,CCB_ACCW) && (updowns[0] == 1)))
            {
              x = xpoints[0];
              if(x < 0)
                x = 0;

              maxx = xpoints[1] + 1;
              if(maxx > maxxt)
                maxx = maxxt;

              if((x < maxx) && !hires_)
                g_CEL_PIXELS_DRAWN += flag_is_set(CCBFLAGS,CCB_MARIA) ?
                  1 : (uint64_t)(maxx - x);

              if(!draw_)
                {
                  if((x < maxx) && flag_is_set(CCBFLAGS,CCB_MARIA))
                    return 0;
                  x = maxx;
                }

              for(; x < maxx; x++)
                {
                  next = (fb_free ? 0 : readPIX(x,y));
                  if(next != curr)
                    {
                      curr  = next;
                      pixel = PPROC(curpix_,next,lamv_);
                      pixel = PPROJ_OUTPUT(pixel,next);
                    }
                  writePIX(x,y,pixel);
                  if(flag_is_set(CCBFLAGS,CCB_MARIA))
                    return 0;
                }
            }
        }
    }

  return 0;
}


static
int32_t
TexelDrawArbitrary(uint16_t curpix_,
                   uint16_t lamv_,
                   int32_t  xA_,
                   int32_t  yA_,
                   int32_t  xB_,
                   int32_t  yB_,
                   int32_t  xC_,
                   int32_t  yC_,
                   int32_t  xD_,
                   int32_t  yD_)
{
  int32_t result;

  g_CEL_TEXELS_WALKED++;
  // Share scan conversion so rounding, clipping and MARIA match native drawing.
  // The timing-only pass counts spans without touching framebuffer pixels.
  result = _rasterize_arbitrary(curpix_,
                               lamv_,
                               xA_,
                               yA_,
                               xB_,
                               yB_,
                               xC_,
                               yC_,
                               xD_,
                               yD_,
                               false,
                               !HIRESMODE);
  if(HIRESMODE)
    _rasterize_arbitrary(curpix_,
                         lamv_,
                         xA_,
                         yA_,
                         xB_,
                         yB_,
                         xC_,
                         yC_,
                         xD_,
                         yD_,
                         true,
                         true);

  return result;
}
