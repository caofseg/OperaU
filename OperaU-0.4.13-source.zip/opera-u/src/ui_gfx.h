/*
 * Small 2D toolkit on top of SDL_Renderer: anti-aliased rounded rectangles,
 * text (stb_truetype glyph cache rasterised at the real output resolution, so
 * it stays sharp on a 1080p TV), gradients and a few procedural icons.
 * All coordinates are logical (1280x720).
 */
#ifndef OPERAU_UI_GFX_H
#define OPERAU_UI_GFX_H

#include "common.h"
#include <SDL.h>

#define RGBA(r, g, b, a) \
    (((uint32_t)(r) << 24) | ((uint32_t)(g) << 16) | ((uint32_t)(b) << 8) | (uint32_t)(a))

/* theme (matches the app icon: deep navy with blue/violet accents) */
#define COL_BG_TOP      RGBA(0x18, 0x1e, 0x3c, 255)
#define COL_BG_BOTTOM   RGBA(0x07, 0x09, 0x14, 255)
#define COL_PANEL       RGBA(0x1b, 0x22, 0x44, 235)
#define COL_PANEL_LIGHT RGBA(0x26, 0x2f, 0x5c, 255)
#define COL_ROW         RGBA(0x20, 0x28, 0x4e, 190)
#define COL_ROW_SEL     RGBA(0x3d, 0x55, 0xb4, 255)
#define COL_ACCENT      RGBA(0x7f, 0x9c, 0xff, 255)
#define COL_ACCENT2     RGBA(0x4f, 0xd1, 0xc5, 255)
#define COL_TEXT        RGBA(0xf0, 0xf4, 0xff, 255)
#define COL_TEXT_DIM    RGBA(0x9a, 0xa8, 0xd4, 255)
#define COL_TEXT_OFF    RGBA(0x5c, 0x66, 0x8c, 255)
#define COL_WARN        RGBA(0xff, 0xc8, 0x57, 255)
#define COL_ERR         RGBA(0xff, 0x6b, 0x6b, 255)
#define COL_OK          RGBA(0x6b, 0xe5, 0x9a, 255)
#define COL_BLACK(a)    RGBA(0, 0, 0, (a))

/* font sizes in logical pixels */
enum { FS_SMALL = 20, FS_NORMAL = 24, FS_LARGE = 30, FS_TITLE = 42, FS_HUGE = 64 };
enum { TXT_LEFT = 0, TXT_CENTER = 1, TXT_RIGHT = 2 };
enum { DIR_UP = 0, DIR_DOWN, DIR_LEFT, DIR_RIGHT };

bool gfx_init(SDL_Renderer *r);
void gfx_shutdown(void);
void gfx_frame_begin(void);

void gfx_fill(float x, float y, float w, float h, uint32_t c);
void gfx_round_fill(float x, float y, float w, float h, float radius, uint32_t c);
void gfx_background(void);
void gfx_disc(float cx, float cy, float diameter, uint8_t alpha);
void gfx_triangle(float cx, float cy, float size, int dir, uint32_t c);
void gfx_folder(float x, float y, float size, uint32_t c);
/* Round button badge with a letter ("A", "B", "+"); returns its width. */
float gfx_badge(float x, float y, float h, const char *label, uint32_t fg, uint32_t bg);

float gfx_line_height(int size);
float gfx_text_width(const char *s, int size);
/* Draws one line (ellipsis when wider than max_w > 0). `y` is the top of the
 * line box. Returns the width drawn. */
float gfx_text(const char *s, float x, float y, int size, uint32_t c, int align, float max_w);
/* Word-wrapped paragraph(s); returns the height used. max_lines < 0: no limit.
 * With draw == false only measures. */
float gfx_text_wrapped(const char *s, float x, float y, float w, int size, uint32_t c, int max_lines, bool draw);

void gfx_clip(float x, float y, float w, float h);
void gfx_clip_off(void);

#endif
