/*
 * User interface: home screen, file browser (CHD / ISO / CUE from SD or USB),
 * pause menu, settings, per-game core options, controller mapping and help.
 * Everything is drawn with ui_gfx on the shared SDL renderer and driven by the
 * navigation events / pointer from input.c.
 */
#ifndef OPERAU_UI_H
#define OPERAU_UI_H

#include "common.h"

typedef enum {
    UIA_NONE = 0,
    UIA_LAUNCH,           /* path = disc image to start */
    UIA_LAUNCH_RESUME,    /* path = image; also load its automatic state */
    UIA_LAUNCH_BIOS,      /* boot the BIOS without a disc */
    UIA_RESUME,
    UIA_SAVE_STATE,
    UIA_LOAD_STATE,
    UIA_RESET,
    UIA_SCREENSHOT,
    UIA_CLOSE_GAME,
    UIA_QUIT,
    UIA_DIAGNOSTIC,       /* run the core self test (home screen only) */
    UIA_TESTPATTERN,      /* picture test: colour bars and geometry (home screen only) */
    UIA_SETTINGS_CHANGED, /* video/audio/performance settings were edited */
} ui_action_type_t;

typedef struct {
    ui_action_type_t type;
    char path[1024];
} ui_action_t;

typedef enum {
    UI_HOME = 0,          /* no game running */
    UI_PAUSE,             /* game running, menu on top of the frozen picture */
} ui_mode_t;

typedef struct {
    bool (*state_exists)(int slot);   /* is there a save state in this slot? */
    bool (*game_resumable)(const char *path); /* an automatic state exists */
} ui_hooks_t;

typedef struct {
    float emu_fps;
    float video_fps;
    int audio_ms;
    bool fast_forward;
    char perf[112];     /* one-line time split (perf.c); empty until measured */
} ui_hud_t;

bool ui_init(const ui_hooks_t *hooks);
void ui_shutdown(void);

/* Shows the menu. `game_title` is used by the pause menu (NULL on home). */
void ui_open(ui_mode_t mode, const char *game_title);
void ui_update(void);                 /* consume input */
void ui_refresh(void);                /* rebuild the visible screens (state slots, language ...) */
void ui_draw(void);                   /* menu screens + overlays */
void ui_draw_overlays(const ui_hud_t *hud); /* toasts and HUD while a game runs */
/* Full-screen splash with a line of text ("Loading ..."). */
void ui_draw_splash(const char *line1, const char *line2);
/* Same with a progress bar (0..1) and a small caption below it (may be NULL). */
void ui_draw_splash_progress(const char *line1, const char *line2, float progress, const char *line3);

bool ui_next_action(ui_action_t *out);
void ui_toast(const char *fmt, ...) PRINTF_LIKE(1, 2);
/* Modal message box (OK to dismiss). */
void ui_message(const char *title, const char *text, bool is_error);
bool ui_message_active(void);

/* Headless test hook: jump straight to a screen ("browser", "settings", ...). */
void ui_debug_goto(const char *name);

#endif
