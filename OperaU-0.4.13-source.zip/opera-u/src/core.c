#include "core.h"

#include "retro_cdimage.h"
#include "config.h"
#include "input.h"
#include "log.h"
#include "opera_hooks.h"
#include "opera_lr_dsp.h"
#include "platform.h"

#include <SDL.h>
#include <libretro.h>

#include <stdarg.h>

/* Declared in the core's libretro_core_options.h; used to rebuild the BIOS and
 * font lists after the user drops new ROM files into the bios folder. */
void libretro_init_core_options(void);
void libretro_set_core_options(void);

#define MAX_OPTS 64
#define MSG_QUEUE 8

static core_sink_t g_sink;
static core_av_t g_av;
static bool g_inited;
static bool g_loaded;
static bool g_shutdown_req;
static uint32_t g_av_changed;      /* atomic */
static uint32_t g_opts_dirty;      /* atomic */
static char g_game_path[1024];
static char g_error[256];
static core_err_t g_error_code;
static char g_sys_dir[1100];
static char g_save_dir[1100];
static int g_connected_pads = 1;

/* Diagnostic mode (core_diag_enter): atomic flag + the scratch directory the
 * core sees instead of the real system / save directories. */
static uint32_t g_diag;
static char g_diag_dir[1100];

static inline bool diag_on(void)
{
    return __atomic_load_n(&g_diag, __ATOMIC_ACQUIRE) != 0;
}

static core_opt_t g_opts[MAX_OPTS];
static int g_nopts;

static SDL_mutex *g_msg_lock;
static char g_msgs[MSG_QUEUE][160];
static int g_msg_head, g_msg_tail;

/* ---------------------------------------------------------------- messages */

static void msg_push(const char *text)
{
    if (!g_msg_lock || !text || !*text)
        return;
    SDL_LockMutex(g_msg_lock);
    {
        int next = (g_msg_head + 1) % MSG_QUEUE;
        if (next != g_msg_tail) {
            str_copy(g_msgs[g_msg_head], text, sizeof(g_msgs[0]));
            g_msg_head = next;
        }
    }
    SDL_UnlockMutex(g_msg_lock);
}

bool core_pop_message(char *out, size_t cap)
{
    bool ok = false;
    if (!g_msg_lock)
        return false;
    SDL_LockMutex(g_msg_lock);
    if (g_msg_tail != g_msg_head) {
        str_copy(out, g_msgs[g_msg_tail], cap);
        g_msg_tail = (g_msg_tail + 1) % MSG_QUEUE;
        ok = true;
    }
    SDL_UnlockMutex(g_msg_lock);
    return ok;
}

/* ----------------------------------------------------------------- options */

static void opts_free(void)
{
    for (int i = 0; i < g_nopts; i++)
        free(g_opts[i].vals);
    memset(g_opts, 0, sizeof(g_opts));
    g_nopts = 0;
}

static bool value_hidden(const char *key, const char *value)
{
    /* The Wii U GPU has no RGB565 texture format; offering it would only
     * produce a black screen. */
    return !strcmp(key, "opera_vdlp_pixel_format") && !strcmp(value, "RGB565");
}

static void opts_ingest_v2(const struct retro_core_options_v2 *o)
{
    opts_free();
    if (!o || !o->definitions)
        return;
    for (const struct retro_core_option_v2_definition *d = o->definitions; d->key && g_nopts < MAX_OPTS; d++) {
        core_opt_t *c = &g_opts[g_nopts];
        int n = 0;

        str_copy(c->key, d->key, sizeof(c->key));
        str_copy(c->desc, d->desc_categorized ? d->desc_categorized : (d->desc ? d->desc : d->key), sizeof(c->desc));
        str_copy(c->info, d->info_categorized ? d->info_categorized : (d->info ? d->info : ""), sizeof(c->info));
        str_copy(c->category, d->category_key ? d->category_key : "", sizeof(c->category));
        str_copy(c->def, d->default_value ? d->default_value : "", sizeof(c->def));

        for (int v = 0; v < RETRO_NUM_CORE_OPTION_VALUES_MAX && d->values[v].value; v++)
            n++;
        c->vals = calloc((size_t)(n ? n : 1), sizeof(core_opt_val_t));
        for (int v = 0; v < n && c->vals; v++) {
            if (value_hidden(c->key, d->values[v].value))
                continue;
            str_copy(c->vals[c->nvals].value, d->values[v].value, sizeof(c->vals[0].value));
            str_copy(c->vals[c->nvals].label, d->values[v].label ? d->values[v].label : d->values[v].value,
                     sizeof(c->vals[0].label));
            c->nvals++;
        }

        /* frontend-chosen defaults */
        if (!strcmp(c->key, "opera_vdlp_pixel_format"))
            str_copy(c->def, "0RGB1555", sizeof(c->def)); /* native format: no conversion, half the bandwidth */
        if (!strcmp(c->key, "opera_active_devices"))
            str_copy(c->def, "1", sizeof(c->def));
        g_nopts++;
    }
}

int core_opt_count(void) { return g_nopts; }
const core_opt_t *core_opt_at(int i) { return (i >= 0 && i < g_nopts) ? &g_opts[i] : NULL; }

const core_opt_t *core_opt_find(const char *key)
{
    for (int i = 0; i < g_nopts; i++)
        if (!strcmp(g_opts[i].key, key))
            return &g_opts[i];
    return NULL;
}

static bool opt_has_value(const core_opt_t *o, const char *v)
{
    for (int i = 0; i < o->nvals; i++)
        if (!strcmp(o->vals[i].value, v))
            return true;
    return false;
}

/* The option's own default (frontend-chosen where the core's was unsuitable). */
static const char *opt_default_value(const core_opt_t *o)
{
    if (o->def[0] && (o->nvals == 0 || opt_has_value(o, o->def)))
        return o->def;
    return o->nvals ? o->vals[0].value : o->def;
}

const char *core_opt_effective(const char *key)
{
    static char auto_dev[8];
    const core_opt_t *o = core_opt_find(key);
    const char *ov;

    if (!o)
        return NULL;
    ov = config_core_option_lookup(key);
    if (ov && (o->nvals == 0 || opt_has_value(o, ov)))
        return ov;
    if (!strcmp(key, "opera_active_devices")) {
        snprintf(auto_dev, sizeof(auto_dev), "%d", CLAMP(g_connected_pads, 1, 8));
        return auto_dev;
    }
    return opt_default_value(o);
}

/* What the core is told when it asks for a variable. */
static const char *core_opt_for_core(const char *key)
{
    const core_opt_t *o;

    if (!diag_on())
        return core_opt_effective(key);
    o = core_opt_find(key);
    return o ? opt_default_value(o) : NULL;
}

int core_opt_effective_index(const core_opt_t *o)
{
    const char *v = core_opt_effective(o->key);
    for (int i = 0; v && i < o->nvals; i++)
        if (!strcmp(o->vals[i].value, v))
            return i;
    return -1;
}

void core_opts_changed(void)
{
    __atomic_store_n(&g_opts_dirty, 1, __ATOMIC_RELEASE);
}

void core_set_connected_pads(int n)
{
    n = CLAMP(n, 1, 8);
    if (n != g_connected_pads) {
        g_connected_pads = n;
        if (!config_core_option_lookup("opera_active_devices"))
            core_opts_changed();
    }
}

void core_opts_rescan(void)
{
    if (!g_inited)
        return;
    libretro_init_core_options();
    libretro_set_core_options();
    core_opts_changed();
}

/* ------------------------------------------------------- libretro callbacks */

static void RETRO_CALLCONV core_log(enum retro_log_level level, const char *fmt, ...)
{
    char buf[512];
    va_list ap;
    size_t n;

    va_start(ap, fmt);
    vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    n = strlen(buf);
    while (n && (buf[n - 1] == '\n' || buf[n - 1] == '\r'))
        buf[--n] = '\0';
    switch (level) {
    case RETRO_LOG_DEBUG: LOGD("[core] %s", buf); break;
    case RETRO_LOG_INFO:  LOGI("[core] %s", buf); break;
    case RETRO_LOG_WARN:  LOGW("[core] %s", buf); break;
    default:              LOGE("[core] %s", buf); break;
    }
}

static void update_geometry(const struct retro_game_geometry *g)
{
    g_av.width = g->base_width;
    g_av.height = g->base_height;
    g_av.max_width = g->max_width;
    g_av.max_height = g->max_height;
    g_av.aspect = g->aspect_ratio > 0.1f ? g->aspect_ratio
                                         : (g->base_height ? (float)g->base_width / (float)g->base_height : 4.0f / 3.0f);
}

static bool RETRO_CALLCONV env_cb(unsigned cmd, void *data)
{
    switch (cmd) {
    case RETRO_ENVIRONMENT_GET_CAN_DUPE:
        *(bool *)data = true;
        return true;
    case RETRO_ENVIRONMENT_SET_PIXEL_FORMAT: {
        enum retro_pixel_format f = *(enum retro_pixel_format *)data;
        if (f == RETRO_PIXEL_FORMAT_0RGB1555) {
            g_av.format = CORE_PF_0RGB1555;
            return true;
        }
        if (f == RETRO_PIXEL_FORMAT_XRGB8888) {
            g_av.format = CORE_PF_XRGB8888;
            return true;
        }
        LOGW("core asked for unsupported pixel format %d", (int)f);
        return false;
    }
    case RETRO_ENVIRONMENT_GET_SYSTEM_DIRECTORY:
        *(const char **)data = diag_on() ? g_diag_dir : g_sys_dir;
        return true;
    case RETRO_ENVIRONMENT_GET_SAVE_DIRECTORY:
        *(const char **)data = diag_on() ? g_diag_dir : g_save_dir;
        return true;
    case RETRO_ENVIRONMENT_GET_LOG_INTERFACE:
        ((struct retro_log_callback *)data)->log = core_log;
        return true;
    case RETRO_ENVIRONMENT_GET_LANGUAGE:
        *(unsigned *)data = RETRO_LANGUAGE_ENGLISH;
        return true;
    case RETRO_ENVIRONMENT_GET_INPUT_MAX_USERS:
        *(unsigned *)data = MAX_PADS;
        return true;
    case RETRO_ENVIRONMENT_GET_CORE_OPTIONS_VERSION:
        *(unsigned *)data = 2;
        return true;
    case RETRO_ENVIRONMENT_SET_CORE_OPTIONS_V2:
        opts_ingest_v2((const struct retro_core_options_v2 *)data);
        return true;
    case RETRO_ENVIRONMENT_SET_CORE_OPTIONS_V2_INTL:
        opts_ingest_v2(((const struct retro_core_options_v2_intl *)data)->us);
        return true;
    case RETRO_ENVIRONMENT_GET_VARIABLE: {
        struct retro_variable *var = (struct retro_variable *)data;
        const char *v = var->key ? core_opt_for_core(var->key) : NULL;
        var->value = v;
        return v != NULL;
    }
    case RETRO_ENVIRONMENT_GET_VARIABLE_UPDATE:
        *(bool *)data = __atomic_exchange_n(&g_opts_dirty, 0, __ATOMIC_ACQ_REL) != 0;
        return true;
    case RETRO_ENVIRONMENT_SET_SYSTEM_AV_INFO: {
        const struct retro_system_av_info *info = (const struct retro_system_av_info *)data;
        update_geometry(&info->geometry);
        g_av.fps = info->timing.fps;
        g_av.sample_rate = info->timing.sample_rate;
        __atomic_store_n(&g_av_changed, 1, __ATOMIC_RELEASE);
        return true;
    }
    case RETRO_ENVIRONMENT_SET_GEOMETRY:
        update_geometry((const struct retro_game_geometry *)data);
        __atomic_store_n(&g_av_changed, 1, __ATOMIC_RELEASE);
        return true;
    case RETRO_ENVIRONMENT_SET_MESSAGE: {
        const struct retro_message *m = (const struct retro_message *)data;
        if (m && m->msg)
            msg_push(m->msg);
        return true;
    }
    case RETRO_ENVIRONMENT_SET_MESSAGE_EXT: {
        const struct retro_message_ext *m = (const struct retro_message_ext *)data;
        if (m && m->msg)
            msg_push(m->msg);
        return true;
    }
    case RETRO_ENVIRONMENT_SHUTDOWN:
        g_shutdown_req = true;
        return true;
    case RETRO_ENVIRONMENT_GET_THROTTLE_STATE: {
        struct retro_throttle_state *t = (struct retro_throttle_state *)data;
        t->mode = input_fast_forward() ? RETRO_THROTTLE_FAST_FORWARD : RETRO_THROTTLE_NONE;
        t->rate = 0.0f;
        return true;
    }
    case RETRO_ENVIRONMENT_SET_ROTATION:
    case RETRO_ENVIRONMENT_SET_PERFORMANCE_LEVEL:
    case RETRO_ENVIRONMENT_SET_SUPPORT_NO_GAME:
    case RETRO_ENVIRONMENT_SET_INPUT_DESCRIPTORS:
    case RETRO_ENVIRONMENT_SET_CONTROLLER_INFO:
    case RETRO_ENVIRONMENT_SET_SERIALIZATION_QUIRKS:
    case RETRO_ENVIRONMENT_SET_MINIMUM_AUDIO_LATENCY:
        return true;
    default:
        return false; /* VFS, rumble, hw render, disk control, ... not offered */
    }
}

static void RETRO_CALLCONV video_cb(const void *data, unsigned w, unsigned h, size_t pitch)
{
    if (!data || !g_sink.video)
        return;
    g_av.width = w;
    g_av.height = h;
    g_sink.video(data, w, h, pitch, g_av.format);
}

static void RETRO_CALLCONV audio_cb(int16_t l, int16_t r)
{
    int16_t f[2] = {l, r};
    if (g_sink.audio)
        g_sink.audio(f, 1);
}

static size_t RETRO_CALLCONV audio_batch_cb(const int16_t *data, size_t frames)
{
    return g_sink.audio ? g_sink.audio(data, frames) : frames;
}

static void RETRO_CALLCONV input_poll_cb(void) {}

static int16_t RETRO_CALLCONV input_state_cb(unsigned port, unsigned device, unsigned index, unsigned id)
{
    uint32_t m;
    (void)index;
    if ((device & RETRO_DEVICE_MASK) != RETRO_DEVICE_JOYPAD || port >= MAX_PADS || diag_on())
        return 0;
    m = input_port_state(port);
    if (id == RETRO_DEVICE_ID_JOYPAD_MASK)
        return (int16_t)(m & 0xFFFF);
    return (id < 16) ? (int16_t)((m >> id) & 1u) : 0;
}

/* --------------------------------------------------------------- lifecycle */

/*
 * Runs on the DSP thread as it starts, when the DSP is given a thread of its own. The Wii U has three cores and
 * its threads stay where they are put: the interface draws on core 1 and the emulation runs on the core chosen in
 * the settings (2 unless changed), so the DSP goes to whichever of the two outer cores the emulation is not on.
 * Left unpinned it could be scheduled next to the emulation thread, and then it would take time from the very
 * thread it is meant to relieve.
 */
static void dsp_thread_started(void)
{
    if (g_cfg.emu_core >= 0)
        platform_pin_thread(g_cfg.emu_core == 0 ? 2 : 0);
}

bool core_init(const core_sink_t *sink)
{
    struct retro_system_info si;

    if (g_inited)
        return true;
    g_sink = *sink;
    g_msg_lock = SDL_CreateMutex();
    path_join(g_sys_dir, sizeof(g_sys_dir), platform_data_dir(), "bios");
    path_join(g_save_dir, sizeof(g_save_dir), platform_data_dir(), "saves");
    platform_mkdirs(g_sys_dir);
    platform_mkdirs(g_save_dir);

    opera_lr_dsp_thread_start_hook = dsp_thread_started;
    retro_set_environment(env_cb);
    retro_set_video_refresh(video_cb);
    retro_set_audio_sample(audio_cb);
    retro_set_audio_sample_batch(audio_batch_cb);
    retro_set_input_poll(input_poll_cb);
    retro_set_input_state(input_state_cb);
    retro_init();

    memset(&si, 0, sizeof(si));
    retro_get_system_info(&si);
    LOGI("core: %s %s (%s)", si.library_name, si.library_version, si.valid_extensions);
    LOGI("core: %d options registered", g_nopts);

    g_av.format = CORE_PF_0RGB1555;
    g_av.aspect = 4.0f / 3.0f;
    g_av.fps = 60.0;
    g_av.sample_rate = 44100.0;
    g_inited = true;
    return true;
}

void core_diag_enter(const char *scratch_dir)
{
    str_copy(g_diag_dir, scratch_dir ? scratch_dir : "", sizeof(g_diag_dir));
    __atomic_store_n(&g_diag, 1, __ATOMIC_RELEASE);
}

void core_diag_leave(void)
{
    __atomic_store_n(&g_diag, 0, __ATOMIC_RELEASE);
}

void core_set_sink(const core_sink_t *sink)
{
    g_sink = *sink;
}

core_sink_t core_get_sink(void)
{
    return g_sink;
}

void core_deinit(void)
{
    if (!g_inited)
        return;
    if (g_loaded)
        core_unload();
    retro_deinit();
    opts_free();
    if (g_msg_lock)
        SDL_DestroyMutex(g_msg_lock);
    g_msg_lock = NULL;
    g_inited = false;
}
/*
 * wiiu/OperaU/disc.txt: what the disc image actually contains, written whenever a game is opened.
 *
 * A game that starts but draws nothing looks exactly like a game that failed to load, and the difference matters:
 * one is the image, the other is the emulator. This reads the image through the same layer the 3DO side uses and
 * writes down what came back - how many blocks, and the 3DO volume header that sits in the first sector of every
 * real 3DO disc (a record type of 1, five 0x5A sync bytes, then the disc's own comment and label). If those are
 * right, the image is a readable 3DO disc and the fault is further in; if they are not, it is the image or the
 * way it was converted.
 */
static void disc_report(const char *path, bool loaded)
{
    static const char k_sync[5] = {0x5A, 0x5A, 0x5A, 0x5A, 0x5A};
    cdimage_t *cd;
    uint8_t sector[2048];
    char text[2600], out[1100], label[33], comment[33];
    uint32_t blocks = 0;
    int n, ok_sector = 0;

    if (!path || !*path)
        return;

    cd = (cdimage_t *)calloc(1, sizeof(*cd)); /* far too big for the stack */
    n = snprintf(text, sizeof(text), "%s %s disc report\nbuild:          %s\nimage:          %s\nloaded by core: %s\n",
                 APP_NAME, APP_VERSION, APP_BUILD, path, loaded ? "yes" : "NO");
    if (!cd) {
        n += snprintf(text + n, sizeof(text) - (size_t)n, "error:          out of memory\n");
    } else if (retro_cdimage_open(path, cd) != 0) {
        n += snprintf(text + n, sizeof(text) - (size_t)n, "error:          the image could not be opened at all\n");
    } else {
        blocks = (uint32_t)retro_cdimage_get_number_of_logical_blocks(cd);
        n += snprintf(text + n, sizeof(text) - (size_t)n,
                      "blocks:         %u (%.1f MB of data sectors)\n", blocks, blocks * 2048.0 / 1048576.0);
        ok_sector = (retro_cdimage_read_sector(cd, 0, sector, sizeof(sector)) == (ssize_t)sizeof(sector));
        if (!ok_sector) {
            n += snprintf(text + n, sizeof(text) - (size_t)n, "error:          the first sector could not be read\n");
        } else {
            memcpy(label, sector + 40, 32);
            label[32] = '\0';
            memcpy(comment, sector + 8, 32);
            comment[32] = '\0';
            n += snprintf(text + n, sizeof(text) - (size_t)n,
                          "record type:    %u (a 3DO disc has 1)\n"
                          "sync bytes:     %02x %02x %02x %02x %02x (a 3DO disc has 5a five times)\n"
                          "looks like 3DO: %s\n"
                          "disc comment:   %s\n"
                          "disc label:     %s\n",
                          sector[0], sector[1], sector[2], sector[3], sector[4], sector[5],
                          (sector[0] == 1 && !memcmp(sector + 1, k_sync, sizeof(k_sync))) ? "yes" : "NO",
                          comment, label);
            n += snprintf(text + n, sizeof(text) - (size_t)n, "first 32 bytes: ");
            for (int i = 0; i < 32 && n > 0 && (size_t)n < sizeof(text) - 4; i++)
                n += snprintf(text + n, sizeof(text) - (size_t)n, "%02x", sector[i]);
            n += snprintf(text + n, sizeof(text) - (size_t)n, "\n");
        }
        {   /* a handful of sectors spread over the disc, to catch an image that is short or damaged */
            uint32_t probes[6], bad = 0, i;

            probes[0] = 0;
            probes[1] = blocks / 8;
            probes[2] = blocks / 4;
            probes[3] = blocks / 2;
            probes[4] = (blocks > 4) ? (blocks - 4) : 0;
            probes[5] = (blocks > 1) ? (blocks - 1) : 0;
            for (i = 0; i < 6; i++)
                if (retro_cdimage_read_sector(cd, probes[i], sector, sizeof(sector)) != (ssize_t)sizeof(sector))
                    bad++;
            n += snprintf(text + n, sizeof(text) - (size_t)n, "spot checks:    %u of 6 sectors read back\n", 6 - bad);
        }
        retro_cdimage_close(cd);
    }
    free(cd);

    path_join(out, sizeof(out), platform_data_dir(), "disc.txt");
    platform_write_file_atomic(out, text, strlen(text));
    LOGI("disc: %u blocks, first sector %s", blocks, ok_sector ? "read" : "NOT read");
    log_flush();
}


bool core_load(const char *path)
{
    struct retro_game_info gi;
    struct retro_system_av_info av;
    int64_t size = 0;

    g_error[0] = '\0';
    g_error_code = CORE_ERR_NONE;
    if (!g_inited || g_loaded) {
        str_copy(g_error, "core not ready", sizeof(g_error));
        g_error_code = CORE_ERR_NOT_READY;
        return false;
    }
    g_shutdown_req = false;
    memset(&gi, 0, sizeof(gi));
    if (path) {
        size = platform_file_size(path);
        if (size < 0) {
            snprintf(g_error, sizeof(g_error), "file not found");
            g_error_code = CORE_ERR_NOT_FOUND;
            return false;
        }
        gi.path = path;
        gi.size = (size_t)size;
        str_copy(g_game_path, path, sizeof(g_game_path));
    } else {
        g_game_path[0] = '\0';
    }

    core_opts_changed();
    __atomic_exchange_n(&g_opts_dirty, 0, __ATOMIC_ACQ_REL); /* first read happens during load anyway */

    if (!retro_load_game(path ? &gi : NULL)) {
        snprintf(g_error, sizeof(g_error), path ? "the core could not open this image" : "the core could not start");
        g_error_code = path ? CORE_ERR_OPEN_IMAGE : CORE_ERR_START;
        LOGE("retro_load_game failed for %s", path ? path : "(no content)");
        disc_report(path, false);
        g_game_path[0] = '\0';
        return false;
    }

    memset(&av, 0, sizeof(av));
    retro_get_system_av_info(&av);
    update_geometry(&av.geometry);
    g_av.fps = av.timing.fps > 1.0 ? av.timing.fps : 60.0;
    g_av.sample_rate = av.timing.sample_rate > 1.0 ? av.timing.sample_rate : 44100.0;

    for (unsigned p = 0; p < MAX_PADS; p++)
        retro_set_controller_port_device(p, RETRO_DEVICE_JOYPAD);

    opera_hooks_nvram_baseline();
    disc_report(path, true);
    g_loaded = true;
    LOGI("loaded: %s  %ux%u @ %.3f Hz, audio %.0f Hz, format %s", path ? path : "(Opera Boot)", g_av.width,
         g_av.height, g_av.fps, g_av.sample_rate, g_av.format == CORE_PF_XRGB8888 ? "XRGB8888" : "0RGB1555");
    return true;
}

void core_unload(void)
{
    if (!g_loaded)
        return;
    retro_unload_game(); /* writes NVRAM */
    g_loaded = false;
    g_game_path[0] = '\0';
}

bool core_is_loaded(void) { return g_loaded; }
const char *core_game_path(void) { return g_loaded && g_game_path[0] ? g_game_path : NULL; }
const char *core_last_error(void) { return g_error; }
core_err_t core_last_error_code(void) { return g_error_code; }
const core_av_t *core_av(void) { return &g_av; }
bool core_shutdown_requested(void) { return g_shutdown_req; }

bool core_av_take_changed(void)
{
    return __atomic_exchange_n(&g_av_changed, 0, __ATOMIC_ACQ_REL) != 0;
}

void core_run(void)
{
    if (g_loaded)
        retro_run();
}

const void *core_memory(unsigned which, size_t *size)
{
    unsigned id = which ? RETRO_MEMORY_VIDEO_RAM : RETRO_MEMORY_SYSTEM_RAM;
    void *p = g_loaded ? retro_get_memory_data(id) : NULL;

    if (size)
        *size = p ? retro_get_memory_size(id) : 0;
    return p;
}

void core_reset(void)
{
    if (g_loaded) {
        retro_reset();
        opera_hooks_nvram_baseline();
    }
}

size_t core_state_size(void)
{
    return g_loaded ? retro_serialize_size() : 0;
}

bool core_state_save(void *buf, size_t size)
{
    return g_loaded && retro_serialize(buf, size);
}

bool core_state_load(const void *buf, size_t size)
{
    return g_loaded && retro_unserialize(buf, size);
}

void core_flush_nvram(void)
{
    if (g_loaded && opera_hooks_nvram_flush(g_game_path[0] ? g_game_path : NULL))
        LOGD("nvram flushed");
}
