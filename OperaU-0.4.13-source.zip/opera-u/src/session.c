#include "session.h"
#include "audio.h"
#include "config.h"
#include "core.h"
#include "input.h"
#include "log.h"
#include "perf.h"
#include "platform.h"
#include "video.h"

#include <SDL.h>
#include <ctype.h>
#include <time.h>

#define NVRAM_FLUSH_FRAMES 600
#define AUDIO_WAIT_MAX_MS 60

typedef struct {
    char magic[4];
    uint32_t size;
    uint32_t hash;
    uint32_t reserved;
} state_hdr_t;

static struct {
    SDL_Thread *thread;
    SDL_mutex *lock;
    SDL_cond *cond;
    uint32_t want_run;   /* atomic */
    uint32_t quit;       /* atomic */
    bool parked;         /* guarded by lock */
    uint32_t frames;     /* atomic frame counter */
    int pinned_core;
} E = {.pinned_core = -2};

static bool g_loaded;
static bool g_resumed;
static char g_path[1024];
static char g_title[128];
static char g_err[512];

/* fps measurement for the HUD */
static uint32_t g_hud_frames;
static uint64_t g_hud_t0;
static float g_hud_fps;

/* ------------------------------------------------------------------ sinks */

static void sink_video(const void *data, unsigned w, unsigned h, size_t pitch, core_pixel_format_t fmt)
{
    video_submit(data, w, h, pitch, fmt);
}

static uint32_t g_audio_handed; /* sound the core handed over during the frame being run; emulation thread only */

static size_t sink_audio(const int16_t *frames, size_t n)
{
    g_audio_handed += (uint32_t)n;
    if (!input_fast_forward())  /* fast-forward is silent */
        audio_push(frames, n);
    return n;
}

/* ---------------------------------------------------------- emulation thread */

static int emu_main(void *arg)
{
    uint64_t next = 0;
    unsigned flush_count = 0;
    bool was_background = false;
    uint32_t t_start = 0, t_run = 0;
    (void)arg;

    for (;;) {
        if (__atomic_load_n(&E.quit, __ATOMIC_ACQUIRE))
            break;
        perf_sync();

        if (!__atomic_load_n(&E.want_run, __ATOMIC_ACQUIRE)) {
            perf_flush(); /* paused or closing: what the game was doing just now goes to the card */
            SDL_LockMutex(E.lock);
            E.parked = true;
            SDL_CondBroadcast(E.cond);
            while (!__atomic_load_n(&E.quit, __ATOMIC_ACQUIRE) && !__atomic_load_n(&E.want_run, __ATOMIC_ACQUIRE))
                SDL_CondWait(E.cond, E.lock);
            E.parked = false;
            SDL_UnlockMutex(E.lock);
            if (E.pinned_core != g_cfg.emu_core) { /* setting changed since the thread started */
                platform_pin_thread(g_cfg.emu_core);
                E.pinned_core = g_cfg.emu_core;
            }
            next = platform_time_us();
            perf_reset();
            continue;
        }

        if (platform_in_background()) { /* HOME menu is open: stand still */
            if (!was_background) {
                core_flush_nvram();
                perf_flush();
                was_background = true;
            }
            platform_sleep_ms(20);
            next = platform_time_us();
            perf_reset();
            continue;
        }
        was_background = false;

        g_audio_handed = 0;
        t_start = perf_now();
        core_run();
        t_run = perf_now();
        __atomic_fetch_add(&E.frames, 1, __ATOMIC_RELAXED);
        if (++flush_count >= NVRAM_FLUSH_FRAMES) {
            flush_count = 0;
            core_flush_nvram();
        }
        if (core_shutdown_requested()) {
            __atomic_store_n(&E.want_run, 0, __ATOMIC_RELEASE);
            continue;
        }

        /* pacing */
        if (input_fast_forward()) {
            next = platform_time_us();
        } else if (audio_available() && g_audio_handed) {
            /* The sound is the clock: the emulation waits whenever more of it is queued than should be. */
            audio_wait_for_room(AUDIO_WAIT_MAX_MS);
            next = platform_time_us();
        } else {
            /*
             * No sound device - or a frame that handed over no sound at all, which leaves the wait above nothing
             * to wait for: it happened on the console, with the DSP's thread stuck, and the game ran at twice its
             * speed. Such a frame is paced by the wall clock, at the machine's own rate.
             */
            uint64_t now = platform_time_us();
            double fps = core_av()->fps > 1.0 ? core_av()->fps : 60.0;
            next += (uint64_t)(1000000.0 / fps);
            if (next > now)
                platform_sleep_ms((uint32_t)((next - now) / 1000));
            else if (now - next > 100000)
                next = now;
        }
        perf_frame(t_run - t_start, perf_now() - t_run);
    }
    return 0;
}

bool session_init(void)
{
    core_sink_t sink = {sink_video, sink_audio};

    if (!core_init(&sink))
        return false;
    E.lock = SDL_CreateMutex();
    E.cond = SDL_CreateCond();
    if (!E.lock || !E.cond)
        return false;
    E.thread = SDL_CreateThreadWithStackSize(emu_main, "operau-emu", 1024 * 1024, NULL);
    if (!E.thread) {
        LOGE("cannot start the emulation thread: %s", SDL_GetError());
        return false;
    }
    return true;
}

void session_pause(void)
{
    if (!E.thread)
        return;
    __atomic_store_n(&E.want_run, 0, __ATOMIC_RELEASE);
    SDL_LockMutex(E.lock);
    SDL_CondBroadcast(E.cond);
    while (!E.parked)
        SDL_CondWaitTimeout(E.cond, E.lock, 20);
    SDL_UnlockMutex(E.lock);
    audio_pause(true);
}

void session_resume(void)
{
    if (!E.thread || !g_loaded)
        return;
    audio_flush();
    audio_pause(false);
    __atomic_store_n(&E.want_run, 1, __ATOMIC_RELEASE);
    SDL_LockMutex(E.lock);
    SDL_CondBroadcast(E.cond);
    SDL_UnlockMutex(E.lock);
}

bool session_running(void)
{
    return __atomic_load_n(&E.want_run, __ATOMIC_ACQUIRE) != 0;
}

bool session_core_wants_exit(void)
{
    return g_loaded && core_shutdown_requested();
}

void session_shutdown(void)
{
    if (g_loaded)
        session_close_game();
    if (E.thread) {
        __atomic_store_n(&E.quit, 1, __ATOMIC_RELEASE);
        SDL_LockMutex(E.lock);
        SDL_CondBroadcast(E.cond);
        SDL_UnlockMutex(E.lock);
        SDL_WaitThread(E.thread, NULL);
        E.thread = NULL;
    }
    if (E.cond)
        SDL_DestroyCond(E.cond);
    if (E.lock)
        SDL_DestroyMutex(E.lock);
    E.cond = NULL;
    E.lock = NULL;
    core_deinit();
}

/* ------------------------------------------------------------- state files */

static void game_key(const char *path, char *out, size_t cap)
{
    char stem[256];
    uint32_t h = 2166136261u;
    const char *base;

    if (!path || !*path) {
        str_copy(out, "bios", cap);
        return;
    }
    base = path_base(path);
    for (const char *p = base; *p; p++) {
        h ^= (unsigned char)*p;
        h *= 16777619u;
    }
    path_stem(stem, sizeof(stem), path);
    for (char *p = stem; *p; p++)
        if (!isalnum((unsigned char)*p) && *p != '-' && *p != '_' && *p != '.')
            *p = '_';
    if (strlen(stem) > 56)
        stem[56] = '\0';
    snprintf(out, cap, "%s-%08x", stem, (unsigned)h);
}

static void state_file(const char *game_path, int slot, char *out, size_t cap)
{
    char key[96], name[160], dir[1100];
    game_key(game_path, key, sizeof(key));
    if (slot < 0)
        snprintf(name, sizeof(name), "%s.auto.state", key);
    else
        snprintf(name, sizeof(name), "%s.%d.state", key, slot);
    path_join(dir, sizeof(dir), platform_data_dir(), "states");
    path_join(out, cap, dir, name);
}

static uint32_t fnv1a(const void *data, size_t len)
{
    const uint8_t *p = (const uint8_t *)data;
    uint32_t h = 2166136261u;
    for (size_t i = 0; i < len; i++) {
        h ^= p[i];
        h *= 16777619u;
    }
    return h;
}

static bool write_state_file(const char *file)
{
    size_t size = core_state_size();
    uint8_t *buf;
    state_hdr_t hdr;
    bool ok;
    uint64_t t0 = platform_time_us();

    if (size == 0) {
        str_copy(g_err, "the core reports an empty state", sizeof(g_err));
        return false;
    }
    buf = (uint8_t *)malloc(sizeof(hdr) + size);
    if (!buf) {
        str_copy(g_err, "out of memory", sizeof(g_err));
        return false;
    }
    if (!core_state_save(buf + sizeof(hdr), size)) {
        free(buf);
        str_copy(g_err, "the core could not serialise its state", sizeof(g_err));
        return false;
    }
    memcpy(hdr.magic, "OPS1", 4);
    hdr.size = (uint32_t)size;
    hdr.hash = fnv1a(buf + sizeof(hdr), size);
    hdr.reserved = 0;
    memcpy(buf, &hdr, sizeof(hdr));
    ok = platform_write_file_atomic(file, buf, sizeof(hdr) + size);
    free(buf);
    if (!ok)
        str_copy(g_err, "cannot write the state file (is the SD card full or locked?)", sizeof(g_err));
    LOGI("state %s: %s (%zu bytes, %d ms)", ok ? "saved" : "FAILED", file, size, (int)((platform_time_us() - t0) / 1000));
    return ok;
}

static bool read_state_file(const char *file)
{
    size_t len = 0;
    uint8_t *buf = (uint8_t *)platform_read_file(file, &len);
    state_hdr_t hdr;
    bool ok = false;

    if (!buf) {
        str_copy(g_err, "no state in this slot", sizeof(g_err));
        return false;
    }
    if (len > sizeof(hdr)) {
        memcpy(&hdr, buf, sizeof(hdr));
        if (!memcmp(hdr.magic, "OPS1", 4) && hdr.size == len - sizeof(hdr) &&
            hdr.hash == fnv1a(buf + sizeof(hdr), hdr.size)) {
            ok = core_state_load(buf + sizeof(hdr), hdr.size);
            if (!ok)
                str_copy(g_err, "the core rejected this state (saved with another BIOS or core option?)", sizeof(g_err));
        } else {
            str_copy(g_err, "the state file is damaged", sizeof(g_err));
        }
    } else {
        str_copy(g_err, "the state file is damaged", sizeof(g_err));
    }
    free(buf);
    LOGI("state %s: %s", ok ? "loaded" : "FAILED", file);
    return ok;
}

bool session_save_state(int slot)
{
    char file[1100];
    if (!g_loaded)
        return false;
    state_file(g_path[0] ? g_path : NULL, slot, file, sizeof(file));
    return write_state_file(file);
}

bool session_load_state(int slot)
{
    char file[1100];
    bool ok;
    if (!g_loaded)
        return false;
    state_file(g_path[0] ? g_path : NULL, slot, file, sizeof(file));
    ok = read_state_file(file);
    if (ok)
        audio_flush();
    return ok;
}

bool session_state_exists(int slot)
{
    char file[1100];
    if (!g_loaded)
        return false;
    state_file(g_path[0] ? g_path : NULL, slot, file, sizeof(file));
    return platform_exists(file);
}

bool session_autostate_exists(const char *game_path)
{
    char file[1100];
    state_file(game_path, -1, file, sizeof(file));
    return platform_exists(file);
}

/* ---------------------------------------------------------------- lifecycle */

bool session_resumed(void)
{
    return g_resumed;
}

bool session_launch(const char *path, bool resume_auto_state)
{
    g_err[0] = '\0';
    g_resumed = false;
    if (g_loaded)
        session_close_game();

    if (path && *path) {
        config_game_open(path);
        str_copy(g_path, path, sizeof(g_path));
        path_stem(g_title, sizeof(g_title), path);
    } else {
        config_game_close();
        g_path[0] = '\0';
        str_copy(g_title, "Opera Boot", sizeof(g_title));
    }

    core_set_connected_pads(input_connected_count());
    if (!core_load(g_path[0] ? g_path : NULL)) {
        snprintf(g_err, sizeof(g_err), "%s", core_last_error());
        config_game_close();
        g_path[0] = '\0';
        return false;
    }
    g_loaded = true;

    audio_set_input_rate(core_av()->sample_rate);
    audio_set_volume(g_cfg.volume);
    audio_set_latency(g_cfg.latency_ms);
    audio_flush();
    video_reset();
    video_set_game_aspect(core_av()->aspect);
    video_apply_settings();

    if (g_path[0]) {
        config_add_recent(g_path);
        config_save();
    }
    if (resume_auto_state && g_path[0]) {
        char file[1100];
        state_file(g_path, -1, file, sizeof(file));
        if (read_state_file(file))
            g_resumed = true;
        else
            LOGW("could not resume the automatic state: %s", g_err);
        g_err[0] = '\0';
    }
    g_hud_frames = __atomic_load_n(&E.frames, __ATOMIC_RELAXED);
    g_hud_t0 = platform_time_us();
    return true;
}

void session_close_game(void)
{
    if (!g_loaded)
        return;
    session_pause();
    if (g_cfg.autosave_state && g_path[0]) {
        char file[1100];
        state_file(g_path, -1, file, sizeof(file));
        write_state_file(file);
    }
    core_unload(); /* the core writes the NVRAM here */
    config_game_close();
    g_loaded = false;
    g_path[0] = '\0';
    g_title[0] = '\0';
    audio_flush();
}

bool session_active(void) { return g_loaded; }
const char *session_title(void) { return g_title; }
const char *session_error(void) { return g_err; }

void session_reset(void)
{
    if (!g_loaded)
        return;
    core_reset();
    audio_flush();
}

bool session_screenshot(char *out_path, size_t cap)
{
    char dir[1100], key[96], name[160];
    time_t now = time(NULL);
    struct tm tmv;
    char stamp[32];

    if (!g_loaded)
        return false;
    path_join(dir, sizeof(dir), platform_data_dir(), "shots");
    platform_mkdirs(dir);
    game_key(g_path[0] ? g_path : NULL, key, sizeof(key));
    if (strlen(key) > 9) /* drop the hash suffix for a friendlier name */
        key[strlen(key) - 9] = '\0';
#ifdef __WIIU__
    gmtime_r(&now, &tmv);
#else
    localtime_r(&now, &tmv);
#endif
    strftime(stamp, sizeof(stamp), "%Y%m%d-%H%M%S", &tmv);
    snprintf(name, sizeof(name), "%s-%s.png", key, stamp);
    path_join(out_path, cap, dir, name);
    return video_save_game_frame_png(out_path);
}

void session_hud(ui_hud_t *h)
{
    uint64_t now = platform_time_us();
    uint32_t frames = __atomic_load_n(&E.frames, __ATOMIC_RELAXED);

    if (now - g_hud_t0 >= 500000) {
        g_hud_fps = (float)(frames - g_hud_frames) * 1000000.0f / (float)(now - g_hud_t0);
        g_hud_frames = frames;
        g_hud_t0 = now;
    }
    h->emu_fps = g_hud_fps;
    h->video_fps = video_present_fps();
    h->audio_ms = audio_available() ? audio_buffered_frames() * 1000 / 48000 : 0;
    h->fast_forward = input_fast_forward();
    if (!g_cfg.show_fps || !perf_hud_text(h->perf, sizeof(h->perf)))
        h->perf[0] = '\0';
}
