#include <stdbool.h>
#include <stdint.h>
#include <string.h>

#include "opera_hooks.h"
#include "opera_lr_nvram.h"
#include "opera_lr_opts.h"
#include "libopera/opera_mem.h"

static uint32_t g_baseline;
static bool g_have_baseline;

static uint32_t nvram_hash(void)
{
    /* FNV-1a over 32 KB: far below a millisecond even on the Espresso */
    uint32_t h = 2166136261u;
    const uint8_t *p = NVRAM;
    if (p == NULL)
        return 0;
    for (uint32_t i = 0; i < NVRAM_SIZE; i++) {
        h ^= p[i];
        h *= 16777619u;
    }
    return h;
}

void opera_hooks_nvram_baseline(void)
{
    g_baseline = nvram_hash();
    g_have_baseline = true;
}

bool opera_hooks_nvram_flush(const char *game_path)
{
    uint32_t now;

    if (!g_OPTS.initialized_opera || NVRAM == NULL)
        return false;
    now = nvram_hash();
    if (g_have_baseline && now == g_baseline)
        return false;
    opera_lr_nvram_save(game_path, g_OPTS.nvram_shared, g_OPTS.nvram_version);
    g_baseline = now;
    g_have_baseline = true;
    return true;
}

bool opera_hooks_core_ready(void)
{
    return g_OPTS.initialized_opera;
}
