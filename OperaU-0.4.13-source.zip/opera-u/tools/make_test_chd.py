#!/usr/bin/env python3
"""Wraps an ISO (2048-byte sectors) into an uncompressed CHD v5 (MODE1_RAW).

Only meant for tests: it lets us exercise the CHD loading path without
chdman. Real users should run `chdman createcd -i game.cue -o game.chd`.

usage: make_test_chd.py in.iso out.chd
"""
import hashlib
import struct
import sys

FRAME = 2448          # 2352 raw sector + 96 sub-code
HUNK_FRAMES = 8
HUNK = FRAME * HUNK_FRAMES


def bcd(v):
    return ((v // 10) << 4) | (v % 10)


def raw_sector(lba, data):
    lba += 150
    m, s, f = lba // (60 * 75), (lba // 75) % 60, lba % 75
    sec = bytearray(2352)
    sec[0] = 0
    sec[1:11] = b"\xff" * 10
    sec[11] = 0
    sec[12:16] = bytes([bcd(m), bcd(s), bcd(f), 1])
    sec[16:16 + 2048] = data
    return bytes(sec) + bytes(96)


def main(src, dst):
    iso = open(src, "rb").read()
    if len(iso) % 2048:
        iso += bytes(2048 - len(iso) % 2048)
    sectors = len(iso) // 2048
    padded = (sectors + HUNK_FRAMES - 1) // HUNK_FRAMES * HUNK_FRAMES
    frames = [raw_sector(i, iso[i * 2048:(i + 1) * 2048]) if i < sectors else bytes(FRAME) for i in range(padded)]
    body = b"".join(frames)
    hunks = len(body) // HUNK

    meta_text = ("TRACK:1 TYPE:MODE1_RAW SUBTYPE:NONE FRAMES:%d PREGAP:0 PGTYPE:MODE1_RAW PGSUB:NONE POSTGAP:0\0" % sectors).encode()
    # metadata entry: tag(4) flags(1) length(3) next(8) data
    meta = b"CHT2" + bytes([1]) + len(meta_text).to_bytes(3, "big") + struct.pack(">Q", 0) + meta_text

    meta_off = 124
    map_off = meta_off + len(meta)
    first_data = (map_off + hunks * 4 + HUNK - 1) // HUNK      # in hunks
    hunk_map = b"".join(struct.pack(">I", first_data + i) for i in range(hunks))

    raw_sha = hashlib.sha1(body).digest()
    header = b"MComprHD" + struct.pack(">II", 124, 5)
    header += bytes(16)                                         # no compressors
    header += struct.pack(">QQQ", len(body), map_off, meta_off)
    header += struct.pack(">II", HUNK, FRAME)
    header += raw_sha + raw_sha + bytes(20)
    assert len(header) == 124, len(header)

    out = bytearray(first_data * HUNK)
    out[0:124] = header
    out[meta_off:meta_off + len(meta)] = meta
    out[map_off:map_off + len(hunk_map)] = hunk_map
    out += body
    open(dst, "wb").write(out)
    print("%s: %d sectors, %d hunks, %d bytes" % (dst, sectors, hunks, len(out)))


if __name__ == "__main__":
    if len(sys.argv) != 3:
        sys.exit(__doc__)
    main(sys.argv[1], sys.argv[2])
