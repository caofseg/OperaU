/*
 * Newlib system-call layer for running under qemu-ppc (Linux user mode).
 * Only what the Opera core, libretro-common and our platform layer touch.
 */
#include <errno.h>
#include <fcntl.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/types.h>
#include <time.h>

static long sc(long nr, long a, long b, long c)
{
    register long r0 __asm__("0") = nr;
    register long r3 __asm__("3") = a;
    register long r4 __asm__("4") = b;
    register long r5 __asm__("5") = c;
    __asm__ volatile("sc\n\tmfcr %0" : "+r"(r0), "+r"(r3), "+r"(r4), "+r"(r5) : : "memory", "cr0", "r6", "r7", "r8", "r9", "r10", "r11", "r12", "ctr");
    if (r0 & 0x10000000) { /* CR0.SO: error, r3 = errno */
        errno = (int)r3;
        return -1;
    }
    return r3;
}

enum { K_EXIT = 1, K_READ = 3, K_WRITE = 4, K_OPEN = 5, K_CLOSE = 6, K_UNLINK = 10, K_LSEEK = 19, K_GETPID = 20,
       K_RENAME = 38, K_MKDIR = 39, K_GETTOD = 78, K_NANOSLEEP = 162, K_EXIT_GROUP = 234, K_CLOCK_GETTIME = 246 };

void _exit(int code) { for (;;) sc(K_EXIT_GROUP, code, 0, 0); }
int _read(int fd, char *buf, int n) { return (int)sc(K_READ, fd, (long)buf, n); }
int _write(int fd, const char *buf, int n) { return (int)sc(K_WRITE, fd, (long)buf, n); }
int _close(int fd) { return (int)sc(K_CLOSE, fd, 0, 0); }
int _lseek(int fd, int off, int whence) { return (int)sc(K_LSEEK, fd, off, whence); }
int _getpid(void) { return (int)sc(K_GETPID, 0, 0, 0); }
int _kill(int pid, int sig) { (void)pid; (void)sig; errno = EINVAL; return -1; }
int _isatty(int fd) { return fd >= 0 && fd <= 2; }
int _unlink(const char *p) { return (int)sc(K_UNLINK, (long)p, 0, 0); }
int _link(const char *a, const char *b) { (void)a; (void)b; errno = EMLINK; return -1; }
int rename(const char *a, const char *b) { return (int)sc(K_RENAME, (long)a, (long)b, 0); }
int mkdir(const char *p, mode_t m) { return (int)sc(K_MKDIR, (long)p, (long)m, 0); }

int _open(const char *path, int flags, int mode)
{
    int k = flags & 3; /* O_RDONLY / O_WRONLY / O_RDWR share their values */
    if (flags & O_CREAT) k |= 0x40;
    if (flags & O_EXCL) k |= 0x80;
    if (flags & O_TRUNC) k |= 0x200;
    if (flags & O_APPEND) k |= 0x400;
    return (int)sc(K_OPEN, (long)path, k, mode);
}

static void fill_stat(struct stat *st, int is_dir, long size)
{
    memset(st, 0, sizeof(*st));
    st->st_mode = is_dir ? (S_IFDIR | 0755) : (S_IFREG | 0644);
    st->st_size = size;
}

int _fstat(int fd, struct stat *st)
{
    long cur, end;
    if (fd >= 0 && fd <= 2) {
        memset(st, 0, sizeof(*st));
        st->st_mode = S_IFCHR | 0600;
        return 0;
    }
    cur = sc(K_LSEEK, fd, 0, 1);
    if (cur < 0) {
        fill_stat(st, 1, 0); /* directory: seek works but size is meaningless */
        return 0;
    }
    end = sc(K_LSEEK, fd, 0, 2);
    sc(K_LSEEK, fd, cur, 0);
    fill_stat(st, 0, end < 0 ? 0 : end);
    return 0;
}

int _stat(const char *path, struct stat *st)
{
    long fd = sc(K_OPEN, (long)path, 0x4000 /* O_DIRECTORY */, 0);
    if (fd >= 0) {
        sc(K_CLOSE, fd, 0, 0);
        fill_stat(st, 1, 0);
        return 0;
    }
    fd = sc(K_OPEN, (long)path, 0, 0);
    if (fd < 0)
        return -1;
    _fstat((int)fd, st);
    sc(K_CLOSE, fd, 0, 0);
    return 0;
}

int _gettimeofday(struct timeval *tv, void *tz)
{
    int32_t k[2] = {0, 0};
    (void)tz;
    if (sc(K_GETTOD, (long)k, 0, 0) < 0)
        return -1;
    if (tv) {
        tv->tv_sec = k[0];
        tv->tv_usec = k[1];
    }
    return 0;
}

int clock_gettime(clockid_t clk, struct timespec *ts)
{
    int32_t k[2] = {0, 0};
    if (sc(K_CLOCK_GETTIME, (long)clk, (long)k, 0) < 0)
        return -1;
    ts->tv_sec = k[0];
    ts->tv_nsec = k[1];
    return 0;
}

int nanosleep(const struct timespec *req, struct timespec *rem)
{
    int32_t k[2] = {(int32_t)req->tv_sec, (int32_t)req->tv_nsec};
    (void)rem;
    return (int)sc(K_NANOSLEEP, (long)k, 0, 0);
}

#define HEAP_BYTES (192u * 1024u * 1024u)
static char g_heap[HEAP_BYTES] __attribute__((aligned(16)));
static size_t g_brk;

void *_sbrk(ptrdiff_t inc)
{
    if (g_brk + (size_t)inc > HEAP_BYTES) {
        errno = ENOMEM;
        return (void *)-1;
    }
    void *p = g_heap + g_brk;
    g_brk += (size_t)inc;
    return p;
}

/* Directory listing is not needed by the harness (no BIOS / disc files). */
#include <dirent.h>
DIR *opendir(const char *p) { (void)p; errno = ENOENT; return NULL; }
struct dirent *readdir(DIR *d) { (void)d; return NULL; }
int closedir(DIR *d) { (void)d; return 0; }

/* newlib atexit hook expects these from the start-up files */
void __fini(void) {}
void __init(void) {}

/* The threaded DSP is compiled in but never enabled in the harness. */
#include <stdbool.h>
bool retro_eventcount_init(void *ec) { (void)ec; return false; }
void retro_eventcount_free(void *ec) { (void)ec; }
void retro_eventcount_notify(void *ec) { (void)ec; }
int retro_eventcount_prepare_wait(void *ec) { (void)ec; return 0; }
void retro_eventcount_cancel_wait(void *ec) { (void)ec; }
void retro_eventcount_commit_wait(void *ec, int key) { (void)ec; (void)key; }
void *sthread_create(void (*f)(void *), void *u) { (void)f; (void)u; return NULL; }
void sthread_join(void *t) { (void)t; }

/* -meabi makes main() call __eabi(); crt0.S already set up r2 / r13. */
void __eabi(void) {}

#include <unistd.h>
long sysconf(int name) { (void)name; return 1; }

/* ---- devkitPPC's newlib is built with retargetable locking and expects the
 * libsysbase layer; provide the (single threaded) pieces it needs. ---- */
#include <stdio.h>
#include <reent.h>
#include <sys/lock.h>

struct _reent *__getreent(void) { return _impure_ptr; }

void __libc_lock_close(_LOCK_T *l) { (void)l; }
void __libc_lock_close_recursive(_LOCK_RECURSIVE_T *l) { (void)l; }
int __libc_lock(_LOCK_T *l) { (void)l; return 0; }
int __libc_lock_recursive(_LOCK_RECURSIVE_T *l) { (void)l; return 0; }
void __libc_lock_acquire(_LOCK_T *l) { (void)l; }
void __libc_lock_acquire_recursive(_LOCK_RECURSIVE_T *l) { (void)l; }
void __libc_lock_release(_LOCK_T *l) { (void)l; }
void __libc_lock_release_recursive(_LOCK_RECURSIVE_T *l) { (void)l; }
int __libc_lock_try_acquire(_LOCK_T *l) { (void)l; return 0; }
int __libc_lock_try_acquire_recursive(_LOCK_RECURSIVE_T *l) { (void)l; return 0; }
void __flockfile(FILE *f) { (void)f; }
void __funlockfile(FILE *f) { (void)f; }
int __ftrylockfile(FILE *f) { (void)f; return 0; }
void flockfile(FILE *f) { (void)f; }
void funlockfile(FILE *f) { (void)f; }
int ftrylockfile(FILE *f) { (void)f; return 0; }

#define REENT_WRAP(ret, name, plain, params, args) \
    ret name params { ret v = plain args; if (v < 0) r->_errno = errno; return v; }

int _open_r(struct _reent *r, const char *p, int f, int m) { int v = _open(p, f, m); if (v < 0) r->_errno = errno; return v; }
int _close_r(struct _reent *r, int fd) { int v = _close(fd); if (v < 0) r->_errno = errno; return v; }
_ssize_t _read_r(struct _reent *r, int fd, void *b, size_t n) { int v = _read(fd, (char *)b, (int)n); if (v < 0) r->_errno = errno; return v; }
_ssize_t _write_r(struct _reent *r, int fd, const void *b, size_t n) { int v = _write(fd, (const char *)b, (int)n); if (v < 0) r->_errno = errno; return v; }
_off_t _lseek_r(struct _reent *r, int fd, _off_t o, int w) { int v = _lseek(fd, (int)o, w); if (v < 0) r->_errno = errno; return v; }
int _fstat_r(struct _reent *r, int fd, struct stat *st) { int v = _fstat(fd, st); if (v < 0) r->_errno = errno; return v; }
int _stat_r(struct _reent *r, const char *p, struct stat *st) { int v = _stat(p, st); if (v < 0) r->_errno = errno; return v; }
int _isatty_r(struct _reent *r, int fd) { (void)r; return _isatty(fd); }
int _unlink_r(struct _reent *r, const char *p) { int v = _unlink(p); if (v < 0) r->_errno = errno; return v; }
int _link_r(struct _reent *r, const char *a, const char *b) { (void)r; return _link(a, b); }
int _rename_r(struct _reent *r, const char *a, const char *b) { int v = rename(a, b); if (v < 0) r->_errno = errno; return v; }
int _kill_r(struct _reent *r, int pid, int sig) { (void)r; return _kill(pid, sig); }
int _getpid_r(struct _reent *r) { (void)r; return _getpid(); }
void *_sbrk_r(struct _reent *r, ptrdiff_t inc) { void *p = _sbrk(inc); if (p == (void *)-1) r->_errno = errno; return p; }
int _gettimeofday_r(struct _reent *r, struct timeval *tv, void *tz) { (void)r; return _gettimeofday(tv, tz); }

void __malloc_lock(struct _reent *r) { (void)r; }
void __malloc_unlock(struct _reent *r) { (void)r; }
int _rmdir_r(struct _reent *r, const char *p) { (void)p; r->_errno = ENOSYS; return -1; }
void __assert_func(const char *file, int line, const char *func, const char *expr)
{
    static const char msg[] = "assertion failed\n";
    (void)file; (void)line; (void)func; (void)expr;
    _write(2, msg, sizeof(msg) - 1);
    _exit(134);
}
