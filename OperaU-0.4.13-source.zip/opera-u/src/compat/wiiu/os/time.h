/* Compatibility shim for libretro-common (see thread.h). Provides the small
 * tick-conversion helpers the old SDK header defined. */
#ifndef OPERAU_COMPAT_WIIU_OS_TIME_H
#define OPERAU_COMPAT_WIIU_OS_TIME_H
#include <coreinit/systeminfo.h>
#include <coreinit/time.h>

#ifndef ms_to_ticks
#define ms_to_ticks(ms)   ((OSTime)OSMillisecondsToTicks(ms))
#endif
#ifndef us_to_ticks
#define us_to_ticks(us)   ((OSTime)OSMicrosecondsToTicks(us))
#endif
#ifndef ticks_to_ms
#define ticks_to_ms(t)    ((int64_t)OSTicksToMilliseconds(t))
#endif
#ifndef ticks_to_us
#define ticks_to_us(t)    ((int64_t)OSTicksToMicroseconds(t))
#endif
#endif
