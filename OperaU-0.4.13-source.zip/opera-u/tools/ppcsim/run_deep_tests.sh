#!/bin/bash
# Differential tests with random input: runs each workload on x86 (operau-host) and on big-endian
# PowerPC (harness.elf under qemu-ppc) and compares the hashes they print.
#
#   tools/ppcsim/run_deep_tests.sh [all|quick|arm|dsp|dspr|dspc|cel|celg|celu|celt|fifo|mat|sport|vdl|tmr|abench|armx ...]
#
# Environment: QEMU_PPC (default qemu-ppc), HOST (build-host/operau-host), PPC (build-ppcsim/harness.elf).
# "quick" runs a tenth of the trials. Exit status is non-zero if any workload differs.
HERE=$(cd "$(dirname "$0")" && pwd)
ROOT=$(cd "$HERE/../.." && pwd)
HOST=${HOST:-$ROOT/build-host/operau-host}
PPC=${PPC:-$ROOT/build-ppcsim/harness.elf}
QEMU_PPC=${QEMU_PPC:-qemu-ppc}
export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy OPERAU_HOME=${OPERAU_HOME:-$(mktemp -d)}

# name  trials  seed
ALL=("arm 6000 12345" "arm 6000 777" "dsp 5000 1" "dsp 5000 2" "dsp 5000 3" "dsp 5000 4" "dsp 5000 31337"
     "cel 4000 12345" "cel 4000 99" "celg 1500 777" "celg 1500 42" "celu 2000 4242" "celu 2000 7"
     "fifo 3000 1" "fifo 3000 2" "fifo 3000 3"
     "mat 20000 5" "mat 20000 6" "sport 6000 5" "sport 6000 6" "vdl 30 5" "vdl 30 6" "tmr 400 7" "tmr 400 8"
     "abench 20 5" "abench 20 6" "armx 3000 3" "armx 3000 4" "armx 3000 5" "dspr 2000 1" "dspr 2000 2" "celt 1 20261113")
div=1
want=("$@")
[ ${#want[@]} -eq 0 ] && want=(all)
for w in "${want[@]}"; do [ "$w" = quick ] && div=10; done

fail=0
for spec in "${ALL[@]}"; do
    set -- $spec
    name=$1; trials=$(($2 / div)); seed=$3
    run=0
    for w in "${want[@]}"; do
        case "$w" in all|quick|"$name") run=1 ;; esac
    done
    [ $run -eq 1 ] || continue
    x86=$("$HOST" --selftest-core --deep "$name" --trials "$trials" --seed "$seed" 2>&1 | grep -E "^$name +[0-9]+ [0-9a-f]+$")
    ppc=$("$QEMU_PPC" -cpu 750 "$PPC" deep "$name" "$trials" "$seed" 2>&1 | grep -E "^$name +[0-9]+ [0-9a-f]+$")
    last=$(echo "$x86" | tail -1)
    if [ -n "$x86" ] && [ "$x86" = "$ppc" ]; then
        printf 'same  %-5s trials %-5d seed %-6s %s\n' "$name" "$trials" "$seed" "$last"
    else
        printf 'DIFF  %-5s trials %-5d seed %-6s\n' "$name" "$trials" "$seed"
        diff <(echo "$x86") <(echo "$ppc") | head -6
        fail=1
    fi
done

# "dspc": the scripts the console's diagnostic plays with the DSP inside the frame and on its own thread. Inside
# the frame each has an x86 reference, which both machines must give. The simulator has no threads, so that half
# is all it can play; the PC plays both, and the thread must leave what the frame left.
run=0
for w in "${want[@]}"; do
    case "$w" in all|quick|dspc) run=1 ;; esac
done
if [ $run -eq 1 ]; then
    pat='^dspc +[0-9]+ inside the frame [0-9a-f]+ expected [0-9a-f]+ ok$'
    x86=$("$HOST" --selftest-core --deep dspc 2>&1)
    ppc=$("$QEMU_PPC" -cpu 750 "$PPC" deep dspc 2>&1)
    nx=$(echo "$x86" | grep -c -E "$pat")
    np=$(echo "$ppc" | grep -c -E "$pat")
    if [ "$nx" = 4 ] && [ "$np" = 4 ] && [ "$(echo "$x86" | grep -E "$pat")" = "$(echo "$ppc" | grep -E "$pat")" ]; then
        printf 'same  %-5s 4 scripts inside the frame, equal to the x86 reference on both\n' dspc
    else
        printf 'DIFF  %-5s inside the frame: %s of 4 equal to the reference on x86, %s of 4 on PowerPC\n' dspc "$nx" "$np"
        echo "$ppc" | grep -E '^dspc' | head -8
        fail=1
    fi
    if echo "$x86" | grep -q 'on a thread 4 of 4 the same'; then
        printf 'same  %-5s 4 scripts on a thread (x86), as inside the frame\n' dspc
    else
        printf 'DIFF  %-5s on a thread (x86)\n' dspc
        echo "$x86" | grep -E '^dspc' | head -8
        fail=1
    fi
fi
exit $fail
