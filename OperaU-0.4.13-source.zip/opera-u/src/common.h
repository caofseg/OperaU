/*
 * Opera U - 3DO emulator frontend for the Nintendo Wii U (Aroma / WUHB).
 * Common definitions.
 */
#ifndef OPERAU_COMMON_H
#define OPERAU_COMMON_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define APP_NAME        "Opera U"
#define APP_ID          "OperaU"
#define APP_VERSION     "0.4.13"
/* Tells two builds of the same version apart: the log, the diagnostic and the screens print it. The Makefiles pass the
 * same stamp to every file of a build; compiled without it, each file stamps the moment it was compiled. */
#ifndef APP_BUILD_STAMP
#define APP_BUILD_STAMP __DATE__ " " __TIME__
#endif
#define APP_BUILD       APP_BUILD_STAMP

#ifndef ARRAY_LEN
#define ARRAY_LEN(a) (sizeof(a) / sizeof((a)[0]))
#endif

#define CLAMP(v, lo, hi) ((v) < (lo) ? (lo) : ((v) > (hi) ? (hi) : (v)))
#define MIN(a, b) ((a) < (b) ? (a) : (b))
#define MAX(a, b) ((a) > (b) ? (a) : (b))

#if defined(__GNUC__)
#define PRINTF_LIKE(f, a) __attribute__((format(printf, f, a)))
#else
#define PRINTF_LIKE(f, a)
#endif

/* Bounded string copy; always NUL terminates. Returns strlen(src). */
size_t str_copy(char *dst, const char *src, size_t cap);
/* Bounded append; always NUL terminates. */
size_t str_cat(char *dst, const char *src, size_t cap);
/* Join two path components with exactly one '/'. */
void path_join(char *out, size_t cap, const char *a, const char *b);
/* Pointer to the file-name part of a path. */
const char *path_base(const char *path);
/* Copy of the file name without its extension. */
void path_stem(char *out, size_t cap, const char *path);
/* Lowercase extension without the dot ("" if none). */
void path_ext(char *out, size_t cap, const char *path);
/* Directory part ("" -> "."). */
void path_dir(char *out, size_t cap, const char *path);
bool str_ieq(const char *a, const char *b);
bool str_has_prefix(const char *s, const char *prefix);

#endif /* OPERAU_COMMON_H */
