#ifndef OPERA_LR_OPTS_H_INCLUDED
#define OPERA_LR_OPTS_H_INCLUDED

#include "libopera/opera_bios.h"
#include "libopera/opera_mem.h"
#include "libopera/opera_vdlp.h"
#include "libopera/opera_region.h"

typedef struct opera_lr_opts_t opera_lr_opts_t;

#define OPERA_LR_OPTS_CHANGE_NONE     0x00000000
#define OPERA_LR_OPTS_CHANGE_REGION   0x00000001
#define OPERA_LR_OPTS_CHANGE_TIMING   0x00000002
#define OPERA_LR_OPTS_CHANGE_GEOMETRY 0x00000004
#define OPERA_LR_OPTS_CHANGE_ERROR    0x80000000

struct opera_lr_opts_t
{
  bool initialized_libretro;
  bool initialized_opera;
  opera_bios_t const *bios;
  opera_bios_t const *font;
  bool nvram_shared;
  uint8_t nvram_version;
  opera_region_e region;
  uint32_t cd_speed;
  uint32_t madam_cel_rate; /* Local modification for OperaU: pixels a second, 0 for never busy */
  float cpu_overclock;
  vdlp_pixel_format_e vdlp_pixel_format;
  bool vdlp_bypass_clut;
  uint32_t *video_buffer;
  bool high_resolution;
  unsigned video_width;
  unsigned video_height;
  unsigned video_pitch_shift;
  unsigned active_devices;
  opera_mem_cfg_t mem_cfg;
  bool hide_lightgun_crosshairs;
  char const *madam_matrix_engine;
  bool kprint;
  bool dsp_threaded;
  bool swi_hle;
};

extern opera_lr_opts_t g_OPTS;

bool opera_lr_opts_get_random_seed(uint32_t *seed);
uint32_t opera_lr_opts_process();
void opera_lr_opts_reset();
void opera_lr_opts_destroy();

#endif
