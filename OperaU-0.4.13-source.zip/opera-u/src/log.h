#ifndef OPERAU_LOG_H
#define OPERAU_LOG_H

#include "common.h"

typedef enum {
    LOG_DEBUG = 0,
    LOG_INFO,
    LOG_WARN,
    LOG_ERROR,
} log_level_t;

/* Opens <data_dir>/logs/operau.log (rotates the previous one). Safe to call
 * once the data directory exists. Before that, messages only go to stdout. */
void log_open(const char *data_dir);
void log_close(void);
void log_set_level(log_level_t lvl);
void log_set_udp(bool enable);
/* Pushes everything buffered so far to the card. Lines below WARNING sit in a buffer (32 KB) until someone calls
 * this - while a game runs, the thread that writes the performance report does, every twenty seconds, and the
 * emulation thread when the game is paused - so a crash or a power-off loses the last of them; call this where
 * the last line before a crash would matter. */
void log_flush(void);
/* What writing lines has cost the threads that wrote them since this was last called: microseconds in all, and
 * the longest single line. A line that fills the buffer is a write to the card. */
void log_cost_take(uint32_t *total_us, uint32_t *longest_us);
/* While on, every line is flushed as it is written (the diagnostic turns it on: its few lines are the ones that
 * matter most if the app dies half way). */
void log_set_sync(bool on);
void log_write(log_level_t lvl, const char *fmt, ...) PRINTF_LIKE(2, 3);

#define LOGD(...) log_write(LOG_DEBUG, __VA_ARGS__)
#define LOGI(...) log_write(LOG_INFO, __VA_ARGS__)
#define LOGW(...) log_write(LOG_WARN, __VA_ARGS__)
#define LOGE(...) log_write(LOG_ERROR, __VA_ARGS__)

#endif
