/*
  www.freedo.org
  The first working 3DO multiplayer emulator.

  The FreeDO licensed under modified GNU LGPL, with following notes:

  *   The owners and original authors of the FreeDO have full right to
  *   develop closed source derivative work.

  *   Any non-commercial uses of the FreeDO sources or any knowledge
  *   obtained by studying or reverse engineering of the sources, or
  *   any other material published by FreeDO have to be accompanied
  *   with full credits.

  *   Any commercial uses of FreeDO sources or any knowledge obtained
  *   by studying or reverse engineering of the sources, or any other
  *   material published by FreeDO is strictly forbidden without
  *   owners approval.

  The above notes are taking precedence over GNU LGPL in conflicting
  situations.

  Project authors:
  *  Alexander Troosh
  *  Maxim Grishin
  *  Allen Wright
  *  John Sammons
  *  Felix Lazarev
*/

#ifndef LIBOPERA_DSP_H_INCLUDED
#define LIBOPERA_DSP_H_INCLUDED

#include "extern_c.h"

#include <stdint.h>

EXTERN_C_BEGIN

uint32_t opera_dsp_loop(void);

uint16_t opera_dsp_imem_read(uint16_t addr_);
void     opera_dsp_imem_write(uint16_t addr_, uint16_t val_);

void     opera_dsp_mem_write(uint16_t addr_, uint16_t val_);

void     opera_dsp_set_running(int val_);

void     opera_dsp_arm_semaphore_write(uint32_t val_);
uint32_t opera_dsp_arm_semaphore_read(void);

void     opera_dsp_init(void);
void     opera_dsp_reset(void);
void     opera_dsp_soft_reset(void);

/*
  Local modifications for OperaU, see third_party/patches/.

  A run of the DSP's program that reaches no sleep is given up on, as the machine's next sample tick would; this
  says how many runs have ended that way since the core was loaded.
*/
uint32_t opera_dsp_runs_cut(void);

/*
  For a DSP that runs on a thread of its own. The CPU's writes that change what the DSP is doing - its program,
  its start / stop and reset, the semaphore, a value handed to one of its input ports, the audio FIFOs it reads
  from - call this first, and whoever runs the thread points the hook at a function that waits until the DSP has
  run every tick handed to it so far. The write then lands between two ticks, the only place it can land when the
  DSP runs inside the frame. So does the CPU's read of the semaphore, which is two words the DSP writes one after
  the other. Null otherwise.

  Not waited for: the knobs (one word each, and written all the time), and the CPU's other reads of the DSP and
  of the FIFOs, which see the DSP as far as the thread has got - a few dozen ticks back at most.
*/
extern void (*opera_dsp_arm_write_hook)(void);
void     opera_dsp_arm_write_sync(void);

uint32_t opera_dsp_state_size(void);
uint32_t opera_dsp_state_size_v1(void);
uint32_t opera_dsp_state_save(void *buf_);
uint32_t opera_dsp_state_load(void const *buf_, uint32_t size_);
uint32_t opera_dsp_state_load_v1(void const *buf_, uint32_t size_);

EXTERN_C_END

#endif /* LIBOPERA_DSP_H_INCLUDED */
