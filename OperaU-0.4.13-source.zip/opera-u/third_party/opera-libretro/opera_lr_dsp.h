#ifndef OPERA_LR_DSP_H_INCLUDED
#define OPERA_LR_DSP_H_INCLUDED

#include "boolean.h"

#include "libopera/endianness.h"

#include <stdint.h>

/*
  Local modification for OperaU, see third_party/patches/.

  One tick of the DSP as the pair of samples a front end is handed. opera_dsp_loop() returns one word, the left
  sample in its low half and the right one in its high half, and the buffers here are words that are handed over
  as pairs of samples. That is left, then right, where the low half of a word comes first in memory. On a
  big-endian machine it is right, then left: the two channels changed places, on every such machine and in every
  game. There the halves are exchanged before the word is stored.
*/
static inline int32_t
opera_lr_dsp_frame(const uint32_t tick_)
{
#if IS_BIG_ENDIAN
  return (int32_t)((tick_ << 16) | (tick_ >> 16));
#else
  return (int32_t)tick_;
#endif
}

void opera_lr_dsp_init(const bool threaded);
void opera_lr_dsp_destroy(void);

void opera_lr_dsp_upload(void);
void opera_lr_dsp_process(void);

/*
  Local modification for OperaU, see third_party/patches/.

  The DSP can run on a thread of its own, and on a console with idle cores that takes its whole cost out of the
  frame. What the frame-time profiler sees then is only the hand-over, so the thread accounts for itself here:
  how long it worked, how many DSP ticks it ran, how many samples found the ring full, how far behind it ever
  was, and which cores it was seen on. The numbers are running totals written by the DSP thread alone; a reader
  takes two snapshots and keeps them when they agree, and works out a period by subtracting.
*/
typedef struct opera_lr_dsp_thread_stats_s
{
  uint64_t busy_ticks;  /* opera_prof_now() ticks spent running DSP ticks */
  uint64_t ticks_run;   /* DSP ticks run */
  uint64_t dropped;     /* samples made while the ring was full, and so lost */
  uint32_t backlog_max; /* most DSP ticks it was behind since the last read; a read clears it */
  uint32_t cores;       /* one bit per core the thread ran on since the last read; a read clears it */
  /*
    The emulation's side of the bargain: how often one of the CPU's writes had to wait for the thread to catch up
    before it could land (see opera_dsp_arm_write_hook), how long that took in all, and how often the thread did
    not get there in the time allowed, so that the write went ahead regardless.
  */
  uint64_t waits;
  uint64_t wait_ticks;  /* opera_prof_now() ticks */
  uint64_t wait_gave_up;
} opera_lr_dsp_thread_stats_t;

bool opera_lr_dsp_is_threaded(void);
void opera_lr_dsp_thread_stats(opera_lr_dsp_thread_stats_t *out);

/*
  Waits until the DSP thread has run every tick handed to it. Saving, loading or tearing down the machine while
  the thread is still working on it would catch the DSP half way through a tick.
*/
void opera_lr_dsp_drain(void);

/* Called once on the DSP thread as it starts, so that a front end can choose the core it runs on. */
extern void (*opera_lr_dsp_thread_start_hook)(void);

#endif
