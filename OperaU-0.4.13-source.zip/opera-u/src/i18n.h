/* Translations (Brazilian Portuguese is the default, English the fallback).
 * Strings live in i18n_strings.def as STR(ID, "pt", "en"). Format strings must
 * take the same arguments in both languages. */
#ifndef OPERAU_I18N_H
#define OPERAU_I18N_H

typedef enum {
#define STR(id, pt, en) id,
#include "i18n_strings.def"
#undef STR
    S__COUNT
} str_id_t;

/* Current language from g_cfg.language. Never returns NULL. */
const char *tr(str_id_t id);

#endif
