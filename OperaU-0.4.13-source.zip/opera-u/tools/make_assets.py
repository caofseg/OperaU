#!/usr/bin/env python3
"""Gera os assets do app (icone e telas de abertura) em TGA nao comprimido.

Saida (compativel com o wuhbtool oficial e com a versao sem FreeImage):
  assets/icon.tga      128x128  32 bpp
  assets/tv.tga       1280x720  24 bpp
  assets/drc.tga       854x480  24 bpp
Requer Pillow. Todo o desenho e original (nao usa marcas ou logotipos de terceiros).
"""
import math, os, struct, sys
from PIL import Image, ImageDraw, ImageFilter, ImageFont

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "assets")
FONT_CANDIDATES = [
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
    "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
]

def app_version():
    """A versao escrita em src/common.h: ela aparece no icone e nas telas de abertura, para que se veja qual
    versao esta sendo aberta ja no menu do Aroma e na tela de carregamento."""
    import re
    with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "common.h"), encoding="utf-8") as f:
        return re.search(r'#define\s+APP_VERSION\s+"([^"]+)"', f.read()).group(1)

def font(size):
    for p in FONT_CANDIDATES:
        if os.path.exists(p):
            return ImageFont.truetype(p, size)
    return ImageFont.load_default()

def write_tga(path, img, bpp):
    """TGA tipo 2, origem inferior-esquerda (igual ao FreeImage), sem RLE."""
    img = img.convert("RGBA" if bpp == 32 else "RGB")
    w, h = img.size
    px = img.transpose(Image.FLIP_TOP_BOTTOM)
    if bpp == 32:
        r, g, b, a = px.split(); raw = Image.merge("RGBA", (b, g, r, a)).tobytes()
    else:
        r, g, b = px.split(); raw = Image.merge("RGB", (b, g, r)).tobytes()
    hdr = struct.pack("<BBBHHBHHHHBB", 0, 0, 2, 0, 0, 0, 0, 0, w, h, bpp, 8 if bpp == 32 else 0)
    # Rodape do TGA 2.0 (26 bytes): dois deslocamentos zerados mais a assinatura. O leitor do menu do Wii U
    # precisa dele - sem o rodape o console trata a imagem como ilegivel e mostra o app como nao reconhecido.
    # E o que a ferramenta oficial (via FreeImage) escreve; o icone padrao do proprio Aroma tambem o tem.
    footer = struct.pack("<II", 0, 0) + b"TRUEVISION-XFILE.\x00"
    with open(path, "wb") as f:
        f.write(hdr + raw + footer)

def gradient(size, top, bottom):
    w, h = size
    img = Image.new("RGB", size)
    d = ImageDraw.Draw(img)
    for y in range(h):
        t = y / max(1, h - 1)
        c = tuple(int(top[i] + (bottom[i] - top[i]) * t) for i in range(3))
        d.line([(0, y), (w, y)], fill=c)
    return img

def monogram(size, cx, cy, r, ss=4):
    """A marca do Opera U: um "O" e um "U" entrelacados, com um arco de disco atras.

    Desenho proprio, feito para este projeto. Formas cheias em vermelho, azul e amarelo saturados, sem degrade,
    porque o icone e lido a 48 pixels no menu do console e o que sobrevive nesse tamanho e contraste, nao detalhe.
    """
    S = size * ss
    im = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    R = r * ss
    X, Y = cx * ss, cy * ss
    RED, BLUE, YEL = (228, 46, 46, 255), (36, 74, 214, 255), (248, 200, 38, 255)

    d.arc([X - R, Y - R, X + R, Y + R], 200, 400, fill=BLUE, width=int(R * 0.167))

    w = int(R * 0.267)
    ro = R * 0.70
    d.ellipse([X - ro * 1.06, Y - ro, X - ro * 1.06 + 2 * ro * 0.92, Y + ro], outline=RED, width=w)

    x0 = X - ro * 0.06
    d.arc([x0, Y - ro * 0.74, x0 + 2 * ro * 0.95, Y + ro], 0, 180, fill=YEL, width=w)
    d.line([(x0, Y - ro * 0.88), (x0, Y + ro * 0.12)], fill=YEL, width=w)
    d.line([(x0 + 2 * ro * 0.95, Y - ro * 0.88), (x0 + 2 * ro * 0.95, Y + ro * 0.12)], fill=YEL, width=w)
    return im.resize((size, size), Image.LANCZOS)

def make_icon():
    S = 128
    base = gradient((S, S), (28, 34, 64), (10, 12, 26)).convert("RGBA")
    mask = Image.new("L", (S, S), 0)
    ImageDraw.Draw(mask).rounded_rectangle([0, 0, S - 1, S - 1], radius=22, fill=255)
    base.putalpha(mask)
    layer = monogram(S, S * 0.5, S * 0.355, S * 0.30)
    base.alpha_composite(layer)
    d = ImageDraw.Draw(base)
    f = font(20)
    txt = "OPERA U"
    tw = d.textlength(txt, font=f)
    d.text(((S - tw) / 2, S - 44), txt, font=f, fill=(236, 240, 250, 255))
    fv = font(17)
    ver = "v" + app_version()
    vw = d.textlength(ver, font=fv)
    d.text(((S - vw) / 2, S - 22), ver, font=fv, fill=(120, 230, 210, 255))
    # bordas arredondadas limpas
    base.putalpha(Image.composite(base.getchannel("A"), Image.new("L", (S, S), 0), mask))
    return base

def make_splash(w, h):
    img = gradient((w, h), (22, 28, 58), (6, 8, 18)).convert("RGBA")
    glow = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    gd = ImageDraw.Draw(glow)
    gd.ellipse([w * .5 - h * .55, h * .46 - h * .55, w * .5 + h * .55, h * .46 + h * .55], fill=(70, 110, 220, 60))
    glow = glow.filter(ImageFilter.GaussianBlur(h * 0.08))
    img.alpha_composite(glow)
    r = h * 0.21
    layer = monogram(max(w, h), w * 0.5, h * 0.40, r)
    img.alpha_composite(layer.crop((0, 0, w, h)))
    d = ImageDraw.Draw(img)
    t1 = font(int(h * 0.11)); t2 = font(int(h * 0.040))
    title = "OPERA U"; sub = "Emulador de 3DO para Wii U"
    d.text((w / 2, h * 0.70), title, font=t1, fill=(240, 244, 252, 255), anchor="mm")
    d.text((w / 2, h * 0.82), sub, font=t2, fill=(150, 170, 215, 255), anchor="mm")
    d.text((w / 2, h * 0.91), "versão " + app_version(), font=font(int(h * 0.050)), fill=(120, 230, 210, 255), anchor="mm")
    return img.convert("RGB")

def main():
    os.makedirs(OUT, exist_ok=True)
    icon = make_icon()
    write_tga(os.path.join(OUT, "icon.tga"), icon, 32)
    write_tga(os.path.join(OUT, "tv.tga"), make_splash(1280, 720), 24)
    write_tga(os.path.join(OUT, "drc.tga"), make_splash(854, 480), 24)
    # previews em PNG (apenas para conferencia; nao entram no .wuhb)
    icon.save(os.path.join(OUT, "icon_preview.png"))
    make_splash(1280, 720).save(os.path.join(OUT, "tv_preview.png"))
    print("assets gerados em", os.path.abspath(OUT))

if __name__ == "__main__":
    sys.exit(main())
