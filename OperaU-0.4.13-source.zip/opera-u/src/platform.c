#include "platform.h"
#include "log.h"

#include <dirent.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

#ifdef __WIIU__
#include <coreinit/memory.h>
#include <coreinit/systeminfo.h>
#include <coreinit/core.h>
#include <coreinit/thread.h>
#include <coreinit/time.h>
#include <proc_ui/procui.h>
#define DATA_DIR       "fs:/vol/external01/wiiu/OperaU"
#define BROWSE_DIR     "fs:/vol/external01"
#define BROWSE_ROOT    "fs:/vol/external01"
#else
#include <time.h>
#endif

/* ------------------------------------------------------------------ dirs */

const char *platform_data_dir(void)
{
#ifdef __WIIU__
    return DATA_DIR;
#else
    static char dir[512];
    if (!dir[0]) {
        const char *env = getenv("OPERAU_HOME");
        snprintf(dir, sizeof(dir), "%s", env && *env ? env : "./data");
    }
    return dir;
#endif
}

const char *platform_apps_dir(void)
{
#ifdef __WIIU__
    return "fs:/vol/external01/wiiu/apps";
#else
    return getenv("OPERAU_APPS_DIR");
#endif
}

const char *platform_default_browse_dir(void)
{
#ifdef __WIIU__
    return BROWSE_DIR;
#else
    static char dir[512];
    if (!dir[0])
        path_join(dir, sizeof(dir), platform_data_dir(), "roms");
    return dir;
#endif
}

const char *platform_browse_root(void)
{
#ifdef __WIIU__
    return BROWSE_ROOT;
#else
    return "/";
#endif
}

int platform_storage_roots(storage_root_t *out, int max)
{
    int n = 0;
#ifdef __WIIU__
    static const struct { const char *path, *label; } cand[] = {
        {"fs:/vol/external01", "SD"},
        {"fs:/vol/storage_usb01", "USB 1"},
        {"fs:/vol/storage_usb02", "USB 2"},
    };
    for (size_t i = 0; i < ARRAY_LEN(cand) && n < max; i++) {
        /* the SD card is listed even if the probe fails so the user always
         * has a way back to the default location */
        if (i == 0 || platform_is_dir(cand[i].path)) {
            str_copy(out[n].path, cand[i].path, sizeof(out[n].path));
            str_copy(out[n].label, cand[i].label, sizeof(out[n].label));
            n++;
        }
    }
#else
    if (max > 0) {
        str_copy(out[n].path, platform_default_browse_dir(), sizeof(out[n].path));
        str_copy(out[n].label, "ROMS", sizeof(out[n].label));
        n++;
    }
    if (max > 1) {
        str_copy(out[n].path, "/", sizeof(out[n].path));
        str_copy(out[n].label, "/", sizeof(out[n].label));
        n++;
    }
#endif
    return n;
}

/* ------------------------------------------------------------------ files */

bool platform_exists(const char *path)
{
    struct stat st;
    return stat(path, &st) == 0;
}

bool platform_is_dir(const char *path)
{
    struct stat st;
    return stat(path, &st) == 0 && S_ISDIR(st.st_mode);
}

int64_t platform_file_size(const char *path)
{
    struct stat st;
    if (stat(path, &st) != 0)
        return -1;
    return (int64_t)st.st_size;
}

bool platform_mkdirs(const char *path)
{
    char tmp[1024];
    size_t len;

    if (!path || !*path)
        return false;
    str_copy(tmp, path, sizeof(tmp));
    len = strlen(tmp);
    while (len > 1 && tmp[len - 1] == '/')
        tmp[--len] = '\0';

    /* skip a "dev:" prefix and leading slashes, never try to create them */
    char *p = tmp;
    char *colon = strchr(tmp, ':');
    if (colon && (!strchr(tmp, '/') || colon < strchr(tmp, '/')))
        p = colon + 1;
    while (*p == '/')
        p++;

    for (; *p; p++) {
        if (*p != '/')
            continue;
        *p = '\0';
        if (!platform_is_dir(tmp) && mkdir(tmp, 0777) != 0 && errno != EEXIST) {
            *p = '/';
            return false;
        }
        *p = '/';
    }
    if (platform_is_dir(tmp))
        return true;
    return mkdir(tmp, 0777) == 0 || errno == EEXIST;
}

bool platform_remove(const char *path)
{
    return remove(path) == 0;
}

bool platform_write_file_atomic(const char *path, const void *data, size_t size)
{
    char tmp[1100];
    FILE *f;
    bool ok;

    snprintf(tmp, sizeof(tmp), "%s.tmp", path);
    f = fopen(tmp, "wb");
    if (!f)
        return false;
    ok = size == 0 || fwrite(data, 1, size, f) == size;
    ok = (fflush(f) == 0) && ok;
    ok = (fclose(f) == 0) && ok;
    if (!ok) {
        remove(tmp);
        return false;
    }
    /* rename() will not overwrite on some devoptab backends */
    remove(path);
    if (rename(tmp, path) != 0) {
        remove(tmp);
        return false;
    }
    return true;
}

void *platform_read_file(const char *path, size_t *size_out)
{
    FILE *f = fopen(path, "rb");
    void *buf = NULL;
    long sz;

    if (!f)
        return NULL;
    if (fseek(f, 0, SEEK_END) == 0 && (sz = ftell(f)) >= 0 && fseek(f, 0, SEEK_SET) == 0) {
        buf = malloc((size_t)sz + 1);
        if (buf) {
            if (fread(buf, 1, (size_t)sz, f) != (size_t)sz) {
                free(buf);
                buf = NULL;
            } else {
                ((char *)buf)[sz] = '\0'; /* text files get a free terminator */
                if (size_out)
                    *size_out = (size_t)sz;
            }
        }
    }
    fclose(f);
    return buf;
}

dir_entry_t *platform_list_dir(const char *path, int *count_out)
{
    DIR *d = opendir(path);
    dir_entry_t *list = NULL;
    int count = 0, cap = 0;
    struct dirent *de;

    *count_out = 0;
    if (!d)
        return NULL;
    while ((de = readdir(d)) != NULL) {
        if (!strcmp(de->d_name, ".") || !strcmp(de->d_name, ".."))
            continue;
        if (count == cap) {
            int ncap = cap ? cap * 2 : 64;
            dir_entry_t *n = realloc(list, (size_t)ncap * sizeof(*list));
            if (!n)
                break;
            list = n;
            cap = ncap;
        }
        dir_entry_t *e = &list[count];
        str_copy(e->name, de->d_name, sizeof(e->name));
        char full[1100];
        path_join(full, sizeof(full), path, e->name);
        struct stat st;
        if (stat(full, &st) == 0) {
            e->is_dir = S_ISDIR(st.st_mode);
            e->size = e->is_dir ? 0 : (int64_t)st.st_size;
        } else {
            e->is_dir = (de->d_type == DT_DIR);
            e->size = 0;
        }
        count++;
    }
    closedir(d);
    *count_out = count;
    return list;
}

/* ------------------------------------------------------------ time/thread */

uint64_t platform_time_us(void)
{
#ifdef __WIIU__
    return (uint64_t)OSTicksToMicroseconds(OSGetSystemTime());
#else
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)ts.tv_sec * 1000000ull + (uint64_t)ts.tv_nsec / 1000ull;
#endif
}

void platform_sleep_ms(uint32_t ms)
{
#ifdef __WIIU__
    OSSleepTicks(OSMillisecondsToTicks(ms));
#else
    struct timespec ts = {ms / 1000, (long)(ms % 1000) * 1000000L};
    nanosleep(&ts, NULL);
#endif
}

void platform_pin_thread(int core)
{
#ifdef __WIIU__
    OSThread *t = OSGetCurrentThread();
    uint32_t aff;
    switch (core) {
    case 0: aff = OS_THREAD_ATTRIB_AFFINITY_CPU0; break;
    case 1: aff = OS_THREAD_ATTRIB_AFFINITY_CPU1; break;
    case 2: aff = OS_THREAD_ATTRIB_AFFINITY_CPU2; break;
    default: aff = OS_THREAD_ATTRIB_AFFINITY_ANY; break;
    }
    {
        /* The move happens when the thread is next scheduled, so it gives up the core it is on at once: a thread
           that pins itself and carries on would stay where it was until something else made it wait. */
        BOOL ok = OSSetThreadAffinity(t, aff);

        OSYieldThread();
        LOGI("thread pinned to core %d: %s, now on core %d", core, ok ? "accepted" : "REFUSED", (int)OSGetCoreId());
    }
#else
    (void)core;
#endif
}

void platform_set_thread_priority_offset(int offset)
{
#ifdef __WIIU__
    OSThread *t = OSGetCurrentThread();
    int p = OSGetThreadPriority(t) + offset;
    OSSetThreadPriority(t, CLAMP(p, 0, 31));
#else
    (void)offset;
#endif
}

/* -------------------------------------------------------------- lifecycle */

static uint32_t g_background;
static uint32_t g_bg_epoch;

#ifdef __WIIU__
static uint32_t procui_release(void *arg)
{
    (void)arg;
    __atomic_store_n(&g_background, 1, __ATOMIC_RELEASE);
    return 0;
}

static uint32_t procui_acquire(void *arg)
{
    (void)arg;
    __atomic_fetch_add(&g_bg_epoch, 1, __ATOMIC_RELEASE);
    __atomic_store_n(&g_background, 0, __ATOMIC_RELEASE);
    return 0;
}
#endif

void platform_lifecycle_init(void)
{
#ifdef __WIIU__
    /* The HOME button is not a controller button: the console itself opens its menu over the app with it. Turning
     * that menu off leaves HOME doing nothing, which is what the app wants - its own menu is L + R, and "Sair"
     * in that menu is how the app is left. */
    OSEnableHomeButtonMenu(FALSE);
    /* SDL owns ProcUI; we only listen (lower priority number = called first) */
    ProcUIRegisterCallback(PROCUI_CALLBACK_RELEASE, procui_release, NULL, 50);
    ProcUIRegisterCallback(PROCUI_CALLBACK_ACQUIRE, procui_acquire, NULL, 50);
#endif
}

bool platform_in_background(void)
{
    return __atomic_load_n(&g_background, __ATOMIC_ACQUIRE) != 0;
}

uint32_t platform_background_epoch(void)
{
    return __atomic_load_n(&g_bg_epoch, __ATOMIC_ACQUIRE);
}

/* ---------------------------------------------------------------- system */

const void *platform_system_font(size_t *size_out)
{
#ifdef __WIIU__
    void *ptr = NULL;
    uint32_t size = 0;
    if (OSGetSharedData(OS_SHAREDDATATYPE_FONT_STANDARD, 0, &ptr, &size) && ptr && size) {
        if (size_out)
            *size_out = size;
        return ptr;
    }
#else
    (void)size_out;
#endif
    return NULL;
}

uint64_t platform_free_memory(void)
{
    return 0; /* not exposed by wut in a stable way; reserved for diagnostics */
}
