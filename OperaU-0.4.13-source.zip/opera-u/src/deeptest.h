#ifndef OPERAU_DEEPTEST_H
#define OPERAU_DEEPTEST_H
/*
 * Differential ("deep") tests of the emulated hardware, used to prove that the
 * big-endian PowerPC build of the Opera core behaves exactly like the x86 one.
 * They drive the core's public units (ARM CPU, DSP, cel engine) with seeded
 * pseudo random but valid input and print hashes of the results. Run the same
 * test on x86 and under qemu-ppc (tools/ppcsim) and diff the output.
 *
 * Also part of the Wii U application: the core diagnostic runs the fixed workloads below on the console.
 */
#include "common.h"

/* what: "arm", "dsp", "cel" (random cels), "celg" (cels set up as games set them), "celu" (cels at their own
 * size and off every edge of the screen, with what a game repeats from cel to cel), "fifo", "mat" (matrix
 * engine), "sport", "vdl" (video list processor), "tmr" (CLIO timers and their clock), "abench" (ARM loops, for
 * timing), "armx" (every ARM instruction class in every mode) or "all". Also "celb": the cel engine timed on
 * sprites, which "all" leaves out because it is a measurement.
 * Prints result lines to stdout.
 * Returns false when the core could not be set up. */
bool deeptest_run(const char *what, uint32_t seed, int trials);


/* One fixed workload of the on-console diagnostic: `name` is a deeptest_run() workload, `expect` the final
 * hash measured on x86-64 (0 until filled in). */
typedef struct {
    const char *name;
    uint32_t seed;
    int trials;
    uint64_t expect;
} deeptest_spec_t;

extern const deeptest_spec_t deeptest_specs[];
extern const int deeptest_spec_count;

/*
 * The cel engine timed on eight sprites shaped like a game's ("celb"). Each row is one shape, drawn `draws` times:
 * how many pixels one draw writes, how long all the draws took with the engine's table of finished pixels off
 * (us[0]) and on (us[1]), and whether both left the same picture. `hash` covers the pictures and the pixel
 * counts, and equals deeptest_celbench_expect() on a correct build. Needs core_init(), no game loaded.
 */
#define DEEPTEST_CELBENCH_ROWS 8
typedef struct {
    const char *name;
    uint64_t pixels;
    int draws;
    uint32_t us[2];
    bool same;
} deeptest_celbench_row_t;

bool deeptest_celbench(deeptest_celbench_row_t rows[DEEPTEST_CELBENCH_ROWS], uint64_t *hash);
uint64_t deeptest_celbench_expect(void);

/*
 * The DSP on a thread of its own against the DSP inside the frame ("dspc", and "dspt" for longer scripts on the
 * PC). Each of the four scripts is played twice on a freshly loaded machine - ticks of the DSP and, between them,
 * what a game's sound code does to it through the CPU's ports - and everything it leaves behind is hashed: the
 * sound, the DSP's and the CLIO's state, the memory the DSP wrote and what the CPU read back. hash[0], with the
 * DSP inside the frame, equals deeptest_dspthread_expect() on a correct build; hash[1], with the thread, must
 * equal hash[0]. Needs core_init(), no game loaded. False only when the machine would not load.
 */
#define DEEPTEST_DSPTHREAD_SCRIPTS 4
typedef struct {
    bool ran;         /* the script ran with the DSP inside the frame */
    bool threaded;    /* and again with the DSP on a thread (false: this build or this machine has none) */
    bool complete;    /* that second run got to its end in reasonable time */
    bool same;        /* and left exactly what the first one did */
    uint64_t hash[2];
    uint64_t part[5]; /* what hash[0] is made of: the sound, the DSP's state, the CLIO's, the memory, what the CPU read */
    bool differs[5];  /* which of those the thread left different, if it did */
    double ms[2];     /* how long each run took */
    uint64_t samples;
    uint64_t irq[3];  /* interrupts the DSP raised: its own, end of a FIFO it reads, end of one it writes */
    uint64_t waits;   /* how often the CPU waited for the thread before a write, */
    uint64_t gave_up; /* how often it stopped waiting, */
    double wait_ms;   /* and how long the waits took in all */
} deeptest_dspthread_row_t;

bool deeptest_dspthread_script(int index, deeptest_dspthread_row_t *row);
uint64_t deeptest_dspthread_expect(int index);

/*
 * What it costs the CPU to wait for the DSP's thread, in microseconds for one tick: with the DSP inside the frame
 * (nothing to wait for: the tick itself), handed to the thread and waited for when the thread has only just
 * stopped, and when it is asleep.
 */
#define DEEPTEST_DSPWAIT_TICKS 2000
#define DEEPTEST_DSPWAIT_SLEEPS 100
typedef struct {
    bool ran;
    bool threaded;
    double frame_us, hot_us, cold_us;
    uint64_t gave_up;
} deeptest_dspwait_t;

bool deeptest_dspwait(deeptest_dspwait_t *out);

/* Runs one workload quietly on a freshly loaded core (needs core_init(), no game loaded) and stores the
 * final hash. False when the core would not load or the workload could not run. */
bool deeptest_hash(const deeptest_spec_t *spec, uint64_t *hash);

#endif
