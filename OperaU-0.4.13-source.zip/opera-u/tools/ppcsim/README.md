# PowerPC simulation harness

The Wii U's CPU is a **big-endian** PowerPC 750 derivative and there was no console (and no Wii U emulator) to test
on. This folder lets the *same C code* that goes into the Wii U build be executed on a big-endian PowerPC under QEMU
user-mode emulation, and compared with the x86 build. The core's behaviour must not depend on the host, so every
difference between the two is a bug (the big-endian ones found this way are listed in
[`../../third_party/patches/README.md`](../../third_party/patches/README.md)).

What it does **not** cover: anything that needs a real console (SDL2/GX2 video, AX audio, controllers, ProcUI, USB, real
speed) and anything threaded (newlib in this harness has no pthreads, so the DSP runs in its default single-threaded
mode, which is also the default of the core option).

## Pieces

| File | Purpose |
| --- | --- |
| `Makefile` | builds `../../build-ppcsim/harness.elf` with devkitPPC and the flags of the Wii U build (`-mcpu=750 -meabi -mhard-float -DMSB_FIRST`), linking the core, `src/core.c`, `src/coretest.c`, `src/deeptest.c`, `src/cdtest.c` and the helpers below |
| `crt0.S`, `sys.c` | a tiny start-up code and Linux system-call layer, so the program runs as a static `qemu-ppc` binary |
| `stubs.c`, `shim/SDL.h` | what the front-end files that are reused expect from the platform |
| `harness_main.c` | the command line (below) |
| `layout_test.c`, `run_layout_test.sh` | bit-field layout test (below) |

## Requirements

* devkitPPC (`/opt/devkitpro/devkitPPC`, override with `DEVKITPPC=`).
* `qemu-ppc` (user mode, QEMU 8 or newer): `QEMU_PPC=/path/to/qemu-ppc`. Run with `-cpu 750`.
* For the host side: `make -f Makefile.host` from the project root (needs SDL2 development files), then
  `export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy OPERAU_HOME=$(mktemp -d)`.

```sh
make -C tools/ppcsim                         # build-ppcsim/harness.elf
make -C tools/ppcsim run QEMU_PPC=qemu-ppc   # the boot test below
```

Neither makefile tracks header dependencies for the front-end files: after editing a header delete
`build-ppcsim/front` (and `build-host/front`) before rebuilding.

## 1. Boot test (the main check)

`harness.elf` with no arguments boots the built-in BIOS for 240 frames, prints a hash of the pictures and of the audio
and compares them with the values measured on x86 (`CORETEST_REF_*` in `src/coretest.h`), then saves a state, replays 60
frames twice and checks that the replays are identical:

```
host byte order: BIG endian
boot hash after 240 frames: video 6a489c8ca0aca201 audio bc2453c55209701d
expected (x86)           : video 6a489c8ca0aca201 audio bc2453c55209701d
state size 6605970  save/load ok  replay bit exact
RESULT: PowerPC build matches the x86 reference bit for bit
```

Hashes cover pixel and sample *values* only, never memory layout, so a correct big-endian build prints exactly the x86
numbers. The same test runs on the host with `./build-host/operau-host --selftest-core`, and on the console itself from
**Settings > System > Core diagnostic** (`src/diag.c`).

`harness.elf diag SCRATCH_DIR` runs the same thing through the path the console diagnostic takes (default options,
no input, scratch save directory).

## 2. Bit-field layout test

GCC allocates bit-fields from the most significant bit on big-endian targets, which silently scrambles every hardware
register that the core models as a C struct of bit-fields. `run_layout_test.sh` extracts the real struct definitions
from the vendored sources, writes and reads every field of every struct on x86 and on PowerPC and diffs the results:

```sh
QEMU_PPC=qemu-ppc DEVKITPPC=/opt/devkitpro/devkitPPC tools/ppcsim/run_layout_test.sh
# layout test: PowerPC bit-field layout identical to x86     (194 field checks)
```

## 3. Differential tests with random input

`harness.elf deep WHAT [TRIALS] [SEED]` on PowerPC and `operau-host --selftest-core --deep WHAT --trials N --seed S` on
x86 run the same pseudo-random workload and print value-based hashes that must be identical. `WHAT` is one of:

| WHAT | Exercises |
| --- | --- |
| `arm` | the ARM60 interpreter: random programs (data processing, shifts, multiplies, loads/stores, block transfers, swaps) |
| `dsp` | the DSP interpreter: random instruction words and operand data |
| `dspr` | DSP programs that never reach a sleep: a jump to itself, nothing but no-ops to the end of the program memory and past it, random arithmetic with no sleep anywhere, two jumps that point at each other. The interpreter has to give up on such a run as the real DSP is started again by every sample tick, or whatever called it never comes back; the hash covers what it returns and the state it leaves, and an ordinary program run over the wreckage |
| `dspc` | the four scripts the on-console diagnostic plays with the DSP inside the frame and on its own thread: ticks of the DSP and, between them, what a game's sound code does to it through the CPU's ports. Not a single hash: each script's result inside the frame is compared with its x86 reference (the simulator has no threads, so that half is all it can play), and on a build with threads the second run must leave what the first one left. `TRIALS` and `SEED` are ignored |
| `dspt` | the same comparison with `TRIALS` longer scripts, seeds `SEED` onwards, for the PC: the DSP on a thread must leave the same sound, the same DSP and CLIO state, the same memory and the same values read back by the CPU as the DSP inside the frame. Seventeen protections of the thread were removed one at a time to see whether it notices; see `third_party/patches/README.md` |
| `celt` | how long the cel engine says it is busy after a list, at each speed it can be set to (9, 12 and 16 million pixels a second, and never): the list is started through the registers a game uses, the clock is stepped, and the cycles until the engine goes idle are counted. They must be the rule's, the count kept for the performance report must be exactly that, and the picture must be the same at every speed. `TRIALS` is ignored |
| `cel` | the MADAM cel engine, including packed cels and the different pixel formats: every field of every cel drawn at random |
| `celg` | the same cels with PIXC set the way games set it, which the random battery produces for one pixel in twenty |
| `celu` | what the two above leave out: cels at their own size on whole pixels (the engine's line path, which is most of what a 2D game draws and which a fractional position never reaches), cels hanging off every edge of the screen and of a clip box smaller than the buffer, and what a game repeats from one cel to the next - a pool of ways of mixing with the frame buffer, source data of few values, 16-bit coded cels with a multiplier per channel. It also hashes the engine's saved state, which carries its busy time and so the number of pixels and texels it counted. Its reference value, like those of `cel` and `celg`, is what upstream's cel engine gives with none of this project's changes; 26 mutations planted on purpose in the changed engine each alter at least one of the three, and nine of them neither of the other two; nine more changes that only move the point at which a mechanism kicks in alter nothing |
| `celb` | not a comparison but a measurement: eight sprites shaped like a game's, each drawn repeatedly and timed per pixel written, with the engine's table of finished pixels off and on. The pictures are hashed too, and are the same on x86, on PowerPC and through upstream's engine. `TRIALS` divides the repeat counts (use 20 or more under qemu) and a `SEED` of 1 to 8 runs that sprite alone |
| `fifo` | the CLIO audio FIFOs |
| `mat` | the MADAM matrix engine (random matrices and vectors) |
| `sport` | the SPORT (bulk VRAM copy / flash) |
| `vdl` | the video display list processor (random VDL programs, line by line) |
| `tmr` | the CLIO timers and the clock that drives them: random control words, counters, reloads and cycle pushes, hashing every counter, the FIQ state and the saved clock state. Written to prove the batched timer walk (`opera_clio_timers_run`) equal to the old per-step loop; three mutations planted on purpose in the timer code each change its hash |
| `abench` | four short ARM loops (a word copy, shifted arithmetic, block moves, calls with a stack frame) run in 32-cycle chunks like the frame loop does; the hash of where each ended up must not change when the interpreter is made faster, and the amount of work is fixed, so it doubles as a timing benchmark |
| `armx` | the ARM interpreter with every instruction class (data processing in all three operand forms, PSR transfers, multiplies, single and block transfers, swaps, branches, SWI, coprocessor and undefined encodings), all six modes with their banked registers and SPSRs, loads and stores through the PC, user-mode transfers, FIQ entry, data aborts from the xbus window, a software reset through the CLIO, the instruction the core skips on purpose, and all condition codes. The expected hash is what the interpreter gave *before* it was optimised: a faster interpreter has to reproduce it to the last flag, cycle count and byte of memory. It found two out-of-bounds reads in the core (MADAM and CLIO register windows) |
| `armd`, `celd`, `celud`, `dspd`, `armxd` | the same as `arm`, `cel`, `celu`, `dsp`, `armx`, but with every trial printed so the first differing one can be found |

With 64 trials or fewer every trial is printed. To find a difference: run both sides with a small trial count and diff
the output, then rebuild with the trace hooks and dump the instruction stream:

```sh
# trace builds (separate output folders, so the normal builds stay untouched)
make -f Makefile.host BUILD=$PWD/build-host-trace CC="gcc -DOPERA_ARM_TRACE -DOPERA_DSP_TRACE"
make -C tools/ppcsim OUT=$PWD/build-ppcsim-trace \
     CC="$DEVKITPPC/bin/powerpc-eabi-gcc -DOPERA_ARM_TRACE -DOPERA_DSP_TRACE"

harness.elf prof                          # boot with the core's timing hooks switched on: the hashes must still match
harness.elf armtrace FILE FROM TO        # per-instruction ARM trace of frames FROM..TO
harness.elf trace FILE [frames]          # per-frame hashes of video, audio, DRAM, VRAM
harness.elf dump FILE [frames]           # the picture of a frame
harness.elf mem PREFIX [frames]          # DRAM and VRAM dumps
```

The DSP reads a clock-seeded pseudo-random value at one address; the tests seed `prng16`/`prng32` themselves, otherwise
the x86 run would not even be repeatable.

Useful seeds and sizes used for the published results: `arm` 6000 trials over several seeds, `dsp` 5 seeds × 5000,
`cel` 2 seeds × 4000, `celg` 2 × 1500, `celu` 2 × 2000, `fifo` 3 seeds × 3000, `mat` 2 × 20000, `sport` 2 × 6000, `vdl` 2 × 30, `tmr` 2 × 400, `abench` 2 × 20, `armx` 3 × 3000, `dspr` 2 × 2000, `celt`, and the four scripts of `dspc`
(`tools/ppcsim/run_deep_tests.sh all` runs all of them on both sides and compares). The same workloads, with fixed
seeds and golden hashes, run on the console inside **Core diagnostic**. A *negative control* matters as much as a pass: re-introduce a known bug
(for example remove the `#include "endianness.h"` from `opera_mem.h`) and the matching test must fail on PowerPC.

## 4. Disc images

```sh
python3 tools/test_chd_codecs.py --out /tmp/discs --host ./build-host/operau-host \
        --ppc build-ppcsim/harness.elf --qemu qemu-ppc
```

Builds a synthetic 3DO disc (text, code-like words, noise, runs, audio and blank gaps), writes it as ISO, as BIN+CUE (2048
and 2352 bytes per sector) and as eleven CHD v5 variants (`cdlz`, `cdzl`, `cdzs`, LZMA, zlib, zstd, mixed hunks, ECC
stripped, large hunks, subcode), reads every sector back through the core's own disc layer (`cdhash`, `src/cdtest.c`) on
x86 and PowerPC and compares with the hashes of the source data. No `chdman` is needed: the script writes the container
itself (`zstd` variants need `libzstd.so.1`).

`harness.elf cdhash PATH` and `harness.elf image PATH [frames]` do the single-image versions (read all sectors / boot a
disc image and print hashes), `tools/make_test_chd.py` wraps an ISO into an uncompressed CHD.

## What a pass does and does not mean

A pass says the PowerPC build of the *tested code paths* computes the same values as the x86 build. It does not say the
emulation is accurate (the x86 build is the reference), nor that a given game runs: no game was used. Parts of the core
that none of these tests reach (FLAC CD audio, the matrix engine in unusual modes, rarely used VDL and cel modes) are
unverified on big-endian.
