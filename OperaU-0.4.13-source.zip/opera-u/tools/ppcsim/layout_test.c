/*
 * Bit-field layout test.
 *
 * The Opera core decodes hardware words (DSP instructions, cel-engine pixels,
 * VDL control words) with C bit-fields. Their layout depends on the host byte
 * order, so the vendored core carries a big-endian variant of every struct
 * (see third_party/patches/). This program reads and writes every field of
 * every struct for all (or many) raw values and prints one hash per field.
 * Build and run it on x86 and under qemu-ppc, then diff the two outputs: they
 * must be identical (tools/ppcsim/run_layout_test.sh does exactly that).
 *
 * The struct definitions are NOT copied: the build extracts them from the
 * vendored sources (opera_dsp.c / opera_madam.c) into generated headers.
 */
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>

#include "endianness.h"
#include "opera_vdlp_i.h"

#pragma pack(push,1)
#include "gen_dsp_structs.h"
#pragma pack(pop)

#pragma pack(push,1)
#include "gen_madam_structs.h"
#pragma pack(pop)

static uint64_t mix(uint64_t h, uint32_t v)
{
    h ^= v;
    h *= 1099511628211ull;
    h ^= h >> 29;
    return h;
}

/* deterministic scrambler (xorshift32) */
static uint32_t scramble(uint32_t x)
{
    x ^= x << 13;
    x ^= x >> 17;
    x ^= x << 5;
    return x;
}

/* read every raw value 0..n-1 */
#define READ(type, member, field, n)                                                   \
    do {                                                                               \
        uint64_t h = 1469598103934665603ull;                                           \
        for (uint32_t r = 0; r < (n); r++) {                                           \
            type u;                                                                    \
            u.raw = r;                                                                 \
            h = mix(h, (uint32_t)u.member.field);                                      \
        }                                                                              \
        printf("R %-34s %016llx\n", #type "." #member "." #field, (unsigned long long)h); \
    } while (0)

/* read pseudo random 32-bit raw values */
#define READ32(type, member, field)                                                    \
    do {                                                                               \
        uint64_t h = 1469598103934665603ull;                                           \
        uint32_t x = 0x1234567u;                                                       \
        for (uint32_t r = 0; r < 200000; r++) {                                        \
            type u;                                                                    \
            x = scramble(x);                                                           \
            u.raw = x;                                                                 \
            h = mix(h, (uint32_t)u.member.field);                                      \
        }                                                                              \
        for (uint32_t b = 0; b < 32; b++) {                                            \
            type u;                                                                    \
            u.raw = 1u << b;                                                           \
            h = mix(h, (uint32_t)u.member.field);                                      \
        }                                                                              \
        printf("R %-34s %016llx\n", #type "." #member "." #field, (unsigned long long)h); \
    } while (0)

/* write every value of a field into scrambled raw words and hash the result */
#define WRITE(type, member, field, bits, mask)                                         \
    do {                                                                               \
        uint64_t h = 1469598103934665603ull;                                           \
        uint32_t x = 0x7654321u;                                                       \
        for (uint32_t r = 0; r < 2048; r++) {                                          \
            x = scramble(x);                                                           \
            for (uint32_t v = 0; v < (1u << (bits)); v++) {                            \
                type u;                                                                \
                u.raw = x & (mask);                                                    \
                u.member.field = v;                                                    \
                h = mix(h, (uint32_t)u.raw & (mask));                                  \
            }                                                                          \
        }                                                                              \
        printf("W %-34s %016llx\n", #type "." #member "." #field, (unsigned long long)h); \
    } while (0)

int main(void)
{
    printf("host byte order: %s\n", IS_BIG_ENDIAN ? "big" : "little");
    printf("sizeof ITAG %u REQ %u pdeco %u PXC %u AVS %u\n", (unsigned)sizeof(ITAG_t), (unsigned)sizeof(REQ_t),
           (unsigned)sizeof(pdeco_t), (unsigned)sizeof(PXC_t), (unsigned)sizeof(AVS_t));

    /* ---------------------------------------------------------------- DSP */
    READ(ITAG_t, aif, BS, 65536);   READ(ITAG_t, aif, ALU, 65536);    READ(ITAG_t, aif, MUXB, 65536);
    READ(ITAG_t, aif, MUXA, 65536); READ(ITAG_t, aif, M2SEL, 65536);  READ(ITAG_t, aif, NUMOPS, 65536);
    READ(ITAG_t, aif, PAD, 65536);
    READ(ITAG_t, cif, BCH_ADDR, 65536); READ(ITAG_t, cif, FLAG_MASK, 65536); READ(ITAG_t, cif, FLGSEL, 65536);
    READ(ITAG_t, cif, MODE, 65536);     READ(ITAG_t, cif, PAD, 65536);
    READ(ITAG_t, iof, IMMEDIATE, 65536); READ(ITAG_t, iof, JUSTIFY, 65536); READ(ITAG_t, iof, TYPE, 65536);
    READ(ITAG_t, nrof, OP_ADDR, 65536); READ(ITAG_t, nrof, DI, 65536); READ(ITAG_t, nrof, WB1, 65536);
    READ(ITAG_t, nrof, PAD, 65536);     READ(ITAG_t, nrof, TYPE, 65536);
    READ(ITAG_t, r2of, R1, 65536); READ(ITAG_t, r2of, R1_DI, 65536); READ(ITAG_t, r2of, R2, 65536);
    READ(ITAG_t, r2of, R2_DI, 65536); READ(ITAG_t, r2of, NUMREGS, 65536); READ(ITAG_t, r2of, WB1, 65536);
    READ(ITAG_t, r2of, WB2, 65536); READ(ITAG_t, r2of, TYPE, 65536);
    READ(ITAG_t, r3of, R1, 65536); READ(ITAG_t, r3of, R1_DI, 65536); READ(ITAG_t, r3of, R2, 65536);
    READ(ITAG_t, r3of, R2_DI, 65536); READ(ITAG_t, r3of, R3, 65536); READ(ITAG_t, r3of, R3_DI, 65536);
    READ(ITAG_t, r3of, TYPE, 65536);
    READ(ITAG_t, branch, BCH_ADDR, 65536); READ(ITAG_t, branch, FLAGM0, 65536); READ(ITAG_t, branch, FLAGM1, 65536);
    READ(ITAG_t, branch, FLAGSEL, 65536);  READ(ITAG_t, branch, MODE0, 65536);  READ(ITAG_t, branch, MODE1, 65536);
    READ(ITAG_t, branch, AC, 65536);
    READ(ITAG_t, br, BCH_ADDR, 65536); READ(ITAG_t, br, bits, 65536); READ(ITAG_t, br, AC, 65536);
    READ(REQ_t, rq, BS, 256); READ(REQ_t, rq, ALU2, 256); READ(REQ_t, rq, ALU1, 256); READ(REQ_t, rq, MULT2, 256);
    READ(REQ_t, rq, MULT1, 256);

    WRITE(ITAG_t, aif, BS, 4, 0xFFFF);   WRITE(ITAG_t, aif, ALU, 4, 0xFFFF);   WRITE(ITAG_t, aif, MUXB, 2, 0xFFFF);
    WRITE(ITAG_t, aif, MUXA, 2, 0xFFFF); WRITE(ITAG_t, aif, M2SEL, 1, 0xFFFF); WRITE(ITAG_t, aif, NUMOPS, 2, 0xFFFF);
    WRITE(ITAG_t, cif, BCH_ADDR, 10, 0xFFFF); WRITE(ITAG_t, cif, MODE, 2, 0xFFFF);
    WRITE(ITAG_t, iof, IMMEDIATE, 8, 0xFFFF); WRITE(ITAG_t, iof, TYPE, 2, 0xFFFF);
    WRITE(ITAG_t, nrof, OP_ADDR, 8, 0xFFFF); WRITE(ITAG_t, nrof, TYPE, 3, 0xFFFF);
    WRITE(ITAG_t, r2of, R1, 4, 0xFFFF); WRITE(ITAG_t, r2of, R2, 4, 0xFFFF); WRITE(ITAG_t, r2of, TYPE, 3, 0xFFFF);
    WRITE(ITAG_t, r3of, R1, 4, 0xFFFF); WRITE(ITAG_t, r3of, R2, 4, 0xFFFF); WRITE(ITAG_t, r3of, R3, 4, 0xFFFF);
    WRITE(ITAG_t, branch, BCH_ADDR, 10, 0xFFFF); WRITE(ITAG_t, branch, MODE1, 1, 0xFFFF);
    WRITE(ITAG_t, br, bits, 5, 0xFFFF);
    WRITE(REQ_t, rq, BS, 1, 0xFF); WRITE(REQ_t, rq, ALU2, 1, 0xFF); WRITE(REQ_t, rq, ALU1, 1, 0xFF);
    WRITE(REQ_t, rq, MULT2, 1, 0xFF); WRITE(REQ_t, rq, MULT1, 1, 0xFF);

    {   /* dsp_alu_flags_u: `raw` is used as a packed value */
        uint64_t h = 1469598103934665603ull;
        for (uint32_t m = 0; m < 16; m++) {
            dsp_alu_flags_t f;
            f.raw = 0;
            f.zero = m & 1;
            f.negative = (m >> 1) & 1;
            f.carry = (m >> 2) & 1;
            f.overflow = (m >> 3) & 1;
            h = mix(h, f.raw);
            h = mix(h, (uint32_t)((f.raw * 0x10080402u) >> 24));
        }
        printf("W %-34s %016llx\n", "dsp_alu_flags_t", (unsigned long long)h);
    }

    /* -------------------------------------------------------------- MADAM */
    READ(pdeco_t, c1b, c, 65536); READ(pdeco_t, c1b, pad, 65536);
    READ(pdeco_t, c2b, c, 65536); READ(pdeco_t, c2b, pad, 65536);
    READ(pdeco_t, c4b, c, 65536); READ(pdeco_t, c4b, pad, 65536);
    READ(pdeco_t, c6b, c, 65536); READ(pdeco_t, c6b, pw, 65536); READ(pdeco_t, c6b, pad, 65536);
    READ(pdeco_t, c8b, c, 65536); READ(pdeco_t, c8b, mpw, 65536); READ(pdeco_t, c8b, m, 65536);
    READ(pdeco_t, c8b, pad, 65536);
    READ(pdeco_t, c16b, c, 65536); READ(pdeco_t, c16b, mb, 65536); READ(pdeco_t, c16b, mg, 65536);
    READ(pdeco_t, c16b, mr, 65536); READ(pdeco_t, c16b, pad, 65536); READ(pdeco_t, c16b, pw, 65536);
    READ(pdeco_t, u8b, b, 65536); READ(pdeco_t, u8b, g, 65536); READ(pdeco_t, u8b, r, 65536);
    READ(pdeco_t, u8b, pad, 65536);
    READ(pdeco_t, u16b, bw, 65536); READ(pdeco_t, u16b, b, 65536); READ(pdeco_t, u16b, g, 65536);
    READ(pdeco_t, u16b, r, 65536); READ(pdeco_t, u16b, p, 65536);
    READ(pdeco_t, r16b, b, 65536); READ(pdeco_t, r16b, g, 65536); READ(pdeco_t, r16b, r, 65536);
    READ(pdeco_t, r16b, p, 65536);
    READ(AVS_t, avsignal, NEG, 256); READ(AVS_t, avsignal, XTEND, 256); READ(AVS_t, avsignal, nCLIP, 256);
    READ(AVS_t, avsignal, dv3, 256); READ(AVS_t, avsignal, pad, 256);
    READ(PXC_t, meaning, dv2, 65536); READ(PXC_t, meaning, av, 65536); READ(PXC_t, meaning, s2, 65536);
    READ(PXC_t, meaning, dv1, 65536); READ(PXC_t, meaning, mxf, 65536); READ(PXC_t, meaning, ms, 65536);
    READ(PXC_t, meaning, s1, 65536);

    WRITE(pdeco_t, r16b, b, 5, 0xFFFF); WRITE(pdeco_t, r16b, g, 5, 0xFFFF); WRITE(pdeco_t, r16b, r, 5, 0xFFFF);
    WRITE(pdeco_t, r16b, p, 1, 0xFFFF);
    WRITE(pdeco_t, c8b, c, 5, 0xFFFF); WRITE(pdeco_t, c16b, mr, 3, 0xFFFF); WRITE(pdeco_t, u16b, bw, 1, 0xFFFF);
    WRITE(AVS_t, avsignal, NEG, 1, 0xFF); WRITE(AVS_t, avsignal, XTEND, 1, 0xFF);
    WRITE(AVS_t, avsignal, nCLIP, 1, 0xFF); WRITE(AVS_t, avsignal, dv3, 2, 0xFF);
    WRITE(PXC_t, meaning, dv2, 1, 0xFFFF); WRITE(PXC_t, meaning, av, 5, 0xFFFF); WRITE(PXC_t, meaning, s2, 2, 0xFFFF);
    WRITE(PXC_t, meaning, dv1, 2, 0xFFFF); WRITE(PXC_t, meaning, mxf, 3, 0xFFFF);
    WRITE(PXC_t, meaning, ms, 2, 0xFFFF); WRITE(PXC_t, meaning, s1, 1, 0xFFFF);

    /* --------------------------------------------------------------- VDLP */
    READ32(clut_dma_ctrl_word_u, cdcw, persist_len);       READ32(clut_dma_ctrl_word_u, cdcw, ctrl_word_cnt);
    READ32(clut_dma_ctrl_word_u, cdcw, prev_fba_override); READ32(clut_dma_ctrl_word_u, cdcw, curr_fba_override);
    READ32(clut_dma_ctrl_word_u, cdcw, prev_fba_tick);     READ32(clut_dma_ctrl_word_u, cdcw, next_vdl_addr_rel);
    READ32(clut_dma_ctrl_word_u, cdcw, vertical_mode);     READ32(clut_dma_ctrl_word_u, cdcw, enable_dma);
    READ32(clut_dma_ctrl_word_u, cdcw, fba_incr_modulo);   READ32(clut_dma_ctrl_word_u, cdcw, padding0);
    READ32(clut_dma_ctrl_word_u, cdcw, padding1);          READ32(clut_dma_ctrl_word_u, cdcw, padding2);
    READ32(vdl_ctrl_word_u, cvw, b);  READ32(vdl_ctrl_word_u, cvw, g);  READ32(vdl_ctrl_word_u, cvw, r);
    READ32(vdl_ctrl_word_u, cvw, addr); READ32(vdl_ctrl_word_u, cvw, rgb_enable); READ32(vdl_ctrl_word_u, cvw, ctrl_color);
    READ32(background_value_word_u, bvw, b); READ32(background_value_word_u, bvw, g);
    READ32(background_value_word_u, bvw, r); READ32(background_value_word_u, bvw, id);
    READ32(display_ctrl_word_u, dcw, vi_off_1_line); READ32(display_ctrl_word_u, dcw, colors_only);
    READ32(display_ctrl_word_u, dcw, hi_on);         READ32(display_ctrl_word_u, dcw, vi_on);
    READ32(display_ctrl_word_u, dcw, line_blue_lsb); READ32(display_ctrl_word_u, dcw, line_hsrc);
    READ32(display_ctrl_word_u, dcw, line_vsrc);     READ32(display_ctrl_word_u, dcw, swap_pen);
    READ32(display_ctrl_word_u, dcw, msb_replication); READ32(display_ctrl_word_u, dcw, random);
    READ32(display_ctrl_word_u, dcw, window_hi_on);  READ32(display_ctrl_word_u, dcw, window_vi_on);
    READ32(display_ctrl_word_u, dcw, window_blue_lsb); READ32(display_ctrl_word_u, dcw, window_hsrc);
    READ32(display_ctrl_word_u, dcw, window_vsrc);   READ32(display_ctrl_word_u, dcw, swap_hv);
    READ32(display_ctrl_word_u, dcw, enable_bg_color_detector); READ32(display_ctrl_word_u, dcw, tran_true);
    READ32(display_ctrl_word_u, dcw, src_sel);       READ32(display_ctrl_word_u, dcw, clut_bypass);
    READ32(display_ctrl_word_u, dcw, reserved);      READ32(display_ctrl_word_u, dcw, pal_ntsc);
    READ32(display_ctrl_word_u, dcw, null);          READ32(display_ctrl_word_u, dcw, ctrl_color);
    READ32(vdl_ctrl_word_u, aocw, padding); READ32(vdl_ctrl_word_u, aocw, ctrl_color);

    WRITE(clut_dma_ctrl_word_u, cdcw, persist_len, 9, 0xFFFFFFFFu);
    WRITE(clut_dma_ctrl_word_u, cdcw, fba_incr_modulo, 3, 0xFFFFFFFFu);
    WRITE(clut_dma_ctrl_word_u, cdcw, enable_dma, 1, 0xFFFFFFFFu);
    WRITE(display_ctrl_word_u, dcw, clut_bypass, 1, 0xFFFFFFFFu);
    WRITE(display_ctrl_word_u, dcw, ctrl_color, 3, 0xFFFFFFFFu);
    WRITE(display_ctrl_word_u, dcw, vi_off_1_line, 1, 0xFFFFFFFFu);
    WRITE(background_value_word_u, bvw, g, 8, 0xFFFFFFFFu);
    return 0;
}
