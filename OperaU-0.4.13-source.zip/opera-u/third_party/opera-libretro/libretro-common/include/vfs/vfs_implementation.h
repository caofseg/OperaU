/* Copyright  (C) 2010-2020 The RetroArch team
*
* ---------------------------------------------------------------------------------------
* The following license statement only applies to this file (vfs_implementation.h).
* ---------------------------------------------------------------------------------------
*
* Permission is hereby granted, free of charge,
* to any person obtaining a copy of this software and associated documentation files (the "Software"),
* to deal in the Software without restriction, including without limitation the rights to
* use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software,
* and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
* INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
* IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
* OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

#ifndef __LIBRETRO_SDK_VFS_IMPLEMENTATION_H
#define __LIBRETRO_SDK_VFS_IMPLEMENTATION_H

#include <stdio.h>
#include <stdint.h>
#include <libretro.h>
#include <retro_environment.h>
#include <vfs/vfs.h>

RETRO_BEGIN_DECLS

libretro_vfs_implementation_file *retro_vfs_file_open_impl(const char *path, unsigned mode, unsigned hints);

/* Deallocate a range of a file without changing its length; see
 * filestream_punch_hole. Returns 0 on success, -1 when the platform or
 * filesystem cannot do it. */
int retro_vfs_file_punch_hole_impl(libretro_vfs_implementation_file *stream, int64_t offset, int64_t len);

/* Allocation unit of the filesystem holding this file; see
 * filestream_get_sparse_granularity. 0 when unknown. */
int64_t retro_vfs_file_get_sparse_granularity_impl(libretro_vfs_implementation_file *stream);

/* Consumes stream even when reporting final I/O failure; do not retry close. */
int retro_vfs_file_close_impl(libretro_vfs_implementation_file *stream);

int retro_vfs_file_error_impl(libretro_vfs_implementation_file *stream);

int64_t retro_vfs_file_size_impl(libretro_vfs_implementation_file *stream);

int64_t retro_vfs_file_truncate_impl(libretro_vfs_implementation_file *stream, int64_t length);

int64_t retro_vfs_file_tell_impl(libretro_vfs_implementation_file *stream);

int64_t retro_vfs_file_seek_impl(libretro_vfs_implementation_file *stream, int64_t offset, int seek_position);

int64_t retro_vfs_file_read_impl(libretro_vfs_implementation_file *stream, void *s, uint64_t len);

int64_t retro_vfs_file_write_impl(libretro_vfs_implementation_file *stream, const void *s, uint64_t len);

int retro_vfs_file_flush_impl(libretro_vfs_implementation_file *stream);

int retro_vfs_file_remove_impl(const char *path);

int retro_vfs_file_rename_impl(const char *old_path, const char *new_path);

const char *retro_vfs_file_get_path_impl(libretro_vfs_implementation_file *stream);

/* Borrowed pointer to the whole file, when this stream is backed by a
 * memory map, else NULL.  Valid until the stream is closed; read-only;
 * never freed by the caller.
 *
 * RETRO_VFS_FILE_ACCESS_HINT_FREQUENT_ACCESS already maps the file,
 * but the mapping was reachable only from inside the read path, which
 * memcpy's out of it - so every consumer of the hint paid for a copy
 * of data that was already addressable, and the point of asking for
 * the map was lost.  This hands the map itself to callers that want
 * to look rather than own: comparing a file against a buffer, hashing
 * it, or passing it to a parser that takes a base pointer.
 *
 * NULL is a normal answer, not an error - no HAVE_MMAP, hint not
 * given, a write mode, a scheme with no mapping, or a frontend-
 * supplied VFS - so callers need the copying path anyway and should
 * treat this as a fast lane, never as the only one. */
const uint8_t *retro_vfs_file_get_mapped_ptr_impl(
      libretro_vfs_implementation_file *stream, int64_t *len);

/**
 * retro_vfs_file_view_impl:
 *
 * retro_vfs_file_read_impl() without the copy: points @ptr at up to
 * @len octets at the position, in the file's mapping or in a network
 * stream's read-ahead window, and moves past them. They stay valid
 * until the next call on @stream. Returns the octets lent, 0 at the
 * end of the file, or -1 when nothing there can be lent; the caller
 * then reads.
 **/
int64_t retro_vfs_file_view_impl(libretro_vfs_implementation_file *stream,
      uint64_t len, const uint8_t **ptr);

/**
 * retro_vfs_file_prefetch_impl:
 * @offset : first byte of the range about to be read
 * @len    : bytes of it
 *
 * Asks the OS to start bringing the range into memory, so a read or a
 * touch of the mapping that follows finds it resident instead of
 * stalling on the disk. Returns at once: madvise(MADV_WILLNEED) on a
 * mapped file, posix_fadvise(WILLNEED) on a descriptor; on Windows the
 * range is handed to the file's read-ahead thread, which calls
 * PrefetchVirtualMemory() (or touches the pages before Windows 8), so
 * the caller never waits on the disk. A no-op where none of these
 * exists, on a scheme that is not a local file, or when the OS
 * declines. A hint, never an error. */
void retro_vfs_file_prefetch_impl(
      libretro_vfs_implementation_file *stream, uint64_t offset,
      uint64_t len);

int retro_vfs_stat_impl(const char *path, int32_t *size);

int retro_vfs_stat_64_impl(const char *path, int64_t *size);

int retro_vfs_mkdir_impl(const char *dir);

int retro_vfs_rmdir_impl(const char *dir);

/**
 * retro_vfs_restrict_permissions_impl:
 * @path : file to restrict
 *
 * Makes @path readable and writable by the owning user only, for
 * files that hold secrets. On platforms without per-user file
 * permissions (Windows profile directories, single-user consoles,
 * Android SAF) there is nothing to do and the call succeeds.
 *
 * Returns: 0 on success, -1 on failure.
 **/
int retro_vfs_restrict_permissions_impl(const char *path);

/* VFS API v5 */
int retro_vfs_set_readonly_impl(const char *path, int readonly);
int retro_vfs_get_mtime_impl(const char *path, int64_t *mtime);
int retro_vfs_set_mtime_impl(const char *path, int64_t mtime);
struct retro_vfs_copy_handle *retro_vfs_copy_begin_impl(const char *src, const char *dst, unsigned flags);
int retro_vfs_copy_step_impl(struct retro_vfs_copy_handle *handle, int64_t max_bytes, int64_t *bytes_done, int64_t *bytes_total);
int retro_vfs_copy_close_impl(struct retro_vfs_copy_handle *handle);
int retro_vfs_dirent_stat_impl(libretro_vfs_implementation_dir *rdir, int64_t *size, int64_t *mtime);

libretro_vfs_implementation_dir *retro_vfs_opendir_impl(const char *dir, bool include_hidden);

bool retro_vfs_readdir_impl(libretro_vfs_implementation_dir *dirstream);

const char *retro_vfs_dirent_get_name_impl(libretro_vfs_implementation_dir *dirstream);

bool retro_vfs_dirent_is_dir_impl(libretro_vfs_implementation_dir *dirstream);

int retro_vfs_closedir_impl(libretro_vfs_implementation_dir *dirstream);

#ifdef __WINRT__

void uwp_set_acl(const wchar_t* path, const wchar_t* AccessString);

#endif

RETRO_END_DECLS

#endif
