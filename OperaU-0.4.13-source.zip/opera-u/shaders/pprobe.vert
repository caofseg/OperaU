#version 150

/*
  Opera U: the vertex half of the pixel-processor probe.

  Nothing but a quad covering the whole target. The fragment shader reads its position from gl_FragCoord instead
  of an interpolated coordinate, so that nothing the rasteriser interpolates can change which texel a pixel reads
  - the point of the probe is to compare the GPU's arithmetic against the CPU's, and an off-by-half texel would
  look like an arithmetic fault.
*/

in vec2 a_position;

void
main()
{
  gl_Position = vec4(a_position,0.0,1.0);
}
