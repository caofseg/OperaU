#include "perf.h"
#include "audio.h"
#include "common.h"
#include "config.h"
#include "core.h"
#include "log.h"
#include "platform.h"

#include "libopera/opera_clock.h"
#include "libopera/opera_madam.h"
#include "libopera/opera_prof.h"
#include "opera_lr_dsp.h"
#include "libopera/opera_dsp.h"

#include <SDL.h>

#define PERF_WINDOW_US 5000000ULL

static uint32_t g_want; /* atomic: 0 / 1 */

static struct {
    bool open;            /* a window is in progress */
    uint64_t t0_us;       /* wall clock at its start */
    uint64_t c0;          /* tick counter at its start */
    uint64_t run, wait;   /* ticks */
    uint32_t frames;
    opera_lr_dsp_thread_stats_t dsp0; /* the DSP thread's running totals at its start */
    unsigned under0;                  /* times the sound buffer had run dry by its start */
    uint32_t cut0;                    /* runs of the DSP's program given up on by its start */
} W;

/*
 * Everything the cels did since the game was started, added up window by window (opera_prof is cleared every
 * five seconds). The percentages only settle after a few seconds of play, and they are what decides which part
 * of the cel engine is worth specialising - so they are written to wiiu/OperaU/perf.txt as well as the log,
 * where they are easy to find and to send on.
 */
static struct {
    uint64_t cels, texels, pixels, frames;
    uint64_t useav, blackfix, twopixc, s1;
    uint64_t s2[4], ms[4], bpp[8], type[3], draw[3];
    char game[160];  /* which game these totals belong to: they are cleared when another one is loaded */
    double fps, run, arm, cel, dsp, vdl, timers, audio, video;
    /* the DSP on its own thread, over the last window: its work per frame in ms, and how it kept up */
    bool dsp_threaded;
    double dsp_thr_ms, dsp_thr_ticks;
    uint64_t dsp_thr_dropped;
    uint32_t dsp_thr_backlog, dsp_thr_cores;
    /* what the emulation paid for keeping its writes in step with the thread: waits per frame, their time per
     * frame in ms, and waits that ran out of time */
    double dsp_thr_waits, dsp_thr_wait_ms;
    uint64_t dsp_thr_gave_up;
    uint32_t dsp_cut;   /* runs of the DSP's program that reached no sleep, in the last window */
    unsigned underruns; /* times the sound buffer ran dry in the last window */
    /*
     * The game's own pace, as against the emulation's: pictures it presented a second (fields that showed another
     * frame buffer than the one before), the share of the machine's time its cel engine was busy, and what
     * reading the disc image cost. A game that shows 30 pictures while the emulation runs its 60 fields is
     * waiting inside the emulated machine, and no amount of host speed changes that.
     */
    double game_pps, cel_busy_pct;
    double cd_per_s, cd_ms, cd_max_ms;
    double write_ms;    /* how long writing this report to the card took, the last time it was written */
    double log_ms, log_max_ms; /* what writing log lines cost in the last window, and the longest single line */
} T;

/*
 * The report of the latest window, kept as text. It reaches the card in two ways: every twenty seconds, handed
 * to a thread of its own, because writing two files on an SD card takes tens of milliseconds and the emulation
 * thread used to spend them with the game standing still; and when the game is paused or closed, written on the
 * spot, so that what is on the card is the five seconds before the pause and not some window up to twenty
 * seconds back. That second way is what makes "close the game in the middle of the scene" a measurement of the
 * scene.
 */
static char g_report[6200];
static size_t g_report_len;
static char g_report_name[200]; /* "perf-<game>.txt", or empty */
static bool g_report_unwritten;
static uint64_t g_report_handed_us;

static struct {
    SDL_Thread *thread;
    SDL_mutex *lock;   /* guards the three fields below, and is held while the files are being written */
    SDL_sem *sem;
    uint32_t quit;     /* atomic */
    char text[6200];
    size_t len;
    char name[200];
    uint32_t last_us;  /* atomic: how long the last write took */
} F;

static void write_report_files(const char *text, size_t len, const char *name)
{
    char path[1100];
    uint64_t t0 = platform_time_us();

    path_join(path, sizeof(path), platform_data_dir(), "perf.txt");
    platform_write_file_atomic(path, text, len);
    if (name[0]) { /* a copy named after the game, so that several games measured in a row each keep their own */
        path_join(path, sizeof(path), platform_data_dir(), name);
        platform_write_file_atomic(path, text, len);
    }
    __atomic_store_n(&F.last_us, (uint32_t)(platform_time_us() - t0), __ATOMIC_RELEASE);
}

static int writer_main(void *arg)
{
    (void)arg;
    for (;;) {
        SDL_SemWait(F.sem);
        if (__atomic_load_n(&F.quit, __ATOMIC_ACQUIRE))
            break;
        SDL_LockMutex(F.lock);
        if (F.len) {
            write_report_files(F.text, F.len, F.name);
            F.len = 0;
        }
        SDL_UnlockMutex(F.lock);
        log_flush(); /* and the log's lines of these twenty seconds, which nobody else sends to the card */
    }
    return 0;
}

/* Emulation thread: hands the latest report to the writer thread. If that is still busy with the one before,
 * this one waits for the next window. */
static void report_write_later(void)
{
    if (!F.lock) {
        F.lock = SDL_CreateMutex();
        F.sem = SDL_CreateSemaphore(0);
        if (F.lock && F.sem)
            F.thread = SDL_CreateThread(writer_main, "operau-perf", NULL);
    }
    if (!F.thread) { /* no thread to be had: as it was done before */
        write_report_files(g_report, g_report_len, g_report_name);
        g_report_unwritten = false;
        return;
    }
    if (SDL_TryLockMutex(F.lock) != 0)
        return;
    memcpy(F.text, g_report, g_report_len);
    F.len = g_report_len;
    str_copy(F.name, g_report_name, sizeof(F.name));
    SDL_UnlockMutex(F.lock);
    SDL_SemPost(F.sem);
    g_report_unwritten = false;
}

void perf_flush(void)
{
    bool newer = g_report_unwritten && g_report_len != 0;

    if (F.lock) {
        SDL_LockMutex(F.lock); /* waits for a write the other thread is in the middle of */
        if (newer)
            write_report_files(g_report, g_report_len, g_report_name);
        else if (F.len)
            write_report_files(F.text, F.len, F.name); /* handed over, not started: done here instead */
        F.len = 0; /* either way, nothing older is left for the writer */
        SDL_UnlockMutex(F.lock);
    } else if (newer) {
        write_report_files(g_report, g_report_len, g_report_name);
    }
    g_report_unwritten = false;
    log_flush();
}

void perf_shutdown(void)
{
    if (F.thread) {
        __atomic_store_n(&F.quit, 1u, __ATOMIC_RELEASE);
        SDL_SemPost(F.sem);
        SDL_WaitThread(F.thread, NULL);
        F.thread = NULL;
    }
    if (F.sem)
        SDL_DestroySemaphore(F.sem);
    if (F.lock)
        SDL_DestroyMutex(F.lock);
    F.sem = NULL;
    F.lock = NULL;
    __atomic_store_n(&F.quit, 0u, __ATOMIC_RELEASE);
}

/* What the probes themselves cost, in ticks (see calibrate()). */
static double g_pair;  /* what one empty probe pair adds to its own measurement */
static double g_full;  /* the whole cost of one probe pair, as seen by whatever encloses it */

static char g_hud[2][112];
static uint32_t g_hud_idx;  /* atomic: which of the two is current, bit 8 set once there is text */

uint32_t perf_now(void)
{
    return opera_prof_now();
}

void perf_set_enabled(bool on)
{
    __atomic_store_n(&g_want, on ? 1u : 0u, __ATOMIC_RELEASE);
}

/* Times empty probe pairs, alone and nested, the way the core's hooks are built, so that their own cost can be taken out
 * of the numbers (on a PowerPC a time base read is cheap, on an x86 TSC it is not). Called with the hooks on, on the
 * emulation thread, between frames. */
static void calibrate(void)
{
    uint32_t best_alone = 0xFFFFFFFFu, best_nested = 0xFFFFFFFFu;
    opera_prof_t scratch;

    memset(&scratch, 0, sizeof(scratch));
    for (int rep = 0; rep < 24; rep++) {
        uint32_t alone = 0, nested = 0;

        for (int i = 0; i < 400; i++) {
            OPERA_PROF_BEGIN(a);
            alone += (uint32_t)(opera_prof_now() - a);
            scratch.dsp_calls++;
        }
        for (int i = 0; i < 400; i++) {
            OPERA_PROF_BEGIN(o);
            {
                OPERA_PROF_BEGIN(a);
                if (opera_prof_enabled) {
                    scratch.dsp += (uint32_t)(opera_prof_now() - a);
                    scratch.dsp_calls++;
                }
            }
            nested += (uint32_t)(opera_prof_now() - o);
        }
        best_alone = MIN(best_alone, alone);
        best_nested = MIN(best_nested, nested);
    }
    g_pair = (double)best_alone / 400.0;
    g_full = (double)best_nested / 400.0 - g_pair;
    if (g_full < g_pair)
        g_full = g_pair;
    LOGI("perf: a probe costs %.1f ticks (%.1f of them outside what it measures)", g_full, g_full - g_pair);
}

void perf_sync(void)
{
    int want = (int)__atomic_load_n(&g_want, __ATOMIC_ACQUIRE);

    if (want != opera_prof_enabled) {
        opera_prof_enabled = want;
        W.open = false;
        if (want)
            calibrate();
        else
            __atomic_store_n(&g_hud_idx, 0u, __ATOMIC_RELEASE);
    }
}

void perf_reset(void)
{
    W.open = false;
    __atomic_store_n(&g_hud_idx, 0u, __ATOMIC_RELEASE);
}

static void window_start(uint64_t now_us)
{
    memset(&opera_prof, 0, sizeof(opera_prof));
    W.run = W.wait = 0;
    W.frames = 0;
    W.t0_us = now_us;
    W.c0 = opera_prof_clock64();
    opera_lr_dsp_thread_stats(&W.dsp0);
    W.under0 = audio_underruns();
    W.cut0 = opera_dsp_runs_cut();
    W.open = true;
}

/*
 * wiiu/OperaU/perf.txt: the same numbers the log carries, in one small file that is easy to find and to send on.
 * Written at most every twenty seconds so that the writing itself does not disturb what is being measured.
 */
/*
 * The shape of the cel work is measured over the same five seconds as the times above it. That alignment is the
 * whole point: the totals since the game started average over menus, loading and every scene played, while the
 * times are from the last window, so reading one against the other compares different things. Three measurements
 * of the same game gave 24.74, 22.82 and 24.68 ms with the share of cels using AV going from 13% to 84% - those
 * were different scenes, not different builds.
 */
static const char *cel_rate_text(void)
{
    static char buf[48];
    uint32_t r = opera_madam_cel_rate_get();

    if (r == 0)
        return "no limit (it is never busy)";
    snprintf(buf, sizeof(buf), "%u million pixels a second", (unsigned)(r / 1000000u));
    return buf;
}

static void write_perf_file(uint64_t now_us, const opera_prof_t *p, double n)
{
    char *text = g_report;
    const size_t text_cap = sizeof(g_report);
    const char *game = core_game_path();
    double c = (double)p->cel_cels;
    int n_out;

#define sizeof_text text_cap
    n_out = snprintf(text, sizeof_text,
                     "%s %s performance\n"
                     "build:          %s\n"
                     "game:           %s\n"
                     "\n"
                     "last 5 seconds: %.1f fps, %.1f ms per frame\n"
                     "  ARM           %.2f ms\n"
                     "  cels          %.2f ms\n"
                     "  DSP           %.2f ms\n"
                     "  video lines   %.2f ms\n"
                     "  timers+bus    %.2f ms\n"
                     "  audio         %.2f ms\n"
                     "  picture       %.2f ms\n"
                     "\n"
                     "the game:       %.1f pictures a second, of the %.1f fields a second the emulation ran\n"
                     "  cel engine    busy %.0f%% of the machine's time, at %s\n"
                     "  disc          %.0f sectors a second, %.2f ms per frame (inside the times above), longest read %.1f ms\n"
                     "\n"
                     "cels in those same 5 seconds: %llu over %.0f frames\n"
                     "  per frame     %.0f cels, %.0f texels, %.0f pixels\n",
                     APP_NAME, APP_VERSION, APP_BUILD, (game && *game) ? path_base(game) : "-",
                     T.fps, T.run, T.arm, T.cel, T.dsp, T.vdl, T.timers, T.audio, T.video,
                     T.game_pps, T.fps, T.cel_busy_pct, cel_rate_text(), T.cd_per_s, T.cd_ms, T.cd_max_ms,
                     (unsigned long long)p->cel_cels, n,
                     n > 0.0 ? c / n : 0.0,
                     n > 0.0 ? (double)p->cel_texels / n : 0.0,
                     n > 0.0 ? (double)p->cel_pixels / n : 0.0);

    if (c > 0.0 && n_out > 0 && (size_t)n_out < sizeof_text)
        n_out += snprintf(text + n_out, sizeof_text - (size_t)n_out,
                          "  pixels        %.0f ns each, at this frame rate\n"
                          "  stored        packed %.0f%% / LR %.0f%% / literal %.0f%%\n"
                          "  drawn by      line %.0f%% / scaled %.0f%% / arbitrary %.0f%%\n"
                          "  texels        %.1f per pixel drawn\n"
                          "  reads the frame buffer %.0f%%\n"
                          "  use AV        %.0f%%\n"
                          "  black fix     %.0f%%\n"
                          "  two PIXC      %.0f%%\n"
                          "  colour1 from frame buffer %.0f%%\n"
                          "  colour2 src   %.0f/%.0f/%.0f/%.0f%%\n"
                          "  colour1 scale %.0f/%.0f/%.0f/%.0f%%\n"
                          "  bpp           %.0f/%.0f/%.0f/%.0f/%.0f/%.0f/%.0f/%.0f%%\n",
                          p->cel_pixels > 0 ? T.cel * 1000000.0 * n / (double)p->cel_pixels : 0.0,
                          p->cel_type[0] * 100.0 / c, p->cel_type[1] * 100.0 / c, p->cel_type[2] * 100.0 / c,
                          p->cel_draw[0] * 100.0 / c, p->cel_draw[1] * 100.0 / c, p->cel_draw[2] * 100.0 / c,
                          p->cel_pixels > 0 ? (double)p->cel_texels / (double)p->cel_pixels : 0.0,
                          p->cel_fbread * 100.0 / c,
                          p->cel_useav * 100.0 / c, p->cel_blackfix * 100.0 / c, p->cel_twopixc * 100.0 / c,
                          p->cel_s1 * 100.0 / c,
                          p->cel_s2[0] * 100.0 / c, p->cel_s2[1] * 100.0 / c, p->cel_s2[2] * 100.0 / c,
                          p->cel_s2[3] * 100.0 / c,
                          p->cel_ms[0] * 100.0 / c, p->cel_ms[1] * 100.0 / c, p->cel_ms[2] * 100.0 / c,
                          p->cel_ms[3] * 100.0 / c,
                          p->cel_bpp[0] * 100.0 / c, p->cel_bpp[1] * 100.0 / c, p->cel_bpp[2] * 100.0 / c,
                          p->cel_bpp[3] * 100.0 / c, p->cel_bpp[4] * 100.0 / c, p->cel_bpp[5] * 100.0 / c,
                          p->cel_bpp[6] * 100.0 / c, p->cel_bpp[7] * 100.0 / c);

    /*
     * What the engine did with them. A cel either has its finished pixels looked up by source value, or - a 16-bit
     * picture of too many colours - has them worked out texel by texel, or reads the frame buffer and is mixed
     * into it pixel by pixel. The last kind costs several times the others, so its share of the pixels is the
     * number to read the "ns each" above against. The pixel processor's whole pipeline still runs wherever no
     * table stands in for it; that count is the slow part that is left, and with it the place to look next.
     */
    if (c > 0.0 && n > 0.0 && n_out > 0 && (size_t)n_out < sizeof_text)
        n_out += snprintf(text + n_out, sizeof_text - (size_t)n_out,
                          "\nhow the engine drew them:\n"
                          "  finished pixel looked up     %3.0f%% of cels\n"
                          "  worked out for every texel   %3.0f%% of cels\n"
                          "  mixed with the frame buffer  %3.0f%% of cels, %.0f%% of pixels\n"
                          "  pixel processor the long way %.0f runs per frame\n"
                          "  mix tables built             %llu in those 5 seconds\n",
                          p->cel_route[0] * 100.0 / c, p->cel_route[1] * 100.0 / c, p->cel_route[2] * 100.0 / c,
                          p->cel_pixels ? p->cel_fbread_px * 100.0 / (double)p->cel_pixels : 0.0,
                          (double)p->pp_long / n, (unsigned long long)p->pp2d_built);

    /*
     * The DSP, in the same five seconds. The diagnostic's dsp battery cannot stand in for this: more than half of
     * that battery's instructions are the test harness around it, and the instruction mix it makes up is not a
     * game's. Its profile is also flat - no single line of the interpreter stands out - so what is worth changing
     * depends on what games really execute, which is what these numbers say.
     */
    if (p->dsp_insts > 0 && n_out > 0 && (size_t)n_out < sizeof_text) {
        double ins = (double)p->dsp_insts;
        double alu = (double)(p->dsp_insts - p->dsp_ctrl);

        n_out += snprintf(text + n_out, sizeof_text - (size_t)n_out,
                          "\n"
                          "DSP in those same 5 seconds: %llu instructions over %.0f frames\n"
                          "  per frame     %.0f instructions, %.0f runs\n"
                          "  instruction   %.0f ns each, at this frame rate\n"
                          "  control       %.0f%% (the rest are ALU)\n"
                          "  operands      %.2f per ALU instruction\n"
                          "  writes back   %.0f%% of ALU instructions\n",
                          (unsigned long long)p->dsp_insts, n, n > 0.0 ? ins / n : 0.0,
                          n > 0.0 ? (double)p->dsp_calls / n : 0.0,
                          (T.dsp_threaded ? T.dsp_thr_ms : T.dsp) * 1000000.0 * n / ins,
                          p->dsp_ctrl * 100.0 / ins, alu > 0.0 ? (double)p->dsp_operands / alu : 0.0,
                          alu > 0.0 ? p->dsp_writeback * 100.0 / alu : 0.0);
    }

    /*
     * Where the DSP ran. On its own thread its work is no longer part of the frame: the "DSP" line at the top then
     * shows only what handing the ticks over costs, and the work itself is here, so that the two can be added up
     * and compared with the same game with the thread off. The last two numbers say whether it kept up: samples
     * dropped are sound that was lost, and the backlog is how far behind the emulation it ever was (735 ticks are
     * one frame of sound).
     */
    if (n_out > 0 && (size_t)n_out < sizeof_text) {
        if (T.dsp_threaded) {
            char cores[16] = "";
            int k, len = 0;

            for (k = 0; k < 3; k++)
                if (T.dsp_thr_cores & (1u << k))
                    len += snprintf(cores + len, sizeof(cores) - (size_t)len, "%s%d", len ? "," : "", k);
            n_out += snprintf(text + n_out, sizeof_text - (size_t)n_out,
                              "\nDSP thread:     on, core %s (emulation on core %d)\n"
                              "  its work      %.2f ms per frame, outside the frame time above\n"
                              "  kept up       %llu samples dropped, at most %u ticks behind\n"
                              "  waited for    %.1f times per frame, %.2f ms per frame, %llu waits gave up\n",
                              cores[0] ? cores : "?", g_cfg.emu_core, T.dsp_thr_ms,
                              (unsigned long long)T.dsp_thr_dropped, (unsigned)T.dsp_thr_backlog,
                              T.dsp_thr_waits, T.dsp_thr_wait_ms, (unsigned long long)T.dsp_thr_gave_up);
        } else {
            n_out += snprintf(text + n_out, sizeof_text - (size_t)n_out,
                              "\nDSP thread:     off (the DSP runs inside the frame, on the emulation's core)\n");
        }
    }

    /*
     * A run of the DSP's program that reached no sleep and was given up on, as the machine's next sample tick
     * would. A game's sound code does not write such programs, so anything but zero here is the DSP caught
     * looking at a program half rewritten - which, before runs were given up on, stopped it for good.
     */
    if (n_out > 0 && (size_t)n_out < sizeof_text)
        n_out += snprintf(text + n_out, sizeof_text - (size_t)n_out,
                          "DSP runs given up on: %u in those 5 seconds (a program that never sleeps)\n",
                          (unsigned)T.dsp_cut);

    /*
     * How much sound is waiting to be played. This is the delay between a thing happening in the game and being
     * heard, on top of what the console's own output adds, and it only shows once a game runs at full speed: a
     * game that runs slow never fills the buffer, so its sound is choppy but not late.
     */
    if (n_out > 0 && (size_t)n_out < sizeof_text && audio_available())
        n_out += snprintf(text + n_out, sizeof_text - (size_t)n_out,
                          "\nsound waiting:  %d ms now, kept at or under %d ms, ran dry %u times in those 5 seconds\n",
                          audio_buffered_frames() * 1000 / 48000, audio_target_frames() * 1000 / 48000,
                          T.underruns);

    /* The totals stay for coverage: they say how much of the whole session the window above is a sample of. */
    if (n_out > 0 && (size_t)n_out < sizeof_text)
        n_out += snprintf(text + n_out, sizeof_text - (size_t)n_out,
                          "\n"
                          "cels since the game started: %llu over %llu frames\n"
                          "  per frame     %.0f cels, %.0f texels, %.0f pixels\n",
                          (unsigned long long)T.cels, (unsigned long long)T.frames,
                          T.frames ? (double)T.cels / (double)T.frames : 0.0,
                          T.frames ? (double)T.texels / (double)T.frames : 0.0,
                          T.frames ? (double)T.pixels / (double)T.frames : 0.0);

    /*
     * What reporting itself costs the game. Writing this file took the emulation thread tens of milliseconds every
     * twenty seconds, and the log's lines a write to the card every few seconds; both now happen on another thread
     * or with the game paused. The first number is how long the last write of this file took there. The second is
     * what is left on the threads that write log lines: it should be a fraction of a millisecond.
     */
    if (n_out > 0 && (size_t)n_out < sizeof_text)
        n_out += snprintf(text + n_out, sizeof_text - (size_t)n_out,
                          "\nthis report:    the last write of this file took %.1f ms, away from the emulation thread\n"
                          "  the log       its lines cost %.2f ms in those 5 seconds, the longest %.2f ms\n",
                          T.write_ms, T.log_ms, T.log_max_ms);
#undef sizeof_text

    g_report_len = strlen(text);
    g_report_name[0] = '\0';
    if (T.game[0]) {
        size_t i;

        snprintf(g_report_name, sizeof(g_report_name), "perf-%s.txt", T.game);
        for (i = 5; g_report_name[i]; i++) /* keep the file name safe on a FAT card */
            if (strchr("\\/:*?\"<>|", g_report_name[i]))
                g_report_name[i] = '_';
    }
    g_report_unwritten = true;

    if (g_report_handed_us == 0 || (now_us - g_report_handed_us) >= 20000000ULL) {
        g_report_handed_us = now_us;
        report_write_later();
    }
}

static void report(uint64_t now_us)
{
    const opera_prof_t p = opera_prof;
    uint64_t dus = now_us - W.t0_us;
    uint64_t dticks = opera_prof_clock64() - W.c0;
    double tpus, n, nominal;
    double run, wait, cel, dsp, vdl, timers, audio, video, arm, fps;
    char *hud;
    uint32_t cur;

    if (dus == 0 || dticks == 0 || W.frames < 10) {
        window_start(now_us);
        return;
    }
    tpus = (double)dticks / (double)dus; /* ticks per microsecond */
    n = (double)W.frames;
#define MS(t) ((double)(t) / tpus / 1000.0 / n) /* ticks in the window -> milliseconds per frame */
    {
        /* take the cost of the probes out: a probe adds g_pair to what it measures, and a nested one adds all of g_full to
         * the measurement of the probe around it; what a top-level probe costs outside its own measurement lands on ARM */
        double fr = (double)p.frames;
        double dsp_t = (double)p.dsp - (double)p.dsp_calls * g_pair;
        double vdl_t = (double)p.vdl - (double)p.vdl_calls * g_pair;
        double cel_t = (double)p.cel - (double)p.cel_calls * g_pair;
        double int_t = (double)p.internal - (double)p.internal_calls * g_pair - (double)(p.dsp_calls + p.vdl_calls) * g_full;
        double aud_t = (double)p.audio_up - fr * g_pair;
        double vid_t = (double)p.video_cb - fr * g_pair;
        double outside = (double)(p.internal_calls + p.cel_calls) * (g_full - g_pair) + 2.0 * fr * (g_full - g_pair);
        double arm_t = (double)W.run - (double)p.internal - (double)p.cel - (double)p.audio_up - (double)p.video_cb - outside;

        run = MS(W.run);
        wait = MS(W.wait);
        cel = MS(MAX(cel_t, 0.0));
        dsp = MS(MAX(dsp_t, 0.0));
        vdl = MS(MAX(vdl_t, 0.0));
        timers = MS(MAX(int_t - dsp_t - vdl_t, 0.0));
        audio = MS(MAX(aud_t, 0.0));
        video = MS(MAX(vid_t, 0.0));
        arm = MS(MAX(arm_t, 0.0));
    }
    fps = n * 1000000.0 / (double)dus;
    nominal = core_av()->fps > 1.0 ? core_av()->fps : 60.0;
#undef MS
#define PCT(x) ((int)(run > 0.0 ? (x) * 100.0 / run + 0.5 : 0.0))

    LOGI("perf: %.1f fps (%d%% of real time) | run %.1f ms + wait %.1f ms per frame", fps, (int)(fps * 100.0 / nominal + 0.5),
         run, wait);
    LOGI("perf: of run: ARM %.1f ms (%d%%) | cel %.1f (%d%%) | DSP %.1f (%d%%) | video lines %.1f (%d%%) | timers+bus %.1f (%d%%) | "
         "audio %.1f | picture %.1f | probes %.1f",
         arm, PCT(arm), cel, PCT(cel), dsp, PCT(dsp), vdl, PCT(vdl), timers, PCT(timers), audio, video,
         MAX(run - arm - cel - dsp - vdl - timers - audio - video, 0.0));
    LOGI("perf: per frame: %.1f cel lists, %.0f cels, %.0fk texels, %.0fk pixels | %.0f DSP runs | %.0f video lines | %.0f timer/bus steps",
         (double)p.cel_calls / n, (double)p.cel_cels / n, (double)p.cel_texels / n / 1000.0, (double)p.cel_pixels / n / 1000.0,
         (double)p.dsp_calls / n, (double)p.vdl_calls / n, (double)p.internal_calls / n);

    {   /* totals belong to one game: starting another one must not blend the two together */
        const char *g = core_game_path();
        const char *name = (g && *g) ? path_base(g) : "";

        if (strncmp(T.game, name, sizeof(T.game) - 1) != 0) {
            memset(&T, 0, sizeof(T));
            str_copy(T.game, name, sizeof(T.game));
        }
    }

    T.frames += p.frames;
    T.cels += p.cel_cels;
    T.texels += p.cel_texels;
    T.pixels += p.cel_pixels;
    T.useav += p.cel_useav;
    T.blackfix += p.cel_blackfix;
    T.twopixc += p.cel_twopixc;
    T.s1 += p.cel_s1;
    for (int i = 0; i < 4; i++) {
        T.s2[i] += p.cel_s2[i];
        T.ms[i] += p.cel_ms[i];
    }
    for (int i = 0; i < 8; i++)
        T.bpp[i] += p.cel_bpp[i];
    for (int i = 0; i < 3; i++) {
        T.type[i] += p.cel_type[i];
        T.draw[i] += p.cel_draw[i];
    }
    T.fps = fps;
    T.run = run;
    T.arm = arm;
    T.cel = cel;
    T.dsp = dsp;
    T.underruns = audio_underruns() - W.under0;
    {
        double freq = (double)opera_clock_cpu_get_freq(); /* emulated CPU cycles a second */

        T.game_pps = (double)p.vdl_flips * 1000000.0 / (double)dus;
        T.cel_busy_pct = (freq > 0.0 && n > 0.0) ? (double)p.cel_busy * 100.0 * nominal / (n * freq) : 0.0;
        T.cd_per_s = (double)p.cd_calls * 1000000.0 / (double)dus;
        T.cd_ms = (double)p.cd / tpus / 1000.0 / n;
        T.cd_max_ms = (double)p.cd_max / tpus / 1000.0;
        T.write_ms = (double)__atomic_load_n(&F.last_us, __ATOMIC_ACQUIRE) / 1000.0;
        LOGI("perf: the game: %.1f pictures a second | cel engine busy %.0f%% of the machine's time | disc %.0f sectors "
             "a second, %.2f ms per frame, longest read %.1f ms",
             T.game_pps, T.cel_busy_pct, T.cd_per_s, T.cd_ms, T.cd_max_ms);
    }
    {
        /* The DSP thread keeps running totals of its own; the window is the difference between two readings. */
        opera_lr_dsp_thread_stats_t d;

        opera_lr_dsp_thread_stats(&d);
        T.dsp_threaded = opera_lr_dsp_is_threaded();
        T.dsp_thr_ms = (double)(d.busy_ticks - W.dsp0.busy_ticks) / tpus / 1000.0 / n;
        T.dsp_thr_ticks = (double)(d.ticks_run - W.dsp0.ticks_run) / n;
        T.dsp_thr_dropped = d.dropped - W.dsp0.dropped;
        T.dsp_thr_backlog = d.backlog_max;
        T.dsp_thr_cores = d.cores;
        T.dsp_thr_waits = (double)(d.waits - W.dsp0.waits) / n;
        T.dsp_thr_wait_ms = (double)(d.wait_ticks - W.dsp0.wait_ticks) / tpus / 1000.0 / n;
        T.dsp_thr_gave_up = d.wait_gave_up - W.dsp0.wait_gave_up;
        T.dsp_cut = opera_dsp_runs_cut() - W.cut0;
        if (T.dsp_threaded)
            LOGI("perf: DSP on its own thread: %.2f ms of work per frame, %.0f ticks, %llu samples dropped, at most %u "
                 "ticks behind, cores mask 0x%x, waited for %.1f times per frame (%.2f ms), %llu waits gave up",
                 T.dsp_thr_ms, T.dsp_thr_ticks, (unsigned long long)T.dsp_thr_dropped, (unsigned)T.dsp_thr_backlog,
                 (unsigned)T.dsp_thr_cores, T.dsp_thr_waits, T.dsp_thr_wait_ms, (unsigned long long)T.dsp_thr_gave_up);
        if (T.dsp_cut)
            LOGW("perf: %u runs of the DSP's program reached no sleep and were given up on", (unsigned)T.dsp_cut);
    }
    T.vdl = vdl;
    T.timers = timers;
    T.audio = audio;
    T.video = video;

    if (p.cel_cels > 0) {
        double c = (double)p.cel_cels;

        LOGI("perf: cels: %.1f%% use AV, %.1f%% need the black fix, %.1f%% have two PIXC halves, %.1f%% take colour 1 "
             "from the frame buffer, %.1f%% read the frame buffer at all",
             p.cel_useav * 100.0 / c, p.cel_blackfix * 100.0 / c, p.cel_twopixc * 100.0 / c, p.cel_s1 * 100.0 / c,
             p.cel_fbread * 100.0 / c);
        LOGI("perf: cels: stored packed/LR/literal %.0f/%.0f/%.0f%% | drawn by line/scaled/arbitrary %.0f/%.0f/%.0f%%",
             p.cel_type[0] * 100.0 / c, p.cel_type[1] * 100.0 / c, p.cel_type[2] * 100.0 / c,
             p.cel_draw[0] * 100.0 / c, p.cel_draw[1] * 100.0 / c, p.cel_draw[2] * 100.0 / c);
        LOGI("perf: cels: colour2 source %.0f/%.0f/%.0f/%.0f%% | colour1 scaling %.0f/%.0f/%.0f/%.0f%% | "
             "bpp %.0f/%.0f/%.0f/%.0f/%.0f/%.0f/%.0f/%.0f%% | %.1f texels per pixel drawn",
             p.cel_s2[0] * 100.0 / c, p.cel_s2[1] * 100.0 / c, p.cel_s2[2] * 100.0 / c, p.cel_s2[3] * 100.0 / c,
             p.cel_ms[0] * 100.0 / c, p.cel_ms[1] * 100.0 / c, p.cel_ms[2] * 100.0 / c, p.cel_ms[3] * 100.0 / c,
             p.cel_bpp[0] * 100.0 / c, p.cel_bpp[1] * 100.0 / c, p.cel_bpp[2] * 100.0 / c, p.cel_bpp[3] * 100.0 / c,
             p.cel_bpp[4] * 100.0 / c, p.cel_bpp[5] * 100.0 / c, p.cel_bpp[6] * 100.0 / c, p.cel_bpp[7] * 100.0 / c,
             p.cel_pixels > 0 ? (double)p.cel_texels / (double)p.cel_pixels : 0.0);
    }

    /* Last, after every log line of this window: handing the report over wakes the thread that also sends the log
       to the card, and a line written while it does would wait for the card with it. */
    {
        uint32_t total = 0, longest = 0;

        log_cost_take(&total, &longest);
        T.log_ms = (double)total / 1000.0;
        T.log_max_ms = (double)longest / 1000.0;
    }
    write_perf_file(now_us, &p, n);

    cur = __atomic_load_n(&g_hud_idx, __ATOMIC_ACQUIRE) & 1u;
    hud = g_hud[cur ^ 1u];
    snprintf(hud, sizeof(g_hud[0]), "run %.1f ms | ARM %d%% CEL %d%% DSP %d%% VDL %d%% TMR %d%% | game %.0f/s", run, PCT(arm),
             PCT(cel), PCT(dsp), PCT(vdl), PCT(timers), T.game_pps);
    __atomic_store_n(&g_hud_idx, (cur ^ 1u) | 0x100u, __ATOMIC_RELEASE);
#undef PCT
    window_start(now_us);
}

void perf_frame(uint32_t run_ticks, uint32_t wait_ticks)
{
    uint64_t now;

    if (!opera_prof_enabled)
        return;
    now = platform_time_us();
    if (!W.open) {
        window_start(now);
        return;
    }
    W.run += run_ticks;
    W.wait += wait_ticks;
    W.frames++;
    if (now - W.t0_us >= PERF_WINDOW_US)
        report(now);
}

bool perf_hud_text(char *out, size_t cap)
{
    uint32_t v = __atomic_load_n(&g_hud_idx, __ATOMIC_ACQUIRE);

    if (!(v & 0x100u) || !cap)
        return false;
    str_copy(out, g_hud[v & 1u], cap);
    return true;
}
