/*
 * Core self test shared by three places:
 *   - the host self tests (selftest.c),
 *   - the PowerPC simulation harness (tools/ppcsim, run under qemu-ppc),
 *   - the "core diagnostic" entry of the Wii U app.
 * The hashes only look at pixel / sample VALUES (never at byte order), so the
 * x86 result is directly comparable with the big-endian PowerPC result.
 */
#ifndef OPERAU_CORETEST_H
#define OPERAU_CORETEST_H

#include "common.h"

/* Reference for 240 frames of the built-in BIOS without a disc, measured on
 * x86-64 (see tools/ppcsim/README.md). Zero while unknown. */
#define CORETEST_REF_FRAMES      240
#define CORETEST_REF_VIDEO_HASH  0x6a489c8ca0aca201ull
#define CORETEST_REF_AUDIO_HASH  0xbc2453c55209701dull

typedef struct {
    bool loaded;              /* core_load succeeded */
    bool cancelled;           /* coretest_cancel() stopped the run */
    int frames;               /* frames behind the boot hashes */
    uint64_t video_hash;      /* first `frames` frames */
    uint64_t audio_hash;
    uint64_t nonzero_pixels;
    unsigned width, height;
    unsigned audio_frames;    /* stereo frames produced in those `frames` */
    size_t state_size;
    bool state_ok;            /* serialise + unserialise both succeeded */
    bool deterministic;       /* 60 frames replayed after a state load are identical */
    uint64_t replay_video_hash, replay_audio_hash;
    double ms_per_frame;      /* pure emulation speed (no hashing) */
    double sample_rate, fps;
    char error[160];
} coretest_result_t;

/* Requires core_init() and no game loaded. `image` NULL = built-in BIOS only.
 * The core's normal audio/video sinks are restored before returning.
 * Returns false when the core would not start or the run was cancelled. */
bool coretest_run(const char *image, int frames, coretest_result_t *out);

/* For a run that executes on another thread: frames done / frames in total
 * (total is 0 before the first run starts), and a request to stop early. */
void coretest_progress(int *done, int *total);
void coretest_cancel(void);

/* True when the boot hashes equal the x86 reference (frames must equal
 * CORETEST_REF_FRAMES and image must be NULL). */
bool coretest_matches_reference(const coretest_result_t *r);

/* Debug aid: boots `image`, runs `frames` and writes the last video frame
 * (native byte order, rows tightly packed) to `path`, plus "<path>.txt" with
 * "width height bytes_per_pixel". Used to diff x86 against PowerPC. */
bool coretest_dump_frame(const char *image, int frames, const char *path);

/* Debug aid: boots `image`, runs `frames` and writes one text line per frame to
 * `path`: value-based hashes of that frame's video, audio, the whole DRAM and
 * the whole VRAM. Diffing the file written on x86 against the one written under
 * qemu-ppc pinpoints the first frame where a big-endian build goes wrong. */
bool coretest_trace(const char *image, int frames, const char *path);

/* Debug aid: boots `image`, runs `frames` and writes the emulated memory as
 * "<path>.dram" and "<path>.vram": every 32-bit word serialised little-endian,
 * so files from x86 and from PowerPC can be compared word by word. */
bool coretest_dump_mem(const char *image, int frames, const char *path);

#ifdef OPERA_ARM_TRACE
/* Debug aid (needs a core built with -DOPERA_ARM_TRACE): boots `image` and
 * logs one line per executed ARM instruction between frame `from` (inclusive)
 * and frame `to` (exclusive): pc, opcode, cpsr and a hash of r0-r14. */
bool coretest_armtrace(const char *image, int from, int to, const char *path);
#endif

#endif
