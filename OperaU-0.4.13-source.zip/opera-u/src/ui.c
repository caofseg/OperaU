#include "ui.h"
#include "config.h"
#include "core.h"
#include "i18n.h"
#include "input.h"
#include "log.h"
#include "platform.h"
#include "ui_gfx.h"
#include "video.h"

#include <ctype.h>
#include <math.h>
#include <stdarg.h>

/* ------------------------------------------------------------------ layout */

#define LIST_X 140
#define LIST_W 1000
#define LIST_Y 124
#define ROW_H 54
#define HDR_H 46
#define FOOT_Y 668
#define MAX_STACK 8
#define MAX_ACTIONS 8
#define BR_UP (-1)

/* ------------------------------------------------------------- menu widget */

typedef enum { MI_ACTION, MI_CHOICE, MI_HEADER, MI_DIR, MI_DISC, MI_INFO } mi_kind_t;

typedef struct {
    char label[200];
    char value[120];
    int id;
    uint8_t kind;
    bool disabled;
    bool hilite;
} mitem_t;

typedef struct {
    mitem_t *it;
    int n, cap;
    int sel;
    float scroll, scroll_to;
} menu_t;

static void menu_reset(menu_t *m)
{
    m->n = 0;
}

static void menu_free(menu_t *m)
{
    free(m->it);
    memset(m, 0, sizeof(*m));
}

static mitem_t *menu_add(menu_t *m, int kind, int id, const char *label, const char *value)
{
    mitem_t *it;
    if (m->n == m->cap) {
        int nc = m->cap ? m->cap * 2 : 32;
        mitem_t *n = (mitem_t *)realloc(m->it, (size_t)nc * sizeof(mitem_t));
        if (!n)
            return NULL;
        m->it = n;
        m->cap = nc;
    }
    it = &m->it[m->n++];
    memset(it, 0, sizeof(*it));
    it->kind = (uint8_t)kind;
    it->id = id;
    str_copy(it->label, label ? label : "", sizeof(it->label));
    str_copy(it->value, value ? value : "", sizeof(it->value));
    return it;
}

static bool selectable(const mitem_t *it)
{
    return it->kind != MI_HEADER && it->kind != MI_INFO;
}

static float item_h(const menu_t *m, int i)
{
    return m->it[i].kind == MI_HEADER ? HDR_H : ROW_H;
}

static float item_y(const menu_t *m, int i)
{
    float y = 0;
    for (int k = 0; k < i; k++)
        y += item_h(m, k);
    return y;
}

static float menu_total(const menu_t *m)
{
    return item_y(m, m->n);
}

static void menu_fix_sel(menu_t *m)
{
    if (m->n == 0) {
        m->sel = 0;
        return;
    }
    m->sel = CLAMP(m->sel, 0, m->n - 1);
    if (!selectable(&m->it[m->sel])) {
        for (int i = 0; i < m->n; i++) {
            int k = (m->sel + i) % m->n;
            if (selectable(&m->it[k])) {
                m->sel = k;
                return;
            }
        }
    }
}

static void menu_move(menu_t *m, int dir)
{
    if (m->n == 0)
        return;
    for (int i = 0; i < m->n; i++) {
        m->sel = (m->sel + dir + m->n) % m->n;
        if (selectable(&m->it[m->sel]))
            return;
    }
}

static void menu_page(menu_t *m, int dir, float view_h)
{
    int rows = MAX(1, (int)(view_h / ROW_H) - 1);
    int target;
    if (m->n == 0)
        return;
    target = CLAMP(m->sel + dir * rows, 0, m->n - 1);
    /* settle on a selectable row, searching away from the jump direction */
    while (target > 0 && target < m->n - 1 && !selectable(&m->it[target]))
        target -= dir;
    m->sel = target;
    menu_fix_sel(m);
}

static void menu_ensure_visible(menu_t *m, float view_h)
{
    float total = menu_total(m), y, h;
    if (m->n == 0) {
        m->scroll_to = 0;
        return;
    }
    y = item_y(m, m->sel);
    h = item_h(m, m->sel);
    /* keep a header in view when the first row after it is selected */
    if (m->sel > 0 && m->it[m->sel - 1].kind == MI_HEADER) {
        y -= HDR_H;
        h += HDR_H;
    }
    if (y < m->scroll_to)
        m->scroll_to = y;
    else if (y + h > m->scroll_to + view_h)
        m->scroll_to = y + h - view_h;
    m->scroll_to = CLAMP(m->scroll_to, 0.0f, MAX(0.0f, total - view_h));
}

static void menu_anim(menu_t *m, float dt)
{
    float k = MIN(1.0f, dt * 16.0f);
    m->scroll += (m->scroll_to - m->scroll) * k;
    if (fabsf(m->scroll_to - m->scroll) < 0.4f)
        m->scroll = m->scroll_to;
}

static int menu_hit(const menu_t *m, float x, float y, float w, float h, float px, float py, bool *right)
{
    float rel;
    if (px < x || px >= x + w || py < y || py >= y + h)
        return -1;
    rel = py - y + m->scroll;
    for (int i = 0, yy = 0; i < m->n; i++) {
        float hh = item_h(m, i);
        if (rel >= (float)yy && rel < (float)yy + hh) {
            if (right)
                *right = px > x + w * 0.62f;
            return selectable(&m->it[i]) ? i : -1;
        }
        yy += (int)hh;
    }
    return -1;
}

static void menu_draw(const menu_t *m, float x, float y, float w, float h, bool focused)
{
    float total = menu_total(m);

    gfx_clip(x - 4, y, w + 8, h);
    for (int i = 0; i < m->n; i++) {
        const mitem_t *it = &m->it[i];
        float iy = item_y(m, i) - m->scroll + y;
        float ih = item_h(m, i);
        bool sel = focused && i == m->sel;
        float pad = 24, vw;
        uint32_t tc;

        if (iy + ih < y || iy > y + h)
            continue;

        if (it->kind == MI_HEADER) {
            gfx_text(it->label, x + 8, iy + 14, FS_SMALL, COL_ACCENT, TXT_LEFT, w - 16);
            gfx_fill(x + 8 + gfx_text_width(it->label, FS_SMALL) + 14, iy + 26, w - 40 - gfx_text_width(it->label, FS_SMALL), 1,
                     RGBA(0x7f, 0x9c, 0xff, 70));
            continue;
        }
        if (it->kind == MI_INFO) {
            gfx_text(it->label, x + pad, iy + 14, FS_NORMAL, COL_TEXT_DIM, TXT_LEFT, w - 2 * pad);
            continue;
        }

        gfx_round_fill(x, iy + 3, w, ih - 6, 12, sel ? COL_ROW_SEL : COL_ROW);
        if (sel)
            gfx_round_fill(x + 6, iy + 14, 4, ih - 28, 2, COL_ACCENT2);

        if (it->kind == MI_DIR) {
            gfx_folder(x + 22, iy + 13, 32, sel ? COL_TEXT : COL_ACCENT);
            pad = 72;
        } else if (it->kind == MI_DISC) {
            gfx_disc(x + 38, iy + ih / 2, 30, 255);
            pad = 72;
        }

        tc = it->disabled ? COL_TEXT_OFF : (sel ? COL_TEXT : RGBA(0xdc, 0xe3, 0xff, 255));
        vw = it->value[0] ? gfx_text_width(it->value, FS_NORMAL) : 0;
        if (it->kind == MI_CHOICE)
            vw += 64;
        gfx_text(it->label, x + pad, iy + (ih - gfx_line_height(FS_NORMAL)) / 2, FS_NORMAL, tc, TXT_LEFT,
                 w - pad - vw - 36);
        if (it->value[0]) {
            uint32_t vc = it->hilite ? COL_ACCENT2 : (sel ? COL_TEXT : COL_TEXT_DIM);
            if (it->kind == MI_CHOICE) {
                float vx = x + w - 52;
                float tw = gfx_text_width(it->value, FS_NORMAL);
                uint32_t ac = sel ? COL_ACCENT2 : COL_TEXT_OFF;
                gfx_triangle(vx + 30, iy + ih / 2, 14, DIR_RIGHT, ac);
                gfx_text(it->value, vx - 8, iy + (ih - gfx_line_height(FS_NORMAL)) / 2, FS_NORMAL, vc, TXT_RIGHT, w * 0.5f);
                gfx_triangle(vx - 8 - tw - 24 + (tw > w * 0.5f ? tw - w * 0.5f : 0), iy + ih / 2, 14, DIR_LEFT, ac);
            } else {
                gfx_text(it->value, x + w - 24, iy + (ih - gfx_line_height(FS_NORMAL)) / 2, FS_NORMAL, vc, TXT_RIGHT, w * 0.4f);
            }
        }
    }
    gfx_clip_off();

    if (total > h) { /* scrollbar */
        float bh = MAX(36.0f, h * h / total);
        float by = y + (h - bh) * (m->scroll / MAX(1.0f, total - h));
        gfx_round_fill(x + w + 10, y, 5, h, 2.5f, RGBA(255, 255, 255, 22));
        gfx_round_fill(x + w + 10, by, 5, bh, 2.5f, RGBA(0x7f, 0x9c, 0xff, 170));
    }
}

/* ------------------------------------------------------------------ state */

typedef enum {
    SCR_HOME,
    SCR_BROWSER,
    SCR_RECENT,
    SCR_PAUSE,
    SCR_SETTINGS,
    SCR_COREOPT_GLOBAL,
    SCR_COREOPT_GAME,
    SCR_CONTROLS,
    SCR_ABOUT,
} scr_id_t;

typedef struct {
    scr_id_t id;
    menu_t menu;
} scr_t;

enum { /* item ids */
    H_CONTINUE = 1, H_OPEN, H_RECENT, H_BIOS, H_SETTINGS, H_HELP, H_QUIT,
    P_RESUME = 20, P_SAVE, P_LOAD, P_SLOT, P_RESET, P_SHOT, P_GAMEOPTS, P_SETTINGS, P_CLOSE,
    ST_ASPECT = 40, ST_FILTER, ST_VSYNC, ST_FPS, ST_VOLUME, ST_LATENCY, ST_EMUCORE,
    ST_DEADZONE, ST_MENULR, ST_CONTROLS, ST_COREOPTS, ST_LANG, ST_AUTOSAVE, ST_UDPLOG, ST_DEFAULTS, ST_DIAG,
    ST_COLORORDER, ST_TESTPAT, ST_PERFLOG,
    CT_PAD_BASE = 100, CT_MAP_BASE = 200, CT_DEFAULTS = 300,
};

static const ui_hooks_t *g_hooks;
static scr_t g_stack[MAX_STACK];
static int g_depth;
static ui_mode_t g_mode = UI_HOME;
static char g_game_title[128];

static ui_action_t g_actions[MAX_ACTIONS];
static int g_act_head, g_act_tail;

static uint64_t g_last_us;
static float g_anim_t;

/* toast / message / capture overlays */
static char g_toast[200];
static uint64_t g_toast_until, g_toast_from;
static struct {
    bool active, err;
    char title[96];
    char text[1024];
} g_msg;
static int g_cap_btn = -1;
static uint64_t g_cap_deadline;

/* browser */
static struct {
    char cwd[1024];
    dir_entry_t *ents;
    int nents;
    storage_root_t roots[4];
    int nroots;
    bool can_up;
    bool read_error;
} g_br;

/* pointer interaction */
static struct {
    bool tracking, dragging;
    float x0, y0;
} g_pt;

static scr_t *cur(void) { return &g_stack[g_depth - 1]; }

static void shorten_path_left(const char *path, char *out, size_t cap, float max_w, int size);

static void push_action(ui_action_type_t t, const char *path)
{
    int next = (g_act_head + 1) % MAX_ACTIONS;
    if (next == g_act_tail)
        return;
    g_actions[g_act_head].type = t;
    str_copy(g_actions[g_act_head].path, path ? path : "", sizeof(g_actions[0].path));
    g_act_head = next;
}

bool ui_next_action(ui_action_t *out)
{
    if (g_act_tail == g_act_head)
        return false;
    *out = g_actions[g_act_tail];
    g_act_tail = (g_act_tail + 1) % MAX_ACTIONS;
    return true;
}

/* ----------------------------------------------------------------- helpers */

static void fmt_size(int64_t b, char *out, size_t cap)
{
    if (b < 0)
        snprintf(out, cap, "?");
    else if (b < 1024)
        snprintf(out, cap, "%d B", (int)b);
    else if (b < 1024 * 1024)
        snprintf(out, cap, "%.1f KB", (double)b / 1024.0);
    else if (b < 1024LL * 1024 * 1024)
        snprintf(out, cap, "%.1f MB", (double)b / (1024.0 * 1024.0));
    else
        snprintf(out, cap, "%.2f GB", (double)b / (1024.0 * 1024.0 * 1024.0));
}

static bool is_disc_ext(const char *name)
{
    char ext[8];
    path_ext(ext, sizeof(ext), name);
    return !strcmp(ext, "chd") || !strcmp(ext, "iso") || !strcmp(ext, "cue") || !strcmp(ext, "bin");
}

static const char *yes_no(bool v) { return v ? tr(S_ON) : tr(S_OFF); }

/* ----------------------------------------------------------- file browser */

static int cmp_entries(const void *a, const void *b)
{
    const dir_entry_t *x = (const dir_entry_t *)a, *y = (const dir_entry_t *)b;
    const char *p = x->name, *q = y->name;
    if (x->is_dir != y->is_dir)
        return x->is_dir ? -1 : 1;
    for (; *p && *q; p++, q++) {
        int d = tolower((unsigned char)*p) - tolower((unsigned char)*q);
        if (d)
            return d;
    }
    return tolower((unsigned char)*p) - tolower((unsigned char)*q);
}

static bool path_is_root(const char *path)
{
    char t[1024];
    size_t l;
    str_copy(t, path, sizeof(t));
    l = strlen(t);
    while (l > 1 && t[l - 1] == '/')
        t[--l] = '\0';
    for (int i = 0; i < g_br.nroots; i++) {
        char r[96];
        size_t rl;
        str_copy(r, g_br.roots[i].path, sizeof(r));
        rl = strlen(r);
        while (rl > 1 && r[rl - 1] == '/')
            r[--rl] = '\0';
        if (!strcmp(t, r))
            return true;
    }
    return !strcmp(t, "/");
}

static bool path_under_a_root(const char *path)
{
    for (int i = 0; i < g_br.nroots; i++) {
        size_t rl = strlen(g_br.roots[i].path);
        if (!strncmp(path, g_br.roots[i].path, rl) && (path[rl] == '\0' || path[rl] == '/' || g_br.roots[i].path[rl - 1] == '/'))
            return true;
    }
    return false;
}

static void browser_free(void)
{
    free(g_br.ents);
    g_br.ents = NULL;
    g_br.nents = 0;
}

static void browser_load(const char *path, const char *select_name)
{
    dir_entry_t *raw;
    int n = 0, keep = 0;
    menu_t *m = &cur()->menu;

    g_br.nroots = platform_storage_roots(g_br.roots, 4);
    browser_free();
    str_copy(g_br.cwd, path, sizeof(g_br.cwd));
    {
        size_t l = strlen(g_br.cwd);
        while (l > 1 && g_br.cwd[l - 1] == '/')
            g_br.cwd[--l] = '\0';
    }
    raw = platform_list_dir(g_br.cwd, &n);
    g_br.read_error = (raw == NULL && !platform_is_dir(g_br.cwd));
    g_br.can_up = !path_is_root(g_br.cwd);

    for (int i = 0; i < n; i++) {
        bool ok = false;
        if (raw[i].name[0] == '.')
            continue;
        if (raw[i].is_dir) {
            ok = true;
        } else if (is_disc_ext(raw[i].name)) {
            char ext[8];
            path_ext(ext, sizeof(ext), raw[i].name);
            ok = true;
            if (!strcmp(ext, "bin")) { /* a .cue with the same name is the entry point */
                char stem[256];
                path_stem(stem, sizeof(stem), raw[i].name);
                for (int k = 0; k < n; k++) {
                    char s2[256], e2[8];
                    if (raw[k].is_dir)
                        continue;
                    path_ext(e2, sizeof(e2), raw[k].name);
                    if (strcmp(e2, "cue"))
                        continue;
                    path_stem(s2, sizeof(s2), raw[k].name);
                    if (str_ieq(stem, s2)) {
                        ok = false;
                        break;
                    }
                }
            }
        }
        if (ok)
            raw[keep++] = raw[i];
    }
    n = keep;
    if (n > 1)
        qsort(raw, (size_t)n, sizeof(*raw), cmp_entries);
    g_br.ents = raw;
    g_br.nents = n;

    /* menu */
    menu_reset(m);
    if (g_br.can_up)
        menu_add(m, MI_DIR, BR_UP, tr(S_BR_UP), "");
    m->sel = 0;
    for (int i = 0; i < n; i++) {
        char sz[32] = "";
        if (!raw[i].is_dir)
            fmt_size(raw[i].size, sz, sizeof(sz));
        menu_add(m, raw[i].is_dir ? MI_DIR : MI_DISC, i, raw[i].name, sz);
        if (select_name && !strcmp(raw[i].name, select_name))
            m->sel = m->n - 1;
    }
    if (!select_name && g_br.can_up && n > 0)
        m->sel = 1; /* first real entry rather than ".." */
    menu_fix_sel(m);
    m->scroll = m->scroll_to = 0;
    menu_ensure_visible(m, 504);
    m->scroll = m->scroll_to;
    str_copy(g_cfg.browse_dir, g_br.cwd, sizeof(g_cfg.browse_dir));
}

static void browser_up(void)
{
    char parent[1024], leaf[256];
    str_copy(leaf, path_base(g_br.cwd), sizeof(leaf));
    path_dir(parent, sizeof(parent), g_br.cwd);
    if (!path_under_a_root(parent))
        return;
    browser_load(parent, leaf);
}

static void browser_enter_root(int idx)
{
    if (idx < 0 || idx >= g_br.nroots)
        return;
    browser_load(g_br.roots[idx].path, NULL);
}

static int browser_current_root(void)
{
    int best = 0;
    size_t best_len = 0;
    for (int i = 0; i < g_br.nroots; i++) {
        size_t rl = strlen(g_br.roots[i].path);
        if (!strncmp(g_br.cwd, g_br.roots[i].path, rl) && rl >= best_len) {
            best = i;
            best_len = rl;
        }
    }
    return best;
}

static void browser_open_dir_default(void)
{
    char start[1024];
    g_br.nroots = platform_storage_roots(g_br.roots, 4);
    str_copy(start, g_cfg.browse_dir[0] ? g_cfg.browse_dir : platform_default_browse_dir(), sizeof(start));
    if (!platform_is_dir(start) || !path_under_a_root(start))
        str_copy(start, platform_default_browse_dir(), sizeof(start));
    if (!platform_is_dir(start))
        str_copy(start, g_br.roots[0].path, sizeof(start));
    browser_load(start, NULL);
}

static void browser_goto_roms(void)
{
    char roms[1100];
    path_join(roms, sizeof(roms), platform_data_dir(), "roms");
    platform_mkdirs(roms);
    if (platform_is_dir(roms))
        browser_load(roms, NULL);
}

/* ------------------------------------------------------------------ screens */

static const char *const k_cat_order[] = {"system", "video", "audio", "input", "advanced", ""};

static const char *cat_title(const char *key)
{
    if (!strcmp(key, "system")) return tr(S_CAT_SYSTEM);
    if (!strcmp(key, "video")) return tr(S_CAT_VIDEO);
    if (!strcmp(key, "audio")) return tr(S_CAT_AUDIO);
    if (!strcmp(key, "input")) return tr(S_CAT_INPUT);
    if (!strcmp(key, "advanced")) return tr(S_CAT_ADV);
    return tr(S_CAT_OTHER);
}

static const kvmap_t *coreopt_scope(const scr_t *s)
{
    return s->id == SCR_COREOPT_GAME ? &g_core_opts_game : &g_core_opts_global;
}

static const char *opt_value_text(const core_opt_t *o, char *buf, size_t cap)
{
    int idx = core_opt_effective_index(o);
    const char *v = core_opt_effective(o->key);
    if (idx >= 0)
        return o->vals[idx].label;
    snprintf(buf, cap, "%s", v ? v : "-");
    return buf;
}

static const char *emucore_text(int v, char *buf, size_t cap)
{
    if (v < 0)
        return tr(S_CORE_AUTO);
    snprintf(buf, cap, "CPU %d", v);
    return buf;
}

static const char *aspect_text(int a)
{
    return a == ASPECT_STRETCH ? tr(S_ASPECT_STRETCH) : (a == ASPECT_INTEGER ? tr(S_ASPECT_INT) : tr(S_ASPECT_43));
}

static void rebuild(scr_t *s)
{
    menu_t *m = &s->menu;
    char a[200], b[200];

    menu_reset(m);
    switch (s->id) {
    case SCR_HOME: {
        bool have_recent = g_cfg.recent_count > 0;
        if (have_recent) {
            char stem[200];
            path_stem(stem, sizeof(stem), g_cfg.recent[0]);
            snprintf(a, sizeof(a), tr(S_HOME_CONTINUE), stem);
            menu_add(m, MI_ACTION, H_CONTINUE, a,
                     (g_hooks && g_hooks->game_resumable && g_hooks->game_resumable(g_cfg.recent[0])) ? tr(S_RESUME_STATE) : "")
                ->hilite = true;
        }
        menu_add(m, MI_ACTION, H_OPEN, tr(S_HOME_OPEN), "");
        menu_add(m, MI_ACTION, H_RECENT, tr(S_HOME_RECENT), have_recent ? "" : "-")->disabled = !have_recent;
        menu_add(m, MI_ACTION, H_BIOS, tr(S_HOME_BIOS), "");
        menu_add(m, MI_ACTION, H_SETTINGS, tr(S_HOME_SETTINGS), "");
        menu_add(m, MI_ACTION, H_HELP, tr(S_HOME_HELP), "");
        menu_add(m, MI_ACTION, H_QUIT, tr(S_HOME_QUIT), "");
        break;
    }
    case SCR_BROWSER: {
        /* rebuilt by browser_load(); language changes simply reload */
        char keep[256];
        int sel = m->sel;
        keep[0] = '\0';
        if (sel >= 0 && sel < m->n && m->it[sel].id >= 0 && m->it[sel].id < g_br.nents)
            str_copy(keep, g_br.ents[m->it[sel].id].name, sizeof(keep));
        browser_load(g_br.cwd[0] ? g_br.cwd : platform_default_browse_dir(), keep[0] ? keep : NULL);
        break;
    }
    case SCR_RECENT:
        for (int i = 0; i < g_cfg.recent_count; i++) {
            char stem[200], dir[1024];
            bool res = g_hooks && g_hooks->game_resumable && g_hooks->game_resumable(g_cfg.recent[i]);
            mitem_t *ri;
            path_stem(stem, sizeof(stem), g_cfg.recent[i]);
            path_dir(dir, sizeof(dir), g_cfg.recent[i]);
            ri = menu_add(m, MI_DISC, i, stem, res ? tr(S_RESUME_STATE) : path_base(dir));
            if (ri)
                ri->hilite = res;
        }
        if (g_cfg.recent_count == 0)
            menu_add(m, MI_INFO, 0, tr(S_RECENT_EMPTY), "");
        break;
    case SCR_PAUSE: {
        bool used = g_hooks && g_hooks->state_exists && g_hooks->state_exists(g_cfg.state_slot);
        menu_add(m, MI_ACTION, P_RESUME, tr(S_P_RESUME), "");
        snprintf(a, sizeof(a), "%s", tr(S_P_SAVE));
        menu_add(m, MI_ACTION, P_SAVE, a, "");
        menu_add(m, MI_ACTION, P_LOAD, tr(S_P_LOAD), "")->disabled = !used;
        snprintf(b, sizeof(b), "%d · %s", g_cfg.state_slot, used ? tr(S_SLOT_USED) : tr(S_SLOT_EMPTY));
        menu_add(m, MI_CHOICE, P_SLOT, tr(S_P_SLOT), b);
        menu_add(m, MI_ACTION, P_RESET, tr(S_P_RESET), "");
        menu_add(m, MI_ACTION, P_SHOT, tr(S_P_SHOT), "");
        menu_add(m, MI_ACTION, P_GAMEOPTS, tr(S_P_GAMEOPTS), "");
        menu_add(m, MI_ACTION, P_SETTINGS, tr(S_P_SETTINGS), "");
        menu_add(m, MI_ACTION, P_CLOSE, tr(S_P_CLOSE), "");
        break;
    }
    case SCR_SETTINGS:
        menu_add(m, MI_HEADER, 0, tr(S_SET_VIDEO), "");
        menu_add(m, MI_CHOICE, ST_ASPECT, tr(S_SET_ASPECT), aspect_text(g_cfg.aspect));
        menu_add(m, MI_CHOICE, ST_FILTER, tr(S_SET_FILTER), g_cfg.filter == FILTER_NEAREST ? tr(S_FILTER_SHARP) : tr(S_FILTER_SMOOTH));
        menu_add(m, MI_CHOICE, ST_VSYNC, tr(S_SET_VSYNC), yes_no(g_cfg.vsync));
        menu_add(m, MI_CHOICE, ST_FPS, tr(S_SET_FPS), yes_no(g_cfg.show_fps));
        snprintf(a, sizeof(a), "%s%s", video_color_order_name(g_cfg.color_order), g_cfg.color_order ? "" : tr(S_COLOR_NORMAL));
        menu_add(m, MI_CHOICE, ST_COLORORDER, tr(S_SET_COLORORDER), a);
        /* the picture test borrows the game texture, so only when no game is loaded */
        menu_add(m, MI_ACTION, ST_TESTPAT, tr(S_SET_TESTPAT), g_mode == UI_HOME ? "" : tr(S_DIAG_CLOSE_FIRST))
            ->disabled = g_mode != UI_HOME;
        menu_add(m, MI_HEADER, 0, tr(S_SET_AUDIO), "");
        snprintf(a, sizeof(a), "%d%%", g_cfg.volume);
        menu_add(m, MI_CHOICE, ST_VOLUME, tr(S_SET_VOLUME), a);
        snprintf(a, sizeof(a), "%d ms", g_cfg.latency_ms);
        menu_add(m, MI_CHOICE, ST_LATENCY, tr(S_SET_LATENCY), a);
        menu_add(m, MI_HEADER, 0, tr(S_SET_PERF), "");
        menu_add(m, MI_CHOICE, ST_EMUCORE, tr(S_SET_EMUCORE), emucore_text(g_cfg.emu_core, a, sizeof(a)));
        menu_add(m, MI_CHOICE, ST_PERFLOG, tr(S_SET_PERFLOG), yes_no(g_cfg.perf_log));
        menu_add(m, MI_HEADER, 0, tr(S_SET_INPUT), "");
        snprintf(a, sizeof(a), "%d%%", g_cfg.deadzone);
        menu_add(m, MI_CHOICE, ST_DEADZONE, tr(S_SET_DEADZONE), a);
        menu_add(m, MI_CHOICE, ST_MENULR, tr(S_SET_MENULR), yes_no(g_cfg.menu_lr));
        menu_add(m, MI_ACTION, ST_CONTROLS, tr(S_SET_CONTROLS), "");
        menu_add(m, MI_HEADER, 0, tr(S_SET_SYSTEM), "");
        menu_add(m, MI_ACTION, ST_COREOPTS, tr(S_SET_COREOPTS), "");
        /* the self test needs the core unloaded, so only from the home screen */
        menu_add(m, MI_ACTION, ST_DIAG, tr(S_SET_DIAG), g_mode == UI_HOME ? "" : tr(S_DIAG_CLOSE_FIRST))
            ->disabled = g_mode != UI_HOME;
        menu_add(m, MI_CHOICE, ST_LANG, tr(S_SET_LANG), tr(S_LANG_NAME));
        menu_add(m, MI_CHOICE, ST_AUTOSAVE, tr(S_SET_AUTOSAVE), yes_no(g_cfg.autosave_state));
        menu_add(m, MI_CHOICE, ST_UDPLOG, tr(S_SET_UDPLOG), yes_no(g_cfg.udp_log));
        menu_add(m, MI_ACTION, ST_DEFAULTS, tr(S_SET_DEFAULTS), "");
        break;
    case SCR_COREOPT_GLOBAL:
    case SCR_COREOPT_GAME: {
        const kvmap_t *scope = coreopt_scope(s);
        for (size_t c = 0; c < ARRAY_LEN(k_cat_order); c++) {
            bool header_done = false;
            for (int i = 0; i < core_opt_count(); i++) {
                const core_opt_t *o = core_opt_at(i);
                char tmp[96];
                mitem_t *it;
                bool known = false;
                if (c + 1 == ARRAY_LEN(k_cat_order)) { /* "other": anything with an unlisted category */
                    for (size_t k = 0; k + 1 < ARRAY_LEN(k_cat_order); k++)
                        if (!strcmp(o->category, k_cat_order[k]))
                            known = true;
                    if (known)
                        continue;
                } else if (strcmp(o->category, k_cat_order[c])) {
                    continue;
                }
                if (!header_done) {
                    menu_add(m, MI_HEADER, 0, cat_title(k_cat_order[c]), "");
                    header_done = true;
                }
                it = menu_add(m, MI_CHOICE, i, o->desc, opt_value_text(o, tmp, sizeof(tmp)));
                if (it && kv_get(scope, o->key))
                    it->hilite = true;
            }
        }
        break;
    }
    case SCR_CONTROLS: {
        int np = input_pad_count();
        menu_add(m, MI_HEADER, 0, tr(S_CTL_PADS), "");
        for (int i = 0; i < np; i++) {
            const pad_info_t *pi = input_pad_info(i);
            snprintf(a, sizeof(a), tr(S_CTL_PLAYER), pi->port + 1);
            menu_add(m, MI_ACTION, CT_PAD_BASE + i, a, pi->name);
        }
        if (np == 0)
            menu_add(m, MI_INFO, 0, tr(S_CTL_NONE), "");
        menu_add(m, MI_HEADER, 0, tr(S_CTL_MAP), "");
        for (int bt = 0; bt < B3DO_COUNT; bt++) {
            snprintf(a, sizeof(a), "3DO  %s", input_3do_name(bt));
            menu_add(m, MI_ACTION, CT_MAP_BASE + bt, a, input_button_name(g_cfg.button_map[bt]));
        }
        menu_add(m, MI_ACTION, CT_DEFAULTS, tr(S_CTL_DEFAULTS), "");
        break;
    }
    case SCR_ABOUT:
        break;
    }
    menu_fix_sel(m);
}

static void rebuild_all(void)
{
    for (int i = 0; i < g_depth; i++) {
        float sc = g_stack[i].menu.scroll, st = g_stack[i].menu.scroll_to;
        rebuild(&g_stack[i]);
        g_stack[i].menu.scroll = sc;
        g_stack[i].menu.scroll_to = st;
    }
}

static void scr_push(scr_id_t id)
{
    scr_t *s;
    if (g_depth >= MAX_STACK)
        return;
    s = &g_stack[g_depth++];
    memset(s, 0, sizeof(*s));
    s->id = id;
    if (id == SCR_BROWSER) {
        browser_open_dir_default();
        return;
    }
    if (id == SCR_COREOPT_GLOBAL || id == SCR_COREOPT_GAME)
        core_opts_rescan();
    rebuild(s);
}

static void scr_pop(void)
{
    scr_t *s;
    if (g_depth <= 1)
        return;
    s = cur();
    switch (s->id) {
    case SCR_SETTINGS:
    case SCR_CONTROLS:
        config_save();
        push_action(UIA_SETTINGS_CHANGED, "");
        break;
    case SCR_COREOPT_GLOBAL:
        config_save();
        core_opts_changed();
        break;
    case SCR_COREOPT_GAME:
        config_game_save();
        core_opts_changed();
        break;
    case SCR_BROWSER:
        config_save();
        browser_free();
        break;
    default:
        break;
    }
    menu_free(&s->menu);
    g_depth--;
    if (g_depth > 0) /* parents may show values the child just changed */
        rebuild(cur());
}

static void go_back(void)
{
    scr_t *s = cur();
    if (s->id == SCR_BROWSER && g_br.can_up) {
        browser_up();
        return;
    }
    if (g_depth > 1) {
        scr_pop();
        return;
    }
    if (s->id == SCR_PAUSE)
        push_action(UIA_RESUME, "");
}

/* --------------------------------------------------------------- adjusting */

static void settings_changed(void)
{
    push_action(UIA_SETTINGS_CHANGED, "");
}

static void adjust_setting(int id, int dir)
{
    switch (id) {
    case ST_ASPECT: g_cfg.aspect = (g_cfg.aspect + dir + ASPECT_COUNT) % ASPECT_COUNT; break;
    case ST_FILTER: g_cfg.filter = g_cfg.filter == FILTER_NEAREST ? FILTER_LINEAR : FILTER_NEAREST; break;
    case ST_VSYNC: g_cfg.vsync = !g_cfg.vsync; break;
    case ST_FPS: g_cfg.show_fps = !g_cfg.show_fps; break;
    case ST_PERFLOG: g_cfg.perf_log = !g_cfg.perf_log; break;
    case ST_COLORORDER: g_cfg.color_order = (g_cfg.color_order + dir + VIDEO_COLOR_ORDERS) % VIDEO_COLOR_ORDERS; break;
    case ST_VOLUME: g_cfg.volume = CLAMP(g_cfg.volume + dir * 5, 0, 100); break;
    case ST_LATENCY: g_cfg.latency_ms = CLAMP(g_cfg.latency_ms + dir * 10, 40, 200); break;
    case ST_EMUCORE: g_cfg.emu_core = ((g_cfg.emu_core + 1 + dir + 4) % 4) - 1; break;
    case ST_DEADZONE: g_cfg.deadzone = CLAMP(g_cfg.deadzone + dir * 2, 0, 60); break;
    case ST_MENULR: g_cfg.menu_lr = !g_cfg.menu_lr; break;
    case ST_LANG:
        g_cfg.language = (g_cfg.language + dir + LANG_COUNT) % LANG_COUNT;
        rebuild_all();
        break;
    case ST_AUTOSAVE: g_cfg.autosave_state = !g_cfg.autosave_state; break;
    case ST_UDPLOG: g_cfg.udp_log = !g_cfg.udp_log; break;
    default: return;
    }
    settings_changed();
}

static void adjust_coreopt(scr_t *s, int opt_index, int dir)
{
    const core_opt_t *o = core_opt_at(opt_index);
    kvmap_t *scope = s->id == SCR_COREOPT_GAME ? &g_core_opts_game : &g_core_opts_global;
    int idx;
    if (!o || o->nvals == 0)
        return;
    idx = core_opt_effective_index(o);
    if (idx < 0)
        idx = 0;
    idx = (idx + dir + o->nvals) % o->nvals;
    if (s->id == SCR_COREOPT_GLOBAL && !strcmp(o->vals[idx].value, o->def) && strcmp(o->key, "opera_active_devices"))
        kv_remove(scope, o->key);
    else
        kv_set(scope, o->key, o->vals[idx].value);
    core_opts_changed();
}

static void adjust_item(scr_t *s, mitem_t *it, int dir)
{
    if (!it || it->kind != MI_CHOICE || it->disabled)
        return;
    switch (s->id) {
    case SCR_PAUSE:
        if (it->id == P_SLOT)
            g_cfg.state_slot = (g_cfg.state_slot + dir + 10) % 10;
        break;
    case SCR_SETTINGS:
        adjust_setting(it->id, dir);
        break;
    case SCR_COREOPT_GLOBAL:
    case SCR_COREOPT_GAME:
        adjust_coreopt(s, it->id, dir);
        break;
    default:
        break;
    }
    rebuild(s);
}

static void reset_item_to_default(scr_t *s, mitem_t *it)
{
    if (!it)
        return;
    if (s->id == SCR_COREOPT_GLOBAL || s->id == SCR_COREOPT_GAME) {
        const core_opt_t *o = core_opt_at(it->id);
        kvmap_t *scope = s->id == SCR_COREOPT_GAME ? &g_core_opts_game : &g_core_opts_global;
        if (o) {
            kv_remove(scope, o->key);
            core_opts_changed();
            rebuild(s);
        }
    }
}

static void settings_defaults(void)
{
    settings_t d;
    config_defaults(&d);
    g_cfg.aspect = d.aspect;
    g_cfg.filter = d.filter;
    g_cfg.vsync = d.vsync;
    g_cfg.show_fps = d.show_fps;
    g_cfg.color_order = d.color_order;
    g_cfg.volume = d.volume;
    g_cfg.latency_ms = d.latency_ms;
    g_cfg.emu_core = d.emu_core;
    g_cfg.perf_log = d.perf_log;
    g_cfg.deadzone = d.deadzone;
    g_cfg.menu_lr = d.menu_lr;
    g_cfg.autosave_state = d.autosave_state;
    g_cfg.udp_log = d.udp_log;
    settings_changed();
}

/* -------------------------------------------------------------- activation */

static void activate(scr_t *s, mitem_t *it)
{
    if (!it || it->disabled)
        return;
    switch (s->id) {
    case SCR_HOME:
        switch (it->id) {
        case H_CONTINUE:
            push_action(g_hooks && g_hooks->game_resumable && g_hooks->game_resumable(g_cfg.recent[0]) ? UIA_LAUNCH_RESUME
                                                                                                    : UIA_LAUNCH,
                        g_cfg.recent[0]);
            break;
        case H_OPEN: scr_push(SCR_BROWSER); break;
        case H_RECENT: scr_push(SCR_RECENT); break;
        case H_BIOS: push_action(UIA_LAUNCH_BIOS, ""); break;
        case H_SETTINGS: scr_push(SCR_SETTINGS); break;
        case H_HELP: scr_push(SCR_ABOUT); break;
        case H_QUIT: push_action(UIA_QUIT, ""); break;
        }
        break;
    case SCR_BROWSER:
        if (it->id == BR_UP) {
            browser_up();
        } else if (it->id >= 0 && it->id < g_br.nents) {
            const dir_entry_t *e = &g_br.ents[it->id];
            char full[1100];
            path_join(full, sizeof(full), g_br.cwd, e->name);
            if (e->is_dir)
                browser_load(full, NULL);
            else
                push_action(UIA_LAUNCH, full);
        }
        break;
    case SCR_RECENT:
        if (it->kind == MI_DISC && it->id >= 0 && it->id < g_cfg.recent_count)
            push_action(g_hooks && g_hooks->game_resumable && g_hooks->game_resumable(g_cfg.recent[it->id]) ? UIA_LAUNCH_RESUME
                                                                                                           : UIA_LAUNCH,
                        g_cfg.recent[it->id]);
        break;
    case SCR_PAUSE:
        switch (it->id) {
        case P_RESUME: push_action(UIA_RESUME, ""); break;
        case P_SAVE: push_action(UIA_SAVE_STATE, ""); break;
        case P_LOAD: push_action(UIA_LOAD_STATE, ""); break;
        case P_SLOT: adjust_item(s, it, 1); break;
        case P_RESET: push_action(UIA_RESET, ""); break;
        case P_SHOT: push_action(UIA_SCREENSHOT, ""); break;
        case P_GAMEOPTS: scr_push(SCR_COREOPT_GAME); break;
        case P_SETTINGS: scr_push(SCR_SETTINGS); break;
        case P_CLOSE: push_action(UIA_CLOSE_GAME, ""); break;
        }
        break;
    case SCR_SETTINGS:
        if (it->id == ST_CONTROLS)
            scr_push(SCR_CONTROLS);
        else if (it->id == ST_COREOPTS)
            scr_push(SCR_COREOPT_GLOBAL);
        else if (it->id == ST_DIAG)
            push_action(UIA_DIAGNOSTIC, "");
        else if (it->id == ST_TESTPAT)
            push_action(UIA_TESTPATTERN, "");
        else if (it->id == ST_DEFAULTS) {
            settings_defaults();
            rebuild(s);
            ui_toast("%s", tr(S_TOAST_DEFAULTS));
        } else
            adjust_item(s, it, 1);
        break;
    case SCR_COREOPT_GLOBAL:
    case SCR_COREOPT_GAME:
        adjust_item(s, it, 1);
        break;
    case SCR_CONTROLS:
        if (it->id >= CT_PAD_BASE && it->id < CT_PAD_BASE + 100) {
            const pad_info_t *pi = input_pad_info(it->id - CT_PAD_BASE);
            if (pi && pi->port >= 0) {
                int n = MAX(2, input_pad_count());
                input_swap_ports(pi->port, (pi->port + 1) % n);
                rebuild(s);
            }
        } else if (it->id >= CT_MAP_BASE && it->id < CT_MAP_BASE + B3DO_COUNT) {
            g_cap_btn = it->id - CT_MAP_BASE;
            g_cap_deadline = platform_time_us() + 6000000ull;
            input_capture_begin();
        } else if (it->id == CT_DEFAULTS) {
            input_default_map(g_cfg.button_map);
            rebuild(s);
        }
        break;
    case SCR_ABOUT:
        break;
    }
}

/* ------------------------------------------------------------ layout/chrome */

static void list_rect(const scr_t *s, float *x, float *y, float *w, float *h)
{
    *x = LIST_X;
    *y = LIST_Y;
    *w = LIST_W;
    *h = 520;
    switch (s->id) {
    case SCR_PAUSE:
        *x = 350; *y = 134; *w = 580; *h = 508;
        break;
    case SCR_HOME:
    case SCR_COREOPT_GLOBAL:
    case SCR_COREOPT_GAME:
        *h = 392;
        break;
    default:
        break;
    }
}

static bool pause_root(void)
{
    return g_mode == UI_PAUSE && g_depth == 1 && cur()->id == SCR_PAUSE;
}

typedef struct {
    const char *btn;
    const char *text;
} hint_t;

static int hints_for(const scr_t *s, hint_t *h)
{
    int n = 0;
    switch (s->id) {
    case SCR_HOME:
        h[n++] = (hint_t){"A", tr(S_H_SELECT)};
        break;
    case SCR_BROWSER:
        h[n++] = (hint_t){"A", tr(S_H_OPEN)};
        h[n++] = (hint_t){"B", tr(S_H_BACK)};
        if (g_br.nroots > 1)
            h[n++] = (hint_t){"X", tr(S_H_STORAGE)};
        h[n++] = (hint_t){"Y", tr(S_H_ROMS)};
        break;
    case SCR_RECENT:
        h[n++] = (hint_t){"A", tr(S_H_OPEN)};
        h[n++] = (hint_t){"B", tr(S_H_BACK)};
        h[n++] = (hint_t){"Y", tr(S_H_REMOVE)};
        break;
    case SCR_PAUSE:
        h[n++] = (hint_t){"A", tr(S_H_SELECT)};
        h[n++] = (hint_t){"B", tr(S_H_RESUME)};
        break;
    case SCR_SETTINGS:
        h[n++] = (hint_t){"A", tr(S_H_CHANGE)};
        h[n++] = (hint_t){"B", tr(S_H_BACK)};
        break;
    case SCR_COREOPT_GLOBAL:
    case SCR_COREOPT_GAME:
        h[n++] = (hint_t){"A", tr(S_H_CHANGE)};
        h[n++] = (hint_t){"X", tr(S_H_DEFAULT)};
        h[n++] = (hint_t){"B", tr(S_H_BACK)};
        break;
    case SCR_CONTROLS:
        h[n++] = (hint_t){"A", tr(S_H_REMAP)};
        h[n++] = (hint_t){"B", tr(S_H_BACK)};
        break;
    case SCR_ABOUT:
        h[n++] = (hint_t){"B", tr(S_H_BACK)};
        h[n++] = (hint_t){"", tr(S_H_SCROLL)};
        break;
    }
    return n;
}

static void draw_footer(const scr_t *s)
{
    hint_t h[6];
    int n = hints_for(s, h);
    float x = 70;
    char buf[64];

    gfx_fill(60, FOOT_Y - 12, 1160, 1, RGBA(255, 255, 255, 26));
    for (int i = 0; i < n; i++) {
        if (h[i].btn[0])
            x += gfx_badge(x, FOOT_Y, 34, h[i].btn, RGBA(0x10, 0x14, 0x2c, 255), COL_ACCENT) + 10;
        x += gfx_text(h[i].text, x, FOOT_Y + (34 - gfx_line_height(FS_SMALL)) / 2, FS_SMALL, COL_TEXT_DIM, TXT_LEFT, 0) + 34;
    }
    snprintf(buf, sizeof(buf), tr(S_CONTROLLERS_N), input_connected_count());
    gfx_text(buf, 1210, FOOT_Y + (34 - gfx_line_height(FS_SMALL)) / 2, FS_SMALL, COL_TEXT_OFF, TXT_RIGHT, 300);
}

static const SDL_Rect k_back_chip = {60, 30, 160, 52};

static void draw_header(const scr_t *s)
{
    const char *title = APP_NAME;
    char sub[1100] = "";
    float tx;

    switch (s->id) {
    case SCR_HOME:
        title = APP_NAME;
        str_copy(sub, tr(S_TAGLINE), sizeof(sub));
        break;
    case SCR_BROWSER:
        title = tr(S_BR_TITLE);
        shorten_path_left(g_br.cwd, sub, sizeof(sub), 700, FS_SMALL);
        break;
    case SCR_RECENT: title = tr(S_RECENT_TITLE); break;
    case SCR_SETTINGS: title = tr(S_SET_TITLE); break;
    case SCR_COREOPT_GLOBAL:
        title = tr(S_CO_TITLE_GLOBAL);
        str_copy(sub, tr(S_CO_NOTE), sizeof(sub));
        break;
    case SCR_COREOPT_GAME:
        title = tr(S_CO_TITLE_GAME);
        str_copy(sub, g_game_title, sizeof(sub));
        break;
    case SCR_CONTROLS: title = tr(S_CTL_TITLE); break;
    case SCR_ABOUT: title = tr(S_ABOUT_TITLE); break;
    default: break;
    }

    if (g_depth > 1) {
        gfx_round_fill((float)k_back_chip.x, (float)k_back_chip.y, (float)k_back_chip.w, (float)k_back_chip.h, 14, COL_PANEL_LIGHT);
        gfx_triangle(k_back_chip.x + 30, k_back_chip.y + k_back_chip.h / 2.0f, 16, DIR_LEFT, COL_ACCENT);
        gfx_text(tr(S_H_BACK), k_back_chip.x + 54, k_back_chip.y + (k_back_chip.h - gfx_line_height(FS_NORMAL)) / 2.0f, FS_NORMAL,
                 COL_TEXT, TXT_LEFT, 90);
        tx = 250;
    } else {
        gfx_disc(96, 56, 72, 255);
        tx = 156;
    }
    gfx_text(title, tx, 22, FS_TITLE, COL_TEXT, TXT_LEFT, 760);
    if (sub[0])
        gfx_text(sub, tx, 76, FS_SMALL, COL_TEXT_DIM, TXT_LEFT, s->id == SCR_BROWSER ? 700 : 900);

    if (s->id == SCR_BROWSER && g_br.nroots > 1) { /* storage chips */
        float x = 1220;
        int curr = browser_current_root();
        for (int i = g_br.nroots - 1; i >= 0; i--) {
            float w = gfx_text_width(g_br.roots[i].label, FS_SMALL) + 36;
            x -= w;
            gfx_round_fill(x, 40, w, 38, 19, i == curr ? COL_ROW_SEL : COL_PANEL_LIGHT);
            gfx_text(g_br.roots[i].label, x + w / 2, 40 + (38 - gfx_line_height(FS_SMALL)) / 2, FS_SMALL,
                     i == curr ? COL_TEXT : COL_TEXT_DIM, TXT_CENTER, 0);
            x -= 10;
        }
    } else {
        gfx_text("v" APP_VERSION, 1220, 38, FS_SMALL, COL_TEXT_OFF, TXT_RIGHT, 0);
    }
}

static void draw_info_panel(const char *text, const char *note)
{
    gfx_round_fill(LIST_X, 526, LIST_W, 126, 14, COL_PANEL);
    gfx_badge(LIST_X + 18, 540, 30, "i", RGBA(0x10, 0x14, 0x2c, 255), COL_ACCENT2);
    gfx_text_wrapped(text, LIST_X + 66, 536, LIST_W - 90, FS_SMALL, COL_TEXT_DIM, note ? 3 : 4, true);
    if (note)
        gfx_text(note, LIST_X + 66, 614, FS_SMALL, COL_WARN, TXT_LEFT, LIST_W - 90);
}

/* Fits a path into max_w pixels by dropping leading folders ("...tail"). */
static void shorten_path_left(const char *path, char *out, size_t cap, float max_w, int size)
{
    static const char ell[] = "\xe2\x80\xa6";
    const char *p = path;

    if (gfx_text_width(path, size) <= max_w) {
        str_copy(out, path, cap);
        return;
    }
    while (*p) {
        const char *slash = strchr(p + 1, '/');
        char tmp[1100];
        if (!slash)
            break;
        p = slash;
        snprintf(tmp, sizeof(tmp), "%s%s", ell, p);
        if (gfx_text_width(tmp, size) <= max_w) {
            str_copy(out, tmp, cap);
            return;
        }
    }
    snprintf(out, cap, "%s%s", ell, p);
}

/* ABOUT / help text */
static float g_about_total;

static float draw_about(float x, float y, float w, float h, float scroll)
{
    static const struct { int head, body; } sec[] = {
        {S_AB_H_ABOUT, S_AB_ABOUT},   {S_AB_H_PLAY, S_AB_PLAY},   {S_AB_H_DISC, S_AB_DISC},
        {S_AB_H_BIOS, S_AB_BIOS},     {S_AB_H_SAVES, S_AB_SAVES}, {S_AB_H_KEYS, S_AB_KEYS},
        {S_AB_H_DIAG, S_AB_DIAG},     {S_AB_H_CREDITS, S_AB_CREDITS},
    };
    float cy = y - scroll;
    char buf[1400];

    gfx_clip(x - 4, y, w + 8, h);
    for (size_t i = 0; i < ARRAY_LEN(sec); i++) {
        float bh;
        snprintf(buf, sizeof(buf), tr(sec[i].body), APP_NAME, APP_VERSION, APP_BUILD);
        gfx_text(tr(sec[i].head), x + 4, cy, FS_LARGE, COL_ACCENT, TXT_LEFT, w - 20);
        cy += gfx_line_height(FS_LARGE) + 6;
        bh = gfx_text_wrapped(buf, x + 4, cy, w - 28, FS_NORMAL, COL_TEXT, -1, true);
        cy += bh + 26;
    }
    gfx_clip_off();
    return cy - (y - scroll); /* total height */
}

/* ------------------------------------------------------------------- draw */

static void draw_overlay_message(void)
{
    float w = 780, th = gfx_text_wrapped(g_msg.text, 0, 0, w - 64, FS_NORMAL, COL_TEXT, 12, false);
    float h = 150 + th, x = (1280 - w) / 2, y = (720 - h) / 2;
    video_draw_dim(190);
    gfx_round_fill(x, y, w, h, 20, COL_PANEL_LIGHT);
    gfx_round_fill(x, y, w, 8, 4, g_msg.err ? COL_ERR : COL_ACCENT2);
    gfx_text(g_msg.title, x + 32, y + 28, FS_LARGE, g_msg.err ? COL_ERR : COL_TEXT, TXT_LEFT, w - 64);
    gfx_text_wrapped(g_msg.text, x + 32, y + 84, w - 64, FS_NORMAL, COL_TEXT, 12, true);
    gfx_badge(x + w - 130, y + h - 56, 36, "A", RGBA(0x10, 0x14, 0x2c, 255), COL_ACCENT);
    gfx_text("OK", x + w - 84, y + h - 54, FS_NORMAL, COL_TEXT_DIM, TXT_LEFT, 0);
}

static void draw_overlay_capture(void)
{
    char buf[160];
    int secs = (int)((g_cap_deadline - platform_time_us()) / 1000000ull) + 1;
    float w = 700, h = 230, x = (1280 - w) / 2, y = (720 - h) / 2;
    video_draw_dim(200);
    gfx_round_fill(x, y, w, h, 20, COL_PANEL_LIGHT);
    snprintf(buf, sizeof(buf), tr(S_CTL_PRESS), input_3do_name(g_cap_btn));
    gfx_text(buf, 640, y + 46, FS_LARGE, COL_TEXT, TXT_CENTER, w - 40);
    snprintf(buf, sizeof(buf), "%d", MAX(secs, 0));
    gfx_text(buf, 640, y + 104, FS_HUGE, COL_ACCENT2, TXT_CENTER, 0);
    gfx_text(tr(S_CTL_CANCEL), 640, y + h - 52, FS_SMALL, COL_TEXT_DIM, TXT_CENTER, w - 40);
}

/* y / max_w differ between the in-game overlay and the menus (the pause panel
 * leaves a strip below it for the toast). */
static void draw_toast(float y, float max_w)
{
    uint64_t now = platform_time_us();
    float tw, w, x, a;
    if (now >= g_toast_until || !g_toast[0])
        return;
    a = 1.0f;
    if (g_toast_until - now < 350000ull)
        a = (float)(g_toast_until - now) / 350000.0f;
    if (now - g_toast_from < 150000ull)
        a = MIN(a, (float)(now - g_toast_from) / 150000.0f);
    tw = gfx_text_width(g_toast, FS_NORMAL);
    w = MIN(tw + 56, max_w);
    x = (1280 - w) / 2;
    gfx_round_fill(x, y, w, 50, 25, RGBA(0x12, 0x17, 0x34, (int)(235 * a)));
    gfx_text(g_toast, 640, y + (50 - gfx_line_height(FS_NORMAL)) / 2, FS_NORMAL, RGBA(0xf0, 0xf4, 0xff, (int)(255 * a)),
             TXT_CENTER, w - 40);
}

void ui_draw(void)
{
    scr_t *s;
    float lx, ly, lw, lh;

    if (g_depth == 0)
        return;
    s = cur();
    gfx_frame_begin();
    list_rect(s, &lx, &ly, &lw, &lh);

    if (pause_root()) {
        video_draw_dim(150);
        gfx_round_fill(330, 34, 620, 592, 24, COL_PANEL);
        gfx_text(g_game_title[0] ? g_game_title : APP_NAME, 640, 52, FS_LARGE, COL_TEXT, TXT_CENTER, 560);
        gfx_text(tr(S_PAUSE_TITLE), 640, 94, FS_SMALL, COL_TEXT_DIM, TXT_CENTER, 0);
    } else {
        gfx_background();
        draw_header(s);
    }

    if (s->id == SCR_ABOUT) {
        g_about_total = draw_about(lx, ly, lw, lh, s->menu.scroll);
    } else {
        menu_draw(&s->menu, lx, ly, lw, lh, true);
    }

    /* per-screen extras */
    switch (s->id) {
    case SCR_HOME:
        draw_info_panel(tr(S_HOME_DISC_NOTE), NULL);
        break;
    case SCR_BROWSER:
        if (g_br.read_error)
            gfx_text_wrapped(tr(S_BR_NOACCESS), 640 - 360, 300, 720, FS_NORMAL, COL_ERR, 3, true);
        else if (g_br.nents == 0)
            gfx_text_wrapped(tr(S_BR_EMPTY), 640 - 360, g_br.can_up ? 230 : 190, 720, FS_NORMAL, COL_TEXT_DIM, 6, true);
        break;
    case SCR_COREOPT_GLOBAL:
    case SCR_COREOPT_GAME:
        if (s->menu.n > 0 && s->menu.sel < s->menu.n) {
            const core_opt_t *o = core_opt_at(s->menu.it[s->menu.sel].id);
            draw_info_panel(o && o->info[0] ? o->info : tr(S_CO_NOTE), tr(S_CO_RESTART_NOTE));
        }
        break;
    default:
        break;
    }
    if (!pause_root() || true)
        draw_footer(s);

    if (g_cap_btn >= 0)
        draw_overlay_capture();
    if (g_msg.active)
        draw_overlay_message();
    if (pause_root())
        draw_toast(634, 560); /* below the panel, between the footer hints */
    else
        draw_toast(596, 1100);
}

void ui_draw_splash(const char *line1, const char *line2)
{
    gfx_frame_begin();
    gfx_background();
    gfx_disc(640, 250, 230, 255);
    gfx_text(line1, 640, 410, FS_TITLE, COL_TEXT, TXT_CENTER, 1100);
    if (line2 && line2[0])
        gfx_text(line2, 640, 470, FS_NORMAL, COL_TEXT_DIM, TXT_CENTER, 1100);
}

void ui_draw_splash_progress(const char *line1, const char *line2, float progress, const char *line3)
{
    const float bx = 340, bw = 600, by = 540, bh = 16;
    float p = CLAMP(progress, 0.0f, 1.0f);

    ui_draw_splash(line1, line2);
    gfx_round_fill(bx, by, bw, bh, bh / 2, RGBA(255, 255, 255, 30));
    if (p > 0.0f)
        gfx_round_fill(bx, by, MAX(bh, bw * p), bh, bh / 2, COL_ACCENT2);
    if (line3 && line3[0])
        gfx_text(line3, 640, by + 34, FS_SMALL, COL_TEXT_DIM, TXT_CENTER, 1100);
    /* which program is this? a photo of this screen answers it */
    gfx_text(APP_NAME " " APP_VERSION "  ·  " APP_BUILD, 640, by + 78, FS_SMALL, COL_TEXT_DIM, TXT_CENTER, 1100);
}

void ui_draw_overlays(const ui_hud_t *hud)
{
    gfx_frame_begin();
    if (hud && g_cfg.show_fps) {
        char b[96];
        snprintf(b, sizeof(b), "%.1f fps   %d ms", hud->emu_fps, hud->audio_ms);
        gfx_round_fill(16, 14, gfx_text_width(b, FS_SMALL) + 28, 36, 12, RGBA(0, 0, 0, 150));
        gfx_text(b, 30, 14 + (36 - gfx_line_height(FS_SMALL)) / 2, FS_SMALL, COL_TEXT, TXT_LEFT, 0);
        if (hud->perf[0]) { /* where the time of a frame goes, measured by perf.c */
            gfx_round_fill(16, 56, gfx_text_width(hud->perf, FS_SMALL) + 28, 36, 12, RGBA(0, 0, 0, 150));
            gfx_text(hud->perf, 30, 56 + (36 - gfx_line_height(FS_SMALL)) / 2, FS_SMALL, COL_TEXT_DIM, TXT_LEFT, 0);
        }
    }
    if (hud && hud->fast_forward) {
        gfx_round_fill(1160, 14, 104, 36, 12, RGBA(0, 0, 0, 150));
        gfx_text(">>  x", 1212, 14 + (36 - gfx_line_height(FS_SMALL)) / 2, FS_SMALL, COL_WARN, TXT_CENTER, 0);
    }
    if (g_msg.active)
        draw_overlay_message();
    draw_toast(620, 1100);
}

/* ------------------------------------------------------------------ update */

static void browser_cycle_storage(void)
{
    if (g_br.nroots > 1)
        browser_enter_root((browser_current_root() + 1) % g_br.nroots);
}

static void handle_nav(nav_action_t a)
{
    scr_t *s = cur();
    menu_t *m = &s->menu;
    float lx, ly, lw, lh;
    mitem_t *it = (m->n > 0 && m->sel < m->n) ? &m->it[m->sel] : NULL;

    list_rect(s, &lx, &ly, &lw, &lh);
    if (s->id == SCR_ABOUT) {
        float max = MAX(0.0f, g_about_total - lh);
        switch (a) {
        case NAV_UP: m->scroll_to -= 80; break;
        case NAV_DOWN: m->scroll_to += 80; break;
        case NAV_PAGE_UP: case NAV_LEFT: m->scroll_to -= lh - 60; break;
        case NAV_PAGE_DOWN: case NAV_RIGHT: m->scroll_to += lh - 60; break;
        case NAV_BACK: go_back(); return;
        default: break;
        }
        m->scroll_to = CLAMP(m->scroll_to, 0.0f, max);
        return;
    }

    switch (a) {
    case NAV_UP: menu_move(m, -1); break;
    case NAV_DOWN: menu_move(m, 1); break;
    case NAV_LEFT:
        if (it && it->kind == MI_CHOICE) adjust_item(s, it, -1);
        else menu_page(m, -1, lh);
        break;
    case NAV_RIGHT:
        if (it && it->kind == MI_CHOICE) adjust_item(s, it, 1);
        else menu_page(m, 1, lh);
        break;
    case NAV_PAGE_UP: menu_page(m, -1, lh); break;
    case NAV_PAGE_DOWN: menu_page(m, 1, lh); break;
    case NAV_ACCEPT:
        activate(s, it);
        s = cur();
        m = &s->menu;
        break;
    case NAV_BACK:
        go_back();
        s = cur();
        m = &s->menu;
        break;
    case NAV_X:
        if (s->id == SCR_BROWSER)
            browser_cycle_storage();
        else if (s->id == SCR_COREOPT_GLOBAL || s->id == SCR_COREOPT_GAME)
            reset_item_to_default(s, it);
        break;
    case NAV_Y:
        if (s->id == SCR_BROWSER) {
            browser_goto_roms();
        } else if (s->id == SCR_RECENT && it && it->kind == MI_DISC) {
            config_remove_recent(it->id);
            config_save();
            rebuild(s);
        }
        break;
    default:
        break;
    }
    s = cur();
    m = &s->menu;
    list_rect(s, &lx, &ly, &lw, &lh);
    menu_fix_sel(m);
    menu_ensure_visible(m, lh);
}

static bool in_rect(float px, float py, float x, float y, float w, float h)
{
    return px >= x && px < x + w && py >= y && py < y + h;
}

static void handle_pointer(const pointer_t *p)
{
    scr_t *s = cur();
    menu_t *m = &s->menu;
    float lx, ly, lw, lh;
    float total = s->id == SCR_ABOUT ? g_about_total : menu_total(m);

    list_rect(s, &lx, &ly, &lw, &lh);
    if (p->pressed) {
        g_pt.tracking = true;
        g_pt.dragging = false;
        g_pt.x0 = p->x;
        g_pt.y0 = p->y;
        if (g_depth > 1 && in_rect(p->x, p->y, (float)k_back_chip.x, (float)k_back_chip.y, (float)k_back_chip.w, (float)k_back_chip.h)) {
            g_pt.tracking = false;
            go_back();
            return;
        }
        if (pause_root() && !in_rect(p->x, p->y, 330, 34, 620, 592)) {
            g_pt.tracking = false;
            push_action(UIA_RESUME, "");
            return;
        }
        if (s->id == SCR_BROWSER && g_br.nroots > 1 && p->y > 36 && p->y < 84 && p->x > 800) { /* storage chips */
            float x = 1220;
            for (int i = g_br.nroots - 1; i >= 0; i--) {
                float w = gfx_text_width(g_br.roots[i].label, FS_SMALL) + 36;
                x -= w;
                if (p->x >= x && p->x < x + w) {
                    g_pt.tracking = false;
                    browser_enter_root(i);
                    return;
                }
                x -= 10;
            }
        }
    }
    if (g_pt.tracking && p->down) {
        if (!g_pt.dragging && fabsf(p->y - g_pt.y0) > 14.0f)
            g_pt.dragging = true;
        if (g_pt.dragging && total > lh) {
            m->scroll_to = CLAMP(m->scroll_to - p->dy, 0.0f, total - lh);
            m->scroll = m->scroll_to;
        }
    }
    if (p->released && g_pt.tracking) {
        g_pt.tracking = false;
        if (!g_pt.dragging && s->id != SCR_ABOUT) {
            bool right = false;
            int hit = menu_hit(m, lx, ly, lw, lh, p->x, p->y, &right);
            if (hit >= 0) {
                mitem_t *it = &m->it[hit];
                m->sel = hit;
                if (it->kind == MI_CHOICE) {
                    if (p->x > lx + lw * 0.80f)
                        adjust_item(s, it, 1);
                    else if (p->x > lx + lw * 0.55f)
                        adjust_item(s, it, -1);
                    else
                        adjust_item(s, it, 1);
                } else {
                    activate(s, it);
                }
            }
        }
    }
}

void ui_update(void)
{
    uint64_t now = platform_time_us();
    float dt = (float)(now - g_last_us) / 1e6f;
    const pointer_t *p = input_pointer();
    nav_action_t a;

    g_last_us = now;
    dt = CLAMP(dt, 0.0f, 0.1f);
    g_anim_t += dt;
    if (g_depth == 0)
        return;

    if (g_msg.active) {
        while ((a = input_next_nav()) != NAV_NONE)
            if (a == NAV_ACCEPT || a == NAV_BACK)
                g_msg.active = false;
        if (p->pressed)
            g_msg.active = false;
        return;
    }
    if (g_cap_btn >= 0) {
        int code;
        while (input_next_nav() != NAV_NONE) {}
        if (input_capture_result(&code)) {
            g_cfg.button_map[g_cap_btn] = code;
            g_cap_btn = -1;
            rebuild(cur());
        } else if (now > g_cap_deadline || p->pressed) {
            input_capture_cancel();
            g_cap_btn = -1;
        }
        return;
    }

    while ((a = input_next_nav()) != NAV_NONE)
        handle_nav(a);
    handle_pointer(p);
    menu_anim(&cur()->menu, dt);
}

/* --------------------------------------------------------------- public API */

bool ui_init(const ui_hooks_t *hooks)
{
    g_hooks = hooks;
    if (!gfx_init(video_renderer()))
        return false;
    g_last_us = platform_time_us();
    return true;
}

void ui_shutdown(void)
{
    while (g_depth > 0)
        menu_free(&g_stack[--g_depth].menu);
    browser_free();
    gfx_shutdown();
}

void ui_refresh(void)
{
    if (g_depth > 0)
        rebuild_all();
}

void ui_open(ui_mode_t mode, const char *game_title)
{
    while (g_depth > 0)
        menu_free(&g_stack[--g_depth].menu);
    browser_free();
    g_mode = mode;
    str_copy(g_game_title, game_title ? game_title : "", sizeof(g_game_title));
    g_cap_btn = -1;
    g_pt.tracking = false;
    g_msg.active = false;
    scr_push(mode == UI_PAUSE ? SCR_PAUSE : SCR_HOME);
}

void ui_toast(const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(g_toast, sizeof(g_toast), fmt, ap);
    va_end(ap);
    g_toast_from = platform_time_us();
    g_toast_until = g_toast_from + 2400000ull;
}

void ui_message(const char *title, const char *text, bool is_error)
{
    g_msg.active = true;
    g_msg.err = is_error;
    str_copy(g_msg.title, title, sizeof(g_msg.title));
    str_copy(g_msg.text, text, sizeof(g_msg.text));
}

bool ui_message_active(void)
{
    return g_msg.active;
}

void ui_debug_goto(const char *name)
{
    if (g_depth == 0)
        ui_open(UI_HOME, NULL);
    if (!strcmp(name, "browser")) scr_push(SCR_BROWSER);
    else if (!strcmp(name, "recent")) scr_push(SCR_RECENT);
    else if (!strcmp(name, "settings")) scr_push(SCR_SETTINGS);
    else if (!strcmp(name, "coreopts")) scr_push(SCR_COREOPT_GLOBAL);
    else if (!strcmp(name, "gameopts")) scr_push(SCR_COREOPT_GAME);
    else if (!strcmp(name, "controls")) scr_push(SCR_CONTROLS);
    else if (!strcmp(name, "about")) scr_push(SCR_ABOUT);
    else if (!strcmp(name, "pause")) ui_open(UI_PAUSE, "Crash 'n Burn");
    else if (!strcmp(name, "message")) ui_message(tr(S_MSG_ERR_TITLE), "Teste de mensagem de erro.\nSegunda linha com texto um pouco mais longo para testar a quebra de linha automática.", true);
    else if (!strcmp(name, "capture")) { scr_push(SCR_CONTROLS); g_cap_btn = B3DO_A; g_cap_deadline = platform_time_us() + 6000000ull; }
    else if (!strcmp(name, "toast")) ui_toast("%s", "Estado salvo no slot 2");
}
