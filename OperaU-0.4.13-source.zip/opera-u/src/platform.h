#ifndef OPERAU_PLATFORM_H
#define OPERAU_PLATFORM_H

#include "common.h"

/* ---- filesystem -------------------------------------------------------- */

/* Root of everything the app stores (config, saves, states, logs, bios).
 * Wii U: fs:/vol/external01/wiiu/OperaU     Host: $OPERAU_HOME or ./data */
const char *platform_data_dir(void);
/* Where the file browser starts the first time. */
const char *platform_default_browse_dir(void);
/* Where Aroma looks for applications ("fs:/vol/external01/wiiu/apps"; host: $OPERAU_APPS_DIR, or NULL). */
const char *platform_apps_dir(void);
/* Highest directory the browser may go up to ("fs:/vol/external01" / "/"). */
const char *platform_browse_root(void);

/* Storage volumes the file browser offers as starting points. Only volumes
 * that exist right now are returned (SD card always first; USB drives are
 * probed at /vol/storage_usb01, /vol/storage_usb02 on the Wii U). */
typedef struct {
    char path[96];
    char label[32];
} storage_root_t;
int platform_storage_roots(storage_root_t *out, int max);

bool platform_exists(const char *path);
bool platform_is_dir(const char *path);
int64_t platform_file_size(const char *path); /* -1 on error */
bool platform_mkdirs(const char *path);      /* mkdir -p */
bool platform_remove(const char *path);
/* Writes to <path>.tmp then renames, so an interrupted write never destroys
 * the previous file. */
bool platform_write_file_atomic(const char *path, const void *data, size_t size);
/* Reads a whole file. Caller frees with free(). */
void *platform_read_file(const char *path, size_t *size_out);

typedef struct {
    char name[256];
    bool is_dir;
    int64_t size;
} dir_entry_t;

/* Lists a directory (without "." and ".."). Returns an malloc'd array the
 * caller must free(); *count_out receives the number of entries. */
dir_entry_t *platform_list_dir(const char *path, int *count_out);

/* ---- time / threads ---------------------------------------------------- */

uint64_t platform_time_us(void);
void platform_sleep_ms(uint32_t ms);

/* Pin the calling thread to a CPU core (Wii U: 0, 1 or 2; -1 = any).
 * No-op on the host. Core 1 is where the main (UI/GX2) thread runs. */
void platform_pin_thread(int core);
/* Lower value = higher priority on CafeOS. No-op on the host. */
void platform_set_thread_priority_offset(int offset);

/* ---- lifecycle --------------------------------------------------------- */

/* Wii U: tracks the HOME-menu overlay (app sent to the background) through
 * ProcUI callbacks. Call once after the video subsystem was initialised. The
 * emulation thread parks itself while platform_in_background() is true. */
void platform_lifecycle_init(void);
bool platform_in_background(void);
/* Incremented every time the app returns from the background; the UI thread
 * (which is blocked inside SDL_PumpEvents while the HOME menu is open) compares
 * it with the last value it saw to resync audio and input. Always 0 on host. */
uint32_t platform_background_epoch(void);

/* ---- system ----------------------------------------------------------- */

/* Pointer to a TrueType font provided by the OS (Wii U shared font), or NULL.
 * The memory is owned by the system; do not free. */
const void *platform_system_font(size_t *size_out);

/* Free memory hint for the diagnostics screen (bytes, 0 if unknown). */
uint64_t platform_free_memory(void);

#endif
