/*
 * Host-only self tests (never part of the Wii U build).
 *
 *   operau-host --selftest-core [--image FILE] [--frames N]
 *   operau-host --selftest-run  [--image FILE] [--seconds S]
 *   operau-host --selftest-ui   DIR
 *   operau-host --selftest-diagstate
 *
 * The SDL dummy video / audio drivers are selected automatically; set
 * OPERAU_HOME to a scratch directory before running.
 */
#ifndef OPERAU_SELFTEST_H
#define OPERAU_SELFTEST_H

/* Returns the process exit code, or -1 when argv holds no self-test flag. */
int selftest_main(int argc, char **argv);

#endif
