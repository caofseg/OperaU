#ifndef OPERAU_CONFIG_H
#define OPERAU_CONFIG_H

#include "common.h"

/* Bumped whenever the default button mapping changes. A config file written before this version has its stored
 * mapping ignored, so an existing installation moves to the new default instead of keeping the old one; anyone who
 * remaps afterwards keeps their own choice, because saving writes the current version. */
#define BUTTON_MAP_VERSION 2

/*
 * How much sound is kept waiting to be played, by default. It is what paces the emulation, and it is also most of
 * the delay between a thing happening in a game and being heard: 80 ms of it, with what the console's own output
 * adds, put the sound about a tenth of a second behind the picture, which shows wherever a game cuts its picture
 * to its music. 50 ms still leaves two frames of margin at full speed. Bumped like the button map: a file written
 * before this version that holds the old default gets the new one, and any other value is the player's own.
 */
#define AUDIO_LATENCY_DEFAULT_MS 50
#define AUDIO_DEFAULTS_VERSION 2

/* ---- tiny key/value store (INI without sections) --------------------- */

typedef struct {
    char *key;
    char *val;
} kv_item_t;

typedef struct {
    kv_item_t *items;
    int count;
    int cap;
} kvmap_t;

void kv_init(kvmap_t *m);
void kv_free(kvmap_t *m);
void kv_clear(kvmap_t *m);
void kv_set(kvmap_t *m, const char *key, const char *val);
bool kv_remove(kvmap_t *m, const char *key);
const char *kv_get(const kvmap_t *m, const char *key);
bool kv_load(kvmap_t *m, const char *path);
bool kv_save(const kvmap_t *m, const char *path);

/* ---- settings --------------------------------------------------------- */

typedef enum {
    ASPECT_4_3 = 0,   /* keep 4:3 (default) */
    ASPECT_STRETCH,   /* fill the whole screen */
    ASPECT_INTEGER,   /* integer scale of the source, no filtering artefacts */
    ASPECT_COUNT
} aspect_mode_t;

typedef enum {
    FILTER_NEAREST = 0,
    FILTER_LINEAR,
    FILTER_COUNT
} filter_mode_t;

typedef enum {
    LANG_PT = 0,
    LANG_EN,
    LANG_COUNT
} language_t;

/* 3DO controller buttons (internal index, not the libretro id) */
typedef enum {
    B3DO_UP = 0, B3DO_DOWN, B3DO_LEFT, B3DO_RIGHT,
    B3DO_A, B3DO_B, B3DO_C, B3DO_L, B3DO_R, B3DO_X, B3DO_P,
    B3DO_COUNT
} btn3do_t;

#define MAX_RECENT 12

typedef struct {
    /* video */
    int aspect;
    int filter;
    bool vsync;
    bool show_fps;
    int color_order;  /* 0 = normal; see video_color_order_name() (Settings > Video, picture test) */
    bool perf_log;    /* measure where the time of a frame goes and write it to the log (perf.c) */
    /* audio */
    int volume;       /* 0..100 */
    int latency_ms;   /* audio buffer target */
    /* performance */
    int emu_core;     /* CPU core for the emulation thread: 0, 1, 2 or -1 (any) */
    bool threaded;    /* run the core on its own thread (recommended) */
    /* input */
    int deadzone;     /* percent of stick travel treated as centred */
    bool menu_lr;     /* L + R pressed together open the menu (ZL/ZR stay free for the game) */
    int button_map[B3DO_COUNT]; /* physical button codes, see input.h */
    /* misc */
    int language;
    bool udp_log;
    bool autosave_state; /* save a state when leaving a game, offer to resume */
    int state_slot;
    char browse_dir[512];
    char recent[MAX_RECENT][512];
    int recent_count;
} settings_t;

extern settings_t g_cfg;

/* Global core option overrides (opera_* keys) and per-game overrides. */
extern kvmap_t g_core_opts_global;
extern kvmap_t g_core_opts_game;

void config_defaults(settings_t *s);
void config_load(void);
bool config_save(void);

/* Per-game option overrides (config/games/<stem>.ini). */
void config_game_open(const char *game_path);
void config_game_close(void);
bool config_game_save(void);
/* Effective value: game override, then global, then NULL. */
const char *config_core_option_lookup(const char *key);

void config_add_recent(const char *path);
void config_remove_recent(int index);

/* Paths inside the data dir. `out` must hold at least 1100 bytes. */
void config_path(char *out, size_t cap, const char *sub);

#endif
