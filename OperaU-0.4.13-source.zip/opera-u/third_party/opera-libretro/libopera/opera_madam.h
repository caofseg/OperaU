/*
  www.freedo.org
  The first working 3DO multiplayer emulator.

  The FreeDO licensed under modified GNU LGPL, with following notes:

  *   The owners and original authors of the FreeDO have full right to
  *   develop closed source derivative work.

  *   Any non-commercial uses of the FreeDO sources or any knowledge
  *   obtained by studying or reverse engineering of the sources, or
  *   any other material published by FreeDO have to be accompanied
  *   with full credits.

  *   Any commercial uses of FreeDO sources or any knowledge obtained
  *   by studying or reverse engineering of the sources, or any other
  *   material published by FreeDO is strictly forbidden without
  *   owners approval.

  The above notes are taking precedence over GNU LGPL in conflicting
  situations.

  Project authors:
  *  Alexander Troosh
  *  Maxim Grishin
  *  Allen Wright
  *  John Sammons
  *  Felix Lazarev
*/

#ifndef	LIBOPERA_MADAM_H_INCLUDED
#define LIBOPERA_MADAM_H_INCLUDED

#include "extern_c.h"

#define FSM_IDLE 1
#define FSM_INPROCESS 2
#define FSM_SUSPENDED 3

/* MADAM MemCtl bits, using Portfolio OS names. */
#define MADAM_MCTL_CLUTXEN 0x00002000
#define MADAM_MCTL_VSCTXEN 0x00004000
#define MADAM_MCTL_PLAYXEN 0x00008000

EXTERN_C_BEGIN

void      opera_madam_init();
void      opera_madam_reset(void);
void      opera_madam_soft_reset(void);

uint32_t  opera_madam_fsm_get(void);
void      opera_madam_fsm_set(uint32_t val_);
uint32_t  opera_madam_mctl(void);

void      opera_madam_cel_handle(void);
void      opera_madam_cel_tick(void);
/* Local modification for OperaU, see opera_madam.c: the cel engine's speed in pixels a second (0: never busy). */
void      opera_madam_cel_rate_set(const uint32_t pixels_per_second_);
uint32_t  opera_madam_cel_rate_get(void);

uint32_t *opera_madam_registers(void);
/* Local modifications for OperaU, see their definitions: for timing the cel engine from a front end. */
void      opera_madam_cel_value_cache(const int on_);
void      opera_madam_cel_last_work(uint64_t *pixels_, uint64_t *texels_);

void      opera_madam_poke(uint32_t addr_, uint32_t val_);
uint32_t  opera_madam_peek(uint32_t addr_);

void      opera_madam_kprint_enable(void);
void      opera_madam_kprint_disable(void);
void      opera_madam_me_mode_software(void);
void      opera_madam_me_mode_hardware(void);

uint32_t  opera_madam_state_size(void);
uint32_t  opera_madam_state_size_v1(void);
uint32_t  opera_madam_state_save(void *buf_);
uint32_t  opera_madam_state_load(void const *buf_, uint32_t size_);
uint32_t  opera_madam_state_load_v1(void const *buf_, uint32_t size_);

EXTERN_C_END

#endif /* LIBOPERA_MADAM_H_INCLUDED */
