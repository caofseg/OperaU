#include "video.h"
#include "config.h"
#include "log.h"
#include "platform.h"
#include "png.h"

#define MAX_FRAME_W 768
#define MAX_FRAME_H 576
#define NEW_FLAG 0x100

typedef struct {
    uint8_t *data;
    unsigned w, h;
    size_t pitch;
    core_pixel_format_t fmt;
} frame_t;

static SDL_Window *g_win;
static SDL_Renderer *g_ren;
static SDL_Texture *g_tex;
static unsigned g_tex_w, g_tex_h;        /* exactly the size of the picture on it */
static int g_tex_filter = -1;
/* Second stage of the sharp scaler: the game picture blown up by a whole number, which is then fitted to the
 * destination. See draw_game() for why. Null whenever the sharp path is off or unavailable. */
static SDL_Texture *g_sharp;
static int g_sharp_w, g_sharp_h;
static bool g_targets_ok;                /* the renderer can draw into a texture (checked once, at init) */
static uint32_t g_target_fmt = SDL_PIXELFORMAT_ARGB8888; /* the renderer's own format, see video_init() */
static int g_sharp_checked;              /* 0 = not yet, 1 = colours verified, -1 = verification failed */
/* The game texture is always 32-bit ARGB8888, the format the interface already
 * uses on the console: the core's 16-bit 0RGB1555 picture is expanded here
 * instead of trusting the SDL Wii U renderer with a 16-bit texture format. */
/* Enough for any picture the console shows; it also bounds the memory the scaling texture may take. */
#define MAX_SHARP_SCALE 4
static uint32_t *g_conv;                 /* MAX_FRAME_W x MAX_FRAME_H pixels */
static uint32_t g_lut1555[32768];        /* 0RGB1555 -> 0xFFRRGGBB, already in the chosen colour order */
static int g_color_order;                /* index into k_order, see video_color_order_name() */

/* Colour order: which source channel (0 = red, 1 = green, 2 = blue) goes to the red, green and blue output. Only
 * order 0 is right unless the console's texture path turns out to swap channels; Settings > Video lets the
 * player pick another one while looking at the picture test. */
static const uint8_t k_order[VIDEO_COLOR_ORDERS][3] = {
    {0, 1, 2}, {2, 1, 0}, {0, 2, 1}, {1, 0, 2}, {1, 2, 0}, {2, 0, 1},
};
static const char *const k_order_name[VIDEO_COLOR_ORDERS] = {"RGB", "BGR", "RBG", "GRB", "GBR", "BRG"};

static frame_t g_frames[3];
static uint32_t g_middle;        /* atomic: index | NEW_FLAG */
static int g_write_idx = 0;      /* producer */
static int g_read_idx = 2;       /* consumer */
static bool g_have_frame;        /* consumer saw at least one frame */
static unsigned g_shown_w, g_shown_h;
static float g_game_aspect = 4.0f / 3.0f;
static unsigned long g_submitted;
static bool g_force_upload;      /* upload the current frame again (colour order changed) */

static uint64_t g_fps_t0;
static int g_fps_n;
static float g_fps;

/* Picks the channels of a 0xRRGGBB colour in the chosen order. */
static inline uint32_t reorder(uint32_t rgb, const uint8_t *o)
{
    uint32_t c[3];

    c[0] = (rgb >> 16) & 0xFF;
    c[1] = (rgb >> 8) & 0xFF;
    c[2] = rgb & 0xFF;
    return (c[o[0]] << 16) | (c[o[1]] << 8) | c[o[2]];
}

static void build_lut(void)
{
    const uint8_t *o = k_order[g_color_order];

    for (uint32_t v = 0; v < 32768; v++) {
        uint32_t r = (v >> 10) & 31, g = (v >> 5) & 31, b = v & 31;

        r = (r << 3) | (r >> 2);
        g = (g << 3) | (g >> 2);
        b = (b << 3) | (b >> 2);
        g_lut1555[v] = 0xFF000000u | reorder((r << 16) | (g << 8) | b, o);
    }
}

const char *video_color_order_name(int order)
{
    return k_order_name[CLAMP(order, 0, VIDEO_COLOR_ORDERS - 1)];
}

bool video_init(void)
{
    Uint32 rflags = SDL_RENDERER_ACCELERATED | (g_cfg.vsync ? SDL_RENDERER_PRESENTVSYNC : 0);

    if (g_win)
        return true;
    if (SDL_InitSubSystem(SDL_INIT_VIDEO) != 0) {
        LOGE("video subsystem: %s", SDL_GetError());
        return false;
    }
    g_win = SDL_CreateWindow(APP_NAME, SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, LOGICAL_W, LOGICAL_H,
                             SDL_WINDOW_SHOWN | SDL_WINDOW_RESIZABLE);
    if (!g_win) {
        LOGE("cannot create window: %s", SDL_GetError());
        return false;
    }
    g_ren = SDL_CreateRenderer(g_win, -1, rflags);
    if (!g_ren) {
        LOGW("accelerated renderer failed (%s), trying software", SDL_GetError());
        g_ren = SDL_CreateRenderer(g_win, -1, SDL_RENDERER_SOFTWARE);
    }
    if (!g_ren) {
        LOGE("cannot create renderer: %s", SDL_GetError());
        return false;
    }
    SDL_RenderSetLogicalSize(g_ren, LOGICAL_W, LOGICAL_H);
    {   /* the sharp scaler needs to draw into a texture; without it the picture is simply scaled in one step */
        SDL_RendererInfo info;

        memset(&info, 0, sizeof(info));
        g_targets_ok = SDL_GetRendererInfo(g_ren, &info) == 0 && (info.flags & SDL_RENDERER_TARGETTEXTURE) != 0;
        /* Drawing into a texture and then drawing from it only round-trips the colours unchanged when the texture
         * is in the renderer's own format. The Wii U renderer, for instance, stores every 32-bit format in the
         * same surface and reorders the channels when the texture is *sampled*; writing into such a texture
         * ignores that reordering, so an ARGB8888 target came back with its channels rotated - the picture went
         * blue. The first format a renderer lists is the one it needs no reordering for. */
        if (g_targets_ok && info.num_texture_formats > 0 && SDL_BITSPERPIXEL(info.texture_formats[0]) == 32)
            g_target_fmt = info.texture_formats[0];
        LOGI("video: renderer %s, draw-into-texture %s, scaling texture format %s", info.name ? info.name : "?",
             g_targets_ok ? "yes" : "no", SDL_GetPixelFormatName(g_target_fmt));
    }
    SDL_SetRenderDrawBlendMode(g_ren, SDL_BLENDMODE_BLEND);
    {
        SDL_RendererInfo ri;
        if (SDL_GetRendererInfo(g_ren, &ri) == 0)
            LOGI("renderer: %s", ri.name);
    }
    for (int i = 0; i < 3; i++) {
        g_frames[i].data = (uint8_t *)calloc((size_t)MAX_FRAME_W * MAX_FRAME_H, 4);
        if (!g_frames[i].data)
            return false;
    }
    g_conv = (uint32_t *)calloc((size_t)MAX_FRAME_W * MAX_FRAME_H, 4);
    if (!g_conv)
        return false;
    g_color_order = CLAMP(g_cfg.color_order, 0, VIDEO_COLOR_ORDERS - 1);
    build_lut();
    __atomic_store_n(&g_middle, 1u, __ATOMIC_RELAXED); /* idx 1, no new data */
    g_fps_t0 = platform_time_us();
    return true;
}

void video_shutdown(void)
{
    if (g_tex)
        SDL_DestroyTexture(g_tex);
    g_tex = NULL;
    if (g_sharp)
        SDL_DestroyTexture(g_sharp);
    g_sharp = NULL;
    if (g_ren)
        SDL_DestroyRenderer(g_ren);
    g_ren = NULL;
    if (g_win)
        SDL_DestroyWindow(g_win);
    g_win = NULL;
    for (int i = 0; i < 3; i++) {
        free(g_frames[i].data);
        g_frames[i].data = NULL;
    }
    free(g_conv);
    g_conv = NULL;
}

SDL_Renderer *video_renderer(void) { return g_ren; }

void video_reset(void)
{
    g_have_frame = false;
    g_force_upload = false;
    g_shown_w = g_shown_h = 0;
}

void video_set_game_aspect(float a)
{
    if (a > 0.5f && a < 4.0f)
        g_game_aspect = a;
}

void video_apply_settings(void)
{
    int order = CLAMP(g_cfg.color_order, 0, VIDEO_COLOR_ORDERS - 1);

    if (order != g_color_order && g_lut1555[0]) { /* the table exists once video_init() ran */
        g_color_order = order;
        build_lut();
        if (g_have_frame) /* the picture on screen is the one the next draw uploads again */
            g_force_upload = true;
        LOGI("video: colour order %s", k_order_name[order]);
    }
    if (g_have_frame && g_tex_filter != g_cfg.filter) /* the texture is rebuilt with the new filter */
        g_force_upload = true;
#if SDL_VERSION_ATLEAST(2, 0, 18)
    if (g_ren)
        SDL_RenderSetVSync(g_ren, g_cfg.vsync ? 1 : 0);
#endif
}

/* ------------------------------------------------------------ frame handoff */

void video_submit(const void *data, unsigned w, unsigned h, size_t pitch, core_pixel_format_t fmt)
{
    frame_t *f = &g_frames[g_write_idx];
    size_t bpp = fmt == CORE_PF_XRGB8888 ? 4 : 2;
    size_t row = (size_t)w * bpp;
    uint32_t old;

    if (w > MAX_FRAME_W || h > MAX_FRAME_H || w == 0 || h == 0)
        return;
    if (pitch == row) {
        memcpy(f->data, data, row * h);
    } else {
        const uint8_t *src = (const uint8_t *)data;
        for (unsigned y = 0; y < h; y++)
            memcpy(f->data + y * row, src + y * pitch, row);
    }
    f->w = w;
    f->h = h;
    f->pitch = row;
    f->fmt = fmt;

    old = __atomic_exchange_n(&g_middle, (uint32_t)g_write_idx | NEW_FLAG, __ATOMIC_ACQ_REL);
    g_write_idx = (int)(old & 0xFF);
    __atomic_fetch_add(&g_submitted, 1, __ATOMIC_RELAXED);
}

unsigned long video_frames_submitted(void)
{
    return __atomic_load_n(&g_submitted, __ATOMIC_RELAXED);
}

/* Expands a picture to 0xFFRRGGBB pixels (dst is w x h, tightly packed). */
static void expand_frame(uint32_t *dst, const frame_t *f)
{
    const uint8_t *o = k_order[g_color_order];

    for (unsigned y = 0; y < f->h; y++) {
        uint32_t *d = dst + (size_t)y * f->w;

        if (f->fmt == CORE_PF_XRGB8888) {
            const uint32_t *s = (const uint32_t *)(const void *)(f->data + (size_t)y * f->pitch);

            if (g_color_order == 0) {
                for (unsigned x = 0; x < f->w; x++)
                    d[x] = s[x] | 0xFF000000u;
            } else {
                for (unsigned x = 0; x < f->w; x++)
                    d[x] = 0xFF000000u | reorder(s[x], o);
            }
        } else {
            const uint16_t *s = (const uint16_t *)(const void *)(f->data + (size_t)y * f->pitch);

            for (unsigned x = 0; x < f->w; x++)
                d[x] = g_lut1555[s[x] & 0x7FFF];
        }
    }
}

/* The texture has exactly the size of the picture (no unused border that the
 * smooth filter could bleed in) and is recreated when the core changes size. */
/*
 * Proves, on this console and this renderer, that a picture drawn into a texture and then drawn from it keeps its
 * colours. Four known colours go through exactly the path draw_game() uses and are read back. Anything other than
 * the four colours turns the sharp scaler off for good, so a wrong guess about the renderer costs a little
 * sharpness instead of showing every game in the wrong colours.
 */
static bool sharp_colours_survive(void)
{
    static const uint32_t want[4] = {0xFFFF0000, 0xFF00FF00, 0xFF0000FF, 0xFFFFFFFF};
    SDL_Texture *src = NULL, *dst = NULL;
    uint32_t got[4] = {0, 0, 0, 0};
    bool ok = false;
    char hint[16];
    const char *old_hint = SDL_GetHint(SDL_HINT_RENDER_SCALE_QUALITY);

    /* the hint is global and is read whenever any part of the app creates a texture: put it back afterwards */
    str_copy(hint, old_hint ? old_hint : "1", sizeof(hint));
    SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, "0");
    src = SDL_CreateTexture(g_ren, SDL_PIXELFORMAT_ARGB8888, SDL_TEXTUREACCESS_STREAMING, 2, 2);
    dst = SDL_CreateTexture(g_ren, g_target_fmt, SDL_TEXTUREACCESS_TARGET, 2, 2);
    if (src && dst) {
        SDL_SetTextureBlendMode(src, SDL_BLENDMODE_NONE);
        SDL_SetTextureBlendMode(dst, SDL_BLENDMODE_NONE);
        if (SDL_UpdateTexture(src, NULL, want, 2 * (int)sizeof(uint32_t)) == 0 &&
            SDL_SetRenderTarget(g_ren, dst) == 0) {
            SDL_RenderCopy(g_ren, src, NULL, NULL);
            ok = SDL_RenderReadPixels(g_ren, NULL, SDL_PIXELFORMAT_ARGB8888, got, 2 * (int)sizeof(uint32_t)) == 0;
            SDL_SetRenderTarget(g_ren, NULL);
            for (int i = 0; ok && i < 4; i++)
                ok = (got[i] | 0xFF000000u) == want[i]; /* the alpha channel is of no interest here */
        }
    }
    if (!ok)
        LOGW("video: colours do not survive drawing into a texture (%08x %08x %08x %08x, wanted %08x %08x %08x "
             "%08x); scaling in one step", (unsigned)got[0], (unsigned)got[1], (unsigned)got[2], (unsigned)got[3],
             (unsigned)want[0], (unsigned)want[1], (unsigned)want[2], (unsigned)want[3]);
    if (src)
        SDL_DestroyTexture(src);
    if (dst)
        SDL_DestroyTexture(dst);
    SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, hint);
    return ok;
}

/* True when the game picture is enlarged in two stages. Only worth it for the smooth filter: the sharp filter
 * never interpolates anyway. */
static bool sharp_path(void)
{
    if (!g_targets_ok || g_cfg.filter == FILTER_NEAREST)
        return false;
    if (g_sharp_checked == 0)
        g_sharp_checked = sharp_colours_survive() ? 1 : -1;
    return g_sharp_checked > 0;
}

/* The intermediate picture of the sharp scaler, drawn into and then drawn from, so it must be filtered. */
static bool ensure_sharp(int w, int h)
{
    if (g_sharp && g_sharp_w == w && g_sharp_h == h)
        return true;
    if (g_sharp)
        SDL_DestroyTexture(g_sharp);
    g_sharp = NULL;
    SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, "1");
    g_sharp = SDL_CreateTexture(g_ren, g_target_fmt, SDL_TEXTUREACCESS_TARGET, w, h);
    if (!g_sharp) {
        LOGW("video: cannot create the %dx%d scaling texture (%s); scaling in one step", w, h, SDL_GetError());
        g_targets_ok = false; /* do not try again every frame */
        return false;
    }
    SDL_SetTextureBlendMode(g_sharp, SDL_BLENDMODE_NONE);
    g_sharp_w = w;
    g_sharp_h = h;
    LOGI("video: sharp scaling through a %dx%d picture", w, h);
    return true;
}

/*
 * Puts the game picture into `dst`.
 *
 * A 3DO picture is 320x240 and the screen is 1280x720, so stretching it to the full 16:9 screen means 4x across
 * and 3x down. Done in one step with a smooth filter, every output pixel is a blend of neighbours and the picture
 * looks soft. Done here in two stages instead: first the picture is blown up by whole numbers with no filtering
 * at all, which cannot invent or lose anything, and only then is that enlarged picture fitted to the destination.
 * For 320x240 on a 1280x720 screen the first stage already lands exactly on the destination size, so the result
 * is pixel-exact; for sizes that do not divide evenly (a 640x480 game, say) the leftover is a small, clean
 * adjustment instead of a four-fold blur. The sharp filter needs none of this and goes straight to the screen.
 */
static void draw_game(const SDL_Rect *dst)
{
    int kx, ky;

    if (!sharp_path() || g_tex_w == 0 || g_tex_h == 0) {
        SDL_RenderCopy(g_ren, g_tex, NULL, dst);
        return;
    }
    kx = (dst->w + (int)g_tex_w - 1) / (int)g_tex_w;
    ky = (dst->h + (int)g_tex_h - 1) / (int)g_tex_h;
    if (kx < 1)
        kx = 1;
    if (ky < 1)
        ky = 1;
    if (kx > MAX_SHARP_SCALE)
        kx = MAX_SHARP_SCALE;
    if (ky > MAX_SHARP_SCALE)
        ky = MAX_SHARP_SCALE;
    if ((kx == 1 && ky == 1) || !ensure_sharp((int)g_tex_w * kx, (int)g_tex_h * ky)) {
        SDL_RenderCopy(g_ren, g_tex, NULL, dst); /* shrinking, or no texture: one step is the right thing */
        return;
    }
    if (SDL_SetRenderTarget(g_ren, g_sharp) != 0) {
        LOGW("video: cannot draw into the scaling texture (%s); scaling in one step", SDL_GetError());
        g_targets_ok = false;
        SDL_SetRenderTarget(g_ren, NULL);
        SDL_RenderCopy(g_ren, g_tex, NULL, dst);
        return;
    }
    SDL_RenderCopy(g_ren, g_tex, NULL, NULL); /* whole-number enlargement, no filtering */
    SDL_SetRenderTarget(g_ren, NULL);
    SDL_RenderCopy(g_ren, g_sharp, NULL, dst); /* final fit, filtered */
}

static bool ensure_texture(const frame_t *f)
{
    bool need = !g_tex || g_tex_filter != g_cfg.filter || f->w != g_tex_w || f->h != g_tex_h;

    if (g_sharp && (f->w != g_tex_w || f->h != g_tex_h)) { /* a new picture size needs a new scaling texture */
        SDL_DestroyTexture(g_sharp);
        g_sharp = NULL;
    }

    if (!need)
        return true;
    if (g_tex)
        SDL_DestroyTexture(g_tex);
    g_tex = NULL;

    /* With the smooth filter the picture is enlarged in two stages (draw_game), and the first of them must not
     * interpolate, so the game texture itself is created without filtering. */
    SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, (g_cfg.filter == FILTER_NEAREST || sharp_path()) ? "0" : "1");
    g_tex = SDL_CreateTexture(g_ren, SDL_PIXELFORMAT_ARGB8888, SDL_TEXTUREACCESS_STREAMING, (int)f->w, (int)f->h);
    if (!g_tex) {
        LOGE("cannot create game texture %ux%u: %s", f->w, f->h, SDL_GetError());
        return false;
    }
    SDL_SetTextureBlendMode(g_tex, SDL_BLENDMODE_NONE);
    LOGI("video: game picture %ux%u (%s), texture ARGB8888", f->w, f->h,
         f->fmt == CORE_PF_XRGB8888 ? "XRGB8888" : "0RGB1555");
    g_tex_w = f->w;
    g_tex_h = f->h;
    g_tex_filter = g_cfg.filter;
    return true;
}

static SDL_Rect dest_rect(unsigned w, unsigned h)
{
    SDL_Rect r = {0, 0, LOGICAL_W, LOGICAL_H};

    switch (g_cfg.aspect) {
    case ASPECT_STRETCH:
        break;
    case ASPECT_INTEGER: {
        int k = MIN(LOGICAL_W / (int)w, LOGICAL_H / (int)h);
        if (k < 1)
            k = 1;
        r.w = (int)w * k;
        r.h = (int)h * k;
        if (r.w > LOGICAL_W || r.h > LOGICAL_H) { /* bigger than the screen: fall back to fit */
            r.w = LOGICAL_W;
            r.h = (int)(LOGICAL_W / g_game_aspect);
        }
        r.x = (LOGICAL_W - r.w) / 2;
        r.y = (LOGICAL_H - r.h) / 2;
        break;
    }
    default: { /* ASPECT_4_3: keep the core's display aspect ratio */
        float a = g_game_aspect;
        r.h = LOGICAL_H;
        r.w = (int)(LOGICAL_H * a + 0.5f);
        if (r.w > LOGICAL_W) {
            r.w = LOGICAL_W;
            r.h = (int)(LOGICAL_W / a + 0.5f);
        }
        r.x = (LOGICAL_W - r.w) / 2;
        r.y = (LOGICAL_H - r.h) / 2;
        break;
    }
    }
    return r;
}

/* Takes the newest picture from the triple buffer (if there is one) and puts it on the texture. */
static bool upload_newest(void)
{
    uint32_t mid = __atomic_load_n(&g_middle, __ATOMIC_ACQUIRE);

    if (mid & NEW_FLAG) {
        uint32_t old = __atomic_exchange_n(&g_middle, (uint32_t)g_read_idx, __ATOMIC_ACQ_REL);
        g_read_idx = (int)(old & 0xFF);
        g_force_upload = true;
    }
    if (g_force_upload) {
        const frame_t *f = &g_frames[g_read_idx];

        g_force_upload = false;
        if (f->w && ensure_texture(f)) {
            expand_frame(g_conv, f);
            SDL_UpdateTexture(g_tex, NULL, g_conv, (int)(f->w * 4));
            g_shown_w = f->w;
            g_shown_h = f->h;
            g_have_frame = true;
        }
    }
    return g_have_frame && g_tex;
}

bool video_draw_game(void)
{
    SDL_Rect dst;

    if (!upload_newest())
        return false;
    dst = dest_rect(g_shown_w, g_shown_h);
    draw_game(&dst);
    return true;
}

bool video_draw_game_rect(const SDL_Rect *r)
{
    if (!upload_newest())
        return false;
    draw_game(r);
    return true;
}

/* ------------------------------------------------------------------ frame */

void video_begin_frame(void)
{
    SDL_SetRenderDrawColor(g_ren, 0, 0, 0, 255);
    SDL_RenderClear(g_ren);
}

void video_end_frame(void)
{
    uint64_t now;

    SDL_RenderPresent(g_ren);
    g_fps_n++;
    now = platform_time_us();
    if (now - g_fps_t0 >= 500000) {
        g_fps = (float)g_fps_n * 1000000.0f / (float)(now - g_fps_t0);
        g_fps_n = 0;
        g_fps_t0 = now;
    }
}

void video_draw_dim(int alpha)
{
    SDL_Rect all = {0, 0, LOGICAL_W, LOGICAL_H};
    SDL_SetRenderDrawColor(g_ren, 0, 0, 0, (Uint8)CLAMP(alpha, 0, 255));
    SDL_RenderFillRect(g_ren, &all);
}

float video_present_fps(void) { return g_fps; }

/* ------------------------------------------------------------ screenshots */

bool video_save_game_frame_png(const char *path)
{
    const frame_t *f;
    uint8_t *rgb;
    bool ok = false;

    if (!g_have_frame || !g_conv)
        return false;
    f = &g_frames[g_read_idx];
    rgb = (uint8_t *)malloc((size_t)f->w * f->h * 3);
    if (!rgb)
        return false;
    /* straight from what the core produced: the colour order setting is for the screen only */
    for (unsigned y = 0; y < f->h; y++) {
        const uint8_t *row = f->data + (size_t)y * f->pitch;
        uint8_t *d = rgb + (size_t)y * f->w * 3;

        for (unsigned x = 0; x < f->w; x++, d += 3) {
            if (f->fmt == CORE_PF_XRGB8888) {
                uint32_t v = ((const uint32_t *)(const void *)row)[x];

                d[0] = (uint8_t)(v >> 16);
                d[1] = (uint8_t)(v >> 8);
                d[2] = (uint8_t)v;
            } else {
                uint32_t v = ((const uint16_t *)(const void *)row)[x] & 0x7FFF;
                uint32_t r = (v >> 10) & 31, g = (v >> 5) & 31, b = v & 31;

                d[0] = (uint8_t)((r << 3) | (r >> 2));
                d[1] = (uint8_t)((g << 3) | (g >> 2));
                d[2] = (uint8_t)((b << 3) | (b >> 2));
            }
        }
    }
    ok = png_write_rgb24(path, rgb, f->w, f->h, (size_t)f->w * 3);
    free(rgb);
    return ok;
}

bool video_save_screen_bmp(const char *path)
{
    int w = 0, h = 0;
    SDL_Surface *s;
    bool ok = false;

    SDL_GetRendererOutputSize(g_ren, &w, &h);
    if (w <= 0 || h <= 0)
        return false;
    s = SDL_CreateRGBSurfaceWithFormat(0, w, h, 24, SDL_PIXELFORMAT_RGB24);
    if (!s)
        return false;
    if (SDL_RenderReadPixels(g_ren, NULL, SDL_PIXELFORMAT_RGB24, s->pixels, s->pitch) == 0)
        ok = SDL_SaveBMP(s, path) == 0;
    SDL_FreeSurface(s);
    return ok;
}

bool video_read_pixel(int x, int y, uint8_t rgb[3])
{
    SDL_Rect r = {x, y, 1, 1};
    uint8_t px[8] = {0};

    if (!g_ren || SDL_RenderReadPixels(g_ren, &r, SDL_PIXELFORMAT_RGB24, px, 3) != 0)
        return false;
    rgb[0] = px[0];
    rgb[1] = px[1];
    rgb[2] = px[2];
    return true;
}
