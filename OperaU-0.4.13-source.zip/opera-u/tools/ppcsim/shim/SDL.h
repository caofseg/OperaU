/* Single-threaded stand-in for the few SDL calls core.c / platform.c use. */
#ifndef SIM_SDL_H
#define SIM_SDL_H
#include <stdint.h>
#include <stdlib.h>
typedef struct SDL_mutex { int unused; } SDL_mutex;
static inline SDL_mutex *SDL_CreateMutex(void) { return (SDL_mutex *)calloc(1, sizeof(SDL_mutex)); }
static inline int SDL_LockMutex(SDL_mutex *m) { (void)m; return 0; }
static inline int SDL_UnlockMutex(SDL_mutex *m) { (void)m; return 0; }
static inline void SDL_DestroyMutex(SDL_mutex *m) { free(m); }
typedef union SDL_Event { int type; } SDL_Event;
#endif
