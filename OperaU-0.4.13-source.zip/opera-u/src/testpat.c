#include "testpat.h"
#include "config.h"
#include "i18n.h"
#include "log.h"
#include "ui.h"
#include "ui_gfx.h"
#include "video.h"

/* Where the picture goes on the 1280x720 screen: 4:3, and a row of reference swatches right above it. */
#define PIC_X 240
#define PIC_Y 116
#define PIC_W 800
#define PIC_H 600
#define SWATCH_Y 64
#define SWATCH_H 48

const uint32_t testpat_bar_rgb[TESTPAT_BARS] = {
    0xFFFFFF, 0xFFFF00, 0x00FFFF, 0x00FF00, 0xFF00FF, 0xFF0000, 0x0000FF, 0x000000,
};

static const struct {
    unsigned w, h;
    core_pixel_format_t fmt;
    bool bars; /* the picture starts with the eight bars (so the swatches above it apply) */
} k_pages[TESTPAT_PAGES] = {
    {320, 240, CORE_PF_0RGB1555, true},
    {320, 240, CORE_PF_0RGB1555, false},
    {640, 480, CORE_PF_0RGB1555, true},
    {320, 240, CORE_PF_XRGB8888, true},
};

static int g_page;
static uint32_t g_canvas[TESTPAT_MAX_W * TESTPAT_MAX_H];
static uint16_t g_pix16[TESTPAT_MAX_W * TESTPAT_MAX_H];

/* ------------------------------------------------------------- drawing kit */

typedef struct {
    uint32_t *px;
    int w, h;
} canvas_t;

static void rect(canvas_t *c, int x, int y, int w, int h, uint32_t rgb)
{
    int x1 = MIN(x + w, c->w), y1 = MIN(y + h, c->h);

    x = MAX(x, 0);
    y = MAX(y, 0);
    for (int yy = y; yy < y1; yy++)
        for (int xx = x; xx < x1; xx++)
            c->px[(size_t)yy * (size_t)c->w + (size_t)xx] = rgb;
}

static void put(canvas_t *c, int x, int y, uint32_t rgb)
{
    if (x >= 0 && y >= 0 && x < c->w && y < c->h)
        c->px[(size_t)y * (size_t)c->w + (size_t)x] = rgb;
}

static void line(canvas_t *c, int x0, int y0, int x1, int y1, uint32_t rgb)
{
    int dx = abs(x1 - x0), sx = x0 < x1 ? 1 : -1;
    int dy = -abs(y1 - y0), sy = y0 < y1 ? 1 : -1;
    int err = dx + dy;

    for (;;) {
        int e2;

        put(c, x0, y0, rgb);
        if (x0 == x1 && y0 == y1)
            break;
        e2 = 2 * err;
        if (e2 >= dy) {
            err += dy;
            x0 += sx;
        }
        if (e2 <= dx) {
            err += dx;
            y0 += sy;
        }
    }
}

static void circle(canvas_t *c, int cx, int cy, int r, uint32_t rgb)
{
    int x = r, y = 0, err = 1 - r;

    while (x >= y) {
        put(c, cx + x, cy + y, rgb);
        put(c, cx + y, cy + x, rgb);
        put(c, cx - y, cy + x, rgb);
        put(c, cx - x, cy + y, rgb);
        put(c, cx - x, cy - y, rgb);
        put(c, cx - y, cy - x, rgb);
        put(c, cx + y, cy - x, rgb);
        put(c, cx + x, cy - y, rgb);
        y++;
        if (err < 0) {
            err += 2 * y + 1;
        } else {
            x--;
            err += 2 * (y - x) + 1;
        }
    }
}

/* Fully saturated colour at position `pos` of `span` around the hue circle. */
static uint32_t hue_rgb(int pos, int span)
{
    int h6 = pos * 6 * 256 / span;
    int f = h6 & 255, up = f, down = 255 - f;
    int r, g, b;

    switch (h6 >> 8) {
    case 0: r = 255; g = up; b = 0; break;
    case 1: r = down; g = 255; b = 0; break;
    case 2: r = 0; g = 255; b = up; break;
    case 3: r = 0; g = down; b = 255; break;
    case 4: r = up; g = 0; b = 255; break;
    default: r = 255; g = 0; b = down; break;
    }
    return ((uint32_t)r << 16) | ((uint32_t)g << 8) | (uint32_t)b;
}

/* ------------------------------------------------------------------ pages */

/* Bars, ramps, a rainbow and the three primaries. Laid out in a 320x240 grid and scaled to the canvas. */
static void render_colour(canvas_t *c)
{
    int s = c->w / 320, bw = c->w / 8;

    rect(c, 0, 0, c->w, c->h, 0x000000);
    for (int i = 0; i < TESTPAT_BARS; i++) {
        rect(c, i * bw, 0, bw, 60 * s, testpat_bar_rgb[i]);
        rect(c, i * bw, 60 * s, bw, 20 * s, testpat_bar_rgb[i] & 0x808080u); /* half intensity */
    }
    for (int ramp = 0; ramp < 4; ramp++) { /* red, green, blue, grey: 32 steps each, the 5 bits of the 16-bit format */
        for (int k = 0; k < 32; k++) {
            uint32_t v = (uint32_t)(k * 255 / 31);
            uint32_t rgb = ramp == 0 ? v << 16 : ramp == 1 ? v << 8 : ramp == 2 ? v : (v << 16) | (v << 8) | v;

            rect(c, k * c->w / 32, (80 + 16 * ramp) * s, (k + 1) * c->w / 32 - k * c->w / 32, 16 * s, rgb);
        }
    }
    for (int x = 0; x < c->w; x++)
        rect(c, x, 144 * s, 1, 32 * s, hue_rgb(x, c->w));
    rect(c, 0, 176 * s, c->w / 3, 64 * s, 0xFF0000);
    rect(c, c->w / 3, 176 * s, c->w / 3, 64 * s, 0x00FF00);
    rect(c, 2 * (c->w / 3), 176 * s, c->w - 2 * (c->w / 3), 64 * s, 0x0000FF);
}

/* Grid, border, diagonals, circles, coloured corners and an asymmetric F; the high resolution page also carries
 * the bars and fine stripes. */
static void render_geometry(canvas_t *c, bool hires)
{
    int s = c->w / 320, w = c->w, h = c->h, m = 12 * s;

    rect(c, 0, 0, w, h, 0x202020);
    for (int x = 0; x < w; x += 16 * s)
        rect(c, x, 0, 1, h, 0x404040);
    for (int y = 0; y < h; y += 16 * s)
        rect(c, 0, y, w, 1, 0x404040);
    for (int i = 0; i <= 4; i++) { /* 4 x 4 cells of 4:3 */
        rect(c, MIN(i * w / 4, w - 1), 0, 1, h, 0x909090);
        rect(c, 0, MIN(i * h / 4, h - 1), w, 1, 0x909090);
    }
    line(c, 0, 0, w - 1, h - 1, 0xFFFFFF);
    line(c, w - 1, 0, 0, h - 1, 0xFFFFFF);
    circle(c, w / 2, h / 2, 100 * s, 0xFFFF00);
    circle(c, w / 2, h / 2, 50 * s, 0x00FFFF);
    rect(c, 24 * s, 80 * s, 6 * s, 48 * s, 0xFFFFFF); /* the F */
    rect(c, 24 * s, 80 * s, 22 * s, 6 * s, 0xFFFFFF);
    rect(c, 24 * s, 100 * s, 16 * s, 6 * s, 0xFFFFFF);
    if (hires) {
        int bw = w / 8;

        for (int i = 0; i < TESTPAT_BARS; i++)
            rect(c, i * bw, 0, bw, 48, testpat_bar_rgb[i]);
        for (int x = 0; x < 160; x++) /* one-pixel stripes, vertical and horizontal */
            rect(c, 24 + x, 400, 1, 48, (x & 1) ? 0x000000 : 0xFFFFFF);
        for (int y = 0; y < 48; y++)
            rect(c, w - 24 - 160, 400 + y, 160, 1, (y & 1) ? 0x000000 : 0xFFFFFF);
    }
    rect(c, 0, 0, w, 1, 0xFFFFFF); /* border */
    rect(c, 0, h - 1, w, 1, 0xFFFFFF);
    rect(c, 0, 0, 1, h, 0xFFFFFF);
    rect(c, w - 1, 0, 1, h, 0xFFFFFF);
    {
        int ty = hires ? 52 : 2; /* below the bars on the high resolution page */

        rect(c, 2, ty, m, m, 0xFF0000); /* corners: red, green / blue, yellow */
        rect(c, w - 2 - m, ty, m, m, 0x00FF00);
    }
    rect(c, 2, h - 2 - m, m, m, 0x0000FF);
    rect(c, w - 2 - m, h - 2 - m, m, m, 0xFFFF00);
}

bool testpat_render(int page, uint32_t *rgb, unsigned *w, unsigned *h, core_pixel_format_t *fmt)
{
    canvas_t c;

    if (page < 0 || page >= TESTPAT_PAGES)
        return false;
    c.px = rgb;
    c.w = (int)k_pages[page].w;
    c.h = (int)k_pages[page].h;
    if (page == 1)
        render_geometry(&c, false);
    else if (page == 2)
        render_geometry(&c, true);
    else
        render_colour(&c);
    *w = k_pages[page].w;
    *h = k_pages[page].h;
    *fmt = k_pages[page].fmt;
    return true;
}

/* ------------------------------------------------------------- the screen */

/* Renders the current page and hands it to the video module the way the emulation thread hands over a frame. */
static void send_page(void)
{
    unsigned w, h;
    core_pixel_format_t fmt;

    if (!testpat_render(g_page, g_canvas, &w, &h, &fmt))
        return;
    if (fmt == CORE_PF_XRGB8888) {
        video_submit(g_canvas, w, h, (size_t)w * 4, fmt);
        return;
    }
    for (size_t i = 0; i < (size_t)w * h; i++) {
        uint32_t v = g_canvas[i];

        g_pix16[i] = (uint16_t)((((v >> 19) & 31u) << 10) | (((v >> 11) & 31u) << 5) | ((v >> 3) & 31u));
    }
    video_submit(g_pix16, w, h, (size_t)w * 2, fmt);
}

int testpat_page(void)
{
    return g_page;
}

void testpat_enter(void)
{
    g_page = 0;
    video_reset();
    send_page();
    LOGI("picture test opened");
}

void testpat_leave(void)
{
    video_reset();
    LOGI("picture test closed (colour order %s)", video_color_order_name(g_cfg.color_order));
}

static const char *filter_name(void)
{
    return g_cfg.filter == FILTER_NEAREST ? tr(S_FILTER_SHARP) : tr(S_FILTER_SMOOTH);
}

bool testpat_nav(nav_action_t a)
{
    switch (a) {
    case NAV_BACK:
    case NAV_MENU:
        return false;
    case NAV_RIGHT:
    case NAV_ACCEPT:
    case NAV_PAGE_DOWN:
        g_page = (g_page + 1) % TESTPAT_PAGES;
        send_page();
        break;
    case NAV_LEFT:
    case NAV_PAGE_UP:
        g_page = (g_page + TESTPAT_PAGES - 1) % TESTPAT_PAGES;
        send_page();
        break;
    case NAV_X:
        g_cfg.color_order = (g_cfg.color_order + 1) % VIDEO_COLOR_ORDERS;
        video_apply_settings();
        ui_toast(tr(S_TP_ORDER), video_color_order_name(g_cfg.color_order));
        break;
    case NAV_Y:
        g_cfg.filter = g_cfg.filter == FILTER_NEAREST ? FILTER_LINEAR : FILTER_NEAREST;
        video_apply_settings();
        ui_toast(tr(S_TP_FILTER_NOW), filter_name());
        break;
    default:
        break;
    }
    return true;
}

static float hint_row(float y, const char *b1, const char *b2, const char *text)
{
    const uint32_t fg = RGBA(0x10, 0x14, 0x2c, 255);
    float x = 1052;
    float h;

    x += gfx_badge(x, y, 34, b1, fg, COL_ACCENT) + 6;
    if (b2)
        x += gfx_badge(x, y, 34, b2, fg, COL_ACCENT) + 6;
    h = gfx_text_wrapped(text, x + 6, y + 4, 1272 - x - 6, FS_SMALL, COL_TEXT_DIM, 2, true);
    return y + MAX(46.0f, h + 12.0f);
}

void testpat_draw(void)
{
    static const str_id_t k_names[TESTPAT_BARS] = {S_TP_C0, S_TP_C1, S_TP_C2, S_TP_C3, S_TP_C4, S_TP_C5, S_TP_C6, S_TP_C7};
    static const str_id_t k_titles[TESTPAT_PAGES] = {S_TP_P0, S_TP_P1, S_TP_P2, S_TP_P3};
    static const str_id_t k_notes[TESTPAT_PAGES] = {S_TP_N0, S_TP_N1, S_TP_N2, S_TP_N3};
    const SDL_Rect pic = {PIC_X, PIC_Y, PIC_W, PIC_H};
    char buf[160];
    float y;

    gfx_frame_begin();
    gfx_fill(0, 0, 1280, 720, RGBA(0x0a, 0x0c, 0x18, 255));

    snprintf(buf, sizeof(buf), "%s  ·  ", tr(S_TP_TITLE));
    snprintf(buf + strlen(buf), sizeof(buf) - strlen(buf), tr(S_TP_PAGE), g_page + 1, TESTPAT_PAGES);
    gfx_text(buf, PIC_X, 6, FS_LARGE, COL_TEXT, TXT_LEFT, PIC_W);
    gfx_text(tr(k_titles[g_page]), PIC_X, 40, FS_SMALL, COL_TEXT_DIM, TXT_LEFT, PIC_W);

    if (k_pages[g_page].bars) { /* what each bar must look like, drawn by the interface itself */
        for (int i = 0; i < TESTPAT_BARS; i++) {
            uint32_t rgb = testpat_bar_rgb[i];
            uint32_t luma = (((rgb >> 16) & 255) * 30 + ((rgb >> 8) & 255) * 59 + (rgb & 255) * 11) / 100;
            float x = (float)(PIC_X + i * (PIC_W / TESTPAT_BARS));

            gfx_fill(x, SWATCH_Y, (float)(PIC_W / TESTPAT_BARS), SWATCH_H, (rgb << 8) | 255u);
            gfx_text(tr(k_names[i]), x + (float)(PIC_W / TESTPAT_BARS) / 2, SWATCH_Y + (SWATCH_H - gfx_line_height(17)) / 2,
                     17, luma > 110 ? RGBA(0, 0, 0, 255) : RGBA(255, 255, 255, 255), TXT_CENTER, PIC_W / TESTPAT_BARS - 4);
        }
    }
    video_draw_game_rect(&pic);

    gfx_text_wrapped(tr(k_notes[g_page]), 16, 70, 216, FS_SMALL, COL_TEXT_DIM, -1, true);

    y = 70;
    y = hint_row(y, "A", ">", tr(S_TP_H_NEXT));
    y = hint_row(y, "<", NULL, tr(S_TP_H_PREV));
    y = hint_row(y, "X", NULL, tr(S_TP_H_ORDER));
    y = hint_row(y, "Y", NULL, tr(S_TP_H_FILTER));
    y = hint_row(y, "B", NULL, tr(S_TP_H_EXIT));
    y += 14;
    snprintf(buf, sizeof(buf), tr(S_TP_ORDER), video_color_order_name(g_cfg.color_order));
    y += gfx_text_wrapped(buf, 1052, y, 212, FS_SMALL, g_cfg.color_order ? COL_WARN : COL_OK, 2, true) + 8;
    snprintf(buf, sizeof(buf), tr(S_TP_FILTER_NOW), filter_name());
    gfx_text_wrapped(buf, 1052, y, 212, FS_SMALL, COL_TEXT_DIM, 2, true);
}
