# Opera libretro core: sources and flags shared by the host and Wii U builds.
# ROOT must be set to the project root before including this file.
#
# The core is compiled from the vendored sources (third_party/opera-libretro plus the
# big-endian patch documented in third_party/patches/), statically linked into the frontend.
# CHD support is the core's own (libretro-common rchd: deflate/lzma/flac/zstd
# are built in, no external library is needed).

OPERA_CORE := $(ROOT)/third_party/opera-libretro
LRC        := $(OPERA_CORE)/libretro-common
OPERA_LIB  := $(OPERA_CORE)/libopera

OPERA_INCS := -I$(OPERA_CORE) -I$(OPERA_LIB) -I$(LRC)/include

OPERA_SRCS := \
	$(OPERA_CORE)/cuefile.c \
	$(OPERA_CORE)/libretro.c \
	$(OPERA_CORE)/libretro_core_options.c \
	$(OPERA_CORE)/opera_lr_nvram.c \
	$(OPERA_CORE)/opera_lr_callbacks.c \
	$(OPERA_CORE)/opera_lr_opts.c \
	$(OPERA_CORE)/opera_lr_dsp.c \
	$(OPERA_CORE)/lr_input.c \
	$(OPERA_CORE)/lr_input_crosshair.c \
	$(OPERA_CORE)/lr_input_descs.c \
	$(OPERA_CORE)/retro_cdimage.c \
	$(OPERA_LIB)/prng16.c $(OPERA_LIB)/prng32.c $(OPERA_LIB)/opera_3do.c \
	$(OPERA_LIB)/opera_arm.c $(OPERA_LIB)/opera_bios.c $(OPERA_LIB)/opera_bitop.c \
	$(OPERA_LIB)/opera_cdrom.c $(OPERA_LIB)/opera_clio.c $(OPERA_LIB)/opera_clock.c \
	$(OPERA_LIB)/opera_diag_port.c $(OPERA_LIB)/opera_dsp.c \
	$(OPERA_LIB)/opera_fixedpoint_math.c $(OPERA_LIB)/opera_log.c \
	$(OPERA_LIB)/opera_madam.c $(OPERA_LIB)/opera_mem.c $(OPERA_LIB)/opera_nvram.c \
	$(OPERA_LIB)/opera_pbus.c $(OPERA_LIB)/opera_region.c $(OPERA_LIB)/opera_sport.c \
	$(OPERA_LIB)/opera_state.c $(OPERA_LIB)/opera_vdlp.c $(OPERA_LIB)/opera_xbus.c \
	$(OPERA_LIB)/opera_xbus_cdrom_plugin.c \
	$(LRC)/streams/file_stream.c \
	$(LRC)/streams/memory_stream.c \
	$(LRC)/streams/interface_stream.c \
	$(LRC)/encodings/encoding_utf.c \
	$(LRC)/encodings/encoding_crc32.c \
	$(LRC)/encodings/encoding_deflate.c \
	$(LRC)/features/features_cpu.c \
	$(LRC)/vfs/vfs_implementation.c \
	$(LRC)/compat/compat_strcasestr.c \
	$(LRC)/compat/compat_posix_string.c \
	$(LRC)/compat/compat_strl.c \
	$(LRC)/compat/compat_snprintf.c \
	$(LRC)/compat/fopen_utf8.c \
	$(LRC)/string/stdstring.c \
	$(LRC)/string/rstrtod.c \
	$(LRC)/file/file_path.c \
	$(LRC)/file/file_path_io.c \
	$(LRC)/file/retro_dirent.c \
	$(LRC)/lists/dir_list.c \
	$(LRC)/lists/string_list.c \
	$(LRC)/memmap/memalign.c \
	$(LRC)/time/rtime.c \
	$(LRC)/rthreads/rthreads.c \
	$(LRC)/rthreads/retro_eventcount.c \
	$(LRC)/queues/retro_spsc.c \
	$(LRC)/streams/chd_stream.c \
	$(LRC)/formats/chd/rchd.c \
	$(LRC)/encodings/encoding_huffman.c \
	$(LRC)/encodings/encoding_rzstd.c \
	$(LRC)/encodings/encoding_xxh64.c \
	$(LRC)/vfs/vfs_prefetch.c \
	$(LRC)/formats/7z/r7z_lzma.c \
	$(LRC)/formats/flac/rflac.c

OPERA_DEFS := \
	-D__LIBRETRO__ -DHAVE_STDINT_H -DHAVE_STDLIB_H -DHAVE_SYS_PARAM_H \
	-DINLINE=inline -DTHREADED_DSP -DHAVE_THREADS \
	-DHAVE_CHD -DHAVE_RCHD -DHAVE_RCHD_DEFLATE -DHAVE_RCHD_LZMA \
	-DHAVE_RCHD_FLAC -DHAVE_RCHD_ZSTD -DHAVE_RFLAC -DNDEBUG

# warnings the upstream project also silences
OPERA_WARN := -Wno-sign-compare -Wno-unused-variable -Wno-unused-function \
	-Wno-uninitialized -Wno-strict-aliasing -Wno-overflow -fno-strict-overflow \
	-Wno-unused-but-set-variable -Wno-misleading-indentation -Wno-implicit-fallthrough

# The frontend's own translation units that need the core's headers
OPERA_FRONT_SRCS := $(ROOT)/src/opera_hooks.c
