#include "audio.h"
#include "log.h"
#include "platform.h"

#include <SDL.h>
#include <math.h>

#define OUT_RATE 48000
#define RING_FRAMES 16384            /* power of two, ~340 ms */
#define RING_MASK (RING_FRAMES - 1)
#define DEVICE_SAMPLES 1024

static SDL_AudioDeviceID g_dev;
static bool g_ok;
static int16_t g_ring[RING_FRAMES * 2];
static uint32_t g_wr, g_rd;          /* free-running, atomics */
static uint32_t g_volume = 100;      /* atomic */
static uint32_t g_target = OUT_RATE * 80 / 1000;
static uint32_t g_underruns;
static bool g_started;               /* the first fill avoids counting an underrun */

static double g_step = 44100.0 / OUT_RATE;
static double g_pos = 1.0;
static int16_t g_carry[4 * 2];

static void SDLCALL audio_cb(void *ud, Uint8 *stream, int len)
{
    int16_t *out = (int16_t *)stream;
    uint32_t need = (uint32_t)len / 4;
    uint32_t wr = __atomic_load_n(&g_wr, __ATOMIC_ACQUIRE);
    uint32_t rd = g_rd;
    uint32_t avail = wr - rd;
    uint32_t n = avail < need ? avail : need;
    int vol = (int)__atomic_load_n(&g_volume, __ATOMIC_RELAXED);
    (void)ud;

    for (uint32_t i = 0; i < n; i++) {
        uint32_t idx = (rd + i) & RING_MASK;
        int l = g_ring[idx * 2], r = g_ring[idx * 2 + 1];
        if (vol != 100) {
            l = l * vol / 100;
            r = r * vol / 100;
        }
        out[i * 2] = (int16_t)l;
        out[i * 2 + 1] = (int16_t)r;
    }
    if (n < need) {
        memset(out + n * 2, 0, (need - n) * 4);
        if (g_started)
            __atomic_fetch_add(&g_underruns, 1, __ATOMIC_RELAXED);
    }
    __atomic_store_n(&g_rd, rd + n, __ATOMIC_RELEASE);
}

bool audio_init(int latency_ms)
{
    SDL_AudioSpec want, have;

    if (g_ok)
        return true;
    if (SDL_InitSubSystem(SDL_INIT_AUDIO) != 0) {
        LOGE("audio subsystem: %s", SDL_GetError());
        return false;
    }
    SDL_zero(want);
    want.freq = OUT_RATE;
    want.format = AUDIO_S16SYS;
    want.channels = 2;
    want.samples = DEVICE_SAMPLES;
    want.callback = audio_cb;
    g_dev = SDL_OpenAudioDevice(NULL, 0, &want, &have, 0);
    if (!g_dev) {
        LOGE("cannot open audio device: %s", SDL_GetError());
        return false;
    }
    LOGI("audio: %d Hz, %d ch, %d samples buffer (driver %s)", have.freq, have.channels, have.samples,
         SDL_GetCurrentAudioDriver() ? SDL_GetCurrentAudioDriver() : "?");
    g_ok = true;
    audio_set_latency(latency_ms);
    SDL_PauseAudioDevice(g_dev, 1);
    return true;
}

void audio_shutdown(void)
{
    if (g_dev)
        SDL_CloseAudioDevice(g_dev);
    g_dev = 0;
    g_ok = false;
}

bool audio_available(void) { return g_ok; }

void audio_set_input_rate(double hz)
{
    if (hz > 8000.0 && hz < 96000.0)
        g_step = hz / OUT_RATE;
}

void audio_set_volume(int percent)
{
    __atomic_store_n(&g_volume, (uint32_t)CLAMP(percent, 0, 100), __ATOMIC_RELAXED);
}

void audio_set_latency(int ms)
{
    ms = CLAMP(ms, 30, 250);
    /* never below two device periods, or the callback starves */
    uint32_t frames = (uint32_t)ms * OUT_RATE / 1000;
    if (frames < DEVICE_SAMPLES * 2)
        frames = DEVICE_SAMPLES * 2;
    if (frames > RING_FRAMES - 2048)
        frames = RING_FRAMES - 2048;
    __atomic_store_n(&g_target, frames, __ATOMIC_RELAXED);
}

/* Catmull-Rom cubic between p1 and p2 */
static inline float cubic(float p0, float p1, float p2, float p3, float t)
{
    float a = -0.5f * p0 + 1.5f * p1 - 1.5f * p2 + 0.5f * p3;
    float b = p0 - 2.5f * p1 + 2.0f * p2 - 0.5f * p3;
    float c = -0.5f * p0 + 0.5f * p2;
    return ((a * t + b) * t + c) * t + p1;
}

static inline int16_t clip16(float v)
{
    if (v > 32767.0f) return 32767;
    if (v < -32768.0f) return -32768;
    return (int16_t)lrintf(v);
}

size_t audio_push(const int16_t *frames, size_t n)
{
    int16_t *tmp;
    size_t total, produced = 0;
    uint32_t wr, rd, room;

    if (!g_ok || n == 0)
        return n;

    total = 4 + n;
    tmp = (int16_t *)malloc(total * 2 * sizeof(int16_t));
    if (!tmp)
        return n;
    memcpy(tmp, g_carry, sizeof(g_carry));
    memcpy(tmp + 8, frames, n * 2 * sizeof(int16_t));

    wr = g_wr;
    rd = __atomic_load_n(&g_rd, __ATOMIC_ACQUIRE);
    room = RING_FRAMES - (wr - rd);

    while ((size_t)g_pos + 2 < total) {
        size_t i1 = (size_t)g_pos;
        float t = (float)(g_pos - (double)i1);
        g_pos += g_step;
        if (produced >= room) /* ring full: drop (only happens when not paced) */
            continue;
        {
            const int16_t *a = tmp + (i1 - 1) * 2;
            uint32_t idx = (wr + (uint32_t)produced) & RING_MASK;
            g_ring[idx * 2] = clip16(cubic(a[0], a[2], a[4], a[6], t));
            g_ring[idx * 2 + 1] = clip16(cubic(a[1], a[3], a[5], a[7], t));
        }
        produced++;
    }
    g_pos -= (double)(total - 4);
    memcpy(g_carry, tmp + (total - 4) * 2, sizeof(g_carry));
    free(tmp);

    __atomic_store_n(&g_wr, wr + (uint32_t)produced, __ATOMIC_RELEASE);
    g_started = true;
    return n;
}

int audio_buffered_frames(void)
{
    return (int)(__atomic_load_n(&g_wr, __ATOMIC_ACQUIRE) - __atomic_load_n(&g_rd, __ATOMIC_ACQUIRE));
}

int audio_target_frames(void)
{
    return (int)__atomic_load_n(&g_target, __ATOMIC_RELAXED);
}

bool audio_wait_for_room(int max_ms)
{
    uint64_t start = platform_time_us();
    while (audio_buffered_frames() > audio_target_frames()) {
        if ((int)((platform_time_us() - start) / 1000) >= max_ms)
            return false;
        platform_sleep_ms(1);
    }
    return true;
}

void audio_pause(bool paused)
{
    if (g_dev)
        SDL_PauseAudioDevice(g_dev, paused ? 1 : 0);
}

void audio_flush(void)
{
    if (g_dev)
        SDL_LockAudioDevice(g_dev);
    __atomic_store_n(&g_rd, __atomic_load_n(&g_wr, __ATOMIC_ACQUIRE), __ATOMIC_RELEASE);
    memset(g_carry, 0, sizeof(g_carry));
    g_pos = 1.0;
    g_started = false;
    if (g_dev)
        SDL_UnlockAudioDevice(g_dev);
}

unsigned audio_underruns(void)
{
    return __atomic_load_n(&g_underruns, __ATOMIC_RELAXED);
}
