#!/usr/bin/env python3
"""Look inside an Aroma .wuhb package and check that it says what it should.

    python3 tools/check_wuhb.py OperaU.wuhb                 # list the contents and run the checks
    python3 tools/check_wuhb.py OperaU.wuhb --extract DIR   # also unpack every file into DIR
    python3 tools/check_wuhb.py OperaU.wuhb --version 0.2.1 # expect a version other than the one in src/common.h

Exit status 0 = every check passed.

Why this exists: up to 0.2.0 the Makefile set the package name, author and icon *after* wut_rules had been read, so
the .wuhb silently came out with the default name "OperaU", the default author "Built with devkitPPC & wut", no
version, no icon and no splash screens - and nothing complained. This script is the guard against that: it reads the
package the way Aroma does (WUHB = a small romfs: header, directory/file tables, data) and checks

  * meta/meta.ini  : longname is "Opera U <version>", shortname "Opera U", author is not wut's default
  * meta/iconTex.tga.gz, bootTvTex.tga.gz, bootDrcTex.tga.gz : present, valid TGAs of 128x128, 1280x720, 854x480
  * code/root.rpx  : a PowerPC big-endian ELF (RPX) whose own text contains the same version and exactly one build
                     stamp (RPX sections are zlib-compressed, so a plain "strings" on the file finds nothing)

WUHB layout (all big endian): "WUHB", header size (0x50), then nine 64-bit values: directory-hash table
offset/size, directory table offset/size, file-hash table offset/size, file table offset/size, file data offset.
A directory entry is parent, sibling, first child dir, first file, next-in-hash, name length (6 x u32) + the name
padded to 4 bytes; a file entry is parent, sibling, offset (u64), size (u64), next-in-hash, name length + the name.
0xFFFFFFFF means "none".
"""
import argparse
import gzip
import os
import re
import struct
import sys
import zlib

NONE = 0xFFFFFFFF
WUT_DEFAULT_AUTHOR = "Built with devkitPPC & wut"


def parse_wuhb(data):
    """Return {path: bytes} for every file in the package."""
    if data[:4] != b"WUHB":
        raise ValueError("not a WUHB file (magic is %r)" % data[:4])
    hdr_size = struct.unpack_from(">I", data, 4)[0]
    if hdr_size != 0x50:
        raise ValueError("unexpected WUHB header size 0x%x" % hdr_size)
    (_dh_off, _dh_sz, dt_off, dt_sz, _fh_off, _fh_sz, ft_off, ft_sz, data_off) = struct.unpack_from(">9Q", data, 8)
    dirs = data[dt_off:dt_off + dt_sz]
    files = data[ft_off:ft_off + ft_sz]

    def dir_entry(off):
        parent, sibling, child, first_file, _h, nlen = struct.unpack_from(">6I", dirs, off)
        name = dirs[off + 24:off + 24 + nlen].decode("utf-8")
        return parent, sibling, child, first_file, name

    def file_entry(off):
        parent, sibling, foff, fsize, _h, nlen = struct.unpack_from(">IIQQII", files, off)
        name = files[off + 32:off + 32 + nlen].decode("utf-8")
        return sibling, foff, fsize, name

    out = {}

    def walk(doff, prefix):
        _parent, _sib, child, first_file, _name = dir_entry(doff)
        f = first_file
        while f != NONE:
            sib, foff, fsize, name = file_entry(f)
            if data_off + foff + fsize > len(data):
                raise ValueError("file %s%s runs past the end of the package" % (prefix, name))
            out[prefix + name] = data[data_off + foff:data_off + foff + fsize]
            f = sib
        c = child
        while c != NONE:
            _p, csib, _cc, _cf, cname = dir_entry(c)
            walk(c, prefix + cname + "/")
            c = csib

    walk(0, "")
    return out


def rpx_text(rpx):
    """Decompress every section of an RPX (ELF32 big endian, sections flagged 0x08000000 are zlib) and join them."""
    if rpx[:4] != b"\x7fELF":
        raise ValueError("code/root.rpx is not an ELF file")
    ei_class, ei_data = rpx[4], rpx[5]
    e_machine = struct.unpack_from(">H", rpx, 0x12)[0]
    if (ei_class, ei_data, e_machine) != (1, 2, 20):
        raise ValueError("code/root.rpx is not a 32-bit big-endian PowerPC ELF (%d,%d,%d)" % (ei_class, ei_data, e_machine))
    shoff = struct.unpack_from(">I", rpx, 0x20)[0]
    shentsize, shnum = struct.unpack_from(">HH", rpx, 0x2E)
    chunks = []
    for i in range(shnum):
        (_name, typ, flags, _addr, off, size, _link, _info, _align, _entsize) = struct.unpack_from(
            ">10I", rpx, shoff + i * shentsize)
        if typ in (0, 8) or size == 0:          # NULL, NOBITS
            continue
        raw = rpx[off:off + size]
        if flags & 0x08000000:                   # SHF_RPL_ZLIB
            want = struct.unpack_from(">I", raw, 0)[0]
            raw = zlib.decompress(raw[4:])
            if len(raw) != want:
                raise ValueError("section %d decompressed to %d bytes, header says %d" % (i, len(raw), want))
        chunks.append(raw)
    return b"".join(chunks)


TGA_FOOTER_SIGNATURE = b"TRUEVISION-XFILE.\x00"


def tga_size(blob):
    """Checks the TGA the way the Wii U menu needs it and returns its size and depth.

    The footer matters: the console's reader needs the 26-byte TGA 2.0 footer, and without it the menu shows the
    app as unrecognised (this is what went wrong in 0.2.3). The official wuhbtool writes it through FreeImage;
    the FreeImage-free build used here writes it in tools/wut-tools-tga-only.patch."""
    if len(blob) < 18:
        raise ValueError("too short to be a TGA")
    id_len, cm_type, im_type = blob[0], blob[1], blob[2]
    w, h = struct.unpack_from("<HH", blob, 12)
    bpp = blob[16]
    if (cm_type, im_type) != (0, 2):
        raise ValueError("not an uncompressed true-colour TGA (colour map %d, type %d)" % (cm_type, im_type))
    pixels_end = 18 + id_len + w * h * (bpp // 8)
    if len(blob) != pixels_end + 26:
        raise ValueError("expected %d bytes (pixels + 26-byte TGA 2.0 footer), got %d" % (pixels_end + 26, len(blob)))
    if blob[-18:] != TGA_FOOTER_SIGNATURE:
        raise ValueError("the 26-byte TGA 2.0 footer is missing; the Wii U menu will not read this image")
    return w, h, bpp


def read_version_from_source():
    here = os.path.dirname(os.path.abspath(__file__))
    with open(os.path.join(here, "..", "src", "common.h"), encoding="utf-8") as f:
        m = re.search(r'^#define\s+APP_VERSION\s+"([^"]+)"', f.read(), re.M)
    if not m:
        raise SystemExit("could not find APP_VERSION in src/common.h")
    return m.group(1)


def main():
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("wuhb")
    ap.add_argument("--version", help="expected version (default: APP_VERSION from src/common.h)")
    ap.add_argument("--extract", metavar="DIR", help="unpack every file of the package into DIR")
    ap.add_argument("--no-art", action="store_true",
                    help="expect a package built with NOART=1: no icon and no splash screens")
    args = ap.parse_args()

    version = args.version or read_version_from_source()
    with open(args.wuhb, "rb") as f:
        raw = f.read()
    files = parse_wuhb(raw)

    print("%s  (%d bytes, %d files)" % (args.wuhb, len(raw), len(files)))
    for path in sorted(files):
        print("  %-28s %9d bytes" % (path, len(files[path])))

    if args.extract:
        for path, blob in files.items():
            dest = os.path.join(args.extract, path)
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            with open(dest, "wb") as f:
                f.write(blob)
        print("unpacked into %s" % args.extract)

    failures = []

    def check(ok, what):
        print("  [%s] %s" % ("ok" if ok else "FAIL", what))
        if not ok:
            failures.append(what)

    print("checks (expected version %s):" % version)

    # ---- meta.ini -------------------------------------------------------------------------------------------
    meta = {}
    if "meta/meta.ini" in files:
        section = None
        for line in files["meta/meta.ini"].decode("utf-8", "replace").splitlines():
            line = line.strip()
            if line.startswith("[") and line.endswith("]"):
                section = line[1:-1]
            elif "=" in line and section == "menu":
                k, v = line.split("=", 1)
                meta[k.strip()] = v.strip()
    check("meta/meta.ini" in files, "meta/meta.ini is present")
    check(meta.get("longname") == "Opera U " + version,
          "longname is 'Opera U %s' (found %r)" % (version, meta.get("longname")))
    check(meta.get("shortname") == "Opera U", "shortname is 'Opera U' (found %r)" % meta.get("shortname"))
    check(bool(meta.get("author")) and meta.get("author") != WUT_DEFAULT_AUTHOR,
          "author is set and is not wut's default (found %r)" % meta.get("author"))

    # ---- icon and splash screens ----------------------------------------------------------------------------
    for name, want in (("meta/iconTex.tga.gz", (128, 128)),
                       ("meta/bootTvTex.tga.gz", (1280, 720)),
                       ("meta/bootDrcTex.tga.gz", (854, 480))):
        if args.no_art:
            check(name not in files, "%s is absent, as asked (NOART=1)" % name)
            continue
        if name not in files:
            check(False, "%s is present" % name)
            continue
        try:
            w, h, bpp = tga_size(gzip.decompress(files[name]))
            check((w, h) == want, "%s is a %dx%d TGA (%d bpp), expected %dx%d" % (name, w, h, bpp, want[0], want[1]))
        except Exception as e:  # noqa: BLE001 - report anything malformed as a failed check
            check(False, "%s is a valid gzip'd TGA (%s)" % (name, e))

    # ---- the program itself ---------------------------------------------------------------------------------
    if "code/root.rpx" not in files:
        check(False, "code/root.rpx is present")
    else:
        try:
            text = rpx_text(files["code/root.rpx"])
            check(True, "code/root.rpx is a PowerPC big-endian RPX (%d bytes once decompressed)" % len(text))
            check(("v" + version).encode() in text, "the program contains the on-screen text 'v%s'" % version)
            m = re.search(rb"Opera U " + re.escape(version.encode()) + rb"[^\x00]{0,40}", text)
            check(bool(m) or (b"Opera U" in text), "the program contains its own name/version text")
            seen = set(re.findall(rb"\b(\d+\.\d+\.\d+)\b", b" ".join(re.findall(rb"Opera U [0-9.]+", text))))
            other = sorted(x.decode() for x in seen - {version.encode()})
            check(not other, "no other 'Opera U x.y.z' version string inside (found %s)" % (other or "none"))
            stamps = sorted(set(m.decode() for m in re.findall(rb"\d{4}-\d\d-\d\d \d\d:\d\d UTC", text)))
            check(len(stamps) == 1, "the program carries exactly one build stamp, the same in every file (found %s)" %
                  (stamps or "none"))
        except Exception as e:  # noqa: BLE001
            check(False, "code/root.rpx can be read (%s)" % e)

    if failures:
        print("%d check(s) FAILED" % len(failures))
        return 1
    print("all checks passed")
    return 0


if __name__ == "__main__":
    sys.exit(main())
