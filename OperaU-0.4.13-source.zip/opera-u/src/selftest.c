#include "selftest.h"
#include "app.h"
#include "audio.h"
#include "config.h"
#include "core.h"
#include "coretest.h"
#include "cdtest.h"
#include "deeptest.h"
#include "diag.h"
#include "i18n.h"
#include "input.h"
#include "log.h"
#include "platform.h"
#include "session.h"
#include "testpat.h"
#include "ui.h"
#include "video.h"

#include "../third_party/opera-libretro/libopera/opera_dsp.h"
#include "../third_party/opera-libretro/libopera/opera_madam.h"
#include "../third_party/opera-libretro/libopera/prng16.h"
#include "../third_party/opera-libretro/libopera/prng32.h"
#include "../third_party/opera-libretro/opera_lr_dsp.h"

#include <SDL.h>
#include <dirent.h>

static int g_fail;

#define CHECK(cond, ...)                                                                                              \
    do {                                                                                                              \
        if (cond) {                                                                                                   \
            printf("  PASS  ");                                                                                       \
        } else {                                                                                                      \
            printf("  FAIL  ");                                                                                       \
            g_fail++;                                                                                                 \
        }                                                                                                             \
        printf(__VA_ARGS__);                                                                                          \
        printf("\n");                                                                                                 \
    } while (0)

static const char *arg_value(int argc, char **argv, const char *name)
{
    for (int i = 1; i + 1 < argc; i++)
        if (!strcmp(argv[i], name))
            return argv[i + 1];
    return NULL;
}

static bool has_flag(int argc, char **argv, const char *name)
{
    for (int i = 1; i < argc; i++)
        if (!strcmp(argv[i], name))
            return true;
    return false;
}

static void headless_env(void)
{
    setenv("SDL_VIDEODRIVER", "dummy", 0);
    setenv("SDL_AUDIODRIVER", "dummy", 0);
    if (!getenv("OPERAU_HOME"))
        setenv("OPERAU_HOME", "./data-test", 0);
}

/* ------------------------------------------------------------ core only */

static void nullv(const void *d, unsigned w, unsigned h, size_t p, core_pixel_format_t f) {}
static size_t nulla(const int16_t *f, size_t n) { return n; }

static int test_core(int argc, char **argv)
{
    const char *image = arg_value(argc, argv, "--image");
    const char *fr = arg_value(argc, argv, "--frames");
    int frames = fr ? atoi(fr) : CORETEST_REF_FRAMES;
    core_sink_t sink = {nullv, nulla};
    coretest_result_t r;
    double expect;

    const char *dump = arg_value(argc, argv, "--dump-frame");
    const char *trace = arg_value(argc, argv, "--trace");
    const char *memdump = arg_value(argc, argv, "--dump-mem");

    printf("== core test (%s) ==\n", image ? image : "Opera Boot, no disc");
    config_load();
    CHECK(core_init(&sink), "core_init");
#ifdef OPERA_ARM_TRACE
    {
        const char *armtrace = arg_value(argc, argv, "--arm-trace");
        const char *from = arg_value(argc, argv, "--from");
        if (armtrace) {
            int f0 = from ? atoi(from) : 0;
            printf("armtrace frames %d..%d -> %s: %s\n", f0, frames, armtrace,
                   coretest_armtrace(image, f0, frames, armtrace) ? "ok" : "FAILED");
            core_deinit();
            return 0;
        }
    }
#endif
    {
        const char *cdhash = arg_value(argc, argv, "--cdhash");
        if (cdhash) {
            bool ok = cdtest_hash(cdhash);
            core_deinit();
            return ok ? 0 : 2;
        }
    }
    {
        const char *deep = arg_value(argc, argv, "--deep");
        if (deep) {
            const char *tr = arg_value(argc, argv, "--trials");
            const char *sd = arg_value(argc, argv, "--seed");
            bool ok = deeptest_run(deep, sd ? (uint32_t)strtoul(sd, NULL, 0) : 12345u, tr ? atoi(tr) : 1000);
            core_deinit();
            return ok ? 0 : 2;
        }
    }
    if (memdump) {
        printf("mem %d frames -> %s.{dram,vram}: %s\n", frames, memdump,
               coretest_dump_mem(image, frames, memdump) ? "ok" : "FAILED");
        core_deinit();
        return 0;
    }
    if (trace) {
        printf("trace %d frames -> %s: %s\n", frames, trace, coretest_trace(image, frames, trace) ? "ok" : "FAILED");
        core_deinit();
        return 0;
    }
    if (dump) {
        printf("dump %d frames -> %s: %s\n", frames, dump, coretest_dump_frame(image, frames, dump) ? "ok" : "FAILED");
        core_deinit();
        return 0;
    }
    CHECK(coretest_run(image, frames, &r), "boot%s%s", r.error[0] ? ": " : "", r.error);
    if (!r.loaded) {
        core_deinit();
        return 1;
    }
    printf("  info  %ux%u, %.2f fps, audio %.0f Hz\n", r.width, r.height, r.fps, r.sample_rate);
    expect = (double)frames * r.sample_rate / r.fps;
    CHECK((double)r.audio_frames > expect * 0.9 && (double)r.audio_frames < expect * 1.1,
          "audio frames %u (expected ~%.0f)", r.audio_frames, expect);
    CHECK(r.nonzero_pixels > 0, "picture is not all black (%llu non-zero pixels)", (unsigned long long)r.nonzero_pixels);
    CHECK(r.state_size > 1000000, "state size %zu bytes", r.state_size);
    CHECK(r.state_ok, "state save / load");
    CHECK(r.deterministic, "replay after state load is bit exact (video %016llx, audio %016llx)",
          (unsigned long long)r.replay_video_hash, (unsigned long long)r.replay_audio_hash);
    printf("  info  boot hash after %d frames: video %016llx audio %016llx\n", frames,
           (unsigned long long)r.video_hash, (unsigned long long)r.audio_hash);
    printf("  info  %.2f ms/frame on this host (%.1fx real time)\n", r.ms_per_frame,
           1000.0 / r.fps / r.ms_per_frame);
    if (!image && frames == CORETEST_REF_FRAMES && CORETEST_REF_VIDEO_HASH != 0)
        CHECK(coretest_matches_reference(&r), "boot hash equals the stored x86 reference");
    core_deinit();
    printf("== core test: %s ==\n", g_fail ? "FAILED" : "passed");
    return g_fail ? 1 : 0;
}

/* ---------------------------------------------------------- full app run */

/* ------------------------------------------------------- hotkeys (no SDL) */

#define BT(b) (1u << (b))

static void check_input(void)
{
    const uint32_t L = BT(SDL_CONTROLLER_BUTTON_LEFTSHOULDER), R = BT(SDL_CONTROLLER_BUTTON_RIGHTSHOULDER);
    const uint32_t MINUS = BT(SDL_CONTROLLER_BUTTON_BACK), PLUS = BT(SDL_CONTROLLER_BUTTON_START);
    const uint32_t X = BT(SDL_CONTROLLER_BUTTON_X), A = BT(SDL_CONTROLLER_BUTTON_A), Y = BT(SDL_CONTROLLER_BUTTON_Y);
    const uint32_t DL = BT(SDL_CONTROLLER_BUTTON_DPAD_LEFT), DR = BT(SDL_CONTROLLER_BUTTON_DPAD_RIGHT);
    const uint32_t GUIDE = BT(SDL_CONTROLLER_BUTTON_GUIDE), ZL = 1u << 30, ZR = 1u << 31;
    bool ff;
    unsigned hk;

    printf("-- hotkeys\n");
    /* L and R pressed together open the menu, whatever the order */
    ff = false;
    CHECK(input_pad_hotkeys(0, L | R, true, &ff) == HK_MENU, "L and R in the same poll open the menu");
    CHECK(input_pad_hotkeys(0, L, true, &ff) == 0, "L alone does nothing");
    CHECK(input_pad_hotkeys(L, L | R, true, &ff) == HK_MENU, "L, then R, opens the menu");
    CHECK(input_pad_hotkeys(0, R, true, &ff) == 0, "R alone does nothing");
    CHECK(input_pad_hotkeys(R, L | R, true, &ff) == HK_MENU, "R, then L, opens the menu");
    CHECK(input_pad_hotkeys(L | R, L | R, true, &ff) == 0, "holding L and R does not repeat the menu");
    CHECK(input_pad_hotkeys(L | R, L, true, &ff) == 0, "releasing one of them does nothing");
    CHECK(input_pad_hotkeys(L, L | R, true, &ff) == HK_MENU, "pressing it again toggles the menu again");
    CHECK(input_pad_hotkeys(0, L | R, false, &ff) == 0, "L+R shortcut switched off in the settings");
    CHECK(!ff, "L+R never asks for fast-forward");

    /* ZL and ZR are free: they never raise a hotkey or fast-forward */
    ff = false;
    CHECK(input_pad_hotkeys(0, ZL | ZR, true, &ff) == 0 && !ff, "ZL+ZR do nothing");
    CHECK(input_pad_hotkeys(0, L | ZR, true, &ff) == 0 && !ff, "L+ZR does not open the menu");
    CHECK(input_pad_hotkeys(0, ZL | R, true, &ff) == 0 && !ff, "ZL+R does not open the menu");
    CHECK(input_pad_hotkeys(MINUS, MINUS | ZR, true, &ff) == 0 && !ff, "- + ZR is no longer fast-forward");
    CHECK(input_pad_hotkeys(MINUS, MINUS | ZL, true, &ff) == 0 && !ff, "- + ZL does nothing");

    /* the - (minus) combinations */
    CHECK(input_pad_hotkeys(MINUS, MINUS | PLUS, true, &ff) == HK_MENU, "- and + open the menu");
    CHECK(input_pad_hotkeys(MINUS, MINUS | PLUS, false, &ff) == HK_MENU, "- and + still work with L+R switched off");
    CHECK(input_pad_hotkeys(PLUS, PLUS | MINUS, true, &ff) == 0, "+ then - does not open it (the new press must be +)");
    CHECK(input_pad_hotkeys(MINUS, MINUS | R, true, &ff) == HK_SAVE_STATE, "- and R save the state");
    CHECK(input_pad_hotkeys(MINUS, MINUS | L, true, &ff) == HK_LOAD_STATE, "- and L load the state");
    CHECK(input_pad_hotkeys(MINUS, MINUS | A, true, &ff) == HK_SCREENSHOT, "- and A take a screenshot");
    CHECK(input_pad_hotkeys(MINUS, MINUS | Y, true, &ff) == HK_RESET, "- and Y reset");
    CHECK(input_pad_hotkeys(MINUS, MINUS | DR, true, &ff) == HK_SLOT_NEXT, "- and D-pad right: next slot");
    CHECK(input_pad_hotkeys(MINUS, MINUS | DL, true, &ff) == HK_SLOT_PREV, "- and D-pad left: previous slot");
    hk = input_pad_hotkeys(MINUS, MINUS | L | R, true, &ff);
    CHECK(!(hk & HK_MENU) && (hk & HK_SAVE_STATE) && (hk & HK_LOAD_STATE), "- with L+R is not the menu shortcut");

    /* fast-forward: - held with X held */
    ff = false;
    input_pad_hotkeys(MINUS, MINUS | X, true, &ff);
    CHECK(ff, "- + X fast-forwards");
    ff = false;
    input_pad_hotkeys(X, X, true, &ff);
    CHECK(!ff, "X alone does not fast-forward");
    ff = false;
    input_pad_hotkeys(MINUS, MINUS, true, &ff);
    CHECK(!ff, "- alone does not fast-forward");
    CHECK(input_pad_hotkeys(MINUS, MINUS | X, true, NULL) == 0, "fast-forward query may be omitted");

    /* the second stick pushed right fast-forwards, with no modifier and without touching the other hotkeys */
    ff = false;
    CHECK(input_pad_hotkeys(0, INPUT_HELD_FFSTICK, true, &ff) == 0 && ff, "second stick to the right fast-forwards");
    ff = false;
    CHECK(input_pad_hotkeys(INPUT_HELD_FFSTICK, INPUT_HELD_FFSTICK | L | R, true, &ff) == HK_MENU && ff,
          "the menu shortcut still works while fast-forwarding");
    ff = false;
    CHECK(input_pad_hotkeys(INPUT_HELD_FFSTICK, INPUT_HELD_FFSTICK, false, &ff) == 0 && ff,
          "holding the stick keeps fast-forwarding");
    ff = false;
    CHECK(input_pad_hotkeys(0, ZL | ZR | L, true, &ff) == 0 && !ff, "ZL/ZR do not fast-forward");
    CHECK(input_pad_hotkeys(0, INPUT_HELD_FFSTICK, true, NULL) == 0, "fast-forward query may be omitted (stick)");

    /* HOME */
    /* HOME belongs to the console (it opens the Wii U's own menu); the app must not react to it at all. */
    CHECK(input_pad_hotkeys(0, GUIDE, true, &ff) == 0, "HOME does not open the app menu");
    CHECK(input_pad_hotkeys(GUIDE, GUIDE, true, &ff) == 0, "holding HOME does nothing");
    CHECK(input_pad_hotkeys(0, GUIDE | L | R, true, &ff) == HK_MENU, "L + R still opens the menu while HOME is held");
}

/* The default mapping is the one asked for; a stored mapping from an older version must not win over it. */
static void check_default_map(void)
{
    static const struct { int b3do; int want; const char *name; } k_want[] = {
        {B3DO_A, SDL_CONTROLLER_BUTTON_B, "3DO A -> Wii U B"},
        {B3DO_B, SDL_CONTROLLER_BUTTON_A, "3DO B -> Wii U A"},
        {B3DO_C, PBTN_LTRIG, "3DO C -> Wii U ZL"},
        {B3DO_L, SDL_CONTROLLER_BUTTON_Y, "3DO L -> Wii U Y"},
        {B3DO_R, PBTN_RTRIG, "3DO R -> Wii U ZR"},
        {B3DO_P, SDL_CONTROLLER_BUTTON_X, "3DO P -> Wii U X"},
        {B3DO_X, SDL_CONTROLLER_BUTTON_START, "3DO X -> Wii U +"},
    };
    int map[B3DO_COUNT];
    char path[1100];

    input_default_map(map);
    for (size_t i = 0; i < ARRAY_LEN(k_want); i++)
        CHECK(map[k_want[i].b3do] == k_want[i].want, "default mapping: %s", k_want[i].name);
    /* the Wii U's own shoulder buttons stay free, which is what the L + R menu shortcut needs */
    for (int b = 0; b < B3DO_COUNT; b++)
        CHECK(map[b] != SDL_CONTROLLER_BUTTON_LEFTSHOULDER && map[b] != SDL_CONTROLLER_BUTTON_RIGHTSHOULDER,
              "default mapping leaves L and R free (3DO %s)", input_3do_name(b));

    /* a config written by an older version keeps its own mapping out of the way */
    config_load(); /* creates the folders the file below goes into */
    config_path(path, sizeof(path), "config/operau.ini");
    {
        static const char old_ini[] = "map.a=3\nmap.b=2\nmap.c=1\nmap.l=9\nmap.r=10\nmap.x=2\nmap.p=6\n";

        CHECK(platform_write_file_atomic(path, old_ini, sizeof(old_ini) - 1), "an old config file is in place");
        config_load();
        CHECK(g_cfg.button_map[B3DO_A] == SDL_CONTROLLER_BUTTON_B &&
              g_cfg.button_map[B3DO_C] == PBTN_LTRIG,
              "a mapping stored before the current default is replaced by it");
        platform_remove(path);
    }
}

static int test_input(void)
{
    check_input();
    check_default_map();
    printf("== hotkeys: %s ==\n", g_fail ? "FAILED" : "all passed");
    return g_fail ? 1 : 0;
}

static int count_files(const char *dir)
{
    int n = 0;
    DIR *d = opendir(dir);
    struct dirent *e;
    if (!d)
        return 0;
    while ((e = readdir(d)))
        if (e->d_name[0] != '.')
            n++;
    closedir(d);
    return n;
}

static void spin(double seconds)
{
    uint64_t end = platform_time_us() + (uint64_t)(seconds * 1e6);
    while (platform_time_us() < end)
        if (!app_frame())
            break;
}

/*
 * The DSP on a thread of its own, and then a DSP program that can never end written over the one that is
 * running - what a game's sound code can leave the DSP looking at for a moment while it rewrites its program,
 * if the thread is caught in the middle. On the console this once stopped a game at a black screen: the thread
 * never came back from that run, so no more sound was made, the game waited for the DSP for ever, the emulation
 * ran at twice its speed because it paces itself by the sound, and closing the game waited for the thread.
 */
static int test_dspthread(void)
{
    ui_action_t act;
    ui_hud_t hud;
    opera_lr_dsp_thread_stats_t a, b, c;
    uint32_t under0;

    printf("== the DSP on its own thread, and a program that never sleeps ==\n");
    if (!app_init()) {
        printf("  FAIL  app_init\n");
        return 1;
    }
    kv_set(&g_core_opts_global, "opera_dsp_threaded", "enabled");
    memset(&act, 0, sizeof(act));
    act.type = UIA_LAUNCH_BIOS;
    app_dispatch(&act);
    CHECK(app_mode() == APP_PLAYING, "the BIOS started (%s)", session_error());
    if (app_mode() != APP_PLAYING) {
        app_shutdown();
        return 1;
    }
    spin(2.0);
    CHECK(opera_lr_dsp_is_threaded(), "the DSP runs on its own thread");
    opera_lr_dsp_thread_stats(&a);
    spin(1.0);
    opera_lr_dsp_thread_stats(&b);
    CHECK(b.ticks_run - a.ticks_run > 30000, "the thread runs the DSP's ticks (%llu in a second)",
          (unsigned long long)(b.ticks_run - a.ticks_run));

    /* the wreck: a jump to itself where the program starts */
    opera_dsp_set_running(1);
    opera_dsp_mem_write(0, 0x8400);
    under0 = audio_underruns();
    spin(3.0);
    opera_lr_dsp_thread_stats(&c);
    session_hud(&hud);
    CHECK(c.ticks_run - b.ticks_run > 90000, "the thread keeps running ticks through a program that never ends (%llu in 3 s)",
          (unsigned long long)(c.ticks_run - b.ticks_run));
    CHECK(hud.emu_fps > 50.0f && hud.emu_fps < 70.0f, "the emulation keeps its pace (%.1f fps)", (double)hud.emu_fps);
    CHECK(audio_underruns() - under0 < 20, "sound keeps arriving (%u gaps in 3 s)", audio_underruns() - under0);

    memset(&act, 0, sizeof(act));
    act.type = UIA_CLOSE_GAME;
    app_dispatch(&act);
    CHECK(app_mode() == APP_HOME && !session_active(), "the game closes");
    app_shutdown();
    kv_set(&g_core_opts_global, "opera_dsp_threaded", "disabled");
    printf("== DSP thread: %s ==\n", g_fail ? "FAILED" : "passed");
    return g_fail ? 1 : 0;
}

static int test_run(int argc, char **argv)
{
    const char *image = arg_value(argc, argv, "--image");
    const char *sec = arg_value(argc, argv, "--seconds");
    double seconds = sec ? atof(sec) : 4.0;
    ui_action_t act;
    ui_hud_t hud;
    char dir[1100];
    uint32_t under0;

    printf("== full app run (%s) ==\n", image ? image : "Opera Boot, no disc");
    check_input();
    if (!app_init()) {
        printf("  FAIL  app_init\n");
        return 1;
    }
    CHECK(app_mode() == APP_HOME, "starts on the home screen");

    /* bad inputs must produce an error box and leave us on the home screen */
    {
        static const struct { const char *name; size_t size; const char *what; } bad[] = {
            {"missing.chd", 0, "missing file"},
            {"empty.iso", 0, "empty ISO"},
            {"tiny.bin", 1000, "truncated BIN"},
            {"garbage.chd", 8192, "corrupt CHD"},
        };
        for (size_t i = 0; i < ARRAY_LEN(bad); i++) {
            char f[1200];
            uint8_t *junk = (uint8_t *)calloc(1, bad[i].size + 1);
            for (size_t k = 0; k < bad[i].size; k++)
                junk[k] = (uint8_t)(k * 2654435761u >> 13);
            path_join(f, sizeof(f), platform_data_dir(), bad[i].name);
            if (i > 0)
                platform_write_file_atomic(f, junk, bad[i].size);
            free(junk);
            memset(&act, 0, sizeof(act));
            act.type = UIA_LAUNCH;
            str_copy(act.path, f, sizeof(act.path));
            app_dispatch(&act);
            CHECK(app_mode() == APP_HOME && ui_message_active() && !session_active(), "%s -> error box, still on home",
                  bad[i].what);
            ui_open(UI_HOME, NULL);
        }
    }

    memset(&act, 0, sizeof(act));
    act.type = image ? UIA_LAUNCH : UIA_LAUNCH_BIOS;
    if (image)
        str_copy(act.path, image, sizeof(act.path));
    app_dispatch(&act);
    CHECK(app_mode() == APP_PLAYING, "game started (%s)", session_error());
    CHECK(session_running(), "emulation thread running");
    if (app_mode() != APP_PLAYING) {
        app_shutdown();
        return 1;
    }

    under0 = 0;
    spin(seconds * 0.25);
    session_hud(&hud);
    printf("  info  after %.1fs: emu %.1f fps, video %.1f fps, audio buffer %d ms\n", seconds * 0.25, (double)hud.emu_fps,
           (double)hud.video_fps, hud.audio_ms);

    app_hotkeys(HK_SAVE_STATE);
    CHECK(session_state_exists(g_cfg.state_slot), "quick save wrote slot %d", g_cfg.state_slot);
    spin(0.3);
    app_hotkeys(HK_LOAD_STATE);
    CHECK(session_running(), "still running after quick load");
    spin(0.3);

    app_hotkeys(HK_SLOT_NEXT);
    CHECK(g_cfg.state_slot == 1, "slot advanced to 1");
    app_hotkeys(HK_SLOT_PREV);
    app_hotkeys(HK_SLOT_PREV);
    CHECK(g_cfg.state_slot == 9, "slot wraps to 9");
    app_hotkeys(HK_SLOT_NEXT);

    path_join(dir, sizeof(dir), platform_data_dir(), "shots");
    app_hotkeys(HK_SCREENSHOT);
    CHECK(count_files(dir) >= 1, "screenshot written to %s", dir);

    app_hotkeys(HK_MENU);
    CHECK(app_mode() == APP_PAUSED, "menu opens");
    CHECK(!session_running(), "emulation parked while the menu is open");
    spin(0.3);
    memset(&act, 0, sizeof(act));
    act.type = UIA_SAVE_STATE;
    app_dispatch(&act);
    act.type = UIA_RESET;
    app_dispatch(&act);
    CHECK(app_mode() == APP_PLAYING && session_running(), "reset from the menu resumes the game");

    spin(seconds * 0.4);
    session_hud(&hud);
    CHECK(hud.emu_fps > 50.0f && hud.emu_fps < 70.0f, "emulation speed %.1f fps (audio paced, target ~60)",
          (double)hud.emu_fps);
    (void)under0;

    if (seconds >= 8.0) { /* long enough for one window of the profiler (perf.c): its summary reaches the HUD */
        memset(&act, 0, sizeof(act));
        act.type = UIA_SETTINGS_CHANGED;
        g_cfg.show_fps = true;
        app_dispatch(&act);
        spin(6.5);
        session_hud(&hud);
        printf("  info  profiler: \"%s\"\n", hud.perf);
        CHECK(hud.perf[0] != '\0' && strstr(hud.perf, "ARM") && strstr(hud.perf, "DSP"), "the profiler produced its summary");
        CHECK(strstr(hud.perf, "| game ") != NULL, "and it says how many pictures a second the game itself presents");

        /* Pausing writes the report of the last full window to the card there and then: closing a game in the
           middle of a scene is how a scene gets measured, and the file used to be up to twenty seconds old. */
        {
            char f[1100], *txt;
            size_t len = 0;

            path_join(f, sizeof(f), platform_data_dir(), "perf.txt");
            session_pause();
            txt = (char *)platform_read_file(f, &len);
            CHECK(txt != NULL && len > 200, "with the game paused the report is on the card (%u bytes)", (unsigned)len);
            free(txt);
            /* and one that only exists in memory - reports go to the card on their own once in twenty seconds -
               is written by the pause itself */
            session_resume();
            remove(f);
            spin(5.6);
            len = 0;
            session_pause();
            txt = (char *)platform_read_file(f, &len);
            CHECK(txt != NULL && len > 200, "pausing the game writes the latest report (%u bytes)", (unsigned)len);
            if (txt) {
                char *copy = (char *)malloc(len + 1);

                if (copy) {
                    memcpy(copy, txt, len);
                    copy[len] = '\0';
                    CHECK(strstr(copy, "last 5 seconds:") != NULL && strstr(copy, "  ARM  ") != NULL,
                          "with where the time of a frame went");
                    CHECK(strstr(copy, "the game:       ") != NULL && strstr(copy, " pictures a second, of the ") != NULL,
                          "the game's own pace beside the emulation's");
                    CHECK(strstr(copy, "  cel engine    busy ") != NULL && strstr(copy, "at 9 million pixels a second") != NULL,
                          "how much of the machine's time the cel engine was busy, and at what speed it is set");
                    CHECK(strstr(copy, "  disc          ") != NULL && strstr(copy, "longest read") != NULL,
                          "and what reading the disc cost");
                    CHECK(strstr(copy, "this report:    the last write of this file took ") != NULL &&
                              strstr(copy, "  the log       its lines cost ") != NULL,
                          "and what the reporting itself cost");
                    printf("%s", copy);
                    free(copy);
                }
                free(txt);
            }
            session_resume();
            spin(0.5);
            CHECK(app_mode() == APP_PLAYING && session_running(), "and the game goes on after it");
        }

        /* The cel engine's speed is a core option like the CD's: listed, stock unless changed, and with the engine
           as soon as it is changed with a game running. */
        {
            static const struct { const char *value; uint32_t rate; } set[] = {
                {"16M", 16000000u}, {"unbounded", 0u}, {"12M", 12000000u}, {"9M", 9000000u}};
            const core_opt_t *o = core_opt_find("opera_madam_cel_rate");

            CHECK(o != NULL && o->nvals == 4, "the cel engine's speed is among the core options, with four values");
            CHECK(opera_madam_cel_rate_get() == 9000000u, "the engine runs at the stock 9 million pixels a second");
            for (size_t i = 0; i < sizeof(set) / sizeof(set[0]); i++) {
                session_pause();
                kv_set(&g_core_opts_global, "opera_madam_cel_rate", set[i].value);
                core_opts_changed();
                session_resume();
                spin(0.4);
                CHECK(opera_madam_cel_rate_get() == set[i].rate, "set to \"%s\" with a game running: the engine has %u",
                      set[i].value, (unsigned)opera_madam_cel_rate_get());
            }
            session_pause();
            kv_remove(&g_core_opts_global, "opera_madam_cel_rate");
            core_opts_changed();
            session_resume();
            spin(0.3);
            CHECK(opera_madam_cel_rate_get() == 9000000u, "and stock again once the choice is taken back");
        }
        g_cfg.show_fps = false;
        app_dispatch(&act);
    }

    memset(&act, 0, sizeof(act));
    act.type = UIA_CLOSE_GAME;
    app_dispatch(&act);
    CHECK(app_mode() == APP_HOME && !session_active(), "game closed, back on the home screen");
    if (image)
        CHECK(session_autostate_exists(image), "automatic state written on close");
    else
        CHECK(!session_autostate_exists(NULL), "no automatic state for a BIOS-only boot (by design)");

    if (image) {
        memset(&act, 0, sizeof(act));
        act.type = UIA_LAUNCH_RESUME;
        str_copy(act.path, image, sizeof(act.path));
        app_dispatch(&act);
        CHECK(app_mode() == APP_PLAYING && session_resumed(), "relaunch resumed from the automatic state");
        spin(0.5);
        act.type = UIA_CLOSE_GAME;
        app_dispatch(&act);
    }

    /* ---- the core diagnostic, started from the menu ---- */
    {
        char f[1100];
        size_t len = 0;
        char *txt;
        uint64_t t0;
        int done = 0, total = 0;

        /* an override that changes the picture: the diagnostic must ignore it */
        kv_set(&g_core_opts_global, "opera_high_resolution", "enabled");

        /* a report left by an older build (what a player sends by mistake when the new test did not finish) */
        path_join(f, sizeof(f), platform_data_dir(), "diagnostic.txt");
        {
            static const char old_report[] = "Opera U 0.1.0 core diagnostic\nresult:         PASS\n";

            CHECK(platform_write_file_atomic(f, old_report, sizeof(old_report) - 1), "an old report is on the card");
        }

        memset(&act, 0, sizeof(act));
        act.type = UIA_DIAGNOSTIC;
        app_dispatch(&act);
        CHECK(app_mode() == APP_DIAG && diag_running(), "diagnostic starts from the menu action");
        txt = (char *)platform_read_file(f, &len);
        CHECK(txt != NULL, "a report exists the moment the diagnostic starts");
        if (txt) {
            CHECK(strstr(txt, "0.1.0") == NULL, "the old report is gone as soon as the new test starts");
            CHECK(strncmp(txt, APP_NAME " " APP_VERSION " core diagnostic\n", strlen(APP_NAME " " APP_VERSION " core diagnostic\n")) == 0,
                  "the first line names this build (%s)", APP_VERSION);
            CHECK(strstr(txt, "build:          " APP_BUILD "\n") != NULL || strstr(txt, "build:          ") != NULL,
                  "it carries the build time");
            CHECK(strstr(txt, "result:         RUNNING") != NULL, "and says the test is still running");
            CHECK(strstr(txt, "stage:          boot test") != NULL, "at the boot test");
            free(txt);
        }
        t0 = platform_time_us();
        {
            int saw_workload = 0;

            while (app_mode() == APP_DIAG && platform_time_us() - t0 < 180000000ull) {
                if (!app_frame())
                    break;
                txt = (char *)platform_read_file(f, &len); /* may be missing for an instant while it is replaced */
                if (txt) {
                    if (strstr(txt, "result:         RUNNING") && strstr(txt, "stage:          workload "))
                        saw_workload++;
                    free(txt);
                }
            }
            CHECK(saw_workload > 0, "the report followed the run from workload to workload (%d samples)", saw_workload);
        }
        diag_progress(&done, &total);
        CHECK(app_mode() == APP_HOME && ui_message_active(), "diagnostic ends on the home screen with a result box");
        CHECK(total > 0 && done == total, "progress reached 100%% (%d/%d frames)", done, total);
        CHECK(!core_is_loaded() && !session_active(), "core unloaded afterwards");
        path_join(f, sizeof(f), platform_data_dir(), "diag");
        CHECK(!platform_exists(f), "scratch folder removed");
        path_join(f, sizeof(f), platform_data_dir(), "diagnostic.txt");
        txt = (char *)platform_read_file(f, &len);
        CHECK(txt != NULL, "report written to %s", f);
        if (txt) {
            char *copy = (char *)malloc(len + 1);
            memcpy(copy, txt, len);
            copy[len] = '\0';
            CHECK(strstr(copy, "result:         PASS") != NULL, "diagnostic PASSED with user overrides in place");
            CHECK(strstr(copy, "RUNNING") == NULL && strstr(copy, "0.1.0") == NULL, "the final report replaced the trail");
            CHECK(strstr(copy, "folder:         ") != NULL, "the report says which folder it is in");
            {
                char want[80];

                snprintf(want, sizeof(want), "workloads:      %d of %d equal to the x86 reference", deeptest_spec_count,
                         deeptest_spec_count);
                CHECK(strstr(copy, want) != NULL, "all %d hardware workloads equal the reference", deeptest_spec_count);
            }
            {
                char want[96];

                snprintf(want, sizeof(want), "cel sprites:    %016llx expected %016llx ok",
                         (unsigned long long)deeptest_celbench_expect(), (unsigned long long)deeptest_celbench_expect());
                CHECK(strstr(copy, want) != NULL, "the sprites drawn to time the cel engine equal the reference");
                CHECK(strstr(copy, "PICTURES DIFFER") == NULL, "and are the same with the table of finished pixels off");
                CHECK(strstr(copy, "4-bit packed sprite, own size") != NULL && strstr(copy, "mixed in") != NULL,
                      "the report lists the time per pixel of each sprite");
            }
            {
                char want[160];

                snprintf(want, sizeof(want),
                         "DSP thread:     inside the frame %d of %d scripts equal to the x86 reference; on a thread %d "
                         "of %d the same",
                         DEEPTEST_DSPTHREAD_SCRIPTS, DEEPTEST_DSPTHREAD_SCRIPTS, DEEPTEST_DSPTHREAD_SCRIPTS,
                         DEEPTEST_DSPTHREAD_SCRIPTS);
                CHECK(strstr(copy, want) != NULL, "the DSP on its own thread leaves what the DSP inside the frame does");
                CHECK(strstr(copy, "thread same") != NULL && strstr(copy, "CUT SHORT") == NULL &&
                          strstr(copy, "thread DIFFERS") == NULL && strstr(copy, "thread none") == NULL,
                      "in every one of the scripts");
                CHECK(strstr(copy, "  one tick      ") != NULL && strstr(copy, "from asleep (gave up 0)") != NULL,
                      "the report says what a wait for the DSP's thread costs, and none was given up on");
            }
            printf("%s", copy);
            free(copy);
            free(txt);
        }
        ui_open(UI_HOME, NULL);

        /* cancel in the middle */
        app_dispatch(&act);
        CHECK(app_mode() == APP_DIAG, "second diagnostic starts");
        t0 = platform_time_us();
        for (;;) {
            diag_progress(&done, &total);
            if (done > 20 || platform_time_us() - t0 > 60000000ull)
                break;
            app_frame();
        }
        diag_cancel();
        t0 = platform_time_us();
        while (app_mode() == APP_DIAG && platform_time_us() - t0 < 60000000ull)
            app_frame();
        CHECK(app_mode() == APP_HOME && !ui_message_active() && !core_is_loaded(), "cancel returns to home without a box");
        path_join(f, sizeof(f), platform_data_dir(), "diagnostic.txt");
        txt = (char *)platform_read_file(f, &len);
        CHECK(txt != NULL && strstr(txt, "result:         cancelled") != NULL && strstr(txt, "RUNNING") == NULL,
              "a cancelled run leaves a report that says so, not a stale 'RUNNING'");
        free(txt);
        kv_remove(&g_core_opts_global, "opera_high_resolution");
        CHECK(diag_start(), "a new diagnostic can start after a cancel");
        diag_shutdown();
        CHECK(!diag_running() && !core_is_loaded(), "shutdown joins a running diagnostic");
    }

    app_shutdown();
    printf("== full app run: %s ==\n", g_fail ? "FAILED" : "passed");
    return g_fail ? 1 : 0;
}

/* ------------------------------------------------------- picture test */

/* The colour the player must see for `rgb` when the colour order setting is `order` (stated here, apart from
 * the implementation in video.c: out = a pick of the source channels). */
static uint32_t shown_colour(uint32_t rgb, int order)
{
    uint32_t r = (rgb >> 16) & 255, g = (rgb >> 8) & 255, b = rgb & 255;

    switch (order) {
    case 1: return (b << 16) | (g << 8) | r; /* BGR */
    case 2: return (r << 16) | (b << 8) | g; /* RBG */
    case 3: return (g << 16) | (r << 8) | b; /* GRB */
    case 4: return (g << 16) | (b << 8) | r; /* GBR */
    case 5: return (b << 16) | (r << 8) | g; /* BRG */
    default: return rgb;
    }
}

static bool pixel_is(int x, int y, uint32_t rgb)
{
    uint8_t p[3];

    if (!video_read_pixel(x, y, p))
        return false;
    if (((uint32_t)p[0] << 16 | (uint32_t)p[1] << 8 | p[2]) != rgb)
        printf("    pixel (%d,%d) is %02x%02x%02x, expected %06x\n", x, y, p[0], p[1], p[2], (unsigned)rgb);
    return ((uint32_t)p[0] << 16 | (uint32_t)p[1] << 8 | p[2]) == rgb;
}

/* Draws the current page of the picture test the way the app does and checks pixels before presenting. */
static int check_colour_page(int page, int order)
{
    int bad = 0;
    int s = page == 2 ? 2 : 1;  /* the hi-res page is 640x480, everything else 320x240 */
    int pw = 320 * s, ph = 240 * s;

    for (int i = 0; i < 3; i++) { /* a few frames: the first one uploads, the next ones prove it stays */
        input_update();
        video_begin_frame();
        testpat_draw();
        if (i == 2) {
            for (int b = 0; b < TESTPAT_BARS; b++) {
                int px = b * (pw / 8) + pw / 16, py = (page == 2 ? 24 : 30);
                int sx = 240 + px * 800 / pw, sy = 116 + py * 600 / ph;

                if (!pixel_is(sx, sy, shown_colour(testpat_bar_rgb[b], order)))
                    bad++;
                /* the reference swatch above the bar is drawn by the interface and never changes */
                if (!pixel_is(240 + b * 100 + 5, 64 + 4, testpat_bar_rgb[b]))
                    bad++;
            }
            if (page != 2) { /* ramps and the three primaries, pages 0 and 3 only */
                for (int k = 0; k < 32; k += 3) { /* grey ramp: the 5 bit level expanded to 8 bits (16-bit pages) or exact (32-bit) */
                    uint32_t v5 = (uint32_t)(k * 255 / 31) >> 3;
                    uint32_t v8 = page == 3 ? (uint32_t)(k * 255 / 31) : (v5 << 3) | (v5 >> 2);
                    int sx = 240 + (k * 10 + 5) * 800 / 320, sy = 116 + (80 + 48 + 8) * 600 / 240;

                    if (!pixel_is(sx, sy, shown_colour((v8 << 16) | (v8 << 8) | v8, order)))
                        bad++;
                }
                if (!pixel_is(240 + 800 / 6, 116 + 208 * 600 / 240, shown_colour(0xFF0000, order)))
                    bad++;
                if (!pixel_is(240 + 400, 116 + 208 * 600 / 240, shown_colour(0x00FF00, order)))
                    bad++;
                if (!pixel_is(240 + 800 * 5 / 6, 116 + 208 * 600 / 240, shown_colour(0x0000FF, order)))
                    bad++;
            }
        }
        video_end_frame();
    }
    return bad;
}

static int test_video(void)
{
    ui_action_t act;

    headless_env();
    printf("== picture test ==\n");
    if (!app_init()) {
        printf("  FAIL  app_init\n");
        return 1;
    }
    g_cfg.color_order = 0;
    video_apply_settings();

    memset(&act, 0, sizeof(act));
    act.type = UIA_TESTPATTERN;
    app_dispatch(&act);
    CHECK(app_mode() == APP_TESTPAT, "the menu action opens the picture test");
    CHECK(testpat_page() == 0, "starts on the colour bars");

    for (int page = 0; page < TESTPAT_PAGES; page++) {
        if (page == 1)
            CHECK(true, "page 2 (geometry) has no swatches to compare, drawn only");
        for (int order = 0; order < VIDEO_COLOR_ORDERS; order++) {
            g_cfg.color_order = order;
            video_apply_settings();
            if (page != 1) {
                int bad = check_colour_page(page, order);
                CHECK(bad == 0, "page %d, colour order %s: bars, ramps and swatches show the right colours (%d wrong)",
                      page + 1, video_color_order_name(order), bad);
            } else {
                int bad = 0;

                for (int i = 0; i < 3; i++) {
                    video_begin_frame();
                    testpat_draw();
                    if (i == 2) { /* corner markers: red, green, blue, yellow (picture 320x240 on 800x600 at 240,116) */
                        if (!pixel_is(240 + 8 * 800 / 320, 116 + 8 * 600 / 240, shown_colour(0xFF0000, order)))
                            bad++;
                        if (!pixel_is(240 + (320 - 8) * 800 / 320, 116 + 8 * 600 / 240, shown_colour(0x00FF00, order)))
                            bad++;
                        if (!pixel_is(240 + 8 * 800 / 320, 116 + (240 - 8) * 600 / 240, shown_colour(0x0000FF, order)))
                            bad++;
                        if (!pixel_is(240 + (320 - 8) * 800 / 320, 116 + (240 - 8) * 600 / 240, shown_colour(0xFFFF00, order)))
                            bad++;
                        /* the white border is the outermost row of the picture (2.5 screen rows, edge softened by the
                         * smooth filter); the row above the picture is the plain background */
                        {
                            uint8_t in[3], out[3];

                            if (!video_read_pixel(240 + 400, 116 + 1, in) || !video_read_pixel(240 + 400, 116 - 3, out) ||
                                in[0] < 0xE0 || in[1] < 0xE0 || in[2] < 0xE0 || out[0] > 0x20 || out[1] > 0x20 || out[2] > 0x30) {
                                printf("    border: inside %02x%02x%02x, outside %02x%02x%02x\n", in[0], in[1], in[2], out[0], out[1], out[2]);
                                bad++;
                            }
                        }
                    }
                    video_end_frame();
                }
                CHECK(bad == 0, "page 2, colour order %s: corners and border (%d wrong)", video_color_order_name(order), bad);
            }
        }
        g_cfg.color_order = 0;
        video_apply_settings();
        input_debug_nav(NAV_RIGHT);
        app_frame();
        CHECK(app_mode() == APP_TESTPAT && testpat_page() == (page + 1) % TESTPAT_PAGES,
              "right moves to page %d", (page + 1) % TESTPAT_PAGES + 1);
    }

    /* X cycles the colour order through the app loop and Y the filter; both are kept */
    {
        int before = g_cfg.color_order, filter = g_cfg.filter;

        input_debug_nav(NAV_X);
        app_frame();
        CHECK(g_cfg.color_order == (before + 1) % VIDEO_COLOR_ORDERS, "X cycles the colour order");
        input_debug_nav(NAV_Y);
        app_frame();
        CHECK(g_cfg.filter != filter, "Y changes the filter");
        g_cfg.color_order = 0;
        video_apply_settings();
    }
    input_debug_nav(NAV_BACK);
    app_frame();
    CHECK(app_mode() == APP_HOME, "B leaves the picture test");

    /* a game-style frame (16 bit, 320x240) on the normal path ends up with the same colours */
    {
        static uint16_t pic[320 * 240];

        for (int i = 0; i < 320 * 240; i++)
            pic[i] = (uint16_t)((31u << 10) | (16u << 5) | 0u); /* r 31, g 16, b 0 -> ff8400 */
        video_reset();
        video_submit(pic, 320, 240, 640, CORE_PF_0RGB1555);
        for (int i = 0; i < 3; i++) {
            video_begin_frame();
            video_draw_game();
            if (i == 2)
                CHECK(pixel_is(640, 360, 0xFF8400), "a game frame (0RGB1555 ff8400) reaches the screen unchanged");
            video_end_frame();
        }
    }

    /*
     * Stretching to the whole 16:9 screen must not soften the picture. A 320x240 source on a 1280x720 screen is
     * exactly 4x across and 3x down, so with the two-stage scaler every screen pixel has to be one of the source
     * colours. Drawn here with the SMOOTH filter on purpose: in one step that filter blends neighbours and the
     * check below finds the in-between colours it produces.
     */
    {
        static uint16_t pic[320 * 240];
        const uint32_t red = 0xFF0000, blue = 0x0000FF;
        int aspect = g_cfg.aspect, filter = g_cfg.filter, blended = 0, wrong = 0;

        for (int y = 0; y < 240; y++)
            for (int x = 0; x < 320; x++)
                pic[y * 320 + x] = (uint16_t)(((x + y) & 1) ? (31u << 10) : 31u); /* 1-pixel red/blue chequer */
        g_cfg.aspect = ASPECT_STRETCH;
        g_cfg.filter = FILTER_LINEAR;
        video_apply_settings();
        video_reset();
        video_submit(pic, 320, 240, 640, CORE_PF_0RGB1555);
        for (int i = 0; i < 3; i++) {
            video_begin_frame();
            video_draw_game();
            if (i == 2) {
                for (int y = 4; y < 720; y += 37) {
                    for (int x = 4; x < 1280; x += 53) {
                        uint8_t px[3];
                        uint32_t got;

                        if (!video_read_pixel(x, y, px)) {
                            wrong++;
                            continue;
                        }
                        got = (uint32_t)px[0] << 16 | (uint32_t)px[1] << 8 | px[2];
                        if (got != red && got != blue) {
                            if (blended < 3)
                                printf("    pixel (%d,%d) is %06x, neither source colour\n", x, y, (unsigned)got);
                            blended++;
                        }
                        /* 4x across, 3x down: the colour must be the one of the source pixel under it */
                        else if (got != ((((x / 4) + (y / 3)) & 1) ? red : blue))
                            wrong++;
                    }
                }
                CHECK(blended == 0, "stretched to 16:9 with the smooth filter, no pixel is a blend (%d blended)",
                      blended);
                CHECK(wrong == 0, "every stretched pixel shows its own source pixel (%d wrong)", wrong);
            }
            video_end_frame();
        }
        g_cfg.aspect = aspect;
        g_cfg.filter = filter;
        video_apply_settings();
    }
    app_shutdown();
    printf("== picture test: %s ==\n", g_fail ? "FAILED" : "passed");
    return g_fail ? 1 : 0;
}

/* -------------------------------------------------------------- UI shots */

static void shot(const char *dir, const char *name, bool with_game)
{
    char path[1200];
    snprintf(path, sizeof(path), "%s/%s.bmp", dir, name);
    for (int i = 0; i < 20; i++) { /* let animations settle */
        input_update();
        ui_update();
        video_begin_frame();
        if (with_game)
            video_draw_game();
        ui_draw();
        if (i == 19)
            video_save_screen_bmp(path);
        video_end_frame();
        platform_sleep_ms(10);
    }
    printf("  shot  %s\n", path);
}

/* The progress screen of the core diagnostic, with the real numbers of the running test. */
static void shot_diag_progress(const char *dir, const char *name)
{
    char path[1200], caption[160], stage[80];

    snprintf(path, sizeof(path), "%s/%s.bmp", dir, name);
    for (int i = 0; i < 3; i++) {
        int done = 0, total = 0;
        float p;

        input_update();
        diag_progress(&done, &total);
        diag_stage(stage, sizeof(stage));
        p = total > 0 ? (float)done / (float)total : 0.0f;
        snprintf(caption, sizeof(caption), tr(S_DIAG_PROGRESS), (int)(p * 100.0f), stage);
        video_begin_frame();
        ui_draw_splash_progress(tr(S_DIAG_TITLE), tr(S_DIAG_RUN_LINE), p, caption);
        if (i == 2)
            video_save_screen_bmp(path);
        video_end_frame();
    }
    printf("  shot  %s\n", path);
}

static void make_fake_library(void)
{
    static const char *const names[] = {
        "Crash 'n Burn (USA).chd", "Gex (USA).chd",        "Need for Speed (USA).iso", "Road Rash (USA).cue",
        "Road Rash (USA).bin",     "Samurai Shodown.chd",  "Super Wing Commander.iso", "The Horde (USA).chd",
        "Twisted - The Game Show.chd", "Way of the Warrior.iso", "notes.txt",
    };
    char dir[1100], f[1200];
    path_join(dir, sizeof(dir), platform_default_browse_dir(), "3DO");
    platform_mkdirs(dir);
    for (size_t i = 0; i < ARRAY_LEN(names); i++) {
        path_join(f, sizeof(f), dir, names[i]);
        platform_write_file_atomic(f, "x", 1);
    }
    path_join(f, sizeof(f), dir, "Homebrew");
    platform_mkdirs(f);
    path_join(dir, sizeof(dir), dir, "Gex (USA).chd");
    config_add_recent(dir);
    path_join(dir, sizeof(dir), platform_default_browse_dir(), "3DO/The Horde (USA).chd");
    config_add_recent(dir);
}

static int test_ui(int argc, char **argv)
{
    const char *dir = NULL;
    ui_action_t act;

    for (int i = 1; i + 1 < argc; i++)
        if (!strcmp(argv[i], "--selftest-ui"))
            dir = argv[i + 1];
    if (!dir) {
        printf("usage: --selftest-ui DIR\n");
        return 2;
    }
    platform_mkdirs(dir);
    printf("== UI screenshots -> %s ==\n", dir);
    if (!app_init()) {
        printf("  FAIL  app_init\n");
        return 1;
    }
    make_fake_library();
    ui_open(UI_HOME, NULL);
    ui_refresh();
    shot(dir, "01-home", false);
    ui_debug_goto("browser");
    shot(dir, "02-browser", false);
    ui_open(UI_HOME, NULL);
    ui_debug_goto("recent");
    shot(dir, "03-recent", false);
    ui_open(UI_HOME, NULL);
    ui_debug_goto("settings");
    shot(dir, "04-settings", false);
    ui_open(UI_HOME, NULL);
    ui_debug_goto("coreopts");
    shot(dir, "05-coreopts", false);
    ui_open(UI_HOME, NULL);
    ui_debug_goto("controls");
    shot(dir, "06-controls", false);
    ui_debug_goto("capture");
    shot(dir, "07-capture", false);
    ui_open(UI_HOME, NULL);
    ui_debug_goto("about");
    shot(dir, "08-about", false);
    ui_open(UI_HOME, NULL);
    ui_debug_goto("message");
    shot(dir, "09-message", false);
    ui_open(UI_HOME, NULL);
    ui_debug_goto("toast");
    shot(dir, "10-toast", false);

    /* pause menu on top of a real frame from the BIOS */
    memset(&act, 0, sizeof(act));
    act.type = UIA_LAUNCH_BIOS;
    app_dispatch(&act);
    if (app_mode() == APP_PLAYING) {
        spin(1.5);
        app_hotkeys(HK_MENU);
        shot(dir, "11-pause", true);
        ui_debug_goto("gameopts");
        shot(dir, "12-gameopts", true);
        act.type = UIA_CLOSE_GAME;
        app_dispatch(&act);
    } else {
        printf("  FAIL  could not boot the BIOS: %s\n", session_error());
        g_fail++;
    }

    /* the core diagnostic: progress screen, then the result box on top of settings */
    ui_open(UI_HOME, NULL);
    ui_debug_goto("settings");
    memset(&act, 0, sizeof(act));
    act.type = UIA_DIAGNOSTIC;
    app_dispatch(&act);
    if (app_mode() == APP_DIAG) {
        uint64_t t0 = platform_time_us();

        for (;;) { /* wait for about a quarter of the test, then show it */
            int done = 0, total = 0;
            diag_progress(&done, &total);
            if ((total > 0 && done * 4 >= total) || platform_time_us() - t0 > 60000000ull)
                break;
            platform_sleep_ms(1);
        }
        shot_diag_progress(dir, "13-diag-running");
        while (app_mode() == APP_DIAG && platform_time_us() - t0 < 120000000ull)
            app_frame();
        shot(dir, "14-diag-result", false);
    } else {
        printf("  FAIL  the diagnostic did not start\n");
        g_fail++;
    }
    /* the picture test: colour bars, geometry, high resolution */
    ui_open(UI_HOME, NULL);
    ui_debug_goto("settings");
    memset(&act, 0, sizeof(act));
    act.type = UIA_TESTPATTERN;
    app_dispatch(&act);
    if (app_mode() == APP_TESTPAT) {
        static const char *const names[] = {"15-testpat-colours", "16-testpat-geometry", "17-testpat-hires"};

        for (int page = 0; page < 3; page++) {
            char path[1200];

            snprintf(path, sizeof(path), "%s/%s.bmp", dir, names[page]);
            for (int i = 0; i < 4; i++) {
                input_update();
                video_begin_frame();
                testpat_draw();
                ui_draw_overlays(NULL);
                if (i == 3)
                    video_save_screen_bmp(path);
                video_end_frame();
            }
            printf("  shot  %s\n", path);
            testpat_nav(NAV_RIGHT);
        }
        input_debug_nav(NAV_BACK);
        app_frame();
    } else {
        printf("  FAIL  the picture test did not open\n");
        g_fail++;
    }
    app_shutdown();
    printf("== UI screenshots: %s ==\n", g_fail ? "FAILED" : "done");
    return g_fail ? 1 : 0;
}

/* ------------------------------------- state the diagnostic leaves behind */

/*
 * A user reported that after running the core diagnostic on the console, a game started in the same session showed
 * wrong colours, that running the diagnostic a second time reported FAILED, and that closing and reopening the app
 * cured both. So something the diagnostic runs leaves state behind that the next core load inherits.
 *
 * This reproduces it at the layer where it matters: boot the BIOS and hash it, run the ten workloads of the
 * diagnostic, boot the BIOS again and compare. The boot hash only depends on pixel and sample values, so a
 * difference means the core carried state across core_unload() / core_load(). When they do differ, each workload
 * is then tried on its own, which names the culprit instead of leaving a guess.
 */
static bool boot_hash(coretest_result_t *out)
{
    memset(out, 0, sizeof(*out));
    return coretest_run(NULL, CORETEST_REF_FRAMES, out) && !out->cancelled;
}

static int test_diagstate(int argc, char **argv)
{
    core_sink_t sink = {nullv, nulla};
    coretest_result_t a, b;
    bool clean;
    (void)argc;
    (void)argv;

    printf("== diagnostic leaves no state behind ==\n");
    config_load();
    CHECK(core_init(&sink), "core_init");

    CHECK(boot_hash(&a), "boot before the workloads");
    CHECK(coretest_matches_reference(&a), "it equals the x86 reference (video %016llx audio %016llx)",
          (unsigned long long)a.video_hash, (unsigned long long)a.audio_hash);

    {   /* probes that separate the three things the workloads do to the core */
        coretest_result_t p;

        CHECK(boot_hash(&p) && p.video_hash == a.video_hash, "a plain second boot is identical (%016llx)",
              (unsigned long long)p.video_hash);

        core_load(NULL);
        core_unload();
        CHECK(boot_hash(&p) && p.video_hash == a.video_hash, "a bare load/unload in between changes nothing (%016llx)",
              (unsigned long long)p.video_hash);

        prng16_seed(0x13579BDFu);
        prng32_seed(0x2468ACE1u);
        CHECK(boot_hash(&p) && p.video_hash == a.video_hash, "re-seeding the noise sources changes nothing (%016llx)",
              (unsigned long long)p.video_hash);
    }

    {   /* --only NAME runs a single workload, so that a fresh process can attribute the damage to it alone:
           once one workload has dirtied the core, every later one in the same process looks dirty too. */
        const char *only = arg_value(argc, argv, "--only");

        for (int i = 0; i < deeptest_spec_count; i++) {
            uint64_t h = 0;

            if (only && strcmp(only, deeptest_specs[i].name))
                continue;
            CHECK(deeptest_hash(&deeptest_specs[i], &h) && h == deeptest_specs[i].expect, "workload %s",
                  deeptest_specs[i].name);
        }
    }

    CHECK(boot_hash(&b), "boot after the workloads");
    clean = a.video_hash == b.video_hash && a.audio_hash == b.audio_hash;
    CHECK(clean, "the same boot hashes as before (video %016llx vs %016llx, audio %016llx vs %016llx)",
          (unsigned long long)a.video_hash, (unsigned long long)b.video_hash,
          (unsigned long long)a.audio_hash, (unsigned long long)b.audio_hash);

    if (!clean && !arg_value(argc, argv, "--only")) { /* name the workload(s) responsible instead of leaving a guess */
        printf("  ----  which workload dirties the core:\n");
        for (int i = 0; i < deeptest_spec_count; i++) {
            coretest_result_t c;
            uint64_t h = 0;

            deeptest_hash(&deeptest_specs[i], &h);
            if (!boot_hash(&c)) {
                printf("        %-6s boot FAILED afterwards\n", deeptest_specs[i].name);
                g_fail++;
                continue;
            }
            printf("        %-6s %s (video %016llx audio %016llx)\n", deeptest_specs[i].name,
                   (c.video_hash == a.video_hash && c.audio_hash == a.audio_hash) ? "clean" : "DIRTIES THE CORE",
                   (unsigned long long)c.video_hash, (unsigned long long)c.audio_hash);
        }
    }

    core_deinit();
    printf("== diagnostic state: %s ==\n", g_fail ? "FAILED" : "passed");
    return g_fail ? 1 : 0;
}

int selftest_main(int argc, char **argv)
{
    if (has_flag(argc, argv, "--selftest-input"))
        return test_input();
    if (has_flag(argc, argv, "--selftest-core")) {
        headless_env();
        return test_core(argc, argv);
    }
    if (has_flag(argc, argv, "--selftest-diagstate")) {
        headless_env();
        return test_diagstate(argc, argv);
    }
    if (has_flag(argc, argv, "--selftest-dspthread")) {
        headless_env();
        return test_dspthread();
    }
    if (has_flag(argc, argv, "--selftest-run")) {
        headless_env();
        return test_run(argc, argv);
    }
    if (has_flag(argc, argv, "--selftest-video"))
        return test_video();
    if (has_flag(argc, argv, "--selftest-ui")) {
        headless_env();
        return test_ui(argc, argv);
    }
    return -1;
}
