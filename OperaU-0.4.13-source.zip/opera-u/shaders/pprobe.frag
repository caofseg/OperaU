#version 150

/*
  Opera U: the 3DO pixel processor, on the GPU, for the probe in the core diagnostic.

  This is a line-for-line copy of what pp_build_lut_half() in opera_madam.c works out on the CPU, for the shape
  almost every cel of a real game uses: each output channel depends only on the five bits of the same channel of
  the source pixel and on values fixed for the whole cel. The question the probe answers is not whether the GPU is
  fast - that is measured separately - but whether it gets the same answer, bit for bit. If it does, the cel
  engine could be moved here without giving up the exactness the whole emulator is tested for.

  Every step is in C's terms on purpose. The CPU code works in int8_t and shifts signed values, so the same
  truncation and the same sign propagation have to happen here. s8() is what a cast to int8_t does to a value, and
  GLSL's >> on a signed int is an arithmetic shift, like C's on a negative signed value in practice. Where the CPU
  code promotes to int before shifting and only then truncates, this does the same, in the same order: the shifts
  of a sum are not wrapped in s8() before the shift, because C does not wrap them either.
*/

uniform usampler2D u_src;     /* the source pixels, one 16-bit 3DO pixel per texel */
uniform usampler2D u_pscalar; /* PSCALAR[mxf][dv1][v] laid out as 32 x 32, index = mxf<<7 | dv1<<5 | v */

/*
  The same pixels again, as plain bytes in an ordinary 8-bit colour texture: the high byte in red, the low byte in
  green. An integer texture is the natural way to hand whole numbers to a shader, but if this GPU will not read
  one, the numbers can still arrive this way - and one run of the probe can say which of the two works.
*/
uniform sampler2D u_src8;
uniform int       u_use8; /* 1 = read the pixel from u_src8 instead of u_src */

/*
  One uniform whose only job is to come back out again, in the alpha channel, where nothing else is written.
  It is how the probe finds out which way of handing a uniform to this GPU actually works: the CPU writes a
  different value through each candidate way and reads back which one arrived. Zero means none of them did,
  and alpha keeps the fixed constant that says the shader ran at all.
*/
uniform int       u_echo;

uniform int u_ms;    /* how colour 1 is scaled */
uniform int u_mxf;   /* the multiplier, when it is fixed for the cel */
uniform int u_dv1;
uniform int u_dv2;
uniform int u_dv3;
uniform int u_s2;    /* where colour 2 comes from */
uniform int u_av;    /* the AV field of PIXC */
uniform int u_neg;
uniform int u_xtend;
uniform int u_nclip;
uniform int u_pxor1;
uniform int u_pxor2;

/*
  What to put in the target. 0 is the pixel processor, the thing being tested. The other two exist because a
  disagreement with the CPU does not say where it came from: 1 hands back the raw value the shader read out of the
  source texture, and 2 hands back what it read out of the table. Running all three in one pass says whether a
  difference is in the arithmetic or in getting the numbers into the GPU in the first place.
*/
uniform int u_mode;

out vec4 fragColor;

/* what a cast to int8_t does to a value: keep the low eight bits, then let bit 7 be the sign */
int
s8(int x_)
{
  return ((x_ << 24) >> 24);
}

int
pscalar(int a_,
        int b_,
        int v_)
{
  int i = (((a_ & 7) << 7) | ((b_ & 3) << 5) | (v_ & 31));

  return int(texelFetch(u_pscalar,ivec2(i & 31,i >> 5),0).r);
}

/*
  One channel, five bits in, five bits out. px1_ and px2_ are this channel's lanes of PXOR1 and PXOR2, already
  taken apart by the caller, because the lanes do not sit in channel order.
*/
int
channel(int v_,
        int px1_,
        int px2_)
{
  int c1;
  int c2;
  int aop;
  int bop;
  int o;

  if(u_ms == 0)
    c1 = s8(pscalar(u_mxf,u_dv1,v_));
  else if(u_ms == 2)
    c1 = s8(pscalar(v_ >> 2,v_ & 3,v_));
  else
    c1 = s8(pscalar(v_ >> 2,u_dv1,v_)); /* case 3; case 1 never reaches the table, see opera_madam.c */

  if(u_s2 == 0)
    c2 = 0;
  else if(u_s2 == 1)
    c2 = s8(u_av >> u_dv3);
  else
    c2 = s8(v_ >> u_dv3); /* cases 2 and 3: colour 2 is the same pixel colour 1 reads */

  aop = s8(c1 & px1_);
  c1  = s8(c1 & px2_);
  bop = s8((u_neg != 0) ? (c2 ^ (-1)) : (c2 ^ c1)); /* (int8_t)0xFF is -1, so that branch is ~c2 */

  if(u_xtend != 0)
    bop = s8((bop << 3) >> 3); /* in int, so it gives the value straight back, exactly as on the CPU */

  o = s8((aop + bop + u_neg) >> u_dv2); /* summed and shifted in int, truncated after, as in C */

  if(u_nclip == 0)
    o = clamp(o,0,31);

  return (o & 31);
}

void
main()
{
  ivec2 at = ivec2(gl_FragCoord.xy);
  uint  p;
  int   r;
  int   g;
  int   b;

  if(u_use8 != 0)
    {
      /* a byte of an 8-bit texture comes back as that byte over 255, so multiplying back and rounding is exact */
      vec4 t = texelFetch(u_src8,at,0);

      p = (uint(t.r * 255.0 + 0.5) << 8u) | uint(t.g * 255.0 + 0.5);
    }
  else
    {
      /*
        The GPU reads a 16-bit texel the other way round from the way a PowerPC writes one, so the two bytes come
        back swapped and have to be put back. This is not a quirk of the probe: the 3DO's frame buffer holds
        16-bit pixels in main memory in the CPU's order, so anything that ever hands those pixels to the GPU
        meets the same swap - and doing it here costs nothing, because the GPU does it per texel as it reads.
      */
      uint raw = texelFetch(u_src,at,0).r;

      p = (((raw << 8u) | (raw >> 8u)) & 0xFFFFu);
    }

  if(u_mode == 3)
    {
      /* no texture at all: only where this pixel is, and a constant, to tell coordinates from reads */
      r = (at.x & 255);
      g = (at.y & 255);
      b = 0x5A;
    }
  else if(u_mode == 1)
    {
      /* the source value, split into its two bytes, and the column it was read at */
      r = int((p >> 8u) & 255u);
      g = int( p        & 255u);
      b = (at.x & 255);
    }
  else if(u_mode == 2)
    {
      /* the table, read at an index the column chooses */
      r = pscalar(u_mxf,u_dv1,at.x & 31);
      g = (at.x & 31);
      b = 0;
    }
  else
    {
      r = channel(int((p >> 10u) & 31u),s8(u_pxor1      ),s8(u_pxor2      ));
      g = channel(int((p >>  5u) & 31u),s8(u_pxor1 >> 16),s8(u_pxor2 >> 16));
      b = channel(int( p         & 31u),s8(u_pxor1 >>  8),s8(u_pxor2 >>  8));
    }

  /*
    The results go out as whole bytes, not as colours: a byte of an 8-bit target comes back to the CPU as the same
    number, so the comparison stays exact and nothing is lost to rounding.
  */
  /*
    Alpha carries a constant that depends on no uniform and on no texture. It is the one part of the output that
    is still meaningful when something upstream has gone wrong: if it arrives, the shader ran and its output
    reached the target, and whatever else is zero is zero for a reason further up.
  */
  fragColor = vec4(float(r) / 255.0,float(g) / 255.0,float(b) / 255.0,
                   (u_echo == 0) ? (195.0 / 255.0) : (float(u_echo & 255) / 255.0));
}
