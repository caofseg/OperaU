#!/usr/bin/env bash
#
# Compile the GLSL shaders to GX2 and embed the result in a C file.
#
# The Wii U offers no way to compile a shader while a program runs, and devkitPro ships no shader compiler, so the
# usual route for homebrew is to write the GPU's own assembly by hand and assemble it with a tool from an
# emulator. CafeGLSL compiles GLSL instead, here, ahead of time. The .gsh and the generated .c are kept in the
# tree so that building Opera U needs none of this: run this script only after changing a shader.
#
# Build the compiler once:
#   git clone https://github.com/Exzap/CafeGLSL
#   cd CafeGLSL && ./cafecompiler/compile_for_host.sh
# Its stub src/gallium/winsys/radeon/drmstub/radeon_drm_winsys.c may not match the Mesa header it is built
# against; if the build stops there, give radeon_drm_winsys_create() the trailing `uint64_t debug_flags`
# parameter the header declares.
#
# Then point GLSLCOMPILER at the binary it built:
#   GLSLCOMPILER=/path/to/CafeGLSL/build-host/cafecompiler/glslcompiler shaders/build_shaders.sh

set -euo pipefail

cd "${0%/*}"

GLSLCOMPILER="${GLSLCOMPILER:-glslcompiler}"
if ! command -v "$GLSLCOMPILER" >/dev/null 2>&1 && [ ! -x "$GLSLCOMPILER" ]; then
    echo "build_shaders: no shader compiler found." >&2
    echo "build_shaders: set GLSLCOMPILER to CafeGLSL's glslcompiler (see the top of this script)." >&2
    exit 1
fi

for name in pprobe; do
    echo "build_shaders: $name"
    # One -vs with one -ps compiles as a pair, so both halves agree on how uniforms are passed.
    "$GLSLCOMPILER" -vs "$name.vert" -ps "$name.frag" -o "$name.gsh"
    python3 ../tools/embed_gsh.py "$name.gsh" "$name.gsh.c" "shader_$name"
done

echo "build_shaders: done"
