#include "png.h"
#include "platform.h"

uint32_t png_crc32(uint32_t crc, const uint8_t *data, size_t len)
{
    static uint32_t table[256];
    static bool ready;

    if (!ready) {
        for (uint32_t n = 0; n < 256; n++) {
            uint32_t c = n;

            for (int k = 0; k < 8; k++)
                c = (c & 1) ? 0xEDB88320u ^ (c >> 1) : c >> 1;
            table[n] = c;
        }
        ready = true;
    }
    crc = ~crc;
    for (size_t i = 0; i < len; i++)
        crc = table[(crc ^ data[i]) & 0xFF] ^ (crc >> 8);
    return ~crc;
}

uint32_t png_adler32(uint32_t adler, const uint8_t *data, size_t len)
{
    uint32_t a = adler & 0xFFFF, b = adler >> 16;

    while (len) {
        size_t n = len < 5552 ? len : 5552; /* the largest run that cannot overflow b */

        len -= n;
        while (n--) {
            a += *data++;
            b += a;
        }
        a %= 65521u;
        b %= 65521u;
    }
    return (b << 16) | a;
}

static void put32(uint8_t *p, uint32_t v)
{
    p[0] = (uint8_t)(v >> 24);
    p[1] = (uint8_t)(v >> 16);
    p[2] = (uint8_t)(v >> 8);
    p[3] = (uint8_t)v;
}

/* Appends one chunk (length, type, data, crc) at *pos. */
static void chunk(uint8_t *buf, size_t *pos, const char type[4], const uint8_t *data, size_t len)
{
    uint8_t *c = buf + *pos;
    uint32_t crc;

    put32(c, (uint32_t)len);
    memcpy(c + 4, type, 4);
    if (len)
        memcpy(c + 8, data, len);
    crc = png_crc32(0, c + 4, len + 4);
    put32(c + 8 + len, crc);
    *pos += len + 12;
}

bool png_write_rgb24(const char *path, const uint8_t *rgb, unsigned w, unsigned h, size_t stride)
{
    static const uint8_t sig[8] = {0x89, 'P', 'N', 'G', 0x0D, 0x0A, 0x1A, 0x0A};
    size_t raw_len, nblocks, z_len, total, pos = 0;
    uint8_t *raw = NULL, *z = NULL, *out = NULL;
    uint8_t ihdr[13];
    uint32_t adler;
    bool ok = false;

    if (!w || !h || w > 16384 || h > 16384)
        return false;
    raw_len = (size_t)h * ((size_t)w * 3 + 1);
    nblocks = (raw_len + 65534) / 65535;
    z_len = 2 + raw_len + nblocks * 5 + 4;
    total = 8 + (13 + 12) + (z_len + 12) + 12;

    raw = (uint8_t *)malloc(raw_len);
    z = (uint8_t *)malloc(z_len);
    out = (uint8_t *)malloc(total);
    if (!raw || !z || !out)
        goto done;

    for (unsigned y = 0; y < h; y++) { /* every scanline: filter type 0 (none) + the pixels */
        uint8_t *row = raw + (size_t)y * ((size_t)w * 3 + 1);

        row[0] = 0;
        memcpy(row + 1, rgb + (size_t)y * stride, (size_t)w * 3);
    }

    { /* zlib stream made of stored blocks */
        size_t zp = 0, left = raw_len, off = 0;

        z[zp++] = 0x78;
        z[zp++] = 0x01;
        while (left) {
            size_t n = left > 65535 ? 65535 : left;

            z[zp++] = (left == n) ? 1 : 0; /* BFINAL, BTYPE = 00 */
            z[zp++] = (uint8_t)(n & 0xFF);
            z[zp++] = (uint8_t)(n >> 8);
            z[zp++] = (uint8_t)(~n & 0xFF);
            z[zp++] = (uint8_t)((~n >> 8) & 0xFF);
            memcpy(z + zp, raw + off, n);
            zp += n;
            off += n;
            left -= n;
        }
        adler = png_adler32(1, raw, raw_len);
        put32(z + zp, adler);
        zp += 4;
        z_len = zp;
    }

    memcpy(out, sig, 8);
    pos = 8;
    put32(ihdr, w);
    put32(ihdr + 4, h);
    ihdr[8] = 8;  /* bit depth */
    ihdr[9] = 2;  /* colour type: truecolour */
    ihdr[10] = 0; /* deflate */
    ihdr[11] = 0; /* adaptive filtering */
    ihdr[12] = 0; /* no interlace */
    chunk(out, &pos, "IHDR", ihdr, sizeof(ihdr));
    chunk(out, &pos, "IDAT", z, z_len);
    chunk(out, &pos, "IEND", NULL, 0);
    ok = platform_write_file_atomic(path, out, pos);

done:
    free(raw);
    free(z);
    free(out);
    return ok;
}
