#include "diag.h"
#include "config.h"
#include "core.h"
#include "deeptest.h"
#include "i18n.h"
#include "log.h"
#include "platform.h"

#include <SDL.h>

#define DIAG_STACK (1024 * 1024)

static struct {
    SDL_Thread *thread;
    uint32_t state;     /* atomic: 0 idle, 1 running, 2 finished, waiting to be collected */
    uint32_t cancel;    /* atomic */
    uint32_t deep_done; /* atomic: hardware workloads finished */
    uint32_t stage;     /* atomic: 0 = boot test, k = workload number k (1-based) is running */
    diag_report_t rep;  /* written by the worker before state becomes 2 */
} D;

/* ---------------------------------------------------------- scratch folder */

/* Removes a directory tree (the scratch folder holds a couple of files at most). */
static void remove_tree(const char *dir, int depth)
{
    int n = 0;
    dir_entry_t *list;

    if (depth > 6 || !platform_exists(dir))
        return;
    list = platform_list_dir(dir, &n);
    for (int i = 0; i < n; i++) {
        char full[1100];
        path_join(full, sizeof(full), dir, list[i].name);
        if (list[i].is_dir)
            remove_tree(full, depth + 1);
        else
            platform_remove(full);
    }
    free(list);
    platform_remove(dir); /* now empty */
}

/* ------------------------------------------------------------ progress file */

static void hex64(char *out, size_t cap, uint64_t v)
{
    snprintf(out, cap, "%08x%08x", (unsigned)(v >> 32), (unsigned)(v & 0xffffffffu));
}

static void diag_report_path(char *path, size_t cap)
{
    path_join(path, cap, platform_data_dir(), "diagnostic.txt");
}

/*
 * The report as far as it is known, written when the test starts and before every step. If the app closes, freezes
 * or the console is switched off half way, this file is what is left: it names the build that ran and the step
 * it was on, instead of leaving the previous run's report in place (which looks like a result of the new build).
 * Called by the thread that owns `rep` at that moment: the one that starts the test, then the worker.
 */
static void write_trail(const diag_report_t *rep, const char *result, const char *stage)
{
    char text[2600], path[1100], hv[20], ha[20];
    int n, finished = (int)__atomic_load_n(&D.deep_done, __ATOMIC_RELAXED);

    n = snprintf(text, sizeof(text),
                 "%s %s core diagnostic\n"
                 "build:          %s\n"
                 "folder:         %s\n"
                 "result:         %s\n"
                 "stage:          %s\n",
                 APP_NAME, APP_VERSION, APP_BUILD, platform_data_dir(), result, stage);
    if (n > 0 && rep->r.frames > 0 && (size_t)n < sizeof(text)) { /* the boot test is over */
        hex64(hv, sizeof(hv), rep->r.video_hash);
        hex64(ha, sizeof(ha), rep->r.audio_hash);
        n += snprintf(text + n, sizeof(text) - (size_t)n,
                      "boot test:      %d frames, video %s audio %s, %s the x86 reference, %.3f ms per frame\n",
                      rep->r.frames, hv, ha, coretest_matches_reference(&rep->r) ? "equal to" : "DIFFERENT from",
                      rep->r.ms_per_frame);
    }
    if (n > 0 && finished > 0 && (size_t)n < sizeof(text)) {
        n += snprintf(text + n, sizeof(text) - (size_t)n, "workloads done: %d of %d\n", finished, rep->deep_n);
        for (int i = 0; i < finished && i < rep->deep_n && n > 0 && (size_t)n < sizeof(text); i++)
            n += snprintf(text + n, sizeof(text) - (size_t)n, "  %-6s        %016llx %s\n", rep->deep[i].name,
                          (unsigned long long)rep->deep[i].hash,
                          !rep->deep[i].ran ? "NOT RUN" : rep->deep[i].match ? "ok" : "DIFFERS");
    }
    diag_report_path(path, sizeof(path));
    platform_remove(path); /* never leave an older report in place if the new one cannot be written */
    platform_write_file_atomic(path, text, strlen(text));
    LOGI("diagnostic: %s", stage);
    log_flush();
}

/* ----------------------------------------------------------------- worker */

/* One workload counts as this many boot frames in the progress bar. */
#define DEEP_WEIGHT 20

/* Runs the fixed hardware workloads on the (diagnostic mode) core. */
static void deep_phase(diag_report_t *rep)
{
    int n = deeptest_spec_count < DIAG_DEEP_MAX ? deeptest_spec_count : DIAG_DEEP_MAX;

    rep->deep_n = n;
    for (int i = 0; i < n; i++) {
        const deeptest_spec_t *sp = &deeptest_specs[i];
        diag_deep_t *d = &rep->deep[i];

        d->name = sp->name;
        d->expect = sp->expect;
        if (__atomic_load_n(&D.cancel, __ATOMIC_ACQUIRE))
            break;
        {
            char stage[80];

            __atomic_store_n(&D.stage, (uint32_t)(i + 1), __ATOMIC_RELEASE);
            snprintf(stage, sizeof(stage), "workload %d of %d: %s", i + 1, n, sp->name);
            write_trail(rep, "RUNNING - not finished (if the app closed or froze, it stopped at this stage)", stage);
        }
        {
            /*
             * Timed as well as hashed. A workload is exactly the same work on every run and in every build, so
             * this is the one measurement of the emulation core that can be compared between versions on the
             * console itself. A timing taken while a game runs cannot be: a different moment of the same game
             * draws a different mix of cels, and that moves the numbers far more than an optimisation does.
             */
            uint64_t t0 = platform_time_us();

            d->ran = deeptest_hash(sp, &d->hash);
            d->ms = (double)(platform_time_us() - t0) / 1000.0;
        }
        d->match = d->ran && sp->expect != 0 && d->hash == sp->expect;
        LOGI("diagnostic: workload %s: hash %016llx expected %016llx %s", sp->name, (unsigned long long)d->hash,
             (unsigned long long)sp->expect, d->match ? "ok" : "DIFFERS");
        __atomic_fetch_add(&D.deep_done, 1, __ATOMIC_RELAXED);
    }
}

/* The workloads and, after them, the timing of the cel engine and the DSP's thread: what the progress bar and the
   stage text count. */
#define DIAG_TESTS (deeptest_spec_count + 2)

/* Times the cel engine on sprites; see deeptest_celbench(). */
static void bench_phase(diag_report_t *rep)
{
    if (__atomic_load_n(&D.cancel, __ATOMIC_ACQUIRE))
        return;
    write_trail(rep, "RUNNING - not finished (if the app closed or froze, it stopped at this stage)",
                "timing the cel engine on sprites");
    __atomic_store_n(&D.stage, (uint32_t)(deeptest_spec_count + 1), __ATOMIC_RELEASE);
    rep->bench_ran = deeptest_celbench(rep->bench, &rep->bench_hash);
    rep->bench_match = rep->bench_ran && rep->bench_hash == deeptest_celbench_expect();
    for (int i = 0; i < DEEPTEST_CELBENCH_ROWS; i++)
        if (!rep->bench[i].same)
            rep->bench_match = false;
    LOGI("diagnostic: cel engine on sprites: hash %016llx expected %016llx %s", (unsigned long long)rep->bench_hash,
         (unsigned long long)deeptest_celbench_expect(), rep->bench_match ? "ok" : "DIFFERS");
    __atomic_fetch_add(&D.deep_done, 1, __ATOMIC_RELAXED);
}

/*
 * Plays the scripts of deeptest_dspthread_script() with the DSP inside the frame and on its own thread, then
 * times a wait for that thread. Last of the worker's phases: if the thread cannot be trusted on this console, the
 * report should already hold everything else.
 */
static void dspthr_phase(diag_report_t *rep)
{
    bool pass = true;
    int ran = 0;

    if (__atomic_load_n(&D.cancel, __ATOMIC_ACQUIRE))
        return;
    __atomic_store_n(&D.stage, (uint32_t)DIAG_TESTS, __ATOMIC_RELEASE);
    for (int i = 0; i < DEEPTEST_DSPTHREAD_SCRIPTS; i++) {
        deeptest_dspthread_row_t *row = &rep->dspthr[i];
        char stage[96];

        if (__atomic_load_n(&D.cancel, __ATOMIC_ACQUIRE))
            return;
        snprintf(stage, sizeof(stage), "the DSP inside the frame and on its own thread: script %d of %d", i + 1,
                 DEEPTEST_DSPTHREAD_SCRIPTS);
        write_trail(rep, "RUNNING - not finished (if the app closed or froze, it stopped at this stage)", stage);
        if (!deeptest_dspthread_script(i, row)) {
            pass = false;
            continue;
        }
        ran++;
        if (row->hash[0] != deeptest_dspthread_expect(i) || (row->threaded && !row->same))
            pass = false;
        LOGI("diagnostic: DSP script %d: inside the frame %016llx expected %016llx %s; on a thread %s (%llu waits, "
             "gave up %llu)",
             i + 1, (unsigned long long)row->hash[0], (unsigned long long)deeptest_dspthread_expect(i),
             row->hash[0] == deeptest_dspthread_expect(i) ? "ok" : "DIFFERS",
             !row->threaded ? "not run" : row->same ? "the same" : row->complete ? "DIFFERS" : "CUT SHORT",
             (unsigned long long)row->waits, (unsigned long long)row->gave_up);
    }
    rep->dspthr_ran = ran == DEEPTEST_DSPTHREAD_SCRIPTS;
    rep->dspthr_pass = rep->dspthr_ran && pass;
    if (!__atomic_load_n(&D.cancel, __ATOMIC_ACQUIRE)) {
        write_trail(rep, "RUNNING - not finished (if the app closed or froze, it stopped at this stage)",
                    "timing a wait for the DSP's thread");
        deeptest_dspwait(&rep->dspwait);
    }
    __atomic_fetch_add(&D.deep_done, 1, __ATOMIC_RELAXED);
}

static int diag_main(void *arg)
{
    char dir[1100];
    diag_report_t *rep = &D.rep;
    bool ran;
    (void)arg;

    platform_pin_thread(g_cfg.emu_core); /* measure the speed where games will run */
    path_join(dir, sizeof(dir), platform_data_dir(), "diag");
    remove_tree(dir, 0);
    platform_mkdirs(dir);

    core_diag_enter(dir);
    if (!__atomic_load_n(&D.cancel, __ATOMIC_ACQUIRE))
        ran = coretest_run(NULL, CORETEST_REF_FRAMES, &rep->r);
    else {
        ran = false;
        rep->r.cancelled = true;
    }
    if (ran && !rep->r.cancelled) {
        deep_phase(rep);
        bench_phase(rep);
        dspthr_phase(rep);
    }
    core_diag_leave();
    remove_tree(dir, 0);

    rep->cancelled = rep->r.cancelled || __atomic_load_n(&D.cancel, __ATOMIC_ACQUIRE) != 0;
    rep->started = rep->r.loaded;
    if (ran && !rep->cancelled) {
        double frame_ms = rep->r.fps > 1.0 ? 1000.0 / rep->r.fps : 1000.0 / 60.0;

        rep->matches = coretest_matches_reference(&rep->r);
        rep->state_ok = rep->r.state_ok;
        rep->deterministic = rep->r.deterministic;
        rep->deep_pass = rep->deep_n > 0;
        for (int i = 0; i < rep->deep_n; i++)
            if (!rep->deep[i].match)
                rep->deep_pass = false;
        rep->ms_per_frame = rep->r.ms_per_frame;
        rep->realtime_x = rep->ms_per_frame > 0.0 ? frame_ms / rep->ms_per_frame : 0.0;
        rep->pass = rep->matches && rep->state_ok && rep->deterministic && rep->deep_pass && rep->bench_match &&
                    rep->dspthr_pass;
    }
    __atomic_store_n(&D.state, 2, __ATOMIC_RELEASE);
    return 0;
}

/* -------------------------------------------------------------- public API */

bool diag_start(void)
{
    if (D.thread || __atomic_load_n(&D.state, __ATOMIC_ACQUIRE) != 0 || core_is_loaded())
        return false;
    memset(&D.rep, 0, sizeof(D.rep));
    __atomic_store_n(&D.cancel, 0, __ATOMIC_RELEASE);
    __atomic_store_n(&D.deep_done, 0, __ATOMIC_RELEASE);
    __atomic_store_n(&D.stage, 0, __ATOMIC_RELEASE);
    __atomic_store_n(&D.state, 1, __ATOMIC_RELEASE);
    log_set_sync(true); /* every line of the run reaches the card as it is written */
    LOGI("diagnostic: starting (%s %s, built %s)", APP_NAME, APP_VERSION, APP_BUILD);
    /* Written here, before the worker exists, so that the previous run's report is gone the moment the test starts. */
    write_trail(&D.rep, "RUNNING - not finished (if the app closed or froze, it stopped at this stage)",
                "boot test (the built-in BIOS, CORETEST_REF_FRAMES frames, then save state, replay and speed)");
    D.thread = SDL_CreateThreadWithStackSize(diag_main, "operau-diag", DIAG_STACK, NULL);
    if (!D.thread) {
        LOGE("diagnostic: cannot start the worker thread: %s", SDL_GetError());
        write_trail(&D.rep, "NOT STARTED", "the worker thread could not be created");
        log_set_sync(false);
        __atomic_store_n(&D.state, 0, __ATOMIC_RELEASE);
        return false;
    }
    LOGI("diagnostic: started");
    return true;
}

bool diag_running(void)
{
    return __atomic_load_n(&D.state, __ATOMIC_ACQUIRE) == 1;
}

void diag_progress(int *done, int *total)
{
    coretest_progress(done, total);
    if (*total > 0) { /* the workloads follow the boot test */
        *total += DIAG_TESTS * DEEP_WEIGHT;
        *done += (int)__atomic_load_n(&D.deep_done, __ATOMIC_RELAXED) * DEEP_WEIGHT;
    }
}

void diag_stage(char *out, size_t cap)
{
    uint32_t st = __atomic_load_n(&D.stage, __ATOMIC_ACQUIRE);

    if (st == 0 || st > (uint32_t)DIAG_TESTS)
        str_copy(out, tr(S_DIAG_STAGE_BOOT), cap);
    else
        snprintf(out, cap, tr(S_DIAG_STAGE_WL), (int)st, DIAG_TESTS,
                 st <= (uint32_t)deeptest_spec_count ? deeptest_specs[st - 1].name
                 : st == (uint32_t)deeptest_spec_count + 1 ? "celb" : "dspc");
}

void diag_cancel(void)
{
    if (!diag_running())
        return;
    __atomic_store_n(&D.cancel, 1, __ATOMIC_RELEASE);
    coretest_cancel();
}

bool diag_poll(diag_report_t *out)
{
    if (__atomic_load_n(&D.state, __ATOMIC_ACQUIRE) != 2)
        return false;
    SDL_WaitThread(D.thread, NULL);
    D.thread = NULL;
    *out = D.rep;

    /*
     * The GPU probe runs here, and not with the workloads above, for one reason: GX2 is a single stream of
     * commands with no locking of its own, and the renderer feeds it from this thread. Sending the probe's draws
     * from the worker thread would interleave two streams and corrupt both. By this point the worker has been
     * joined, and the main loop has not started drawing this frame, so the probe has GX2 to itself.
     */
    if (!out->cancelled)
        gpu_probe(&out->gpu);

    log_set_sync(false);
    __atomic_store_n(&D.state, 0, __ATOMIC_RELEASE);
    return true;
}

void diag_shutdown(void)
{
    if (!D.thread)
        return;
    __atomic_store_n(&D.cancel, 1, __ATOMIC_RELEASE);
    coretest_cancel();
    SDL_WaitThread(D.thread, NULL);
    D.thread = NULL;
    diag_write_report(&D.rep); /* says "cancelled": not a "RUNNING" trail that would never be updated again */
    log_set_sync(false);
    __atomic_store_n(&D.state, 0, __ATOMIC_RELEASE);
}

/* ------------------------------------------------------------------ report */

/* One decimal, with the decimal comma in Portuguese. */
static void fmt1(char *out, size_t cap, double v)
{
    snprintf(out, cap, "%.1f", v);
    if (g_cfg.language == LANG_PT)
        for (char *c = out; *c; c++)
            if (*c == '.')
                *c = ',';
}

bool diag_format(const diag_report_t *rep, char *out, size_t cap)
{
    char line[400], hv[20], ha[20], rv[20], ra[20], n1[24], n2[24];
    bool problem = true;

    out[0] = '\0';
    if (rep->cancelled) {
        str_copy(out, tr(S_DIAG_CANCELLED), cap);
        return false;
    }
    if (!rep->started) {
        snprintf(line, sizeof(line), tr(S_DIAG_NOSTART), rep->r.error[0] ? rep->r.error : "?");
        str_copy(out, line, cap);
        return true;
    }

    if (rep->pass) {
        str_copy(out, tr(S_DIAG_PASS), cap);
        problem = false;
    } else if (!rep->matches) {
        str_copy(out, tr(S_DIAG_FAIL), cap);
    } else if (!rep->state_ok || !rep->deterministic) {
        str_copy(out, tr(S_DIAG_FAIL_STATE), cap);
    } else if (!rep->deep_pass || !rep->bench_match) {
        str_copy(out, tr(S_DIAG_FAIL_DEEP), cap);
    } else {
        str_copy(out, tr(S_DIAG_FAIL_DSPTHR), cap);
    }

    hex64(hv, sizeof(hv), rep->r.video_hash);
    hex64(ha, sizeof(ha), rep->r.audio_hash);
    hex64(rv, sizeof(rv), CORETEST_REF_VIDEO_HASH);
    hex64(ra, sizeof(ra), CORETEST_REF_AUDIO_HASH);
    if (!rep->matches) {
        snprintf(line, sizeof(line), tr(S_DIAG_HASHES), hv, rv, ha, ra);
        str_cat(out, "\n\n", cap);
        str_cat(out, line, cap);
    }

    str_cat(out, "\n\n", cap);
    if (!rep->state_ok) {
        str_cat(out, tr(S_DIAG_STATE_FAIL), cap);
    } else if (!rep->deterministic) {
        str_cat(out, tr(S_DIAG_STATE_DIFF), cap);
    } else {
        fmt1(n1, sizeof(n1), (double)rep->r.state_size / (1024.0 * 1024.0));
        snprintf(line, sizeof(line), tr(S_DIAG_STATE_OK), n1);
        str_cat(out, line, cap);
    }

    if (rep->deep_n > 0) { /* hardware workloads */
        int ok = 0;
        char bad[160] = "";

        for (int i = 0; i < rep->deep_n; i++) {
            if (rep->deep[i].match) {
                ok++;
            } else {
                if (bad[0])
                    str_cat(bad, ", ", sizeof(bad));
                str_cat(bad, rep->deep[i].name, sizeof(bad));
            }
        }
        str_cat(out, "\n", cap);
        if (ok == rep->deep_n)
            snprintf(line, sizeof(line), tr(S_DIAG_DEEP_OK), ok, rep->deep_n);
        else
            snprintf(line, sizeof(line), tr(S_DIAG_DEEP_FAIL), ok, rep->deep_n, bad);
        str_cat(out, line, cap);
    }

    if (rep->dspthr_ran) { /* the DSP on its own thread */
        int threaded = 0, same = 0, equal = 0;

        for (int i = 0; i < DEEPTEST_DSPTHREAD_SCRIPTS; i++) {
            threaded += rep->dspthr[i].threaded ? 1 : 0;
            same += rep->dspthr[i].same ? 1 : 0;
            equal += rep->dspthr[i].hash[0] == deeptest_dspthread_expect(i) ? 1 : 0;
        }
        str_cat(out, "\n", cap);
        if (!threaded)
            snprintf(line, sizeof(line), "%s", tr(S_DIAG_DSPTHR_NONE));
        else if (same == DEEPTEST_DSPTHREAD_SCRIPTS && equal == DEEPTEST_DSPTHREAD_SCRIPTS)
            snprintf(line, sizeof(line), tr(S_DIAG_DSPTHR_OK), same, DEEPTEST_DSPTHREAD_SCRIPTS);
        else
            snprintf(line, sizeof(line), tr(S_DIAG_DSPTHR_FAIL), same < equal ? same : equal,
                     DEEPTEST_DSPTHREAD_SCRIPTS);
        str_cat(out, line, cap);
    }

    str_cat(out, "\n", cap);
    fmt1(n1, sizeof(n1), rep->ms_per_frame);
    fmt1(n2, sizeof(n2), rep->realtime_x);
    snprintf(line, sizeof(line), tr(S_DIAG_SPEED), n1, n2);
    str_cat(out, line, cap);
    return problem;
}

bool diag_write_report(const diag_report_t *rep)
{
    char text[8400], path[1100], hv[20], ha[20], rv[20], ra[20];
    int n;

    hex64(hv, sizeof(hv), rep->r.video_hash);
    hex64(ha, sizeof(ha), rep->r.audio_hash);
    hex64(rv, sizeof(rv), CORETEST_REF_VIDEO_HASH);
    hex64(ra, sizeof(ra), CORETEST_REF_AUDIO_HASH);
    n = snprintf(text, sizeof(text),
                 "%s %s core diagnostic\n"
                 "build:          %s\n"
                 "folder:         %s\n"
                 "result:         %s\n"
                 "started:        %d\n"
                 "frames:         %d\n"
                 "video hash:     %s\n"
                 "video expected: %s\n"
                 "audio hash:     %s\n"
                 "audio expected: %s\n"
                 "picture:        %ux%u, %llu non-black pixels\n"
                 "audio frames:   %u at %.0f Hz\n"
                 "state size:     %zu bytes, save/load ok: %d, replay identical: %d\n"
                 "replay video:   %016llx\n"
                 "replay audio:   %016llx\n"
                 "speed:          %.3f ms per frame (%.2fx real time)\n"
                 "error:          %s\n",
                 APP_NAME, APP_VERSION, APP_BUILD, platform_data_dir(),
                 rep->cancelled ? "cancelled" : (rep->pass ? "PASS" : "FAIL"), rep->started,
                 rep->r.frames, hv, rv, ha, ra, rep->r.width, rep->r.height, (unsigned long long)rep->r.nonzero_pixels,
                 rep->r.audio_frames, rep->r.sample_rate, rep->r.state_size, rep->state_ok, rep->deterministic,
                 (unsigned long long)rep->r.replay_video_hash, (unsigned long long)rep->r.replay_audio_hash,
                 rep->ms_per_frame, rep->realtime_x, rep->r.error[0] ? rep->r.error : "-");
    if (n < 0)
        return false;
    if ((size_t)n < sizeof(text)) {
        int ok = 0;

        for (int i = 0; i < rep->deep_n; i++)
            ok += rep->deep[i].match ? 1 : 0;
        n += snprintf(text + n, sizeof(text) - (size_t)n, "workloads:      %d of %d equal to the x86 reference\n", ok,
                      rep->deep_n);
        for (int i = 0; i < rep->deep_n && (size_t)n < sizeof(text); i++) {
            const diag_deep_t *d = &rep->deep[i];

            n += snprintf(text + n, sizeof(text) - (size_t)n,
                          "  %-6s        %016llx expected %016llx %-7s %8.1f ms\n", d->name,
                          (unsigned long long)d->hash, (unsigned long long)d->expect,
                          !d->ran ? "NOT RUN" : d->match ? "ok" : "DIFFERS", d->ms);
        }
    }

    /*
     * The cel engine on sprites. The workloads above are random cels: right for finding a difference, wrong for
     * saying what a game pays. These are eight shapes a game draws, and the time is per pixel written, with the
     * engine's table of finished pixels switched off and on - so the line says what that table is worth on this
     * console, for a picture that is the same in every build.
     */
    if ((size_t)n < sizeof(text)) {
        if (!rep->bench_ran)
            n += snprintf(text + n, sizeof(text) - (size_t)n, "cel sprites:    not run\n");
        else
            n += snprintf(text + n, sizeof(text) - (size_t)n,
                          "cel sprites:    %016llx expected %016llx %s\n"
                          "  ns per pixel written, with the table of finished pixels off and on\n",
                          (unsigned long long)rep->bench_hash, (unsigned long long)deeptest_celbench_expect(),
                          rep->bench_match ? "ok" : "DIFFERS");
        for (int i = 0; rep->bench_ran && i < DEEPTEST_CELBENCH_ROWS && (size_t)n < sizeof(text); i++) {
            const deeptest_celbench_row_t *b = &rep->bench[i];
            double px = (double)b->pixels * (double)b->draws;

            n += snprintf(text + n, sizeof(text) - (size_t)n, "  %-33s %6llu px  off %7.1f  on %7.1f  %s\n", b->name,
                          (unsigned long long)b->pixels, px > 0 ? b->us[0] * 1000.0 / px : 0.0,
                          px > 0 ? b->us[1] * 1000.0 / px : 0.0, b->same ? "same picture" : "PICTURES DIFFER");
        }
    }

    /*
     * The DSP on a thread of its own. Each script is ticks of the DSP and, between them, what a game's sound
     * code does to it; it is played with the DSP inside the frame, which must give what x86 gives, and again with
     * the DSP on its thread, which must give the same again. The times are the whole script either way, and the
     * waits are the CPU's, for the thread to catch up before one of its writes. The last line is what one such
     * wait costs here: it decides how the thread should be woken.
     */
    if ((size_t)n < sizeof(text)) {
        int threaded = 0, same = 0, equal = 0;

        for (int i = 0; i < DEEPTEST_DSPTHREAD_SCRIPTS; i++) {
            threaded += rep->dspthr[i].threaded ? 1 : 0;
            same += rep->dspthr[i].same ? 1 : 0;
            equal += rep->dspthr[i].ran && rep->dspthr[i].hash[0] == deeptest_dspthread_expect(i) ? 1 : 0;
        }
        if (!rep->dspthr_ran)
            n += snprintf(text + n, sizeof(text) - (size_t)n, "DSP thread:     not run\n");
        else if (!threaded)
            n += snprintf(text + n, sizeof(text) - (size_t)n,
                          "DSP thread:     NO THREAD COULD BE STARTED; inside the frame %d of %d scripts equal to the "
                          "x86 reference\n",
                          equal, DEEPTEST_DSPTHREAD_SCRIPTS);
        else
            n += snprintf(text + n, sizeof(text) - (size_t)n,
                          "DSP thread:     inside the frame %d of %d scripts equal to the x86 reference; on a thread "
                          "%d of %d the same\n"
                          "  ms for the script inside the frame / on the thread; the CPU's waits for the thread\n",
                          equal, DEEPTEST_DSPTHREAD_SCRIPTS, same, DEEPTEST_DSPTHREAD_SCRIPTS);
        for (int i = 0; rep->dspthr_ran && i < DEEPTEST_DSPTHREAD_SCRIPTS && (size_t)n < sizeof(text); i++) {
            const deeptest_dspthread_row_t *d = &rep->dspthr[i];
            static const char *const parts[5] = {"the sound", "the DSP's state", "the CLIO's state",
                                                 "the memory it wrote", "what the CPU read back"};

            n += snprintf(text + n, sizeof(text) - (size_t)n,
                          "  script %d      %016llx expected %016llx %-7s thread %-9s %7.1f / %7.1f ms, %5llu waits "
                          "%7.1f ms, gave up %llu\n",
                          i + 1, (unsigned long long)d->hash[0], (unsigned long long)deeptest_dspthread_expect(i),
                          d->hash[0] == deeptest_dspthread_expect(i) ? "ok" : "DIFFERS",
                          !d->threaded ? "none" : d->same ? "same" : d->complete ? "DIFFERS" : "CUT SHORT", d->ms[0],
                          d->ms[1], (unsigned long long)d->waits, d->wait_ms, (unsigned long long)d->gave_up);
            if (d->threaded && d->complete && !d->same && (size_t)n < sizeof(text)) {
                n += snprintf(text + n, sizeof(text) - (size_t)n, "                on the thread %016llx; different:",
                              (unsigned long long)d->hash[1]);
                for (int k = 0; k < 5 && (size_t)n < sizeof(text); k++)
                    if (d->differs[k])
                        n += snprintf(text + n, sizeof(text) - (size_t)n, " %s;", parts[k]);
                if ((size_t)n < sizeof(text))
                    n += snprintf(text + n, sizeof(text) - (size_t)n, "\n");
            }
        }
        if (rep->dspwait.ran && (size_t)n < sizeof(text)) {
            if (rep->dspwait.threaded)
                n += snprintf(text + n, sizeof(text) - (size_t)n,
                              "  one tick      %.2f us inside the frame; handed to the thread and waited for, %.2f us "
                              "just after it ran, %.2f us from asleep (gave up %llu)\n",
                              rep->dspwait.frame_us, rep->dspwait.hot_us, rep->dspwait.cold_us,
                              (unsigned long long)rep->dspwait.gave_up);
            else
                n += snprintf(text + n, sizeof(text) - (size_t)n, "  one tick      %.2f us inside the frame\n",
                              rep->dspwait.frame_us);
        }
    }

    /*
     * The GPU probe. Two numbers decide whether the cel engine could be drawn by the GPU instead of the CPU:
     * whether it computes the 3DO's pixel arithmetic identically, and what it costs to hand a frame back - the
     * 3DO's frame buffer cannot leave main memory, because the ARM, the SPORT and the video hardware all read it
     * as ordinary memory. A hand-off has to fit, with everything else, inside 16.7 ms for 60 fps.
     */
    if ((size_t)n < sizeof(text)) {
        const gpu_probe_t *g = &rep->gpu;

        if (!g->ran)
            n += snprintf(text + n, sizeof(text) - (size_t)n, "GPU probe:      not run (%s)\n",
                          g->err[0] ? g->err : "-");
        else
            n += snprintf(text + n, sizeof(text) - (size_t)n,
                          "GPU probe:      %s\n"
                          "  never drawn   %u pixels still held the CPU's mark\n"
                          "  shader ran    %u of %u pixels lack the shader's own constant\n"
                          "  reads source  %u of %u wrong\n"
                          "  reads table   %u of %u wrong\n"
                          "  pixel maths   %u of %u wrong, over %u shapes\n"
                          "  first differs %s\n"
                          "  draw          %.3f ms for 320x240\n"
                          "  draw+hand-off %.3f ms (the CPU waiting for pixels it may read)\n"
                          "  target layout pitch %u, image %u bytes\n",
                          g->exact ? "exact" : "DIFFERS FROM THE CPU", (unsigned)g->untouched,
                          (unsigned)g->beacon_wrong, (unsigned)g->beacon_pixels, (unsigned)g->src_wrong,
                          (unsigned)g->src_pixels, (unsigned)g->lut_wrong, (unsigned)g->lut_pixels,
                          (unsigned)g->math_wrong, (unsigned)g->math_pixels, (unsigned)g->configs,
                          g->sample[0] ? g->sample : "-", g->draw_ms, g->trip_ms, (unsigned)g->pitch,
                          (unsigned)g->image_size);

        for (int i = 0; i < g->shape_n && (size_t)n < sizeof(text); i++)
            n += snprintf(text + n, sizeof(text) - (size_t)n, "  shape %-22s %.3f ms\n", g->shape[i].name,
                          g->shape[i].ms);

        for (int i = 0; i < g->uni_n && (size_t)n < sizeof(text); i++)
            n += snprintf(text + n, sizeof(text) - (size_t)n, "  uniform by %-20s got %02x want %02x %s\n",
                          g->uni[i].name, g->uni[i].got, g->uni[i].want,
                          g->uni[i].got == g->uni[i].want ? "<== this one works" : "");

        for (int i = 0; i < g->per_n && (size_t)n < sizeof(text); i++)
            n += snprintf(text + n, sizeof(text) - (size_t)n, "  %-15s %u of 320 wrong\n", g->per[i].name,
                          (unsigned)g->per[i].wrong);
    }
    LOGI("diagnostic report:\n%s", text);
    path_join(path, sizeof(path), platform_data_dir(), "diagnostic.txt");
    return platform_write_file_atomic(path, text, strlen(text));
}
