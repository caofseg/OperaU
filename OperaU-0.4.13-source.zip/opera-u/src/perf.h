/*
 * Where the time of a frame goes.
 *
 * The core carries a few timing hooks (libopera/opera_prof.h). While they are on, the emulation thread calls
 * perf_frame() after every frame; every few seconds the numbers are turned into a short report in the log and
 * a one-line summary for the on-screen display (Settings > Video > Show FPS):
 *
 *   perf: 33.4 fps (56% of real time) | run 29.9 ms + wait 0.0 ms per frame
 *   perf: of run: ARM 17.8 ms (60%) | cel 6.0 (20%) | DSP 3.9 (13%) | video lines 1.1 (4%) | ...
 *   perf: per frame: 3 cel lists, 41 cels, 118k texels, 79k pixels | 735 DSP runs | 263 video lines
 *
 * The cost of measuring is a few hundred time base reads per frame (well under 1% of a frame).
 */
#ifndef OPERAU_PERF_H
#define OPERAU_PERF_H

#include "common.h"

/* Asks for measuring on or off. Any thread; takes effect between two frames (perf_sync). */
void perf_set_enabled(bool on);
/* Emulation thread, start of every loop turn: applies the request above. */
void perf_sync(void);
/* The time base the run/wait stretches below are measured in. */
uint32_t perf_now(void);
/* Emulation thread, once per frame: ticks spent in core_run() and in pacing (waiting for audio / the clock). */
void perf_frame(uint32_t run_ticks, uint32_t wait_ticks);
/* A new game or a resume: forget the window in progress and the summary on screen. */
void perf_reset(void);
/* Emulation thread, when the game stops running (paused, closed, HOME menu): writes the report of the last full
 * window to the card now, if it is not there yet. The game is standing still, so the write disturbs nothing. */
void perf_flush(void);
/* Any thread, once, when the app closes and no game runs: ends the thread that writes the report while a game
 * plays. */
void perf_shutdown(void);
/* UI thread: copies the latest one-line summary ("run 29.9 ms | ARM 60% CEL 20% ..."); false while there is none. */
bool perf_hud_text(char *out, size_t cap);

#endif
