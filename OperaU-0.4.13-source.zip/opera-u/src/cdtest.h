/*
 * Disc image read test (host and PowerPC harness only, never in the Wii U app).
 *
 * Opens an ISO, BIN/CUE or CHD through the core's own cdimage layer, reads every
 * sector the way the 3DO side does and prints FNV-1a hashes of what came back:
 *
 *   cdhash blocks N user <hash> full <hash> bytes B
 *
 * "user" is the 2048 bytes of data of each sector, "full" is the whole sector
 * as the track stores it (2048, 2352 or 2448 bytes). The hashes only depend on
 * byte VALUES, so the line printed on x86 and the one printed under qemu-ppc
 * must be identical, and tools/test_chd_codecs.py compares both against the
 * hashes of the source data the test image was built from.
 */
#ifndef OPERAU_CDTEST_H
#define OPERAU_CDTEST_H

#include "common.h"

bool cdtest_hash(const char *path);

#endif
