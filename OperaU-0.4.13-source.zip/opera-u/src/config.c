#include "config.h"
#include "input.h"
#include "log.h"
#include "platform.h"

#include <ctype.h>

settings_t g_cfg;
kvmap_t g_core_opts_global;
kvmap_t g_core_opts_game;

static char g_game_ini_path[1100];

/* ===================================================================== */
/* key/value store                                                        */
/* ===================================================================== */

void kv_init(kvmap_t *m)
{
    memset(m, 0, sizeof(*m));
}

void kv_clear(kvmap_t *m)
{
    for (int i = 0; i < m->count; i++) {
        free(m->items[i].key);
        free(m->items[i].val);
    }
    m->count = 0;
}

void kv_free(kvmap_t *m)
{
    kv_clear(m);
    free(m->items);
    memset(m, 0, sizeof(*m));
}

static char *dupstr(const char *s)
{
    size_t n = strlen(s) + 1;
    char *p = malloc(n);
    if (p)
        memcpy(p, s, n);
    return p;
}

void kv_set(kvmap_t *m, const char *key, const char *val)
{
    for (int i = 0; i < m->count; i++) {
        if (!strcmp(m->items[i].key, key)) {
            char *nv = dupstr(val);
            if (nv) {
                free(m->items[i].val);
                m->items[i].val = nv;
            }
            return;
        }
    }
    if (m->count == m->cap) {
        int ncap = m->cap ? m->cap * 2 : 32;
        kv_item_t *n = realloc(m->items, (size_t)ncap * sizeof(*n));
        if (!n)
            return;
        m->items = n;
        m->cap = ncap;
    }
    m->items[m->count].key = dupstr(key);
    m->items[m->count].val = dupstr(val);
    if (m->items[m->count].key && m->items[m->count].val)
        m->count++;
}

bool kv_remove(kvmap_t *m, const char *key)
{
    for (int i = 0; i < m->count; i++) {
        if (!strcmp(m->items[i].key, key)) {
            free(m->items[i].key);
            free(m->items[i].val);
            memmove(&m->items[i], &m->items[i + 1], (size_t)(m->count - i - 1) * sizeof(kv_item_t));
            m->count--;
            return true;
        }
    }
    return false;
}

const char *kv_get(const kvmap_t *m, const char *key)
{
    for (int i = 0; i < m->count; i++)
        if (!strcmp(m->items[i].key, key))
            return m->items[i].val;
    return NULL;
}

static char *trim(char *s)
{
    while (*s && isspace((unsigned char)*s))
        s++;
    char *e = s + strlen(s);
    while (e > s && isspace((unsigned char)e[-1]))
        *--e = '\0';
    return s;
}

bool kv_load(kvmap_t *m, const char *path)
{
    size_t size = 0;
    char *buf = platform_read_file(path, &size);
    if (!buf)
        return false;
    char *line = buf;
    while (line && *line) {
        char *next = strchr(line, '\n');
        if (next)
            *next++ = '\0';
        char *l = trim(line);
        if (*l && *l != '#' && *l != ';') {
            char *eq = strchr(l, '=');
            if (eq) {
                *eq = '\0';
                char *k = trim(l);
                char *v = trim(eq + 1);
                if (*k)
                    kv_set(m, k, v);
            }
        }
        line = next;
    }
    free(buf);
    return true;
}

bool kv_save(const kvmap_t *m, const char *path)
{
    size_t cap = 256;
    for (int i = 0; i < m->count; i++)
        cap += strlen(m->items[i].key) + strlen(m->items[i].val) + 4;
    char *buf = malloc(cap);
    if (!buf)
        return false;
    size_t n = 0;
    for (int i = 0; i < m->count; i++)
        n += (size_t)snprintf(buf + n, cap - n, "%s=%s\n", m->items[i].key, m->items[i].val);
    bool ok = platform_write_file_atomic(path, buf, n);
    free(buf);
    return ok;
}

/* ===================================================================== */
/* settings                                                               */
/* ===================================================================== */

void config_path(char *out, size_t cap, const char *sub)
{
    path_join(out, cap, platform_data_dir(), sub);
}

void config_defaults(settings_t *s)
{
    memset(s, 0, sizeof(*s));
    s->aspect = ASPECT_4_3;
    s->filter = FILTER_LINEAR;
    s->vsync = true;
    s->show_fps = false;
    s->color_order = 0;
    s->perf_log = true;
    s->volume = 100;
    s->latency_ms = AUDIO_LATENCY_DEFAULT_MS;
    s->emu_core = 2;
    s->threaded = true;
    s->deadzone = 28;
    s->menu_lr = true;
    input_default_map(s->button_map);
    s->language = LANG_PT;
    s->udp_log = false;
    s->autosave_state = true;
    s->state_slot = 0;
    str_copy(s->browse_dir, platform_default_browse_dir(), sizeof(s->browse_dir));
}

static const char *const k_btn_key[B3DO_COUNT] = {
    "map.up", "map.down", "map.left", "map.right",
    "map.a", "map.b", "map.c", "map.l", "map.r", "map.x", "map.p",
};

static bool parse_bool(const char *v, bool def)
{
    if (!v)
        return def;
    if (!strcmp(v, "1") || str_ieq(v, "true") || str_ieq(v, "yes") || str_ieq(v, "on"))
        return true;
    if (!strcmp(v, "0") || str_ieq(v, "false") || str_ieq(v, "no") || str_ieq(v, "off"))
        return false;
    return def;
}

static int parse_int(const char *v, int def, int lo, int hi)
{
    if (!v || !*v)
        return def;
    char *end;
    long n = strtol(v, &end, 10);
    if (end == v)
        return def;
    return (int)CLAMP(n, lo, hi);
}

static void make_dirs(void)
{
    static const char *const subs[] = {
        "", "roms", "bios", "saves", "states", "config", "config/games", "shots", "logs",
    };
    char p[1100];
    for (size_t i = 0; i < ARRAY_LEN(subs); i++) {
        config_path(p, sizeof(p), subs[i]);
        if (!platform_is_dir(p) && !platform_mkdirs(p))
            LOGW("could not create %s", p);
    }
}

void config_load(void)
{
    char path[1100];
    kvmap_t m;

    make_dirs();
    config_defaults(&g_cfg);
    kv_init(&g_core_opts_global);
    kv_init(&g_core_opts_game);
    kv_init(&m);

    config_path(path, sizeof(path), "config/operau.ini");
    if (kv_load(&m, path)) {
        settings_t *s = &g_cfg;
        s->aspect = parse_int(kv_get(&m, "aspect"), s->aspect, 0, ASPECT_COUNT - 1);
        s->filter = parse_int(kv_get(&m, "filter"), s->filter, 0, FILTER_COUNT - 1);
        s->vsync = parse_bool(kv_get(&m, "vsync"), s->vsync);
        s->show_fps = parse_bool(kv_get(&m, "show_fps"), s->show_fps);
        s->color_order = parse_int(kv_get(&m, "color_order"), s->color_order, 0, 5);
        s->perf_log = parse_bool(kv_get(&m, "perf_log"), s->perf_log);
        s->volume = parse_int(kv_get(&m, "volume"), s->volume, 0, 100);
        s->latency_ms = parse_int(kv_get(&m, "latency_ms"), s->latency_ms, 30, 300);
        /* a file from before the default went down still holds the old default, not a choice: see config.h */
        if (parse_int(kv_get(&m, "audio_version"), 1, 1, 100) < AUDIO_DEFAULTS_VERSION && s->latency_ms == 80)
            s->latency_ms = AUDIO_LATENCY_DEFAULT_MS;
        s->emu_core = parse_int(kv_get(&m, "emu_core"), s->emu_core, -1, 2);
        s->threaded = parse_bool(kv_get(&m, "threaded"), s->threaded);
        s->deadzone = parse_int(kv_get(&m, "deadzone"), s->deadzone, 5, 80);
        s->menu_lr = parse_bool(kv_get(&m, "menu_lr"), s->menu_lr);
        s->language = parse_int(kv_get(&m, "language"), s->language, 0, LANG_COUNT - 1);
        s->udp_log = parse_bool(kv_get(&m, "udp_log"), s->udp_log);
        s->autosave_state = parse_bool(kv_get(&m, "autosave_state"), s->autosave_state);
        s->state_slot = parse_int(kv_get(&m, "state_slot"), s->state_slot, 0, 9);
        const char *bd = kv_get(&m, "browse_dir");
        if (bd && *bd)
            str_copy(s->browse_dir, bd, sizeof(s->browse_dir));
        if (parse_int(kv_get(&m, "map_version"), 1, 1, 100) >= BUTTON_MAP_VERSION) {
            for (int i = 0; i < B3DO_COUNT; i++) {
                const char *v = kv_get(&m, k_btn_key[i]);
                if (v && *v)
                    s->button_map[i] = parse_int(v, s->button_map[i], -1, 200);
            }
        } else {
            LOGI("config: the stored button mapping is older than the current default; using the new default");
        }
        s->recent_count = 0;
        for (int i = 0; i < MAX_RECENT; i++) {
            char key[24];
            snprintf(key, sizeof(key), "recent.%d", i);
            const char *v = kv_get(&m, key);
            if (v && *v) {
                str_copy(s->recent[s->recent_count], v, sizeof(s->recent[0]));
                s->recent_count++;
            }
        }
    }
    kv_free(&m);

    config_path(path, sizeof(path), "config/core.ini");
    kv_load(&g_core_opts_global, path);
}

bool config_save(void)
{
    char path[1100];
    kvmap_t m;
    char num[32];
    const settings_t *s = &g_cfg;
    bool ok;

    kv_init(&m);
#define SET_INT(k, v) do { snprintf(num, sizeof(num), "%d", (int)(v)); kv_set(&m, k, num); } while (0)
    SET_INT("aspect", s->aspect);
    SET_INT("filter", s->filter);
    SET_INT("vsync", s->vsync);
    SET_INT("show_fps", s->show_fps);
    SET_INT("color_order", s->color_order);
    SET_INT("perf_log", s->perf_log);
    SET_INT("volume", s->volume);
    SET_INT("latency_ms", s->latency_ms);
    SET_INT("audio_version", AUDIO_DEFAULTS_VERSION);
    SET_INT("emu_core", s->emu_core);
    SET_INT("threaded", s->threaded);
    SET_INT("deadzone", s->deadzone);
    SET_INT("menu_lr", s->menu_lr);
    SET_INT("language", s->language);
    SET_INT("udp_log", s->udp_log);
    SET_INT("autosave_state", s->autosave_state);
    SET_INT("state_slot", s->state_slot);
    kv_set(&m, "browse_dir", s->browse_dir);
    SET_INT("map_version", BUTTON_MAP_VERSION);
    for (int i = 0; i < B3DO_COUNT; i++)
        SET_INT(k_btn_key[i], s->button_map[i]);
    for (int i = 0; i < s->recent_count; i++) {
        char key[24];
        snprintf(key, sizeof(key), "recent.%d", i);
        kv_set(&m, key, s->recent[i]);
    }
#undef SET_INT
    config_path(path, sizeof(path), "config/operau.ini");
    ok = kv_save(&m, path);
    kv_free(&m);

    config_path(path, sizeof(path), "config/core.ini");
    ok = kv_save(&g_core_opts_global, path) && ok;
    if (!ok)
        LOGW("failed to save configuration");
    return ok;
}

/* ===================================================================== */
/* per-game overrides                                                     */
/* ===================================================================== */

static void game_ini_path(char *out, size_t cap, const char *game_path)
{
    char stem[256], safe[256], sub[300];
    path_stem(stem, sizeof(stem), game_path);
    size_t j = 0;
    for (size_t i = 0; stem[i] && j + 1 < sizeof(safe); i++) {
        unsigned char c = (unsigned char)stem[i];
        safe[j++] = (strchr("\\/:*?\"<>|", c) || c < 32) ? '_' : (char)c;
    }
    safe[j] = '\0';
    snprintf(sub, sizeof(sub), "config/games/%s.ini", safe);
    config_path(out, cap, sub);
}

void config_game_open(const char *game_path)
{
    kv_clear(&g_core_opts_game);
    g_game_ini_path[0] = '\0';
    if (!game_path || !*game_path)
        return;
    game_ini_path(g_game_ini_path, sizeof(g_game_ini_path), game_path);
    kv_load(&g_core_opts_game, g_game_ini_path);
}

void config_game_close(void)
{
    kv_clear(&g_core_opts_game);
    g_game_ini_path[0] = '\0';
}

bool config_game_save(void)
{
    if (!g_game_ini_path[0])
        return false;
    if (g_core_opts_game.count == 0) {
        platform_remove(g_game_ini_path); /* no overrides -> no file */
        return true;
    }
    return kv_save(&g_core_opts_game, g_game_ini_path);
}

const char *config_core_option_lookup(const char *key)
{
    const char *v = kv_get(&g_core_opts_game, key);
    if (!v)
        v = kv_get(&g_core_opts_global, key);
    return v;
}

/* ===================================================================== */
/* recent list                                                            */
/* ===================================================================== */

void config_add_recent(const char *path)
{
    settings_t *s = &g_cfg;
    int found = -1;

    for (int i = 0; i < s->recent_count; i++)
        if (!strcmp(s->recent[i], path)) {
            found = i;
            break;
        }
    if (found < 0) {
        found = s->recent_count < MAX_RECENT ? s->recent_count++ : MAX_RECENT - 1;
    }
    for (int i = found; i > 0; i--)
        memcpy(s->recent[i], s->recent[i - 1], sizeof(s->recent[0]));
    str_copy(s->recent[0], path, sizeof(s->recent[0]));
}

void config_remove_recent(int index)
{
    settings_t *s = &g_cfg;
    if (index < 0 || index >= s->recent_count)
        return;
    for (int i = index; i < s->recent_count - 1; i++)
        memcpy(s->recent[i], s->recent[i + 1], sizeof(s->recent[0]));
    s->recent_count--;
}
