/*
  www.freedo.org
  The first working 3DO multiplayer emulator.

  The FreeDO licensed under modified GNU LGPL, with following notes:

  *   The owners and original authors of the FreeDO have full right to
  *   develop closed source derivative work.

  *   Any non-commercial uses of the FreeDO sources or any knowledge
  *   obtained by studying or reverse engineering of the sources, or
  *   any other material published by FreeDO have to be accompanied
  *   with full credits.

  *   Any commercial uses of FreeDO sources or any knowledge obtained
  *   by studying or reverse engineering of the sources, or any other
  *   material published by FreeDO is strictly forbidden without
  *   owners approval.

  The above notes are taking precedence over GNU LGPL in conflicting
  situations.

  Project authors:
  *  Alexander Troosh
  *  Maxim Grishin
  *  Allen Wright
  *  John Sammons
  *  Felix Lazarev
*/

#ifndef	LIBOPERA_CLIO_H_INCLUDED
#define LIBOPERA_CLIO_H_INCLUDED

#include "extern_c.h"

#include <stdint.h>

#define ADBIO_OTHERROM    0x04
#define ADBIO_OTHERROM_EN (ADBIO_OTHERROM << 4)

#define OPERA_CLIO_RESET_SOFT        0x10
#define OPERA_CLIO_RESET_CLEAR_DIPIR 0x20

EXTERN_C_BEGIN

void     opera_clio_init(int reason_);
void     opera_clio_reset(void);
void     opera_clio_soft_reset(int clear_dipir);
void     opera_clio_xbus_media_access(uint32_t unit);
int      opera_clio_xbus_access_aborts(uint32_t unit, uint32_t addr);

// Retry enabled XBUS DMA; DIPIR protection leaves the transfer pending.
void
opera_clio_xbus_dma_execute(void);

uint32_t opera_clio_line_vint0(void);
uint32_t opera_clio_line_vint1(void);

int      opera_clio_fiq_needed(void);
void     opera_clio_fiq_generate(uint32_t reason1_, uint32_t reason2_);
/*
  Local modification for OperaU, see third_party/patches/: an interrupt raised by the DSP - its own, or the end
  of an audio FIFO it was reading or writing. With the DSP inside the frame this is opera_clio_fiq_generate().
  With the DSP on a thread of its own that would be two threads changing the same interrupt word, each reading it,
  changing it and writing it back, and one of them losing its change - an interrupt the game then waits for and
  never gets. So the thread's owner points the hook at something that only notes the interrupt, and raises it
  itself from the thread the rest of the machine runs on.
*/
extern void (*opera_clio_fiq_from_dsp_hook)(uint32_t reason1_);
void     opera_clio_fiq_generate_from_dsp(uint32_t reason1_);

void     opera_clio_fifo_write(uint32_t addr_, uint32_t val_);
uint32_t opera_clio_fifo_read(uint32_t addr_);
void     opera_clio_fifo_eo(uint16_t channel_, uint16_t val_);
uint16_t opera_clio_fifo_ei(uint16_t channel_);
uint16_t opera_clio_fifo_eo_status(uint8_t channel_);
uint16_t opera_clio_fifo_ei_status(uint8_t channel_);
uint16_t opera_clio_fifo_ei_read(uint16_t channel_);

uint32_t opera_clio_peek(uint32_t addr_);
int      opera_clio_poke(uint32_t addr_, uint32_t val_);

void     opera_clio_vcnt_update(int line_, int half_frame_);

uint32_t opera_clio_timer_get_delay(void);
void     opera_clio_timer_execute(uint32_t timer);
/* Runs every timer slot that has come due since the last call. */
void     opera_clio_timers_run(void);

uint32_t opera_clio_state_size(void);
uint32_t opera_clio_state_size_v1(void);
uint32_t opera_clio_state_save(void *buf_);
uint32_t opera_clio_state_load(const void *buf_, uint32_t size_);
uint32_t opera_clio_state_load_v1(const void *buf_, uint32_t size_);

EXTERN_C_END

#endif /* LIBOPERA_CLIO_H_INCLUDED */
