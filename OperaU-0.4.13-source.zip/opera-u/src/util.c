#include "common.h"

#include <ctype.h>

size_t str_copy(char *dst, const char *src, size_t cap)
{
    size_t n = src ? strlen(src) : 0;
    if (cap == 0)
        return n;
    size_t c = n < cap - 1 ? n : cap - 1;
    if (c && src)
        memcpy(dst, src, c);
    dst[c] = '\0';
    return n;
}

size_t str_cat(char *dst, const char *src, size_t cap)
{
    size_t dl = strlen(dst);
    if (dl >= cap)
        return dl + (src ? strlen(src) : 0);
    return dl + str_copy(dst + dl, src, cap - dl);
}

void path_join(char *out, size_t cap, const char *a, const char *b)
{
    char tmp[1024];
    str_copy(tmp, a ? a : "", sizeof(tmp));
    size_t l = strlen(tmp);
    while (l > 1 && tmp[l - 1] == '/')
        tmp[--l] = '\0';
    while (b && *b == '/')
        b++;
    if (l == 0)
        snprintf(out, cap, "%s", b ? b : "");
    else if (tmp[l - 1] == '/' || tmp[l - 1] == ':')
        snprintf(out, cap, "%s%s", tmp, b ? b : "");
    else
        snprintf(out, cap, "%s/%s", tmp, b ? b : "");
}

const char *path_base(const char *path)
{
    const char *s = strrchr(path, '/');
    return s ? s + 1 : path;
}

void path_stem(char *out, size_t cap, const char *path)
{
    str_copy(out, path_base(path), cap);
    char *dot = strrchr(out, '.');
    if (dot && dot != out)
        *dot = '\0';
}

void path_ext(char *out, size_t cap, const char *path)
{
    const char *b = path_base(path);
    const char *dot = strrchr(b, '.');
    size_t i = 0;
    if (dot && dot != b) {
        for (dot++; *dot && i + 1 < cap; dot++)
            out[i++] = (char)tolower((unsigned char)*dot);
    }
    if (cap)
        out[i] = '\0';
}

void path_dir(char *out, size_t cap, const char *path)
{
    const char *s = strrchr(path, '/');
    if (!s) {
        str_copy(out, ".", cap);
        return;
    }
    size_t n = (size_t)(s - path);
    if (n == 0)
        n = 1; /* root */
    if (n >= cap)
        n = cap - 1;
    memcpy(out, path, n);
    out[n] = '\0';
}

bool str_ieq(const char *a, const char *b)
{
    for (; *a && *b; a++, b++)
        if (tolower((unsigned char)*a) != tolower((unsigned char)*b))
            return false;
    return *a == *b;
}

bool str_has_prefix(const char *s, const char *prefix)
{
    return strncmp(s, prefix, strlen(prefix)) == 0;
}
