#ifndef OPERA_U_GPU_H
#define OPERA_U_GPU_H

#include <stdbool.h>
#include <stdint.h>

/*
 * What the probe found out about using the GPU for the cel engine.
 *
 * The cel engine is where most of a frame goes in a heavy game - 24.68 of 45.6 ms in one measurement of Yu Yu
 * Hakusho - and the work it does is the kind a GPU is built for: the same arithmetic on many pixels. Two things
 * have to be true before any of it could move there, and neither can be settled by reasoning about it.
 *
 * The first is exactness. The emulator is tested against reference hashes, and a GPU that rounds differently
 * would quietly change what every game looks like. The 3DO pixel processor works in int8_t, with sign-propagating
 * shifts and clamping, so the probe makes the GPU do that arithmetic and compares every pixel against the CPU
 * doing the same thing with the same inputs.
 *
 * The second is the cost of the hand-off. The 3DO's frame buffer cannot leave main memory: the ARM reads and
 * writes it as ordinary memory, the SPORT copies it with memcpy, and the video hardware reads it to build the
 * picture. So the GPU would have to hand each frame back, and the CPU would have to wait for it. The probe times
 * a draw on its own, and then a draw followed by that wait, and the difference is the price of the hand-off. At
 * 60 fps there are 16.7 ms for everything, so a hand-off of a few milliseconds decides the whole question.
 *
 * What the exactness check does not cover: the GPU is compared against a copy of the pixel processor kept in
 * src/gpu.c, not against the core's own code, which is private to opera_madam.c. A mistake in that copy makes the
 * probe report a difference that is not there - the harmless direction - and a mistake shared by the copy and the
 * shader would be caught later anyway, because any real use of the GPU still has to pass the cel batteries the
 * whole emulator is tested against.
 */
typedef struct {
    bool ran;            /* the probe got far enough to mean something */
    bool exact;          /* every pixel matched the CPU, bit for bit */
    uint32_t configs;    /* pixel-processor shapes tried */
    uint32_t pixels;     /* pixels compared */
    uint32_t wrong;      /* pixels that came back different */
    double draw_ms;      /* one 320x240 draw, not waiting for the result */
    double trip_ms;      /* one draw plus the wait until the CPU may read it */
    uint32_t pitch;      /* how GX2 laid the target out, which the next step will need to know */
    uint32_t image_size;
    /*
     * A disagreement with the CPU does not say where it came from, so the probe checks the three stages apart:
     * whether the shader reads the source texture as it was written, whether it reads the table, and whether it
     * computes like the CPU. Only the last one is about arithmetic; the first two are about getting numbers into
     * the GPU, where byte order and surface layout can go wrong without any sum being wrong.
     */
    uint32_t untouched;  /* pixels the draw never wrote: the mark the CPU left was still there */
    /* The constant the shader writes into alpha, which depends on no uniform and no texture: it separates a
       shader that ran and wrote its output from one that was fed nothing. */
    uint32_t beacon_wrong, beacon_pixels;
    uint32_t src_wrong, src_pixels;
    uint32_t lut_wrong, lut_pixels;
    uint32_t math_wrong, math_pixels;
    /* One line per thing tried, because an aggregate cannot say which of them failed. */
    struct {
        const char *name;
        uint32_t wrong;
    } per[24];
    int per_n;
    /*
     * Which way of handing a uniform to the GPU works. Each candidate writes a different value into the one
     * uniform the shader echoes back, so the one that arrives identifies itself and no reset is needed between
     * them. All of them failing is itself the answer: the uniforms are not reaching the shader at all.
     */
    struct {
        const char *name;
        uint8_t want, got;
    } uni[8];
    int uni_n;
    /*
     * What a real cel engine's shape costs, which one full-screen pass cannot say. A cel is its own draw with its
     * own pixel-processor settings, and games differ enormously in how they split the work: Yu Yu Hakusho draws
     * about 11 cels of roughly 8000 pixels each per frame, Super Street Fighter 2 Turbo about 353 of roughly 220.
     * Many small draws are where a GPU gives its advantage back, so both shapes are timed here against the same
     * frames the CPU takes 24.55 and 9.25 ms over.
     */
    struct {
        const char *name;
        int draws, side;
        double ms;
    } shape[4];
    int shape_n;
    char sample[120];    /* the first pixel that differed, as got against wanted */
    char err[160];       /* why it could not run, when it could not */
} gpu_probe_t;

/*
 * Runs the probe. Returns false and fills err when it cannot run at all, which is the normal answer away from the
 * console. Everything it allocates is released before it returns, and it leaves no GX2 state behind that the
 * renderer does not set for itself on its next draw.
 */
bool gpu_probe(gpu_probe_t *out);

#endif
