#ifndef OPERAU_PNG_H
#define OPERAU_PNG_H

#include "common.h"

/* Writes an 8-bit RGB picture (w x h, `stride` bytes per row) as a PNG file,
 * atomically. The image data is stored without compression (valid deflate
 * "stored" blocks): ~230 KB for a 320x240 screenshot, no zlib needed. */
bool png_write_rgb24(const char *path, const uint8_t *rgb, unsigned w, unsigned h, size_t stride);

/* The pieces, exposed for the self test. */
uint32_t png_crc32(uint32_t crc, const uint8_t *data, size_t len);
uint32_t png_adler32(uint32_t adler, const uint8_t *data, size_t len);

#endif
