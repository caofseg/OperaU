#include "app.h"
#include "audio.h"
#include "config.h"
#include "core.h"
#include "diag.h"
#include "i18n.h"
#include "input.h"
#include "log.h"
#include "platform.h"
#include "perf.h"
#include "session.h"
#include "testpat.h"
#include "ui.h"
#include "video.h"

#include <SDL.h>

#define FRAME_US 16666u

static app_mode_t g_mode = APP_HOME;
static bool g_quit;
static int g_pads_seen = -1;
static uint32_t g_epoch_seen;
static uint64_t g_frame_t0;

static struct {
    bool log, sdl, video, input, audio, ui, session;
} g_up;

/* ------------------------------------------------------------------ hooks */

static bool hook_state_exists(int slot)
{
    return session_state_exists(slot);
}

static bool hook_resumable(const char *path)
{
    return session_autostate_exists(path);
}

static const ui_hooks_t k_hooks = {hook_state_exists, hook_resumable};

/* ------------------------------------------------------------- mode changes */

app_mode_t app_mode(void)
{
    return g_mode;
}

static void enter_pause(void)
{
    if (g_mode != APP_PLAYING)
        return;
    session_pause();
    input_set_game_active(false);
    ui_open(UI_PAUSE, session_title());
    g_mode = APP_PAUSED;
}

static void leave_pause(void)
{
    if (g_mode != APP_PAUSED)
        return;
    input_set_game_active(true);
    g_mode = APP_PLAYING;
    session_resume();
}

static void close_game(void)
{
    session_close_game(); /* autosave + NVRAM write-back */
    input_set_game_active(false);
    video_reset();
    g_mode = APP_HOME;
    ui_open(UI_HOME, NULL);
}

/* Runs fn(arg) with the emulation thread parked (if it was running). */
static bool with_paused(bool (*fn)(int), int arg)
{
    bool was_running = session_running();
    bool ok;

    if (was_running)
        session_pause();
    ok = fn(arg);
    if (was_running)
        session_resume();
    return ok;
}

static void report_error(const char *fmt_text, const char *detail)
{
    char buf[900];
    snprintf(buf, sizeof(buf), fmt_text, detail && *detail ? detail : "?");
    ui_message(tr(S_MSG_ERR_TITLE), buf, true);
}

/* ---------------------------------------------------------------- actions */

static void save_state_now(void)
{
    int slot = g_cfg.state_slot;
    uint64_t t0 = platform_time_us();

    if (with_paused(session_save_state, slot)) {
        ui_toast(tr(S_TOAST_SAVED), slot);
        LOGI("state saved to slot %d in %d ms", slot, (int)((platform_time_us() - t0) / 1000));
    } else if (g_mode == APP_PAUSED) {
        report_error(tr(S_ERR_STATE_SAVE), session_error());
    } else {
        ui_toast("%s", tr(S_TOAST_SAVE_FAIL));
    }
    ui_refresh();
}

/* Returns true when a state was loaded. */
static bool load_state_now(void)
{
    int slot = g_cfg.state_slot;

    if (!session_state_exists(slot)) {
        ui_toast(tr(S_TOAST_NO_STATE), slot);
        return false;
    }
    if (with_paused(session_load_state, slot)) {
        ui_toast(tr(S_TOAST_LOADED), slot);
        return true;
    }
    if (g_mode == APP_PAUSED)
        report_error(tr(S_ERR_STATE_LOAD), session_error());
    else
        ui_toast("%s", tr(S_TOAST_LOAD_FAIL));
    return false;
}

static void reset_now(void)
{
    bool was_running = session_running();
    if (was_running)
        session_pause();
    session_reset();
    if (was_running)
        session_resume();
    ui_toast("%s", tr(S_TOAST_RESET));
}

static void screenshot_now(void)
{
    char path[1100];

    if (session_screenshot(path, sizeof(path)))
        ui_toast(tr(S_TOAST_SHOT), path_base(path));
    else
        ui_toast("%s", tr(S_TOAST_SHOT_FAIL));
}

static void change_slot(int dir)
{
    g_cfg.state_slot = (g_cfg.state_slot + dir + 10) % 10;
    ui_toast(tr(S_TOAST_SLOT), g_cfg.state_slot,
             session_state_exists(g_cfg.state_slot) ? tr(S_SLOT_USED) : tr(S_SLOT_EMPTY));
    ui_refresh();
}

static void apply_settings(void)
{
    video_apply_settings();
    audio_set_volume(g_cfg.volume);
    audio_set_latency(g_cfg.latency_ms);
    log_set_udp(g_cfg.udp_log);
    perf_set_enabled(g_cfg.perf_log || g_cfg.show_fps);
}

/* Cheap sanity check so an empty / truncated download gets a clear message
 * instead of a BIOS that silently shows "no disc". */
static bool image_plausible(const char *path)
{
    char ext[8];
    int64_t size = platform_file_size(path);

    path_ext(ext, sizeof(ext), path);
    if (size < 0)
        return true; /* let the core report the real problem */
    if ((!strcmp(ext, "iso") || !strcmp(ext, "bin") || !strcmp(ext, "img")) && size < 32768)
        return false;
    if (!strcmp(ext, "chd") && size < 2048)
        return false;
    return true;
}

static const char *launch_error_detail(void)
{
    switch (core_last_error_code()) {
    case CORE_ERR_OPEN_IMAGE:
        return tr(S_ERR_OPEN_IMAGE);
    case CORE_ERR_START:
        return tr(S_ERR_START);
    default:
        return session_error();
    }
}

static void do_launch(const char *path, bool resume)
{
    char title[256];
    bool have_path = path && *path;

    if (have_path && !platform_exists(path)) {
        report_error(tr(S_ERR_FILE_MISSING), path);
        return;
    }
    if (have_path && !image_plausible(path)) {
        report_error(tr(S_ERR_TOO_SMALL), path);
        return;
    }
    if (have_path)
        path_stem(title, sizeof(title), path);
    else
        str_copy(title, "Opera Boot", sizeof(title));

    /* opening a CHD / scanning a disc takes a moment: show something first */
    video_begin_frame();
    ui_draw_splash(tr(S_LOADING), title);
    video_end_frame();

    if (!session_launch(have_path ? path : NULL, resume)) {
        report_error(tr(S_ERR_LAUNCH), launch_error_detail());
        return;
    }
    if (session_resumed())
        ui_toast("%s", tr(S_TOAST_RESUMED));
    else if (!have_path)
        ui_toast("%s", tr(S_TOAST_BIOS_BOOT));

    input_set_game_active(true);
    g_mode = APP_PLAYING;
    session_resume();
}

/* ------------------------------------------------------------ diagnostic */

static void start_diagnostic(void)
{
    if (g_mode != APP_HOME || session_active())
        return;
    if (!diag_start()) {
        report_error(tr(S_DIAG_NOSTART), "thread");
        return;
    }
    g_mode = APP_DIAG;
}

/* ----------------------------------------------------------- picture test */

static void start_testpattern(void)
{
    if (g_mode != APP_HOME || session_active())
        return;
    testpat_enter();
    g_mode = APP_TESTPAT;
}

/* One main-loop iteration of the picture test. */
static void testpat_frame(void)
{
    nav_action_t a;

    while ((a = input_next_nav()) != NAV_NONE) {
        if (!testpat_nav(a)) {
            testpat_leave();
            config_save(); /* the colour order and filter may have changed here */
            g_mode = APP_HOME;
            return;
        }
    }
}

/* One main-loop iteration while the self test runs on its worker thread. */
static void diag_frame(void)
{
    diag_report_t rep;
    nav_action_t a;

    while ((a = input_next_nav()) != NAV_NONE)
        if (a == NAV_BACK)
            diag_cancel();
    if (!diag_poll(&rep))
        return;
    g_mode = APP_HOME;
    if (rep.cancelled) {
        diag_write_report(&rep); /* replaces the "RUNNING" trail with "cancelled" */
        ui_toast("%s", tr(S_DIAG_CANCELLED));
        return;
    }
    {
        char text[1000];
        bool problem = diag_format(&rep, text, sizeof(text));

        diag_write_report(&rep);
        ui_message(tr(S_DIAG_TITLE), text, problem);
    }
}

void app_dispatch(const ui_action_t *a)
{
    switch (a->type) {
    case UIA_NONE:
        break;
    case UIA_LAUNCH:
        do_launch(a->path, false);
        break;
    case UIA_LAUNCH_RESUME:
        do_launch(a->path, true);
        break;
    case UIA_LAUNCH_BIOS:
        do_launch(NULL, false);
        break;
    case UIA_RESUME:
        leave_pause();
        break;
    case UIA_SAVE_STATE:
        if (session_active())
            save_state_now();
        break;
    case UIA_LOAD_STATE:
        if (session_active() && load_state_now())
            leave_pause();
        break;
    case UIA_RESET:
        if (session_active()) {
            reset_now();
            leave_pause();
        }
        break;
    case UIA_SCREENSHOT:
        if (session_active())
            screenshot_now();
        break;
    case UIA_CLOSE_GAME:
        if (session_active())
            close_game();
        break;
    case UIA_QUIT:
        g_quit = true;
        break;
    case UIA_SETTINGS_CHANGED:
        apply_settings();
        break;
    case UIA_DIAGNOSTIC:
        start_diagnostic();
        break;
    case UIA_TESTPATTERN:
        start_testpattern();
        break;
    }
}

void app_hotkeys(unsigned hk)
{
    if (!hk || !session_active())
        return;
    if (g_mode == APP_PAUSED) {
        if (hk & HK_MENU)
            leave_pause();
        return;
    }
    if (g_mode != APP_PLAYING)
        return;
    if (hk & HK_MENU) {
        enter_pause();
        return;
    }
    if (hk & HK_SLOT_NEXT)
        change_slot(+1);
    if (hk & HK_SLOT_PREV)
        change_slot(-1);
    if (hk & HK_SAVE_STATE)
        save_state_now();
    if (hk & HK_LOAD_STATE)
        load_state_now();
    if (hk & HK_SCREENSHOT)
        screenshot_now();
    if (hk & HK_RESET)
        reset_now();
    if (hk & (HK_SLOT_NEXT | HK_SLOT_PREV))
        config_save();
}

/* --------------------------------------------------------------- main loop */

static void pump_events(void)
{
    SDL_Event ev;

    while (SDL_PollEvent(&ev)) {
        if (ev.type == SDL_QUIT) {
            g_quit = true;
            continue;
        }
        input_handle_event(&ev);
    }
}

static void track_pads(void)
{
    int n = input_connected_count();

    if (g_pads_seen >= 0 && n != g_pads_seen) {
        if (n > g_pads_seen)
            ui_toast(tr(S_TOAST_PAD_ON), n);
        else
            ui_toast("%s", tr(S_TOAST_PAD_OFF));
        if (session_active())
            core_set_connected_pads(n);
    }
    g_pads_seen = n;
}

static void track_background(void)
{
    uint32_t ep = platform_background_epoch();

    if (ep == g_epoch_seen)
        return;
    g_epoch_seen = ep;
    /* coming back from the HOME menu: do not drop the player into a running
     * game, show the pause menu instead */
    if (g_mode == APP_PLAYING)
        enter_pause();
}

static void playing_checks(void)
{
    char msg[160];

    if (session_core_wants_exit()) {
        ui_toast("%s", tr(S_TOAST_CORE_EXIT));
        close_game();
        return;
    }
    if (core_av_take_changed()) {
        video_set_game_aspect(core_av()->aspect);
        audio_set_input_rate(core_av()->sample_rate);
    }
    while (core_pop_message(msg, sizeof(msg)))
        ui_toast("%s", msg);
}

static void draw_current(void)
{
    ui_hud_t hud;

    video_begin_frame();
    switch (g_mode) {
    case APP_HOME:
        ui_draw();
        break;
    case APP_PAUSED:
        video_draw_game();
        ui_draw();
        break;
    case APP_PLAYING:
        session_hud(&hud);
        video_draw_game();
        ui_draw_overlays(&hud);
        break;
    case APP_TESTPAT:
        testpat_draw();
        ui_draw_overlays(NULL);
        break;
    case APP_DIAG: {
        int done = 0, total = 0;
        char caption[160], stage[80];
        float p;

        diag_progress(&done, &total);
        diag_stage(stage, sizeof(stage));
        p = total > 0 ? (float)done / (float)total : 0.0f;
        snprintf(caption, sizeof(caption), tr(S_DIAG_PROGRESS), (int)(p * 100.0f), stage);
        ui_draw_splash_progress(tr(S_DIAG_TITLE), tr(S_DIAG_RUN_LINE), p, caption);
        break;
    }
    }
    video_end_frame();
}

/* Keeps the loop near 60 Hz when the presentation does not block (VSync off,
 * headless drivers) so the UI thread does not burn a whole CPU core. */
static void frame_limit(void)
{
    uint64_t now = platform_time_us();
    uint64_t target = g_frame_t0 + FRAME_US;

    if (now + 1500 < target) {
        platform_sleep_ms((uint32_t)((target - now - 1000) / 1000));
        now = platform_time_us();
    }
    g_frame_t0 = (now < target) ? target : now;
}

bool app_frame(void)
{
    ui_action_t act;

    pump_events();
    if (g_quit)
        return false;

    input_update();
    track_pads();
    track_background();
    app_hotkeys(input_take_hotkeys());

    if (g_mode == APP_PLAYING) {
        playing_checks();
    } else if (g_mode == APP_DIAG) {
        diag_frame();
    } else if (g_mode == APP_TESTPAT) {
        testpat_frame();
    } else {
        ui_update();
        while (ui_next_action(&act))
            app_dispatch(&act);
    }
    if (g_quit)
        return false;

    draw_current();
    frame_limit();
    return true;
}

/* ------------------------------------------------------- init / shutdown */

static bool name_is_ours(const char *name)
{
    char low[160];
    size_t n = strlen(name), i;

    if (n >= sizeof(low))
        return false;
    for (i = 0; i <= n; i++)
        low[i] = (char)((name[i] >= 'A' && name[i] <= 'Z') ? name[i] + 32 : name[i]);
    if (!strstr(low, "opera"))
        return false;
    return (n > 5 && !strcmp(low + n - 5, ".wuhb")) || (n > 4 && !strcmp(low + n - 4, ".rpx"));
}

/* Writes <data dir>/version.txt (which build ran last) and looks in wiiu/apps (and one folder level below) for
 * Opera U packages. Two or more means an old copy is still on the card: Aroma lists each as its own entry and the
 * old entry starts the old program, which looks exactly like "the update did not work". Returns how many it found
 * and their names, one per line, in `list`. */
static int find_installed_copies(char *list, size_t cap)
{
    const char *apps = platform_apps_dir();
    dir_entry_t *top;
    int n = 0, found = 0;

    list[0] = '\0';
    if (!apps)
        return 0;
    top = platform_list_dir(apps, &n);
    for (int i = 0; i < n; i++) {
        if (!top[i].is_dir) {
            if (name_is_ours(top[i].name)) {
                found++;
                str_cat(list, "  wiiu/apps/", cap);
                str_cat(list, top[i].name, cap);
                str_cat(list, "\n", cap);
            }
        } else {
            char sub[1100];
            int m = 0;
            dir_entry_t *in;

            path_join(sub, sizeof(sub), apps, top[i].name);
            in = platform_list_dir(sub, &m);
            for (int k = 0; k < m; k++)
                if (!in[k].is_dir && name_is_ours(in[k].name)) {
                    found++;
                    str_cat(list, "  wiiu/apps/", cap);
                    str_cat(list, top[i].name, cap);
                    str_cat(list, "/", cap);
                    str_cat(list, in[k].name, cap);
                    str_cat(list, "\n", cap);
                }
            free(in);
        }
    }
    free(top);
    return found;
}

static void write_version_file(const char *copies, int ncopies)
{
    char text[1800], path[1100];

    snprintf(text, sizeof(text),
             "%s %s\nbuild: %s\n"
             "This file is rewritten every time the app starts: it names the program that ran last.\n"
             "Opera U packages found in wiiu/apps: %d\n%s",
             APP_NAME, APP_VERSION, APP_BUILD, ncopies, copies);
    path_join(path, sizeof(path), platform_data_dir(), "version.txt");
    platform_remove(path);
    platform_write_file_atomic(path, text, strlen(text));
}

bool app_init(void)
{
    const char *dir = platform_data_dir();

    platform_mkdirs(dir);
    log_open(dir);
    g_up.log = true;
    LOGI("%s %s starting (built %s)", APP_NAME, APP_VERSION, APP_BUILD);
    log_flush(); /* so the log says which build ran even if the app dies a moment later */
    config_load();
    log_set_udp(g_cfg.udp_log);

    SDL_SetHint(SDL_HINT_JOYSTICK_ALLOW_BACKGROUND_EVENTS, "1");
    if (SDL_Init(SDL_INIT_TIMER | SDL_INIT_EVENTS) != 0) {
        LOGE("SDL_Init: %s", SDL_GetError());
        return false;
    }
    g_up.sdl = true;

    if (!video_init())
        return false;
    g_up.video = true;
    platform_lifecycle_init();
    g_epoch_seen = platform_background_epoch();

    input_set_logical_size(LOGICAL_W, LOGICAL_H);
    input_init();
    g_up.input = true;

    g_up.audio = audio_init(g_cfg.latency_ms);
    audio_set_volume(g_cfg.volume);
    video_apply_settings();
    perf_set_enabled(g_cfg.perf_log || g_cfg.show_fps);

    if (!ui_init(&k_hooks))
        return false;
    g_up.ui = true;

    if (!session_init())
        return false;
    g_up.session = true;

    ui_open(UI_HOME, NULL);
    if (!g_up.audio)
        ui_toast("%s", tr(S_TOAST_NO_AUDIO));
    {
        char copies[700], text[1400];
        int ncopies = find_installed_copies(copies, sizeof(copies));

        write_version_file(copies, ncopies);
        LOGI("Opera U packages in wiiu/apps: %d\n%s", ncopies, copies);
        log_flush();
        if (ncopies > 1) {
            snprintf(text, sizeof(text), tr(S_COPIES_TEXT), APP_VERSION, ncopies, copies);
            ui_message(tr(S_COPIES_TITLE), text, true);
        }
    }
    g_frame_t0 = platform_time_us();
    return true;
}

void app_shutdown(void)
{
    if (g_up.log)
        LOGI("shutting down");
    diag_shutdown(); /* a self test still running must end before the core goes away */
    if (g_up.session)
        session_shutdown(); /* closes the game: autosave, NVRAM, thread join */
    perf_shutdown(); /* after the emulation thread, which is the one that hands it work */
    if (g_up.log)
        config_save();
    if (g_up.ui)
        ui_shutdown();
    if (g_up.audio)
        audio_shutdown();
    if (g_up.input)
        input_shutdown();
    if (g_up.video)
        video_shutdown();
    if (g_up.sdl)
        SDL_Quit();
    if (g_up.log)
        log_close();
    memset(&g_up, 0, sizeof(g_up));
}
