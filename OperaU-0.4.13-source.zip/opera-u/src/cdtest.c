#include "cdtest.h"

#include "retro_cdimage.h"

#include <stdio.h>
#include <string.h>

#define FNV_INIT  0xcbf29ce484222325ull
#define FNV_PRIME 0x100000001b3ull

static uint64_t fnv_bytes(uint64_t h, const uint8_t *p, size_t n)
{
    while (n--)
        h = (h ^ *p++) * FNV_PRIME;
    return h;
}

bool cdtest_hash(const char *path)
{
    static cdimage_t cd; /* big, and the harness has a small stack */
    static uint8_t user[2048], full[4096];
    uint64_t hu = FNV_INIT, hf = FNV_INIT;
    uint64_t bytes = 0;
    ssize_t blocks;
    size_t lba;

    memset(&cd, 0, sizeof(cd));
    if (retro_cdimage_open(path, &cd) != 0) {
        printf("cdhash: cannot open %s\n", path);
        return false;
    }
    blocks = retro_cdimage_get_number_of_logical_blocks(&cd);
    if (blocks <= 0) {
        printf("cdhash: no blocks in %s\n", path);
        retro_cdimage_close(&cd);
        return false;
    }
    for (lba = 0; lba < (size_t)blocks; lba++) {
        ssize_t nu = retro_cdimage_read_sector(&cd, lba, user, sizeof(user));
        ssize_t nf = retro_cdimage_read_sector(&cd, lba, full, sizeof(full));

        if (nu != (ssize_t)sizeof(user) || nf <= 0) {
            printf("cdhash: read failed at block %lu (user %ld, full %ld)\n", (unsigned long)lba, (long)nu, (long)nf);
            retro_cdimage_close(&cd);
            return false;
        }
        hu = fnv_bytes(hu, user, (size_t)nu);
        hf = fnv_bytes(hf, full, (size_t)nf);
        bytes += (uint64_t)nf;
    }
    printf("cdhash blocks %ld user %016llx full %016llx bytes %llu\n", (long)blocks, (unsigned long long)hu,
           (unsigned long long)hf, (unsigned long long)bytes);
    retro_cdimage_close(&cd);
    return true;
}
