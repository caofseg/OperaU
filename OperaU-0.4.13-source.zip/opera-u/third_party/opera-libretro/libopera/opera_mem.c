/*
  documentation:
  * https://3dodev.com/documentation/hardware/opera/memory_configurations
  * About Memory: https://3dodev.com/documentation/development/opera/pf25/ppgfldr/pgsfldr/spg/05spg001
  * Manageing Memory: https://3dodev.com/documentation/development/opera/pf25/ppgfldr/pgsfldr/spg/01spg003
  */

#include "opera_mem.h"
#include "endianness.h"
#include "opera_state.h"

#include <assert.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>

uint32_t  RAM_SIZE        = (DEFAULT_RAM_SIZE);
uint32_t  HIRES_RAM_SIZE  = (DEFAULT_HIRES_RAM_SIZE);
bool      HIRESMODE       = false;
uint8_t  *DRAM            = NULL;
uint32_t  DRAM_SIZE       = (DEFAULT_DRAM_SIZE);
uint8_t  *VRAM            = NULL;
uint32_t  VRAM_SIZE       = (DEFAULT_VRAM_SIZE);
uint32_t  VRAM_SIZE_MASK  = (DEFAULT_VRAM_SIZE - 1);
uint32_t  HIRES_VRAM_SIZE = (DEFAULT_HIRES_VRAM_SIZE);
uint8_t  *NVRAM           = NULL;
uint8_t  *ROM             = NULL;
uint8_t  *ROM1            = NULL;
uint8_t  *ROM2            = NULL;

static opera_mem_cfg_t g_MEM_CFG = DRAM_VRAM_UNSET;

typedef struct opera_mem_state_t opera_mem_state_t;
struct opera_mem_state_t
{
  uint8_t mem_cfg;
};

opera_mem_cfg_t
opera_mem_cfg()
{
  return g_MEM_CFG;
}


bool
opera_mem_is_valid_cfg(opera_mem_cfg_t cfg_)
{
  switch(cfg_)
    {
    case DRAM_2MB_VRAM_1MB:
    case DRAM_2MB_VRAM_2MB:
    case DRAM_4MB_VRAM_1MB:
    case DRAM_4MB_VRAM_2MB:
    case DRAM_8MB_VRAM_1MB:
    case DRAM_8MB_VRAM_2MB:
    case DRAM_14MB_VRAM_2MB:
    case DRAM_15MB_VRAM_1MB:
      return true;
    default:
      return false;
    }
}

uint32_t
opera_mem_dram_size(opera_mem_cfg_t cfg_)
{
  return (((cfg_ & 0xF0) >> 4) * ONE_MB);
}

uint32_t
opera_mem_vram_size(opera_mem_cfg_t cfg_)
{
  return (((cfg_ & 0x0F) >> 0) * ONE_MB);
}

static
void
_setup_dram_vram(opera_mem_cfg_t const cfg_)
{
  assert(DRAM != NULL);
  assert(opera_mem_is_valid_cfg(cfg_));

  DRAM_SIZE       = opera_mem_dram_size(cfg_);
  VRAM_SIZE       = opera_mem_vram_size(cfg_);
  VRAM_SIZE_MASK  = (VRAM_SIZE - 1);
  HIRES_VRAM_SIZE = (VRAM_SIZE * 4);
  RAM_SIZE        = (DRAM_SIZE + VRAM_SIZE);
  HIRES_RAM_SIZE  = (DRAM_SIZE + HIRES_VRAM_SIZE);

  assert(RAM_SIZE <= MAX_RAM_SIZE);
  assert(HIRES_RAM_SIZE <= MAX_HIRES_RAM_SIZE);

  /* VRAM is always at the top of DRAM */
  VRAM = &DRAM[DRAM_SIZE];
}

#define MADAM_RAM_MASK     0x0000007F
#define DRAMSIZE_SHIFT     3    /* RED ONLY */
#define VRAMSIZE_SHIFT     0    /* RED ONLY */
#define VRAMSIZE_1MB       0x00000001 /* RED ONLY */
#define VRAMSIZE_2MB       0x00000002 /* RED ONLY */
#define DRAMSIZE_SETMASK   3    /* RED ONLY */
#define DRAMSIZE_1MB       0x000000001 /* RED ONLY */
#define DRAMSIZE_4MB       0x000000002 /* RED ONLY */
#define DRAMSIZE_16MB      0x000000003 /* RED ONLY */
#define DRAMSIZE_SET1SHIFT 3    /* RED ONLY */
#define DRAMSIZE_SET0SHIFT (DRAMSIZE_SET1SHIFT+2) /* RED ONLY */

uint32_t
opera_mem_madam_red_sysbits(uint32_t const v_)
{
  uint32_t v = v_;

  v &= ~MADAM_RAM_MASK;

  switch(g_MEM_CFG)
    {
    default:
    case DRAM_2MB_VRAM_1MB:
      v |= ((VRAMSIZE_1MB << VRAMSIZE_SHIFT)     |
            (DRAMSIZE_1MB << DRAMSIZE_SET0SHIFT) |
            (DRAMSIZE_1MB << DRAMSIZE_SET1SHIFT));
      break;
    case DRAM_2MB_VRAM_2MB:
      v |= ((VRAMSIZE_2MB << VRAMSIZE_SHIFT)     |
            (DRAMSIZE_1MB << DRAMSIZE_SET0SHIFT) |
            (DRAMSIZE_1MB << DRAMSIZE_SET1SHIFT));
      break;
    case DRAM_4MB_VRAM_1MB:
      v |= ((VRAMSIZE_1MB << VRAMSIZE_SHIFT)     |
            (DRAMSIZE_4MB << DRAMSIZE_SET0SHIFT));
      break;
    case DRAM_4MB_VRAM_2MB:
      v |= ((VRAMSIZE_2MB << VRAMSIZE_SHIFT)     |
            (DRAMSIZE_4MB << DRAMSIZE_SET0SHIFT));
      break;
    case DRAM_8MB_VRAM_1MB:
      v |= ((VRAMSIZE_1MB << VRAMSIZE_SHIFT)     |
            (DRAMSIZE_4MB << DRAMSIZE_SET0SHIFT) |
            (DRAMSIZE_4MB << DRAMSIZE_SET1SHIFT));
      break;
    case DRAM_8MB_VRAM_2MB:
      v |= ((VRAMSIZE_2MB << VRAMSIZE_SHIFT)     |
            (DRAMSIZE_4MB << DRAMSIZE_SET0SHIFT) |
            (DRAMSIZE_4MB << DRAMSIZE_SET1SHIFT));
      break;
    case DRAM_14MB_VRAM_2MB:
      v |= ((VRAMSIZE_2MB  << VRAMSIZE_SHIFT)     |
            (DRAMSIZE_16MB << DRAMSIZE_SET1SHIFT));
      break;
    case DRAM_15MB_VRAM_1MB:
      v |= ((VRAMSIZE_1MB  << VRAMSIZE_SHIFT)     |
            (DRAMSIZE_16MB << DRAMSIZE_SET1SHIFT));
      break;
    }

  return v;
}

int
opera_mem_init(opera_mem_cfg_t const cfg_)
{
  opera_mem_cfg_t cfg = DRAM_2MB_VRAM_1MB;

  if(g_MEM_CFG != DRAM_VRAM_UNSET)
    return -1;

  cfg = cfg_;
  if(cfg == DRAM_VRAM_UNSET)
    cfg = DRAM_VRAM_STOCK;

  if(!opera_mem_is_valid_cfg(cfg))
    return -1;

  /*
    Allocate max possible RAM to make things easier
    Since it is zeroed out it will compress well

    Local modification for OperaU, see third_party/patches/: sixteen bytes more than that. The cel engine's bit
    reader fetches three bytes for every read (cel_bits() in opera_madam.c), so a cel whose data ends on the last
    byte of memory makes it look two bytes past the end. Those bytes are never used and never saved.
  */
  DRAM  = calloc(MAX_HIRES_RAM_SIZE + 16,1);
  ROM1  = calloc(ROM1_SIZE,1);
  ROM2  = calloc(ROM2_SIZE,1);
  NVRAM = calloc(NVRAM_SIZE,1);

  if(!DRAM || !ROM1 || !ROM2 || !NVRAM)
    {
      opera_mem_destroy();
      return -1;
    }

  _setup_dram_vram(cfg);

  opera_mem_rom_select(ROM1);

  g_MEM_CFG = cfg;

  return 0;
}

void
opera_mem_destroy()
{
  if(DRAM)
    free(DRAM);
  DRAM = NULL;
  VRAM = NULL;

  if(ROM1)
    free(ROM1);
  ROM1 = NULL;

  if(ROM2)
    free(ROM2);
  ROM2 = NULL;

  if(NVRAM)
    free(NVRAM);
  NVRAM = NULL;

  g_MEM_CFG = DRAM_VRAM_UNSET;
}

void
opera_mem_rom1_clear()
{
  memset(ROM1,0,ROM1_SIZE);
}

void
opera_mem_rom1_byteswap32_if_le()
{
  uint32_t *mem;
  uint64_t  size;

  mem  = (uint32_t*)ROM1;
  size = (ROM1_SIZE / sizeof(uint32_t));

  swap32_array_if_little_endian(mem,size);
}

void
opera_mem_rom2_clear()
{
  memset(ROM2,0,ROM2_SIZE);
}

void
opera_mem_rom2_byteswap32_if_le()
{
  uint32_t *mem;
  uint64_t  size;

  mem  = (uint32_t*)ROM2;
  size = (ROM2_SIZE / sizeof(uint32_t));

  swap32_array_if_little_endian(mem,size);
}

void
opera_mem_rom_select(void *rom_)
{
  if((rom_ != ROM1) && (rom_ != ROM2))
    rom_ = ROM1;

  ROM = rom_;
}

uint32_t
opera_mem_state_size_v1()
{
  uint32_t size;

  size = 0;
  size += opera_state_save_size(sizeof(opera_mem_state_t));
  size += opera_state_save_size(MAX_HIRES_RAM_SIZE);
  size += opera_state_save_size(ROM1_SIZE);
  size += opera_state_save_size(ROM2_SIZE);
  size += opera_state_save_size(NVRAM_SIZE);

  return size;
}

/*
 * The MEM2 chunk: the memory configuration, how many RAM bytes follow,
 * that much of DRAM, then NVRAM.
 *
 * The RAM stored is what the configuration uses: DRAM plus VRAM and its
 * three high-resolution copies, which sit directly above it. That is
 * fixed for a session -- the configuration is chosen once, and the
 * copies are kept whether or not high resolution is on, since it can
 * be switched at any time -- so the state size does not change under a
 * frontend that sized its buffers once. The ROMs are not stored: they
 * are the BIOS and font loaded for the session and never change.
 *
 * The older MEM chunk (V3) stored the whole 22 MB DRAM allocation and
 * both ROMs, 24.1 MB, whatever the configuration.
 */
static
uint32_t
opera_mem_state_ram_bytes(opera_mem_cfg_t const cfg_)
{
  return (opera_mem_dram_size(cfg_) + (opera_mem_vram_size(cfg_) * 4));
}

static
uint32_t
opera_mem_state_payload_size(void)
{
  return (sizeof(uint8_t) +
          sizeof(uint32_t) +
          opera_mem_state_ram_bytes(g_MEM_CFG) +
          NVRAM_SIZE);
}

uint32_t
opera_mem_state_size()
{
  return opera_state_chunk_size(opera_mem_state_payload_size());
}

uint32_t
opera_mem_state_save(void *data_)
{
  uint32_t ram_bytes;
  opera_state_writer_t writer;

  ram_bytes = opera_mem_state_ram_bytes(g_MEM_CFG);

  opera_state_writer_init(&writer,data_,opera_mem_state_size());
  opera_state_write_chunk_header(&writer,
                                 "MEM2",
                                 opera_mem_state_payload_size());
  opera_state_write_u8(&writer,(uint8_t)g_MEM_CFG);
  opera_state_write_u32(&writer,ram_bytes);
  opera_state_write_bytes(&writer,DRAM,ram_bytes);
  opera_state_write_bytes(&writer,NVRAM,NVRAM_SIZE);

  return opera_state_writer_ok(&writer) ? opera_state_writer_used(&writer) : 0;
}

uint32_t
opera_mem_state_load_v1(void const     *data_,
                        uint32_t const  size_)
{
  uint8_t const *start = (uint8_t const*)data_;
  uint8_t const *data  = (uint8_t const*)data_;
  uint8_t const *end   = (uint8_t const*)data_ + size_;
  opera_mem_state_t memstate;
  uint32_t rv;

  rv = opera_state_load_sized(&memstate,"MCFG",data,(uint32_t)(end - data),sizeof(memstate));
  if((rv == 0) || !opera_mem_is_valid_cfg((opera_mem_cfg_t)memstate.mem_cfg))
    return 0;
  data += rv;
  rv = opera_state_load_sized(DRAM,"RAM",data,(uint32_t)(end - data),MAX_HIRES_RAM_SIZE);
  if(rv == 0)
    return 0;
  data += rv;
  rv = opera_state_load_sized(ROM1,"ROM1",data,(uint32_t)(end - data),ROM1_SIZE);
  if(rv == 0)
    return 0;
  data += rv;
  rv = opera_state_load_sized(ROM2,"ROM2",data,(uint32_t)(end - data),ROM2_SIZE);
  if(rv == 0)
    return 0;
  data += rv;
  rv = opera_state_load_sized(NVRAM,"NVRM",data,(uint32_t)(end - data),NVRAM_SIZE);
  if(rv == 0)
    return 0;
  data += rv;

  _setup_dram_vram((opera_mem_cfg_t)memstate.mem_cfg);
  g_MEM_CFG = (opera_mem_cfg_t)memstate.mem_cfg;

  return (data - start);
}

static
uint32_t
opera_mem_state_load_mem(void const     *data_,
                         uint32_t const  size_)
{
  uint8_t mem_cfg;
  opera_state_reader_t reader;
  opera_state_reader_t payload;

  opera_state_reader_init(&reader,data_,size_);

  if(!opera_state_read_chunk(&reader,"MEM",&payload) ||
     !opera_state_read_u8(&payload,&mem_cfg) ||
     !opera_mem_is_valid_cfg((opera_mem_cfg_t)mem_cfg) ||
     (opera_state_reader_remaining(&payload) != (MAX_HIRES_RAM_SIZE +
                                                 ROM1_SIZE +
                                                 ROM2_SIZE +
                                                 NVRAM_SIZE)))
    return 0;

  /* Validating: the sizes were checked above, so the bulk payload is
   * only stepped over, not copied. */
  if(opera_state_validating())
    {
      if(!opera_state_skip_bytes(&payload,opera_state_reader_remaining(&payload)) ||
         !opera_state_reader_finished(&payload))
        return 0;
      return opera_state_reader_used(&reader);
    }

  if(!opera_state_read_bytes(&payload,DRAM,MAX_HIRES_RAM_SIZE) ||
     !opera_state_read_bytes(&payload,ROM1,ROM1_SIZE) ||
     !opera_state_read_bytes(&payload,ROM2,ROM2_SIZE) ||
     !opera_state_read_bytes(&payload,NVRAM,NVRAM_SIZE) ||
     !opera_state_reader_finished(&payload))
    return 0;

  _setup_dram_vram((opera_mem_cfg_t)mem_cfg);
  g_MEM_CFG = (opera_mem_cfg_t)mem_cfg;

  return opera_state_reader_used(&reader);
}

static
uint32_t
opera_mem_state_load_mem2(void const     *data_,
                          uint32_t const  size_)
{
  uint8_t mem_cfg;
  uint32_t ram_bytes;
  opera_state_reader_t reader;
  opera_state_reader_t payload;

  opera_state_reader_init(&reader,data_,size_);

  if(!opera_state_read_chunk(&reader,"MEM2",&payload) ||
     !opera_state_read_u8(&payload,&mem_cfg) ||
     !opera_mem_is_valid_cfg((opera_mem_cfg_t)mem_cfg) ||
     !opera_state_read_u32(&payload,&ram_bytes) ||
     (ram_bytes != opera_mem_state_ram_bytes((opera_mem_cfg_t)mem_cfg)) ||
     (ram_bytes > MAX_HIRES_RAM_SIZE) ||
     (opera_state_reader_remaining(&payload) != (ram_bytes + NVRAM_SIZE)))
    return 0;

  if(opera_state_validating())
    {
      if(!opera_state_skip_bytes(&payload,opera_state_reader_remaining(&payload)) ||
         !opera_state_reader_finished(&payload))
        return 0;
      return opera_state_reader_used(&reader);
    }

  if(!opera_state_read_bytes(&payload,DRAM,ram_bytes) ||
     !opera_state_read_bytes(&payload,NVRAM,NVRAM_SIZE) ||
     !opera_state_reader_finished(&payload))
    return 0;

  _setup_dram_vram((opera_mem_cfg_t)mem_cfg);
  g_MEM_CFG = (opera_mem_cfg_t)mem_cfg;

  return opera_state_reader_used(&reader);
}

/* MEM2 from V4 states, MEM from V3; the chunk name says which. */
uint32_t
opera_mem_state_load(void const     *data_,
                     uint32_t const  size_)
{
  uint8_t const *name = (uint8_t const*)data_;

  if((size_ >= 4) && !memcmp(name,"MEM2",4))
    return opera_mem_state_load_mem2(data_,size_);

  return opera_mem_state_load_mem(data_,size_);
}
