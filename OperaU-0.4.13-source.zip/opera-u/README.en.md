# Opera U — 3DO emulator for the Wii U (Aroma)

[Versão em português](README.md)

Opera U is a 3DO emulator that runs as an **Aroma** application (`.wuhb`) on the Wii U. It uses the
[Opera](https://github.com/libretro/opera-libretro) core (a libretro project derived from 4DO and FreeDO), built
together with a purpose-written Wii U front end: SDL2/GX2 video, audio, controllers, menus, save states, per-game
options and a core diagnostic that runs on the console itself.

> **Project status.** Opera U was written and verified on a Linux server (no console, no games) and has been tested,
> version by version, on a real Wii U by the person who commissioned it. Confirmed on the console so far: the app opens
> from Aroma, the **Core diagnostic passes** (video and audio hashes equal to the PC's), an original BIOS works and
> games start. Still being tuned: picture colours (fixed in this version, **still to be confirmed on the console**
> with the **Picture test**) and speed (heavy games ran at ~33 frames per second in the previous version). What was
> verified and what was **not** is listed under [Verification](#verification-what-was-and-was-not-tested). If
> something fails, **Settings > System > Core diagnostic**, **Settings > Video > Picture test** and the
> `wiiu/OperaU/logs` folder help find out why.

**Non-commercial use only** (the core's license; see [Licenses](#licenses)). No BIOS or games are included.

## Screenshots

Generated on a PC by the automatic UI test (`--selftest-ui`); the interface is the same as on the Wii U, but these are
**not screenshots of a console**.

| | |
| --- | --- |
| ![Settings](docs/screenshots/04-settings.png) | ![Core options](docs/screenshots/05-coreopts.png) |
| ![Help & credits](docs/screenshots/08-about.png) | ![Pause menu](docs/screenshots/11-pause.png) |
| ![Diagnostic running](docs/screenshots/13-diag-running.png) | ![Diagnostic result](docs/screenshots/14-diag-result.png) |
| ![Picture test: colour bars](docs/screenshots/15-testpat-colours.png) | ![Picture test: geometry](docs/screenshots/16-testpat-geometry.png) |

## Installation

1. Copy `dist/OperaU-<version>.wuhb` (or the `OperaU.wuhb` you build with `make`; its SHA-256 is in
   `dist/SHA256SUMS.txt`) to `sd:/wiiu/apps/` (the Wii U's SD card, with Aroma installed). If an `OperaU.wuhb` from an
   earlier version is already there, delete it: the data lives in `sd:/wiiu/OperaU/` and is not lost.
2. Start **Opera U** from the Aroma menu. The version shows in the Aroma entry's name (from 0.2.1 on), at the top right
   of the app and in **Help & credits**; `diagnostic.txt` and the log start with it.
3. On first run the app creates `sd:/wiiu/OperaU/` with these folders:

| Folder | Contents |
| --- | --- |
| `roms/` | suggested games folder (the browser's **Y** key jumps to it) |
| `bios/` | original BIOS dumps, optional (see below) |
| `saves/` | the 3DO's internal memory (NVRAM), written automatically |
| `states/` | save states (10 slots per game + one automatic) |
| `shots/` | screenshots |
| `config/` | app, core-option and per-game settings |
| `logs/` | run log (useful when reporting problems) |

Everything lives inside `wiiu/OperaU`; deleting that folder returns the app to its initial state. (The `diag/`
subfolder only exists while the diagnostic runs and is removed afterwards.)

## Games: CHD, ISO and discs

The app opens **CHD, ISO and BIN+CUE** disc images (for BIN+CUE open the `.cue` file). Copy the images to the SD card
(or a USB drive, if your environment exposes it to the app) and use **Open game** to browse to them.

* **CHD** (v5): the usual `chdman` CD compressors are supported (`cdlz`, `cdzl`, `cdzs`, plus LZMA, zlib, zstd and
  FLAC for audio tracks). No external library is needed: the reader is part of the core.
* **ISO** (2048 bytes per sector) and **BIN+CUE** (2352 bytes per sector, the `.cue` describing the tracks).
* **An original disc in the Wii U drive: not possible.** The Wii U's optical drive only reads Nintendo discs and gives
  no raw access to the sectors of other discs; no application can read a 3DO disc through it. This is a limit of the
  hardware and the system, not of the emulator. What the app does instead: browse SD/USB and open the image of your
  disc.

How to get an image of a disc you own (on a PC):

```sh
# 1) make a .bin/.cue pair with any CD ripping tool (e.g. cdrdao, ImgBurn, dd + a hand-written cue)
# 2) convert it to CHD (smaller and faster to read):
chdman createcd -i game.cue -o game.chd
```

Then copy `game.chd` to the SD card (for example `sd:/wiiu/OperaU/roms/`).

## BIOS

The app embeds **Opera Boot** (a free BIOS, GPL-2.0, the [opera-boot](https://github.com/trapexit/opera-boot) project),
so it starts without extra files, but compatibility with it may be partial. For better compatibility put original BIOS
dumps **that you own** in `sd:/wiiu/OperaU/bios/` (names such as `panafz10.bin`; the accepted names are listed in the
core's README) and select them in **Settings > Core options > BIOS**. Some Japanese games also need a font (kanji) ROM
in the same folder.

## Controls

Default mapping (changeable in **Settings > Controls**; per-controller remapping and port swapping are available):

| 3DO | Wii U |
| --- | --- |
| D-pad | D-pad |
| A / B / C | B / A / ZL |
| L / R | Y / ZR |
| P (play/pause) | X |
| X (stop) | + |

In-game shortcuts: **L + R at the same time** opens or closes the menu (it can be turned off in Settings > Controls if
a game uses L + R together); **the second (right) stick pushed to the right** fast-forwards while held; the **HOME button belongs to the console** and opens the Wii U's own menu, the app does not use it; **ZL and ZR are game buttons** (the 3DO's C and R), and the Wii U's own **L and R shoulders stay free** for the menu shortcut. Holding **−** and pressing: **+** (menu), **R** (save state), **L** (load state), **←/→** (change
slot), **A** (PNG screenshot, in `wiiu/OperaU/shots`), **Y** (reset the console); **−** + a held **X** fast-forwards
too (for pads without a second stick). The same text is in **Help & credits** inside the app.

The app uses the controllers the Wii U SDL2 port exposes (GamePad, Pro Controller and, depending on the port, Wii
Remote with extensions), up to 8 ports, and the GamePad touch screen navigates the menus. None of this could be tested
on a console.

## Settings

Video (aspect, filter, VSync, FPS counter, **colour channel order** and the **Picture test**), audio (volume, latency), the
**CPU core used for emulation** (automatic, 0, 1 or 2; default 2) and the **profiler**, controls, language
(Portuguese/English), automatic state on exit, UDP logging and the
**Opera core options** (BIOS, HiRes CEL rendering, matrix engine, region, CD speed, memory, ...). Core options apply to
every game, and each game can have its own from the pause menu.

## Picture test (colours and geometry)

**Settings > Video > Picture test** (home screen only, with no game open) shows synthetic pictures that take exactly the
path a game's pictures take (conversion to 32 bits, texture, screen). Right above the colour bars there are reference
squares drawn by the menu itself: **if a bar is the same colour as its square, the colours are right**.

* Page 1: colour bars (full and half intensity), red, green, blue and grey ramps, a rainbow and three squares (red,
  green, blue), in 16 bits (0RGB1555, the core's format).
* Page 2: geometry: a 4×4 grid, circles (they must be round at 4:3), diagonals, a fully visible white border, red /
  green / blue / yellow corners and an **F** (to notice mirroring or rotation).
* Page 3: the same at high resolution (640×480), with 1-pixel stripes to see what the filter does.
* Page 4: the bars again, sent in 32 bits (XRGB8888). If they are right here and wrong on page 1, the problem is only
  in the 16-bit path.

**A** or **→** goes to the next page, **←** goes back, **X** changes the **colour channel order** (RGB, BGR, RBG, GRB,
GBR, BRG; applies to every game and is saved), **Y** changes the filter and **B** exits. The normal order (RGB) is the
right one; the others exist only to fix swapped channels in case the console's video output produces them. PNG
screenshots (− + A) are always saved with the exact colours the core produced, whatever this option says.

## Performance

* On a PC (x86-64) the idle BIOS runs about 14× faster than real time. On the Wii U, the previous version's diagnostic
  measured 9.8 ms per frame with the idle BIOS (1.7× real time) and heavy games ran at ~33 frames per second (≈ 55% of
  full speed). This version brings **exact** optimisations (bit-for-bit identical results, verified on the PC and on
  the simulated PowerPC) and a profiler to guide the next ones.
* **Profiler** (Settings > Performance; on by default): every 5 seconds it writes to the log (`wiiu/OperaU/logs`) how
  many milliseconds per frame each part of the emulator takes (ARM processor, graphics / cel engine, audio DSP, video
  lines, timers, audio and picture copies), how many cels, texels and pixels per frame, and how often the DSP runs. With
  **Show FPS** on, a summary appears on a second line of the screen. This is how to find out whether a game's bottleneck
  is the ARM, the graphics or the audio. Measuring is cheap (a few hundred time base reads per frame) and its cost is
  subtracted from what is shown.
* Turn on **Show FPS** to see the emulation speed in game, and use **Core diagnostic** to measure the speed of the idle
  BIOS (an upper bound for what a game can reach).
* If it is too slow: keep **HiRes CEL Rendering** off, keep the default pixel format, and try another **CPU core**
  (automatic, 0, 1 or 2) in Settings.

## Core diagnostic (a test on the Wii U itself)

**Settings > System > Core diagnostic** (home screen only, with no game open). It runs 240 frames of the built-in BIOS,
hashes every picture and every audio sample, saves a state, replays 60 frames twice (the replays must be identical) and
measures speed. It then runs thirteen random-input **workload batteries** (ARM interpreter, DSP, DSP programs that
never end, the cel engine in three shapes, audio FIFOs, matrices, SPORT, VDL, timers, ARM loops, and the ARM in
every instruction class and mode).
Every hash is compared with
those measured on a PC; since the Wii U is big-endian and the PC is little-endian, this is the most direct proof that
the Wii U build computes the same thing as the original. Last, it draws eight sprites shaped like a game's and measures
**how many nanoseconds a pixel costs** on your console (the `cel sprites` block of the report): the number that lets
the cel engine be compared from one version to the next. The last stage (the `DSP thread` block) plays four scripts -
ticks of the DSP and, between them, what a game's sound code does to it - twice: with the DSP inside the frame, which
must give what the PC gives, and with the DSP on its own thread (the **Threaded DSP** option), which must give the
same again. It is the one part of the diagnostic that depends on the console's threads and processor, so only the
console can answer it. The same stage measures what it costs the CPU, on your console, to wait for that thread.
The test uses the default options and a scratch folder, so it never touches your saves or settings.

The result is shown on screen and written to `wiiu/OperaU/diagnostic.txt`. The first line of the file says **which
version ran** (`Opera U 0.2.2 core diagnostic`) and the second one the build time. The file is created the moment the
test starts (the old report is removed) and updated before every battery: while it says `result: RUNNING` the test has
not finished, and the `stage:` line shows where it is. If the app closes or freezes, that text is what is left. Send it
to whoever maintains the project, together with the log (`wiiu/OperaU/logs/operau.log`; the previous run's is
`operau.old.log`). If it says **FAILED**, the procedure is the same.

## Verification: what was and was not tested

Everything below was executed on a Linux server. The Wii U is a **big-endian** PowerPC 750 derivative; the Opera core
was written for little-endian CPUs, so the port needed fixes (listed in
[`third_party/patches/README.md`](third_party/patches/README.md)). To check them without the console, the same C code
is built for x86 and for PowerPC with devkitPPC (same flags as the Wii U), the PowerPC build runs under QEMU
(`qemu-ppc`, 750 CPU) and the results are compared:

* Built-in BIOS: per-frame video, audio, DRAM and VRAM hashes are identical on x86 and PowerPC; booting from an ISO and
  from a CHD, and the save-state replay, match too.
* 194 bit-field layout checks (the most likely source of big-endian errors), with a negative control proving the test
  catches the mistake.
* Differential tests with random inputs: the ARM interpreter (up to 6000 programs per seed), the DSP (5 × 5000), the
  cel engine including packed cels (2 × 4000), the CLIO audio FIFOs (3 × 3000), the matrix engine, the SPORT, the VDL,
  the CLIO timers, an ARM loop benchmark and the ARM in every instruction class and mode (random programs that also
  touch the MADAM and the CLIO): ten batteries with identical hashes on both architectures. These tests found five
  real bugs (the ROR carry, a missing `#include` that left the memory accessors little-endian, an uninitialised
  variable in the DSP, and two out-of-bounds reads of the MADAM and CLIO registers), all fixed.
* **Exact** performance optimisations (CLIO timers resolved in batches and a compact XBUS device list): about 17% less
  time per frame on the PC, with the boot hash and those of all the batteries identical on both processors (the timer
  battery was written for this and demonstrably catches errors: three mutations planted on purpose change the hash).
* Picture test screen: on the PC the automatic test (`--selftest-video`) reads the actual screen pixels and checks every
  bar, ramp and square on the 4 pages × 6 channel orders, on the 16- and 32-bit paths, plus a game-style picture; with a
  negative control (two planted defects, including red/blue swapped in the 15-bit table, are caught).
* `.wuhb` package (`tools/check_wuhb.py`, also in CI): opens the package the way Aroma does and checks the name with
  the version, the author, the icon, both splash screens and that the program inside carries the same version. It
  exists because up to 0.2.0 the package came out with a generic name, no version and no icon without anything
  complaining; run on the 0.2.0 package it reports exactly those defects.
* Disc reading: 14 images (ISO, BIN+CUE with 2048- and 2352-byte sectors, and 11 CHD variants: `cdlz`, `cdzl`,
  `cdzs`, LZMA, zlib, zstd, mixed hunks, no ECC, large hunks, with subcode) read on both architectures return exactly
  the source bytes (`tools/test_chd_codecs.py`).
* End-to-end test on the host (`--selftest-run`): open a game, save state, reset, close, invalid files (show an error
  and return to the menu), the diagnostic and cancelling the diagnostic.

**Confirmed by the user on the console** (earlier versions): the app opens and runs, the Core diagnostic passes with
hashes equal to the PC's, an original BIOS works and games start.

**Not verified yet**: the colour fix on the console (the cause was found by reading the Wii U SDL2 port's code, which
handles the 16-bit ARGB1555 texture with swapped channels; the fix, a 32-bit texture, is tested on the PC but **needs
the Picture test on the console**), Wii U audio beyond "it plays", the USB path, the HOME menu (ProcUI), speed in games
after this version's optimisations, broad game compatibility, FLAC (`cdfl`) CD audio tracks on big-endian, and the
matrix-engine / VDL paths beyond what the BIOS, the cel simulation and the differential tests exercise.

## Version history

The number is shown at the top right of the app, in the package name in the Aroma menu, in the header of
`diagnostic.txt` and on the first line of every log (with the build time).

* **0.4.13**: the game's own pace is now measured, and the cel engine's speed becomes an option. The report
  behind it: in the opening of Super Street Fighter II Turbo the sound keeps its time and the picture falls
  behind; after that the game runs normally. Sound on time means the emulator is delivering its 60 fields a
  second - it is the *game* that shows fewer pictures than fields, and that is decided inside the emulated
  machine, not by the Wii U's speed. In there a game waits for three things, and `perf.txt` now measures all
  three (the `the game` block):
  * **The game's pictures a second**: how many fields showed another frame than the one before. Also on screen,
    next to the percentages (`game 30/s`), with "Show FPS" on.
  * **Cel engine busy**: after drawing a list the emulated engine says it is busy for a time that depends on
    how much it drew, and the game waits. The core uses 9 million pixels a second; the 3DO's published
    specification says 9 to 16 million. At 9, a game that draws more than 150 thousand pixels a field cannot
    show a picture every field - and the music, which the DSP plays on time, gets ahead. If the Street Fighter
    opening shows this number near 100%, that is it.
  * **Disc**: sectors read a second, what reading cost and the longest single read. This is what tells CHD from
    ISO: the read happens on the emulation thread, and a slow one is a pause in the game.

  **New option: CEL Engine Speed** (Settings → Core options, or for one game in Game options): 9 million pixels
  a second (the default, the core's own figure), 12, 16, or unbounded (the engine is never busy, as in older
  versions of the core; some games then run too fast). At the default nothing changes: the hashes of every
  workload and of the boot are the same. A new battery, `celt`, checks that the busy time is exactly the rule's
  at each speed, that the report's count is that same time, and that the picture is identical at all of them -
  the speed changes *when*, never *what*. It caught a mistake in my count (a list drawn at cycle zero was not
  counted) before it shipped.

  **`perf.txt` is now written when the game is paused or closed**, with the five seconds before. It used to be
  written every twenty seconds and could be twenty seconds old: "close the game in the middle of the scene"
  measured another scene. The periodic write stays (it is what leaves a record when a game hangs), but it left
  the emulation thread: writing two files to the card takes tens of milliseconds, and those were milliseconds
  of the game standing still. The file says how long its last write took.

  **The log too.** The meter writes about nine lines to the log every five seconds, and the C library's default
  buffer is a block or two: every time it filled was a write to the card, made by the emulation thread. The log
  now has a 32 KB buffer and goes to the card from the thread that writes the report (every twenty seconds) or
  when the game is paused; warnings and errors still go at once. `perf.txt` shows what writing to the log cost
  (`the log`): a fraction of a millisecond is what to expect. And the very first run, when the folders do not
  exist yet, now has a log.

  `logs/operau.log` holds these same measurements **for the whole session**, one batch every five seconds: it
  is the file that shows the opening and the fight of the same game, with no need to pause at the right moment.
* **0.4.12**: the DSP on its own thread (**Threaded DSP**) no longer stops the game and now does exactly what
  the DSP inside the frame does; and on the way it turned out that **left and right were exchanged on the Wii U**,
  in every game and since the first version.
  * **The game that stopped at a black screen.** In Yu Yu Hakusho, with the option on, the game stopped after a
    fight and the console had to be restarted. The `perf.txt` of that moment showed the DSP thread at a
    standstill, the emulation at 109 frames per second and no sound. Reproduced on the PC: a DSP program that
    never reaches its sleep instruction held the thread for good. The game waited for a DSP that did not answer;
    the emulator, which paces itself by the sound, had nothing to pace by; and closing the game waited for the
    thread to end, which it never did. A game does not write such programs, but it rewrites its program while the
    DSP runs, and the thread - up to a few dozen ticks behind the CPU - could catch it half done. On a real 3DO
    that costs one tick: the sample clock starts the program again from the top for every sample. The interpreter
    now does the same (it gives up on a run after 1024 instructions, or when it leaves the program memory), and a
    frame that hands over no sound at all is now paced by the clock instead of by the sound.
  * **The thread now does what the frame does.** Two defects that reading the code pointed at and the tests
    confirmed. The interrupts the DSP raises were written by the thread into the same word the emulation writes
    from the other side, unprotected: one could be lost - and a game waiting for the end of a sound goes on
    waiting. Now the thread only notes the request and the emulation raises the interrupt. And the CPU's writes to
    the DSP's program, the audio FIFOs, start / stop and the semaphore landed wherever the thread happened to be:
    in the middle of a tick, or ahead of ticks still to run. Each one now waits for the thread to finish what it
    was handed, and lands between the same two ticks as it would with the DSP inside the frame. Left out on
    purpose: the knobs (one word each, written all the time) and the CPU's reads of the DSP, which see the DSP a
    few ticks back. And the emulation no longer gets more than a frame of ticks ahead of the thread: in fast
    forward it handed ticks over faster than a busy DSP can run them, without limit, and the DSP - and the
    sound - ended up seconds behind.
  * **Left and right.** The core returns each sample as one word with the left channel in its low half and the
    right one in its high half, and hands it over as two numbers in a row. On a PC the low half comes first in
    memory; on a PowerPC, the high half. The Wii U played the right channel on the left. The new test caught it
    because it compares the sound value by value between the two architectures with programs that write
    different things to each channel - the BIOS of the boot test writes the same to both, so its hash never saw.
  * **Sound delay.** The default sound queue goes from 80 to 50 ms (Settings → Audio → Audio buffer; whoever had
    80 because it was the old default moves to 50, whoever chose another value keeps it). By the sizes of the
    buffers - not a measurement - the sound came out about 95 ms after the picture and now comes out about 65 ms
    after it. If it crackles while a game loads, set it back to 80.

  **How it was checked.** A new battery, `dspt`, plays the same script twice on a freshly loaded machine: ticks of
  the DSP and, between them, what a game's sound code does (rewriting the program, starting, stopping, resetting,
  pointing FIFOs, switching channels on and off, the semaphore, interrupts answered). It compares every sample of
  sound, the DSP's state, the CLIO's, the memory the DSP wrote and what the CPU read back. With the protections
  in place, 24 scripts of 185 to 290 thousand ticks give the same both ways, and the race detector
  (ThreadSanitizer) reports nothing in the ten I ran under it. I removed the protections one at a time, 17 in
  all. Fifteen change the result every time the battery runs. The other two are real races, which depend on
  chance: without the wait before a reset the result changed in some runs and not in others (a reset between two
  ticks alters nothing, since every tick starts with one; only one that lands in the middle of a tick matters),
  and without the noting of interrupts it changed in 1 script of 12 in one run, 4 of 24 in another and none in a
  third - writes really lost in the interrupt word, on a PC. The race detector reports both every time. The
  `dspr` battery runs programs that never end, and became the diagnostic's thirteenth workload. With the old
  defect put back on purpose, the emulator now stays at 59.9 frames per second where it used to shoot up to
  between 316 and 745 on the PC.

  **What only the console can answer**, and so went into the diagnostic: whether the thread gives the same result
  with the Wii U's threads and processor (the `DSP thread` block), and what each wait costs there. `perf.txt`
  gained the lines `waited for` (waits per frame and milliseconds) and `DSP runs given up on`.

  **What this version does not solve.** The frame rate dropping in Yu Yu Hakusho's fights: the only `perf.txt`
  of a fight I have is from 0.4.8, and the one from 0.4.11 was overwritten by the black screen. And the picture
  and sound out of step in the opening of Super Street Fighter II Turbo has no proven cause: this version deals
  with two possible ones (interrupts lost with the thread on, and the sound delay), and if neither is the real
  one it is the `perf.txt` of the opening that will say where to look.
* **0.4.11**: the cel engine stops working the same sum out again. Three changes, all exact:
  * **The finished pixel, per source value.** In a cel that cannot see the frame buffer, everything between the
    bits read from the source and the pixel written - decoder, pixel processor, projector - depends on those
    bits alone. A 4-bit cel has 16 values and thousands of texels, and the whole chain ran for every texel. Now
    each value goes through the chain the first time it turns up and is kept; after that a texel costs the read
    of its bits and one lookup. 16-bit pictures with too many colours for that to pay are spotted within their
    first 512 texels and go back to the previous path.
  * **Cels mixed with what is behind them** (shadows, glass, fades - the ones that read the frame buffer). These
    were the dearest, because the whole pipeline ran for every pixel, and they are anything from none to 90% of
    the pixels depending on the game. Each channel of the answer depends only on the same channel of the two
    pixels, five bits each: a 32 x 32 table. It is built from very little (half a PIXC word and two flags), and
    a game mixes in a handful of ways it keeps repeating - so the tables are kept from one cel to the next and
    from one frame to the next.
  * **Reading the bits, and filling.** Reading each texel's bits was a call into another file that fetched a
    byte at a time; it is now three bytes and a cut, inside the loop. And a scaled cel fills each texel's block
    in one go, clipped to the edge of the screen, instead of testing pixel by pixel.

  Instructions per pixel on the PC, 0.4.10 -> 0.4.11: 4- or 6-bit sprite at its own size 160 -> 83; 8-bit sprite
  shaded per texel (the mode that carries about 70% of Yu Yu Hakusho's pixels) 319 -> 116; 16-bit picture
  251 -> 129; scaled sprite
  97 -> 63; sprite mixed with the background 311 -> 218; turned sprite 277 -> 225. The console's number comes
  from this version's diagnostic, which times those same eight sprites with the table off and on.

  **How it was checked - and a gap that turned up.** The cel batteries always drew fractional positions, and the
  engine only takes its line path - a sprite at its own size, which is most of what a 2D game draws - when the
  position is a whole pixel. That path had never been exercised by them, and neither had cels leaving through the
  top or the left of the screen. The new battery, `celu`, covers that, plus what a game repeats from one cel to
  the next, and also checks the engine's pixel count. On its first run it caught a mistake of mine in this
  version (a fourth place where the sum was done, which I had not seen), fixed before release. The engine of
  0.4.9 and 0.4.10 was put through it afterwards: it was correct. The reference is now the **original engine,
  with none of this project's changes**: 21 runs of 2500 cels and the eight sprites give the same result on it,
  on 0.4.10 and on this version; and this version gives the same on x86 and on PowerPC. And to know whether the
  batteries can see a mistake, I
  planted 26 on purpose in the new code: every one is reported, and nine of them go unnoticed by the two older
  batteries. Nine
  changes that must not alter anything (the cel numbering going round, two tables instead of 32, four slots
  instead of 1024) indeed alter nothing.

  **About the GPU.** I started this version to have the GPU draw the cels. Reading the drawing path in order to
  move it to the shader, the sum came out against it: what the shader would compute per pixel is a pure function
  of the source value, and the CPU settles that with a lookup, without the 0.18 ms each hand-over to the GPU
  costs on this console and without taking the frame buffer out of the memory the rest of the 3DO reads it
  from. A GPU path for the cels would be slower than this one. The shader probe stays in the diagnostic;
  `perf.txt` swaps the "could the GPU draw them" block for "how the engine drew them", which says how many pixels
  still go through the long sum.
* **0.4.10**: the pixel-processor tables now cover the per-texel scale mode (`ms == 1`). They left it out
  because the multiplier changes with every texel, so each of its pixels ran the whole sum; in Yu Yu Hakusho that
  mode carries about 70% of the pixels. Since there are only eight multipliers per channel, there is now a table
  per multiplier, built the first time a texel asks for it and only after the cel has drawn 64 pixels through the
  long path, so that small cels do not pay for tables they will not use. It is exact - the table body is the one
  that already existed, with the multiplier substituted - and was checked against the old path over 14 runs of
  2500 cels, which do exercise the mode: identical hashes.
  Result of 0.4.9 on the console: the cost per pixel in Yu Yu Hakusho fell from 276 to 234 ns.
* **0.4.9**: cels that cannot see the frame buffer stop paying for the pixel processor at every pixel. Reading
  the drawing path in order to move it to the GPU showed why a pixel costs 90 to 277 ns: all three paths (line,
  scaled and arbitrary) read the frame buffer under every pixel and ran the pixel processor and the projector
  again whenever that value changed - which over a background is every pixel - to reach the same answer each
  time, because for these cels the colour depends on the source texel alone. The colour is now worked out once
  per texel and the pixels are only written. In the games measured on the console these are 46 to 100% of the
  cels drawn. It is exact by construction, and was checked by building the old path (`-DOPERA_NO_FB_FREE`) and
  comparing 14 runs of 2500 cels: identical hashes. On a PC the cel engine executes 14.9% fewer instructions in
  the game-shaped battery; the real gain on the console shows in the "pixels ... ns each" line.
  Result of the DSP thread test on the console, with the option on: Yu Yu Hakusho went from 22.5 to 27.2 fps
  and Samurai Shodown from 40.8 to 58.7, with no sample of sound lost across five games.
  It also fixes a number mislabelled in 0.4.8: "ran dry N times since the game started" counted from the moment
  the app opened, adding up every game and menu. It now counts the last five seconds only.
* **0.4.8**: the DSP thread worked on the console: in Road Rash it did 8.15 ms of work per frame outside the
  frame time, lost no sample and was never more than 33 ticks behind. Two things were left unclear and this build
  measures them. The report showed the thread on cores 0, 1 and 2, but that number was cumulative since the
  start and did not say where it was running now; it now covers the last five seconds only, and pinning now
  gives up the processor at once and logs whether the system accepted it. And with a game at last running at
  full speed, a delay between sound and picture showed up: `perf.txt` now says how much sound is waiting to be
  played, the configured limit and how many times the buffer ran dry. A slow game never fills the buffer - its
  sound is choppy but not late - so this delay only appears once a game runs fast.
* **0.4.7**: the DSP can leave the frame. The upstream core already carries an option, off by default and marked
  experimental, that runs the DSP on a thread of its own; on the Wii U that means using one of the two cores that
  sit idle, and the DSP costs 5 to 9 ms of every frame on the one core the emulation uses. This build does not
  turn the option on by itself - it makes it measurable and safe to use: the thread is pinned to the free core
  (the interface is on 1, the emulation on 2, the DSP goes to 0), accounts for its own work, finishes what it
  was handed before a state is saved or loaded, and is stopped before the machine is destroyed, not after.
  `perf.txt` now says whether the thread is on, which core it ran on, how many milliseconds per frame it worked
  outside the frame time, how many samples of sound were lost and how far behind the emulation it ever was.
  Without that, a measurement with the option on would show the DSP as free and not say whether it kept up.
  What changes for exactness: graphics do not change; the moment at which the DSP sees what the CPU wrote is no
  longer identical from run to run. The diagnostic always runs with the option off, so the hashes still hold.
  To turn it on: Settings -> Core options -> "Threaded DSP" -> enabled.
* **0.4.6**: a playable build with no visual change and no speed gain yet: it measures what decides whether a
  hybrid is possible at all. The question is not how many cels the GPU could draw but **how they are arranged**.
  The 3DO's frame buffer cannot leave the CPU's memory, so cels drawn by the GPU and by the CPU must reach it in
  the right order, and every change of hands costs the wait measured at 0.178 ms on the console. A frame whose
  eligible cels arrive in a few long runs needs few waits; one that alternates needs hundreds, and at 353 cels a
  frame that is far more than the whole frame.
  `perf.txt` now reports, at three levels of strictness, how many cels and pixels the GPU could take, how many
  runs per frame they form and what the waiting would cost. It also asks the question that may make the runs
  beside the point: **how many whole cel lists** the GPU could draw on its own. Deciding per list instead of per
  cel removes the mixing - either the list goes to the GPU or it stays on the CPU - and the frame then pays one
  wait, the same one it already pays for the video hardware to read the frame buffer.
  It also carries the DSP counters, ready since 0.3.9 and not yet in the user's hands.
* **0.4.5**: **the probe came out exact.** Zero differences across 5120 pixels, over 20 configurations, through
  both texture paths: the Wii U's GPU computes the 3DO's pixel processor bit for bit as the CPU does, including
  truncation to signed 8 bits, arithmetic shifts, the 0..31 clamp, the PSCALAR table and sign extension. With the
  hand-off measured at 0.178 ms, both objections that could have killed the GPU route are gone.
  What that still does not answer is what this build measures. One full-screen pass is not the shape of a cel
  engine: each cel is its own draw with its own geometry and settings, and games split that work very
  differently - Yu Yu Hakusho draws about 11 cels of ~8000 pixels a frame, Super Street Fighter 2 Turbo about 353
  of ~220. Many small draws are exactly where a GPU gives its advantage back. So the diagnostic now times four
  frame shapes, with a register write per draw, to compare directly against the 24.55 ms and 9.25 ms the CPU
  spends in those two games.
* **0.4.4**: with the uniforms arriving, 0.4.3 finally measured what sat behind them, and three things came good
  at once: **`coords` 0 of 320**, **`table` 0 of 320**, and the mode selection. Coordinates, reading a
  single-channel texture and choosing a path are all correct. The two that remained failed for different reasons,
  and the report found both.
  The first is byte order: `0x0007` was written into the 16-bit texture and the shader read `0x0700`. The GPU
  reads a 16-bit texel the opposite way round from the way a PowerPC writes one. The swap now happens in the
  shader, where it costs nothing, and it is not a quirk of the probe: the 3DO's frame buffer holds 16-bit pixels
  in the CPU's order, so any path that ever hands those pixels to the GPU meets the same problem.
  The second was mine: the component map for a **one**-channel texture was applied to the **four**-channel one as
  well, which made its green always read zero. The table texture, which really is one channel, read perfectly
  with that map - the contrast between the two is what gave it away.
* **0.4.3**: the finding: `GX2SetPixelUniformReg` with `count = 1` **writes nothing at all**. 0.4.2's six-route
  trial measured it on the console with no ambiguity: the two routes that passed a `vec4` arrived (`got 42 want
  42`, `got 43 want 43`) and every route that passed a single word left the shader reading zero. The count is in
  words but the hardware writes whole registers, so a count of 1 rounds down to nothing. It was not the unit of
  the offset, which is where I looked twice.
  Each uniform is now written as a complete register, four words. Since each owns a register to itself (the
  compiled offsets are 0, 4, 8 ... 52), filling all four components harms nothing - the shader reads the first.
  With the uniforms arriving, everything that sat behind them means something for the first time: the mode
  selection, the reads of both textures, the coordinates and the eight shapes of the arithmetic. The six-route
  trial stays, as a guard against regression and as a record of which route works on this machine.
* **0.4.2**: 0.4.0's beacon narrowed the problem to the bone: **0 of 6400 pixels lacking the shader's own
  constant**, so the shader runs and its output reaches the target. And still every uniform reads as zero, with
  counts identical to 0.3.9's - `GX2SetShaderMode` was not the cause, and CafeGLSL's own documentation says why:
  *"GX2 uses GX2_SHADER_MODE_UNIFORM_REGISTER by default"*. The call was redundant.
  Reading the compiled `.gsh` from the inside, the stored offsets are 0, 4, 8 ... 52 (each uniform in a register
  of its own) and the mode is 0, register, with no block. What the compiler's code does not settle is which unit
  the system function expects that number in, and I have guessed wrong at this twice already.
  So this build stops guessing. The shader gained one uniform whose only job is to come back out in the alpha
  channel, where nothing else is written, and the probe writes it through **six different routes**, each with a
  distinct value. Whichever arrives names itself, with no reset needed between attempts. `diagnostic.txt` lists
  all six and marks the one that worked. If none works, that is an answer too: uniforms do not arrive this way at
  all, and the way out is to move to uniform blocks.
* **0.4.1**: the icon and splash screens carry the project's own mark: an "O" and a "U" interlocked with a disc
  arc behind them, in flat red, blue and yellow. Drawn for this project, with no gradient, because the icon is
  read at 48 pixels in the console's menu and what survives at that size is contrast, not detail. The name and
  version stay on the icon - that is what revealed, back in 0.2.x, that the console was opening an old file left
  on the card. Nothing else changed: the GPU probe is identical to 0.4.0's.
* **0.4.0**: the probe was not reporting an arithmetic fault - it was computing with **nothing**, and 0.3.9's data
  proved it with no room left. The `coords` mode hands back a constant written inside the shader, reading no
  texture at all, and it came back zero: that branch never ran, so `u_mode` arrived as zero. The hypothesis "the
  output is identically zero" reproduces all eight shapes of the arithmetic exactly, one by one: `negated`
  reporting "0 of 320 wrong" was not a pass, that shape expects zero in every column; and the odd 317 and 274 are
  precisely the number of columns where the CPU expects zero as well. Every uniform was arriving as zero.
  The cause is a documented requirement of CafeGLSL that I had missed: GX2 uses **one** uniform mode for the
  vertex and the pixel shader of a draw, and it has to be selected before drawing. The shader was compiled to read
  its uniforms from registers and the probe's context was not in that mode, so every register written was
  ignored. `GX2SetShaderMode(GX2_SHADER_MODE_UNIFORM_REGISTER)` is now called before the draws.
  So that this kind of mistake cannot pass for a wrong sum again, the shader now writes a constant into the alpha
  channel that depends on no uniform and no texture. If it arrives, the shader ran and its output reached the
  target, and whatever is zero is zero further up the path. `diagnostic.txt` reports that line.
* **0.3.9**: the shader was reading **zero** from the textures, and 0.3.8's probe proved it in one run.
  The line `first differs read source x=0 src=0007 got 00 00 00 want 00 07 00` says the value read was zero, and
  the table count confirms it: 310 of 320 wrong, with the 10 right ones being exactly the columns where the wanted
  value is zero too. `never drawn 0` ruled out the rest - the draw covered the whole target. And because the
  source mode and the table mode gave different counts, the uniforms do arrive and the shader does switch
  branches: the fault is only in getting the texture data to the GPU.
  This build goes at both possible causes at once. First, saying outright that the CPU wrote a texture
  (`GX2Invalidate` with `CPU_TEXTURE`) after each write - without it the GPU reads stale memory, which is exactly
  what zeros look like. Second, the same pixels also go across in an ordinary 8-bit texture, high byte in red and
  low byte in green, because an integer texture is the natural way to hand numbers to a shader but may not be one
  this GPU will read.
  `diagnostic.txt` now lists **one line per thing tried** instead of only aggregates, and there is a new mode that
  reads no texture at all - it hands back the pixel's own coordinate and a constant - to separate "wrong
  coordinate" from "wrong read" for good. The eight shapes of the arithmetic run twice, once over each texture, so
  that whichever way of handing the numbers over works, the same run already says whether the sums on top of it
  are right.
  It also brings the DSP counters to `perf.txt`: instructions per frame, nanoseconds each, control against ALU,
  operands and result write-back. The diagnostic's dsp battery cannot stand in for this - measured with an
  instruction counter, more than half of it is the test harness, not the DSP - and the interpreter's profile is
  flat (no line above 0.3%), so what is worth changing depends on what games execute. The counters live in locals
  and are handed over once per run, behind a flag read once: 1% of the loop, against the 4% that counting
  unconditionally cost.
* **0.3.8**: the GPU probe now says *where* it is wrong, and two mistakes of mine are fixed.
  0.3.7 measured the thing that mattered - the GPU-to-CPU hand-off costs **0.18 ms**, and a full-screen draw
  0.415 ms against the 24.36 ms the cels cost on the CPU in Yu Yu Hakusho - but the exactness check reported 2191
  of 2560 pixels different, and that is not rounding: it was my bug. The source texture was 320x1 pixels and the
  shader read it over 240 rows; past the first, `texelFetch` does not clamp and reads whatever lies in memory. It
  now has the full height. The component map of the single-channel textures also pointed at channels the format
  does not have, and the geometry became a triangle strip with culling off, so which way round it is wound cannot
  decide whether anything is drawn.
  Rather than swap one guess for another, the probe now checks the three stages apart: it hands back **the raw
  value it read** from the source texture, **the value it read** from the table, and only then the arithmetic -
  and it marks the target row before drawing, so "nothing was drawn" cannot pass for an arithmetic fault.
  `diagnostic.txt` carries the three lines and the first differing pixel, with what came back and what was wanted.
* **0.3.7**: the GPU route stops being guesswork. This build makes nothing faster: it measures the two things
  that decide whether the cel engine (24.68 of a 45.6 ms frame in Yu Yu Hakusho) could be drawn by the GPU.
  - **The arithmetic.** Wii U shaders normally have to be written in the GPU's own assembly and assembled by a
    tool from an emulator; CafeGLSL compiles GLSL instead, here on a PC, and the result is embedded in the RPX
    (nothing extra ships to the console). `shaders/pprobe.frag` is a line-for-line copy of the 3DO's pixel
    processor in C's terms: truncation to `int8_t`, sign-propagating shifts, clamping to 0..31. The diagnostic
    runs eight different shapes of the processor and compares **every** pixel against the CPU doing the same sum.
    If they agree, the GPU can do the work without giving up the exactness the whole emulator is tested for.
  - **The cost of the hand-off.** The 3DO's frame buffer cannot leave main memory: the ARM reads and writes it as
    ordinary memory, the SPORT copies it with `memcpy`, and the video hardware reads it to build the picture. So
    the GPU would have to hand each frame back and the CPU would have to wait. The probe times a draw on its own
    and then a draw plus that wait; the difference is the price of the hand-off. At 60 fps there are 16.7 ms for
    everything.
  - The probe works in a GX2 context state of its own, so nothing it sets is stored in the renderer's saved state
    - that is how the colours broke after running the diagnostic in an earlier build.
  - It also fixes the cel measurement in `perf.txt`: their shape is now measured over the **same five seconds** as
    the times above it, instead of averaged over the whole session. And there is a new number, "reads the frame
    buffer": the share of cels that read the pixel already there. That one decides whether cels could go to the
    GPU in a batch, because reading the destination forces a draw to stop and wait for the ones before it.
* **0.3.6**: the diagnostic now times each battery, which fixes a mistake in my method.
  I had been comparing cel timings between versions using measurements taken **while a game was running**, and
  those are not comparable: a different moment of the same game draws a completely different mix of cels, and that
  moves the numbers far more than any optimisation. Three measurements of Yu Yu Hakusho gave 24.74, 22.82 and
  24.68 ms, with the share of cels using AV ranging from 13% to 84% - different scenes, not better or worse
  builds. The diagnostic's batteries, by contrast, do exactly the same work every time and in every build. Each
  one now carries its time in `diagnostic.txt`, and that is where the real effect of an optimisation should be
  read on the console.
* **0.3.5**: a disc report. Whenever a game is opened the app writes `wiiu/OperaU/disc.txt` with what the image
  actually holds: how many blocks, whether the first sector could be read, and the volume header every real 3DO
  disc carries in that first sector (record type 1, five 0x5A bytes, and the disc's own comment and label), plus
  spot reads spread over the image. A game that opens and draws nothing looks on screen exactly like a game that
  failed to open - and that difference is precisely the one between the image and the emulator.
* **0.3.4**: the per-cel tables are only built when a pixel needs them.
  The twelve-game set showed that many cels are processed and **draw nothing at all**: 74% of them in one game.
  0.3.2 built the tables for every cel, those included, and a cel that draws a handful of pixels did not repay the
  cost either. The tables are now built the first time a pixel asks for them, and only the half of PIXC that pixel
  uses. On the random battery the engine went from 333.3 to 330.2 million instructions; in games with many
  discarded cels the gain is larger. The report also gives the absolute number of cels, texels and pixels per frame.
* **0.3.3**: one measurement file per game. Until now, playing two games in the same session **added both** into the
  same `perf.txt`, and the blend would have led to wrong conclusions about how cels are configured. The totals are
  now cleared when another game is loaded, and besides `perf.txt` (always the latest game) a `perf-<game>.txt` is
  written for each one. Several games can be measured in a single session.
* **0.3.2**: the per-cel tables now cover nearly everything, thanks to the second game measured.
  The `perf.txt` from a different game showed a shape 0.3.1 did not cover: 13% of its cels used AV, 9% took colour 1
  from the frame buffer and 7% used another scaling mode. The general rule is simpler than what I had written: the
  tables hold whenever **every value that indexes them comes from the same source**. That brought AV, colour 1 from
  the frame buffer and scaling modes 2 and 3 into the fast path. Coverage on the random battery went from 5.4% to
  **39.1%** of pixels, and is 100% on the game-shaped one. The engine fell a further 3.7% on the random battery
  (346.3 to 333.3 million instructions) and keeps the 13.8% on the game-shaped one. 28 comparisons against the
  build without the fast path all came out equal, on x86 and on PowerPC.
* **0.3.1**: the largest speed-up so far, and it came out of your `perf.txt`.
  * **The pixel processor is now worked out once per cel.** The figures from the running game showed that almost
    every cel uses it in one single way: AV off in 100% of them, `s1` always 0, `ms` equal to 0 in 98% and colour 2
    coming from anywhere but the frame buffer in 98%. In that shape **each output channel depends only on the five
    bits of the same channel of the source pixel** and on values fixed for the whole cel. So the answer for all 32
    possible values is worked out once per cel, and drawing a pixel costs three table lookups instead of the whole
    pipeline. Measured on the game-shaped workload: the engine's work fell from 148.7 to 128.2 million
    instructions, **13.8% less**.
  * **A new battery: `celg`.** It turned out the old cel battery draws every configuration at random and only
    produces the real-game shape for 5.4% of its pixels - so it would barely have tested the fast path above.
    `celg` generates cels exactly the way a game does. Its reference value was measured with the fast path turned
    **off**, and the fast path reproduces it; on top of that, 20 comparisons between the two builds (10 seeds x 2
    batteries) all came out equal, on x86 and on PowerPC. There are eleven batteries now, and this one runs on the
    console too.
* **0.3.0**: the performance figures now come out in a file of their own.
  * **`wiiu/OperaU/perf.txt`.** The same information that already went to the log is also written to this file, in
    the same folder as `diagnostic.txt`: frames per second, what each part of the emulator costs and, added up
    since the game was started, how the cels are configured and which of the three routines draws them. It is
    rewritten at most every twenty seconds so that the writing does not disturb the measurement. Hunting for lines
    inside the log was awkward and easy to get wrong; this file is small and to the point.
* **0.2.9**: finishes the cel round.
  * **The scaled path is inlined too.** 0.2.8 inlined the rasteriser of the *arbitrary* path; this does the same for
    the *scaled* one. It mattered because I did not know which of the two games use: if they use the scaled path,
    0.2.8 on its own would do nothing on the console. Measured: 1% off the whole cel test (16.8 million
    instructions), with identical results on x86 and PowerPC.
  * **The log now says which path is used.** This was exactly what 0.2.8 was missing: the profiler records how each
    cel is stored (packed, LR form or literal) and which of the three routines drew it (line, scaled or arbitrary).
    It is the first thing to look at before optimising, because the three cost very different amounts.
* **0.2.8**: a second round on performance, in the cel engine (40% of the frame in your measurements).
  * **The rasteriser is inlined.** The routine that turns each texel into pixels is called 1.4 million times in the
    cel test and nearly all of its cost is setup. Both call sites pass the resolution mode as a constant, so
    inlining lets the compiler drop eight variable shifts and several branches: that path went from 152.5 to 128.5
    million instructions, **16% less**.
  * **Cel statistics in the log.** The profiler now records, once per cel (which costs nothing per pixel), how each
    one is set up: whether it uses AV, whether it needs the black fix-up, where the colours come from and how many
    bits per pixel. The BIOS draws almost no cels, so **only a real game can say** what is worth specialising;
    those log lines are the measurement the next optimisation needs.
  * **Tried and dropped**, for the record: rewriting the pixel processor with scalar arithmetic instead of the byte
    unions (no gain on x86, larger code on PowerPC), inlining the DSP memory accessor (0.9%), and replacing the
    rasteriser's divisions with shifts - 98.3% of them are by +-1 or +-2 and the replacement is provably exact
    (120 million comparisons), but it costs about 20 instructions to avoid one division, which does not pay. None
    of them went in.
* **0.2.7**: a new button mapping and the first speed-up of the ARM interpreter.
  * **Buttons (new default).** The 3DO's A on **B**, B on **A**, C on **ZL**, L on **Y**, R on **ZR**, P on **X**
    and X (stop) on **+**. That leaves the Wii U's own **L and R shoulders free**, which is what the menu shortcut
    uses. An existing installation is moved to the new default automatically; anyone who remaps afterwards keeps
    their own choice.
  * **Performance.** The most common case of all - a register operand with no shift ("LSL #0") - needs neither the
    shifter nor writing the carry flag back over itself. Measured with callgrind: **6.4% less work** over the whole
    boot (8.23 down to 7.71 billion instructions), 5.7% of it inside the interpreter. The result is still identical
    to the old interpreter: the ten batteries match on x86 and on PowerPC, and 24 extra comparisons (12 seeds x 2
    ARM batteries, 4000 trials each) against the previous version's binary all came out equal.
* **0.2.6**: fixes two problems 0.2.5 introduced, found on the console:
  * **Bluish picture.** The two-stage scaler of 0.2.5 drew into an ARGB8888 texture. The Wii U keeps every 32-bit
    format in the same surface and **reorders the channels when the texture is read**; writing into it ignores that
    reordering, so the picture came back with its channels rotated. The texture now uses the renderer's own format.
    On top of that the app **checks the colours at run time**: it draws four known colours through that same path
    and reads them back, and falls back to one-step scaling by itself if they do not match. A wrong guess of mine
    now costs a little sharpness, never the colours.
  * **HOME button.** It is not a controller button: the console itself opens that menu over the app. The app now
    turns that menu off (`OSEnableHomeButtonMenu`), so HOME does nothing. The Opera U menu is **L + R**, and "Exit"
    in that menu is how to leave.
* **0.2.5**: three fixes that came out of testing on the console:
  * **Wrong colours after the diagnostic.** The diagnostic's video workload reconfigures the 3DO's video processor
    and left it in the last format it used; the core applies that format only once, at startup, so the next game was
    drawn in one format and read in another. That is what made the colours go wrong again after a diagnostic (and a
    second diagnostic report FAILED) until the app was closed and reopened. The format is now re-asserted on every
    load, and a new test (`--selftest-diagstate`) proves the diagnostic leaves no state behind.
  * **HOME button.** It no longer opens the app's menu: HOME belongs to the console and opens the Wii U's own menu.
    The Opera U menu is still **L + R** (or **−** and **+** together).
  * **Stretch to screen (16:9) without losing sharpness.** The picture is now enlarged in two stages: first by a
    whole number with no filtering at all, and only then fitted to the destination. For 320x240 on a 1280x720 screen
    the first stage already lands exactly (4x and 3x), so the result is pixel for pixel. A test reads the screen and
    requires that no pixel is a blend of two; with the old path, 500 of 500 sampled pixels were blends.
* **0.2.4**: **fixes the icon**, which stopped the console from recognising the app (it showed as an unrecognised
  application with a question mark). The package images (icon and splash screens) were written without the 26-byte
  TGA 2.0 footer that the Wii U menu's reader requires; the official packaging tool writes it through the FreeImage
  library, and the FreeImage-free build used here did not (and cut off the end of the file as well). The generated
  icon is now structurally identical to Aroma's own default icon, and `tools/check_wuhb.py` requires the footer, so
  the mistake cannot come back unnoticed. There is also `make NOART=1`, which builds the same program with no icon
  and no splash screens.
* **0.2.3**: the version is shown **on the icon and on the splash screen** (before the app even loads). On start the
  app writes `wiiu/OperaU/version.txt` (which program ran last) and looks for Opera U copies in `wiiu/apps`: with more
  than one it warns on screen and lists the files, because each copy is its own entry in the Aroma menu and the old
  one keeps starting the old version.
* **0.2.2**: leaves no doubt about which version is running: the version and the build time (UTC) are shown in
  "Help & credits", on the diagnostic's progress screen, on the first line of the log and in `diagnostic.txt`. The
  diagnostic now **writes `diagnostic.txt` as soon as it starts** (removing any old report, which could be mistaken for
  the new version's result) and **before every test**, with the text `RUNNING` and the current stage: if the app closes
  or freezes half way, the file shows the version that ran and where it stopped. The log is written line by line during
  the diagnostic, and a cancelled diagnostic also leaves its report (`result: cancelled`).
* **0.2.1**: the `.wuhb` package now carries the name **"Opera U 0.2.1"**, the icon and the splash screens (up to 0.2.0 it
  came out with the default name "OperaU", the author "Built with devkitPPC & wut", no icon and no version). Two
  out-of-bounds reads of the MADAM and CLIO registers were fixed (they could crash the app if a game read those
  addresses). New ARM test covering every instruction class, which also runs in the console's diagnostic.
* **0.2.0**: colours fixed (32-bit texture), Picture test, performance meter, CLIO timers ~17% faster.
* **0.1.0**: first version.

## Building

Wii U (needs [devkitPro](https://devkitpro.org) with devkitPPC, wut and the Wii U SDL2 port):

```sh
export DEVKITPRO=/opt/devkitpro DEVKITPPC=/opt/devkitpro/devkitPPC
export PATH=$DEVKITPRO/portlibs/wiiu/bin:$DEVKITPRO/tools/bin:$DEVKITPPC/bin:$PATH
make -j4          # produces OperaU.wuhb (and OperaU.rpx / OperaU.elf)
make NOART=1 -j4  # the same program with no icon and no splash screens (to test whether a console
                  # rejects the package art rather than the program)
```

PC (Linux; SDL2 installed), for the automatic tests:

```sh
make -f Makefile.host -j4
export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy OPERAU_HOME=$(mktemp -d)
./build-host/operau-host --selftest-core        # BIOS boot, save state, hash against the x86 reference
./build-host/operau-host --selftest-run         # the whole application, including the diagnostic
./build-host/operau-host --selftest-ui DIR      # screenshots of every screen into DIR
```

The PowerPC simulation (bit-field layout, differential tests, disc reading) is described in
[`tools/ppcsim/README.md`](tools/ppcsim/README.md). `.github/workflows` holds a CI workflow that builds the `.wuhb`
and runs the host tests (written, but not executed in the environment where the project was made).

A note on wuhbtool: the `wuhbtool` used for the build accepts uncompressed TGA; `tools/wut-tools-tga-only.patch` (which also writes the TGA 2.0 footer the Wii U menu requires) shows
the small change made to wut-tools to build it without FreeImage. The official devkitPro package does not need it.

## Layout

```
src/                 front end (app, ui, video, audio, input, session, configuration, tests)
third_party/opera-libretro/   Opera core (libretro) with the big-endian patch in third_party/patches/
third_party/stb/     stb_truetype (fonts)
assets/              icon, splash screens, DejaVu Sans font
shaders/             the GLSL shaders, the .gsh CafeGLSL compiles and the generated C the RPX carries
tools/               asset and test-image generators, .wuhb package checker, PowerPC harness, wut-tools patch
mk/opera_core.mk     core source list and flags (shared by the Wii U and host builds)
Makefile             Wii U build (.wuhb)            Makefile.host   PC build (tests)
```

## Licenses

The Opera/FreeDO core is licensed under a **modified LGPL**: non-commercial use is allowed with full credits;
commercial use is forbidden without the owners' approval. This application is therefore free and **for
non-commercial use only**. The embedded Opera Boot is GPL-2.0. The front-end code is under the MIT license (see
`LICENSE`), but the distributed whole (the `.wuhb`) follows the core's conditions. Credits, notices and full texts:
[`NOTICE.md`](NOTICE.md) and the [`licenses/`](licenses/) folder. 3DO is a trademark of its respective owners; this
project is not affiliated with them.
