/*
 * Core diagnostic: the built-in self test, runnable on the console itself.
 *
 * It boots the built-in BIOS for CORETEST_REF_FRAMES frames, hashes every
 * picture and every audio sample, saves a state, replays 60 frames twice (a
 * state must replay bit-exactly) and times a speed pass. Then it runs fixed
 * workloads of the emulated hardware that games use and the BIOS does not
 * (ARM, DSP, cel engine, matrix engine, SPORT, video list processor, audio
 * FIFOs: src/deeptest.c) and compares each result with the x86 one, and plays
 * four scripts with the DSP inside the frame and on its own thread, which must
 * leave the same. The hashes only depend
 * on pixel / sample values, so they must equal the ones measured on a PC (x86);
 * if they do not, the big-endian PowerPC build of the core computes something
 * differently. The run happens on a worker thread so the UI (and ProcUI) stay
 * responsive, and in the core's "diagnostic mode" (default options, no input,
 * scratch save directory) so it never touches the user's saves or settings.
 */
#ifndef OPERAU_DIAG_H
#define OPERAU_DIAG_H

#include "common.h"
#include "coretest.h"
#include "deeptest.h"
#include "gpu.h"

#define DIAG_DEEP_MAX 13

/* One fixed hardware workload (CPU, DSP, cel engine, ...) and how it compared with the x86 reference. */
typedef struct {
    const char *name;
    uint64_t hash, expect;
    bool ran;                      /* the workload could run on the console */
    bool match;                    /* ran and equals the reference */
    double ms;                     /* how long it took here: the same work every time, so versions compare */
} diag_deep_t;

typedef struct {
    bool cancelled;                /* the user (or shutdown) stopped it */
    bool started;                  /* the core booted at all */
    bool matches;                  /* boot hashes equal the x86 reference */
    bool state_ok;                 /* save + load worked */
    bool deterministic;            /* replay after load was identical */
    bool deep_pass;                /* every hardware workload equals the x86 reference */
    bool pass;                     /* all of the above */
    int deep_n;
    diag_deep_t deep[DIAG_DEEP_MAX];
    double ms_per_frame;
    double realtime_x;             /* 1.0 = exactly as fast as a real 3DO */
    /*
     * The cel engine timed on sprites shaped like a game's (deeptest_celbench()): the one place where the cost of
     * a pixel on this console can be read off for a fixed picture, with and without the engine's table of
     * finished pixels.
     */
    bool bench_ran;
    bool bench_match;              /* the pictures equal the x86 ones, and are the same with the table off */
    uint64_t bench_hash;
    deeptest_celbench_row_t bench[DEEPTEST_CELBENCH_ROWS];
    /*
     * The DSP on a thread of its own against the DSP inside the frame (deeptest_dspthread_script()): the same
     * scripts of ticks and CPU writes played both ways, and whether they left the same sound and the same state -
     * measured here because it depends on this console's threads and on its processor, which no PC stands in for.
     * And what it costs the CPU to wait for that thread (deeptest_dspwait()).
     */
    bool dspthr_ran;               /* every script ran */
    bool dspthr_pass;              /* inside the frame they equal the x86 ones, and the thread gave the same */
    deeptest_dspthread_row_t dspthr[DEEPTEST_DSPTHREAD_SCRIPTS];
    deeptest_dspwait_t dspwait;
    gpu_probe_t gpu;               /* whether the GPU gets the pixel processor right, and what a hand-off costs */
    coretest_result_t r;
} diag_report_t;

/* Starts the test on a worker thread. False if one is already running or a
 * game / the BIOS is currently loaded. */
bool diag_start(void);
bool diag_running(void);
/* Frames done / frames in total of the running test (0, 0 before it starts). */
void diag_progress(int *done, int *total);
/* What the worker is doing right now, in the current language: the boot test or "test k of n: name". */
void diag_stage(char *out, size_t cap);
void diag_cancel(void);
/* True exactly once after the worker finished (and joins it). */
bool diag_poll(diag_report_t *out);

/* Text for the result box (current language). Returns true when it reports a
 * problem (shown as an error). */
bool diag_format(const diag_report_t *rep, char *out, size_t cap);
/* Writes the full, language independent report to <data dir>/diagnostic.txt
 * and to the log. Returns true if the file was written. */
bool diag_write_report(const diag_report_t *rep);

/* Wait for a running test to end (shutdown). */
void diag_shutdown(void);

#endif
