#include "ui_gfx.h"
#include "log.h"

#include <math.h>

#define STB_TRUETYPE_IMPLEMENTATION
#define STBTT_STATIC
#if defined(__GNUC__)
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wunused-function"
#endif
#include "stb_truetype.h"
#if defined(__GNUC__)
#pragma GCC diagnostic pop
#endif

extern const unsigned char operau_font_start[];
extern const unsigned char operau_font_end[];

#define ATLAS_W 1024
#define ATLAS_H 1024
#define HASH_SIZE 8192

typedef struct {
    uint32_t cp;
    uint16_t rpx;      /* raster pixel height; 0 = empty slot */
    uint16_t ax, ay;   /* position in the atlas */
    uint8_t w, h;
    int16_t ix0, iy0;  /* bitmap offset from the pen position / baseline */
} glyph_t;

static SDL_Renderer *g_r;
static float g_scale = 1.0f;

static stbtt_fontinfo g_font;
static int g_ascent, g_descent, g_linegap;  /* font units */

static SDL_Texture *g_atlas;
static glyph_t *g_hash;
static int g_hash_used;
static int g_pen_x, g_pen_y, g_row_h;

static SDL_Texture *g_corner;   /* 32x32 rounded corner source */
static SDL_Texture *g_vgrad;    /* 1x128 background gradient */
static SDL_Texture *g_glow;     /* radial falloff */
static SDL_Texture *g_disc;     /* conic disc */

#define COLOR_R(c) ((Uint8)((c) >> 24))
#define COLOR_G(c) ((Uint8)((c) >> 16))
#define COLOR_B(c) ((Uint8)((c) >> 8))
#define COLOR_A(c) ((Uint8)(c))

/* ---------------------------------------------------------- procedural art */

static SDL_Texture *make_texture(int w, int h, const uint32_t *argb)
{
    SDL_Texture *t = SDL_CreateTexture(g_r, SDL_PIXELFORMAT_ARGB8888, SDL_TEXTUREACCESS_STATIC, w, h);
    if (!t)
        return NULL;
    SDL_UpdateTexture(t, NULL, argb, w * 4);
    SDL_SetTextureBlendMode(t, SDL_BLENDMODE_BLEND);
    return t;
}

static float clampf(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }
static float smooth(float t) { t = clampf(t, 0, 1); return t * t * (3 - 2 * t); }

static SDL_Texture *build_corner(void)
{
    enum { N = 32, SS = 4 };
    uint32_t px[N * N];
    const float R = N / 2.0f;

    for (int y = 0; y < N; y++)
        for (int x = 0; x < N; x++) {
            int hit = 0;
            for (int sy = 0; sy < SS; sy++)
                for (int sx = 0; sx < SS; sx++) {
                    float fx = x + (sx + 0.5f) / SS - R, fy = y + (sy + 0.5f) / SS - R;
                    if (fx * fx + fy * fy <= R * R)
                        hit++;
                }
            uint32_t a = (uint32_t)(255.0f * hit / (SS * SS) + 0.5f);
            px[y * N + x] = (a << 24) | 0x00ffffffu;
        }
    return make_texture(N, N, px);
}

static SDL_Texture *build_vgrad(void)
{
    enum { N = 128 };
    uint32_t px[N];
    for (int y = 0; y < N; y++) {
        float t = y / (float)(N - 1);
        int r = (int)(COLOR_R(COL_BG_TOP) + (COLOR_R(COL_BG_BOTTOM) - COLOR_R(COL_BG_TOP)) * t);
        int g = (int)(COLOR_G(COL_BG_TOP) + (COLOR_G(COL_BG_BOTTOM) - COLOR_G(COL_BG_TOP)) * t);
        int b = (int)(COLOR_B(COL_BG_TOP) + (COLOR_B(COL_BG_BOTTOM) - COLOR_B(COL_BG_TOP)) * t);
        px[y] = 0xff000000u | (uint32_t)(r << 16) | (uint32_t)(g << 8) | (uint32_t)b;
    }
    return make_texture(1, N, px);
}

static SDL_Texture *build_glow(void)
{
    enum { N = 128 };
    static uint32_t px[N * N];
    for (int y = 0; y < N; y++)
        for (int x = 0; x < N; x++) {
            float dx = (x + 0.5f - N / 2.0f) / (N / 2.0f), dy = (y + 0.5f - N / 2.0f) / (N / 2.0f);
            float d = sqrtf(dx * dx + dy * dy);
            float a = clampf(1.0f - d, 0, 1);
            a = a * a * a;
            px[y * N + x] = ((uint32_t)(a * 255.0f) << 24) | 0x00ffffffu;
        }
    return make_texture(N, N, px);
}

static void lerp3(const uint8_t *a, const uint8_t *b, float t, float *o)
{
    for (int i = 0; i < 3; i++)
        o[i] = a[i] + (b[i] - a[i]) * t;
}

static SDL_Texture *build_disc(void)
{
    enum { N = 384 };
    static uint32_t px[N * N];
    static const struct { float ang; uint8_t c[3]; } stops[] = {
        {-135.0f, {0x2c, 0x4a, 0x9a}}, /* blue */
        {-45.0f, {0x2f, 0x6e, 0x78}},  /* teal */
        {45.0f, {0x58, 0x62, 0x70}},   /* slate */
        {135.0f, {0x4b, 0x2f, 0x86}},  /* violet */
        {225.0f, {0x2c, 0x4a, 0x9a}},  /* blue again (wrap) */
    };
    const float R = N / 2.0f - 1.0f;

    for (int y = 0; y < N; y++)
        for (int x = 0; x < N; x++) {
            float dx = x + 0.5f - N / 2.0f, dy = y + 0.5f - N / 2.0f;
            float r = sqrtf(dx * dx + dy * dy);
            float ang = atan2f(dy, dx) * 57.2957795f;
            float col[3], alpha;

            if (ang < -135.0f)
                ang += 360.0f;
            {
                int s = 0;
                while (s < 3 && ang > stops[s + 1].ang)
                    s++;
                lerp3(stops[s].c, stops[s + 1].c,
                      smooth((ang - stops[s].ang) / (stops[s + 1].ang - stops[s].ang)), col);
            }
            {
                float rim = (r / R);
                float k = 1.0f + 0.35f * rim * rim;
                for (int i = 0; i < 3; i++)
                    col[i] = clampf(col[i] * k, 0, 255);
            }
            alpha = clampf(R - r + 0.5f, 0, 1);
            if (r > R * 0.955f && r < R * 0.972f) { /* thin highlight ring */
                for (int i = 0; i < 3; i++)
                    col[i] = col[i] + (235.0f - col[i]) * 0.45f;
            }
            if (r < R * 0.17f + 0.5f) { /* spindle hole */
                float m = clampf(R * 0.17f + 0.5f - r, 0, 1);
                static const float dark[3] = {0x14, 0x17, 0x2a};
                for (int i = 0; i < 3; i++)
                    col[i] = col[i] + (dark[i] - col[i]) * m;
            }
            if (r < R * 0.095f + 0.5f) {
                float m = clampf(R * 0.095f + 0.5f - r, 0, 1);
                static const float light[3] = {0xd6, 0xdc, 0xea};
                for (int i = 0; i < 3; i++)
                    col[i] = col[i] + (light[i] - col[i]) * m;
            }
            px[y * N + x] = ((uint32_t)(alpha * 255.0f) << 24) | ((uint32_t)col[0] << 16) |
                            ((uint32_t)col[1] << 8) | (uint32_t)col[2];
        }
    return make_texture(N, N, px);
}

/* -------------------------------------------------------------------- init */

bool gfx_init(SDL_Renderer *r)
{
    size_t font_size = (size_t)(operau_font_end - operau_font_start);

    g_r = r;
    if (!stbtt_InitFont(&g_font, operau_font_start, stbtt_GetFontOffsetForIndex(operau_font_start, 0))) {
        LOGE("cannot parse the embedded font (%zu bytes)", font_size);
        return false;
    }
    stbtt_GetFontVMetrics(&g_font, &g_ascent, &g_descent, &g_linegap);

    SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, "1");
    g_atlas = SDL_CreateTexture(r, SDL_PIXELFORMAT_ARGB8888, SDL_TEXTUREACCESS_STATIC, ATLAS_W, ATLAS_H);
    if (!g_atlas) {
        LOGE("cannot create glyph atlas: %s", SDL_GetError());
        return false;
    }
    SDL_SetTextureBlendMode(g_atlas, SDL_BLENDMODE_BLEND);
    g_hash = (glyph_t *)calloc(HASH_SIZE, sizeof(glyph_t));
    if (!g_hash)
        return false;

    g_corner = build_corner();
    g_vgrad = build_vgrad();
    g_glow = build_glow();
    g_disc = build_disc();
    if (!g_corner || !g_vgrad || !g_glow || !g_disc) {
        LOGE("cannot build UI textures: %s", SDL_GetError());
        return false;
    }
    LOGI("ui: font %zu KB, atlas %dx%d", font_size / 1024, ATLAS_W, ATLAS_H);
    return true;
}

void gfx_shutdown(void)
{
    SDL_Texture **ts[] = {&g_atlas, &g_corner, &g_vgrad, &g_glow, &g_disc};
    for (size_t i = 0; i < ARRAY_LEN(ts); i++) {
        if (*ts[i])
            SDL_DestroyTexture(*ts[i]);
        *ts[i] = NULL;
    }
    free(g_hash);
    g_hash = NULL;
}

void gfx_frame_begin(void)
{
    int ow = 1280, oh = 720;
    SDL_GetRendererOutputSize(g_r, &ow, &oh);
    g_scale = fminf((float)ow / 1280.0f, (float)oh / 720.0f);
    if (g_scale < 0.5f || g_scale > 4.0f)
        g_scale = 1.0f;
}

/* ---------------------------------------------------------------- shapes */

static void set_color(uint32_t c)
{
    SDL_SetRenderDrawColor(g_r, COLOR_R(c), COLOR_G(c), COLOR_B(c), COLOR_A(c));
}

void gfx_fill(float x, float y, float w, float h, uint32_t c)
{
    SDL_FRect rc = {x, y, w, h};
    if (w <= 0 || h <= 0)
        return;
    set_color(c);
    SDL_RenderFillRectF(g_r, &rc);
}

void gfx_round_fill(float x, float y, float w, float h, float r, uint32_t c)
{
    const int Q = 16; /* quadrant size in the corner texture */
    float m = MIN(w, h) / 2.0f;
    SDL_Rect tl = {0, 0, Q, Q}, tr = {Q, 0, Q, Q}, bl = {0, Q, Q, Q}, br = {Q, Q, Q, Q};
    SDL_Rect top = {Q - 1, 0, 1, Q}, bot = {Q - 1, Q, 1, Q}, lef = {0, Q - 1, Q, 1}, rig = {Q, Q - 1, Q, 1};

    if (w <= 0 || h <= 0)
        return;
    if (r > m)
        r = m;
    if (r < 1.0f) {
        gfx_fill(x, y, w, h, c);
        return;
    }
    SDL_SetTextureColorMod(g_corner, COLOR_R(c), COLOR_G(c), COLOR_B(c));
    SDL_SetTextureAlphaMod(g_corner, COLOR_A(c));
#define PIECE(src, dx, dy, dw, dh) \
    do { SDL_FRect d_ = {(dx), (dy), (dw), (dh)}; SDL_RenderCopyF(g_r, g_corner, &(src), &d_); } while (0)
    PIECE(tl, x, y, r, r);
    PIECE(tr, x + w - r, y, r, r);
    PIECE(bl, x, y + h - r, r, r);
    PIECE(br, x + w - r, y + h - r, r, r);
    if (w > 2 * r) {
        PIECE(top, x + r, y, w - 2 * r, r);
        PIECE(bot, x + r, y + h - r, w - 2 * r, r);
    }
    if (h > 2 * r) {
        PIECE(lef, x, y + r, r, h - 2 * r);
        PIECE(rig, x + w - r, y + r, r, h - 2 * r);
    }
#undef PIECE
    if (w > 2 * r && h > 2 * r)
        gfx_fill(x + r, y + r, w - 2 * r, h - 2 * r, c);
}

void gfx_background(void)
{
    SDL_FRect all = {0, 0, 1280, 720};
    SDL_FRect glow = {140, -330, 1000, 760};
    SDL_FRect glow2 = {700, 260, 760, 560};

    SDL_SetTextureBlendMode(g_vgrad, SDL_BLENDMODE_NONE);
    SDL_RenderCopyF(g_r, g_vgrad, NULL, &all);
    SDL_SetTextureColorMod(g_glow, 0x4a, 0x62, 0xd8);
    SDL_SetTextureAlphaMod(g_glow, 120);
    SDL_RenderCopyF(g_r, g_glow, NULL, &glow);
    SDL_SetTextureColorMod(g_glow, 0x55, 0x2e, 0x9a);
    SDL_SetTextureAlphaMod(g_glow, 70);
    SDL_RenderCopyF(g_r, g_glow, NULL, &glow2);
    gfx_disc(1090, 640, 560, 26);
}

void gfx_disc(float cx, float cy, float d, uint8_t alpha)
{
    SDL_FRect dst = {cx - d / 2, cy - d / 2, d, d};
    SDL_SetTextureColorMod(g_disc, 255, 255, 255);
    SDL_SetTextureAlphaMod(g_disc, alpha);
    SDL_RenderCopyF(g_r, g_disc, NULL, &dst);
}

void gfx_triangle(float cx, float cy, float size, int dir, uint32_t c)
{
    int n = (int)(size * g_scale);
    if (n < 2)
        n = 2;
    for (int i = 0; i < n; i++) {
        float f = (float)(i + 0.5f) / (float)n;          /* 0 at the tip, 1 at the base */
        float half = f * size / 2.0f;
        float step = size / (float)n;
        switch (dir) {
        case DIR_UP:    gfx_fill(cx - half, cy - size / 2 + i * step, half * 2, step, c); break;
        case DIR_DOWN:  gfx_fill(cx - half, cy + size / 2 - (i + 1) * step, half * 2, step, c); break;
        case DIR_LEFT:  gfx_fill(cx - size / 2 + i * step, cy - half, step, half * 2, c); break;
        default:        gfx_fill(cx + size / 2 - (i + 1) * step, cy - half, step, half * 2, c); break;
        }
    }
}

void gfx_folder(float x, float y, float s, uint32_t c)
{
    gfx_round_fill(x, y + s * 0.12f, s * 0.42f, s * 0.3f, s * 0.1f, c);
    gfx_round_fill(x, y + s * 0.26f, s, s * 0.62f, s * 0.12f, c);
}

float gfx_badge(float x, float y, float h, const char *label, uint32_t fg, uint32_t bg)
{
    int fs = (int)(h * 0.62f);
    float tw = gfx_text_width(label, fs);
    float w = MAX(h, tw + h * 0.5f);
    gfx_round_fill(x, y, w, h, h / 2, bg);
    gfx_text(label, x + w / 2, y + (h - gfx_line_height(fs)) / 2, fs, fg, TXT_CENTER, 0);
    return w;
}

void gfx_clip(float x, float y, float w, float h)
{
    SDL_Rect r = {(int)floorf(x), (int)floorf(y), (int)ceilf(w), (int)ceilf(h)};
    SDL_RenderSetClipRect(g_r, &r);
}

void gfx_clip_off(void)
{
    SDL_RenderSetClipRect(g_r, NULL);
}

/* ------------------------------------------------------------------- text */

static uint32_t utf8_next(const char **p)
{
    const unsigned char *s = (const unsigned char *)*p;
    uint32_t cp;
    int extra;

    if (s[0] < 0x80)      { cp = s[0]; extra = 0; }
    else if (s[0] >= 0xF0) { cp = s[0] & 0x07; extra = 3; }
    else if (s[0] >= 0xE0) { cp = s[0] & 0x0F; extra = 2; }
    else if (s[0] >= 0xC0) { cp = s[0] & 0x1F; extra = 1; }
    else { *p += 1; return '?'; }
    s++;
    for (int i = 0; i < extra; i++) {
        if ((s[0] & 0xC0) != 0x80) {
            *p = (const char *)s;
            return '?';
        }
        cp = (cp << 6) | (s[0] & 0x3F);
        s++;
    }
    *p = (const char *)s;
    return cp;
}

static float font_scale_logical(int size)
{
    return stbtt_ScaleForPixelHeight(&g_font, (float)size);
}

float gfx_line_height(int size)
{
    return (float)(g_ascent - g_descent + g_linegap) * font_scale_logical(size);
}

static float advance(uint32_t cp, int size)
{
    int adv, lsb;
    stbtt_GetCodepointHMetrics(&g_font, (int)cp, &adv, &lsb);
    return (float)adv * font_scale_logical(size);
}

static float run_width(const char *s, size_t len, int size)
{
    const char *end = s + len;
    float w = 0;
    while (s < end && *s) {
        uint32_t cp = utf8_next(&s);
        w += advance(cp, size);
    }
    return w;
}

float gfx_text_width(const char *s, int size)
{
    return run_width(s, strlen(s), size);
}

static void atlas_reset(void)
{
    SDL_RenderFlush(g_r); /* queued draws still reference the old contents */
    memset(g_hash, 0, HASH_SIZE * sizeof(glyph_t));
    g_hash_used = 0;
    g_pen_x = g_pen_y = g_row_h = 0;
    LOGD("glyph atlas reset");
}

static glyph_t *glyph_get(uint32_t cp, int rpx)
{
    uint32_t h = (cp * 2654435761u) ^ ((uint32_t)rpx * 40503u);
    glyph_t *g;
    int ix0, iy0, ix1, iy1, w, hgt;
    float sc;
    static uint32_t buf[128 * 128];

    for (int probe = 0; probe < HASH_SIZE; probe++) {
        g = &g_hash[(h + (uint32_t)probe) & (HASH_SIZE - 1)];
        if (g->rpx == 0)
            break;
        if (g->cp == cp && g->rpx == rpx)
            return g;
    }
    if (g_hash_used > HASH_SIZE * 3 / 4)
        atlas_reset();
    /* find the free slot again (the table may have been cleared) */
    for (int probe = 0; probe < HASH_SIZE; probe++) {
        g = &g_hash[(h + (uint32_t)probe) & (HASH_SIZE - 1)];
        if (g->rpx == 0)
            break;
    }

    sc = stbtt_ScaleForPixelHeight(&g_font, (float)rpx);
    stbtt_GetCodepointBitmapBox(&g_font, (int)cp, sc, sc, &ix0, &iy0, &ix1, &iy1);
    w = ix1 - ix0;
    hgt = iy1 - iy0;
    if (w > 126 || hgt > 126 || w < 0 || hgt < 0) {
        w = hgt = 0;
    }
    g->cp = cp;
    g->rpx = (uint16_t)rpx;
    g->w = (uint8_t)w;
    g->h = (uint8_t)hgt;
    g->ix0 = (int16_t)ix0;
    g->iy0 = (int16_t)iy0;
    g_hash_used++;
    if (w == 0 || hgt == 0)
        return g;

    if (g_pen_x + w + 2 > ATLAS_W) {
        g_pen_x = 0;
        g_pen_y += g_row_h + 1;
        g_row_h = 0;
    }
    if (g_pen_y + hgt + 2 > ATLAS_H) {
        atlas_reset();
        return glyph_get(cp, rpx);
    }
    {
        static unsigned char cov[128 * 128];
        stbtt_MakeCodepointBitmap(&g_font, cov, w, hgt, w, sc, sc, (int)cp);
        for (int i = 0; i < w * hgt; i++)
            buf[i] = ((uint32_t)cov[i] << 24) | 0x00ffffffu;
        {
            SDL_Rect rc = {g_pen_x + 1, g_pen_y + 1, w, hgt};
            SDL_UpdateTexture(g_atlas, &rc, buf, w * 4);
            g->ax = (uint16_t)rc.x;
            g->ay = (uint16_t)rc.y;
        }
    }
    g_pen_x += w + 2;
    if (hgt + 2 > g_row_h)
        g_row_h = hgt + 2;
    return g;
}

static void draw_run(const char *s, size_t len, float x, float y, int size, uint32_t c)
{
    const char *end = s + len;
    int rpx = (int)lroundf((float)size * g_scale);
    float baseline = y + (float)g_ascent * font_scale_logical(size);
    float pen = x;

    if (rpx < 6)
        rpx = 6;
    SDL_SetTextureColorMod(g_atlas, COLOR_R(c), COLOR_G(c), COLOR_B(c));
    SDL_SetTextureAlphaMod(g_atlas, COLOR_A(c));
    while (s < end && *s) {
        uint32_t cp = utf8_next(&s);
        glyph_t *g = glyph_get(cp, rpx);
        if (g->w && g->h) {
            SDL_Rect src = {g->ax, g->ay, g->w, g->h};
            float dx = roundf(pen * g_scale) + (float)g->ix0;
            float dy = roundf(baseline * g_scale) + (float)g->iy0;
            SDL_FRect dst = {dx / g_scale, dy / g_scale, (float)g->w / g_scale, (float)g->h / g_scale};
            SDL_RenderCopyF(g_r, g_atlas, &src, &dst);
        }
        pen += advance(cp, size);
    }
}

float gfx_text(const char *s, float x, float y, int size, uint32_t c, int align, float max_w)
{
    size_t len = strlen(s);
    float w = run_width(s, len, size);
    bool cut = false;
    size_t cut_len = len;
    float ell_w = 0;

    if (max_w > 0 && w > max_w) {
        const char *p = s;
        float acc = 0;
        ell_w = advance(0x2026, size);
        cut = true;
        cut_len = 0;
        while (*p) {
            const char *q = p;
            uint32_t cp = utf8_next(&q);
            float a = advance(cp, size);
            if (acc + a + ell_w > max_w)
                break;
            acc += a;
            p = q;
        }
        cut_len = (size_t)(p - s);
        w = acc + ell_w;
    }
    if (align == TXT_CENTER)
        x -= w / 2;
    else if (align == TXT_RIGHT)
        x -= w;
    draw_run(s, cut_len, x, y, size, c);
    if (cut) {
        char ell[4] = {(char)0xE2, (char)0x80, (char)0xA6, 0};
        draw_run(ell, 3, x + w - ell_w, y, size, c);
    }
    return w;
}

float gfx_text_wrapped(const char *s, float x, float y, float w, int size, uint32_t c, int max_lines, bool draw)
{
    float lh = gfx_line_height(size);
    float space = advance(' ', size);
    int lines = 0;
    const char *p = s;

    while (*p) {
        /* one paragraph: up to '\n' */
        const char *para_end = strchr(p, '\n');
        const char *pe = para_end ? para_end : p + strlen(p);
        const char *line_start = p;
        float line_w = 0;
        const char *q = p;
        bool any = false;

        if (pe == p) { /* blank line */
            lines++;
            p = para_end ? para_end + 1 : pe;
            if (max_lines >= 0 && lines >= max_lines)
                break;
            continue;
        }
        while (q < pe) {
            const char *ws = q;
            const char *we;
            float ww;
            while (ws < pe && *ws == ' ')
                ws++;
            we = ws;
            while (we < pe && *we != ' ')
                we++;
            if (we == ws)
                break;
            ww = run_width(ws, (size_t)(we - ws), size);
            if (any && line_w + space + ww > w) {
                if (draw)
                    draw_run(line_start, (size_t)(q - line_start), x, y + lines * lh, size, c);
                lines++;
                if (max_lines >= 0 && lines >= max_lines)
                    return lines * lh;
                line_start = ws;
                line_w = ww;
            } else {
                line_w += (any ? space : 0) + ww;
                if (!any)
                    line_start = ws;
            }
            any = true;
            q = we;
        }
        if (any) {
            if (draw)
                draw_run(line_start, (size_t)(pe - line_start), x, y + lines * lh, size, c);
            lines++;
        }
        if (max_lines >= 0 && lines >= max_lines)
            break;
        p = para_end ? para_end + 1 : pe;
    }
    return lines * lh;
}
