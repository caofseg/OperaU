/*
  Optional timing hooks for the front end (Opera U).

  The core runs on a front end's emulation thread; to find out where the time of a frame goes (ARM, cel
  engine, DSP, video lines, timers, copies) the front end switches opera_prof_enabled on and reads and clears
  opera_prof between frames. While it is off a hook costs one load and one branch. Nothing here touches
  emulated state.

  Ticks are the processor's own time base (the PowerPC time base on the Wii U, the TSC on x86); the front end
  works out how many ticks make a second by comparing opera_prof_clock64() with its wall clock.

  Modified for Opera U; see third_party/patches/README.md.
*/

#ifndef LIBOPERA_PROF_H_INCLUDED
#define LIBOPERA_PROF_H_INCLUDED

#include "extern_c.h"
#include "inline.h"

#include <stdint.h>

EXTERN_C_BEGIN

typedef struct opera_prof_s opera_prof_t;
struct opera_prof_s
{
  /* ticks */
  uint64_t internal; /* opera_3do_internal_frame, DSP and VDL below included */
  uint64_t dsp;      /* DSP program runs (one per audio sample) */
  uint64_t vdl;      /* video line processing */
  uint64_t cel;      /* cel engine list drawing */
  uint64_t audio_up; /* handing the frame's audio to the front end */
  uint64_t video_cb; /* handing the frame's picture to the front end */
  /* calls and amounts */
  uint64_t internal_calls;
  uint64_t dsp_calls;
  uint64_t vdl_calls;
  uint64_t cel_calls;  /* cel lists drawn */
  uint64_t cel_cels;   /* cels in those lists */
  uint64_t cel_texels; /* source texels walked */
  uint64_t cel_pixels; /* pixels written */
  /*
    How the cels are set up, counted once for each cel (so it costs nothing per pixel). This says how much work
    the pixel processor has to do for every pixel of that cel, which is what decides whether specialising it
    would pay off: the BIOS draws almost no cels, so the only honest source for this is a real game.
  */
  uint64_t cel_useav;    /* CCB_USEAV: the AV signals come from PIXC instead of being zero */
  uint64_t cel_blackfix; /* CCB_NOBLK clear: every pixel is compared against black */
  uint64_t cel_twopixc;  /* the two halves of PIXC differ, so the cel can use either per pixel */
  uint64_t cel_s1;       /* colour 1 comes from the frame buffer, not from the source pixel */
  uint64_t cel_s2[4];    /* where colour 2 comes from */
  /*
    The cel reads the pixel already in the frame buffer, through either half of PIXC: colour 1 taken from there
    (s1), or colour 2 taken from there (s2 == 2). Counted on its own, with the pixels such cels drew, because it
    is the one property that decides what a pixel costs: a cel that cannot see the frame buffer has its finished
    pixels looked up, and one that can has every pixel mixed with what is there.
  */
  uint64_t cel_fbread;
  uint64_t cel_fbread_px;
  uint64_t cel_ms[4];    /* how colour 1 is scaled */
  uint64_t cel_bpp[8];   /* bits per pixel of the source (PRE0) */
  /*
    What the DSP actually runs, which the diagnostic's own battery cannot say: more than half of that battery's
    time is the test harness around it, and the mix of instructions it makes up is not a game's. These are
    counted in locals inside opera_dsp_loop() and added here once per run, so the loop itself stays tight.
  */
  uint64_t dsp_insts;     /* instructions executed */
  uint64_t dsp_ctrl;      /* of those, control instructions rather than ALU ones */
  uint64_t dsp_operands;  /* operands the ALU instructions asked to be loaded */
  uint64_t dsp_writeback; /* ALU instructions that wrote their result back */
  /*
    What became of the cels once the engine stopped running the whole pixel pipeline for each of them. A cel that
    cannot see the frame buffer has its finished pixels looked up by source value, unless it is a 16-bit picture
    with too many colours for that to pay; a cel that can see it is decoded per texel and mixed per pixel. And
    the pipeline itself still runs wherever no table stands in for it, which is the slow part that is left.
  */
  uint64_t cel_route[3]; /* cels by texel route: finished pixel looked up, worked out every time, decoded only */
  uint64_t pp_long;      /* runs of the pixel processor's whole pipeline */
  uint64_t pp2d_built;   /* tables for mixing with the frame buffer built (they are kept, so this should fall to 0) */
  uint64_t cel_type[3];  /* how the cel's data is stored: packed, LR form, literal */
  uint64_t cel_draw[3];  /* which texel path drew it: line, scaled, arbitrary */
  /*
    What a game can be kept waiting by inside the emulated machine, where the host being fast does not help. A
    game that shows fewer pictures than the machine shows fields, while the emulation itself keeps its 60 fields
    a second, is waiting for one of these: the cel engine, which stays busy for a time that depends on how much
    it drew; the disc, which hands sectors over at the speed of a drive; or its own processor.
  */
  uint64_t cel_busy;     /* emulated CPU cycles during which the cel engine said it was busy */
  uint64_t vdl_flips;    /* fields that showed another frame buffer than the field before: pictures presented */
  /* reading sectors from the disc image: how long (ticks), how many, and the longest single read (ticks) */
  uint64_t cd;
  uint64_t cd_calls;
  uint64_t cd_max;
  uint64_t frames;
};

extern int          opera_prof_enabled;
extern opera_prof_t opera_prof;

#if defined(__powerpc__) || defined(__PPC__)

static OPERA_FORCEINLINE uint32_t opera_prof_now(void)
{
  uint32_t t;

  __asm__ volatile("mftb %0" : "=r"(t));
  return t;
}

static INLINE uint64_t opera_prof_clock64(void)
{
  uint32_t hi, lo, hi2;

  do
    {
      __asm__ volatile("mftbu %0" : "=r"(hi));
      __asm__ volatile("mftb %0" : "=r"(lo));
      __asm__ volatile("mftbu %0" : "=r"(hi2));
    }
  while(hi != hi2);

  return (((uint64_t)hi << 32) | lo);
}

#elif defined(__x86_64__) || defined(__i386__)

static OPERA_FORCEINLINE uint32_t opera_prof_now(void)
{
  uint32_t lo, hi;

  __asm__ volatile("rdtsc" : "=a"(lo), "=d"(hi));
  (void)hi;
  return lo;
}

static INLINE uint64_t opera_prof_clock64(void)
{
  uint32_t lo, hi;

  __asm__ volatile("rdtsc" : "=a"(lo), "=d"(hi));
  return (((uint64_t)hi << 32) | lo);
}

#else

static INLINE uint32_t opera_prof_now(void)     { return 0; }
static INLINE uint64_t opera_prof_clock64(void) { return 0; }

#endif

/* Times a stretch of code into opera_prof.<ticks> and counts it in opera_prof.<calls>. */
#define OPERA_PROF_BEGIN(v) \
  const uint32_t v = opera_prof_enabled ? opera_prof_now() : 0

#define OPERA_PROF_END(v,ticks,calls)                             \
  do                                                              \
    {                                                             \
      if(opera_prof_enabled)                                      \
        {                                                         \
          opera_prof.ticks += (uint32_t)(opera_prof_now() - (v)); \
          opera_prof.calls++;                                     \
        }                                                         \
    }                                                             \
  while(0)

EXTERN_C_END

#endif /* LIBOPERA_PROF_H_INCLUDED */
