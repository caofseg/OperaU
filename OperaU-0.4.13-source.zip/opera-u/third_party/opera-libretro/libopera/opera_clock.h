#ifndef LIBOPERA_CLOCK_H_INCLUDED
#define LIBOPERA_CLOCK_H_INCLUDED

#include "extern_c.h"

#include <stdint.h>

EXTERN_C_BEGIN

/*
  Pacing of the CLIO timers: the CLIO scans its 16 timer slots one after the
  other (SLOT cycles apart) and waits GAP cycles after the last one. All
  times are CPU cycles in 16.16 fixed point. The clock owns this state and
  the CLIO walks it (opera_clio_timers_run), which saves a function call
  for each of the ~100000 slot events a second.
  (Local modification for OperaU, see third_party/patches/.)
*/
typedef struct opera_clock_timers_s opera_clock_timers_t;
struct opera_clock_timers_s
{
  int32_t  acc;          /* time pushed and not yet consumed */
  int32_t  until;        /* time until the slot below comes due */
  int32_t  slot_cycles;  /* time between two slots */
  int32_t  gap_cycles;   /* time between the last slot and the first */
  uint32_t slot;         /* the slot that comes due next, 0..15 */
  uint32_t in_gap;       /* waiting out the gap before slot 0 */
};

opera_clock_timers_t *opera_clock_timers(void);

int      opera_clock_vdl_queued(void);
int      opera_clock_dsp_queued(void);
int      opera_clock_timer_queued(uint32_t *timer);

void     opera_clock_reset(void);
void     opera_clock_push_cycles(const uint32_t clks);

void     opera_clock_cpu_set_freq(const uint32_t freq);
void     opera_clock_cpu_set_freq_mul(const float mul);
uint32_t opera_clock_cpu_get_freq(void);
uint32_t opera_clock_cpu_get_default_freq(void);
uint64_t opera_clock_cpu_get_cycles(void);
uint64_t opera_clock_cpu_cycles_per_field(void);
double   opera_clock_field_rate(void);

void     opera_clock_region_set_ntsc(void);
void     opera_clock_region_set_pal(void);

void     opera_clock_timer_set_delay(const uint32_t td);

uint32_t opera_clock_state_size(void);
uint32_t opera_clock_state_save(void *buf);
uint32_t opera_clock_state_load(const void *buf, uint32_t size);

EXTERN_C_END

#endif /* LIBOPERA_CLOCK_H_INCLUDED */
