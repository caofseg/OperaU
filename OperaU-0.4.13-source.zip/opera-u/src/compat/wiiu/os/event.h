/* Compatibility shim: libretro-common was written against the older "wiiu/os"
 * SDK layout; wut ships the same API under <coreinit/...>. */
#ifndef OPERAU_COMPAT_WIIU_OS_EVENT_H
#define OPERAU_COMPAT_WIIU_OS_EVENT_H
#include <coreinit/event.h>
#endif
