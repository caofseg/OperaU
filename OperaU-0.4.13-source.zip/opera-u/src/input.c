/*
 * Input: SDL game controllers (GamePad, Pro Controller, Wii Remote + extensions
 * on the Wii U), touch screen, keyboard fallback (host builds / USB keyboards).
 *
 * Everything is polled once per main-loop iteration (input_update). The result
 * for the emulation thread is published as one atomic 32-bit RetroPad mask per
 * port, so the emu thread never takes a lock.
 */
#include "input.h"
#include "log.h"
#include "platform.h"

#define NAV_QUEUE 32
#define NAV_REPEAT_DELAY_MS 380
#define NAV_REPEAT_RATE_MS 85

/* RetroPad bit positions (libretro.h RETRO_DEVICE_ID_JOYPAD_*) */
enum {
    RP_B = 0, RP_Y, RP_SELECT, RP_START, RP_UP, RP_DOWN, RP_LEFT, RP_RIGHT,
    RP_A, RP_X, RP_L, RP_R, RP_L2, RP_R2, RP_L3, RP_R3
};

/* How each 3DO button is presented to the core. The Opera core reads
 *   A <- RP_Y, B <- RP_B, C <- RP_A, L <- RP_L, R <- RP_R,
 *   X <- RP_SELECT, P <- RP_START (or RP_X). */
static const int k_retro_bit[B3DO_COUNT] = {
    [B3DO_UP] = RP_UP, [B3DO_DOWN] = RP_DOWN, [B3DO_LEFT] = RP_LEFT, [B3DO_RIGHT] = RP_RIGHT,
    [B3DO_A] = RP_Y, [B3DO_B] = RP_B, [B3DO_C] = RP_A,
    [B3DO_L] = RP_L, [B3DO_R] = RP_R, [B3DO_X] = RP_SELECT, [B3DO_P] = RP_START,
};

typedef struct {
    SDL_GameController *gc;
    SDL_JoystickID id;
    char name[64];
    int port;
    uint32_t held;      /* bit n = SDL button n, bit 29 = second stick pushed right, bit 30 = ZL, bit 31 = ZR */
    uint32_t prev;
    int16_t lx, ly;
    bool ff_stick;      /* second stick state with hysteresis */
} pad_t;

#define HELD_FFSTICK INPUT_HELD_FFSTICK /* virtual bit: second (right) stick pushed right = fast-forward */
#define HELD_LTRIG (1u << 30)
#define HELD_RTRIG (1u << 31)

/* How far the second stick must go (of 32767) to start / keep fast-forwarding. */
#define FF_STICK_ON 18000
#define FF_STICK_OFF 12000

_Static_assert(SDL_CONTROLLER_BUTTON_MAX <= 29, "SDL button bits would collide with the virtual bits");

static pad_t g_pads[MAX_PADS];
static pad_info_t g_info[MAX_PADS];
static int g_npads;

static uint32_t g_port_state[MAX_PADS];  /* atomics */
static uint32_t g_hotkeys;               /* atomic */
static uint32_t g_ff;                    /* atomic */

static bool g_game_active;
static bool g_swallow;
static bool g_mask_block_arm;            /* capture held buttons on the next update */
static uint32_t g_mask_block[MAX_PADS];  /* buttons ignored until released */
static int g_logical_w = 1280, g_logical_h = 720;

/* navigation */
static nav_action_t g_navq[NAV_QUEUE];
static int g_navq_head, g_navq_tail;
static uint64_t g_nav_since[NAV_PAGE_DOWN + 2];
static uint64_t g_nav_last[NAV_PAGE_DOWN + 2];
static bool g_nav_held[NAV_MENU + 1];
static bool g_nav_blocked[NAV_MENU + 1];

/* pointer */
static pointer_t g_ptr;
static pointer_t g_ptr_pending;
static bool g_ptr_pressed_acc, g_ptr_released_acc;
static float g_ptr_dx_acc, g_ptr_dy_acc;

/* capture */
static bool g_cap_active;
static bool g_cap_done;
static int g_cap_code = PBTN_NONE;

/* ------------------------------------------------------------------ names */

const char *input_button_name(int code)
{
    static const char *const names[] = {
        "A", "B", "X", "Y", "-", "HOME", "+", "L3", "R3", "L", "R",
        "Up", "Down", "Left", "Right", "Misc", "P1", "P2", "P3", "P4", "Touch",
    };
    if (code == PBTN_LTRIG)
        return "ZL";
    if (code == PBTN_RTRIG)
        return "ZR";
    if (code >= 0 && code < (int)ARRAY_LEN(names))
        return names[code];
    return "--";
}

const char *input_3do_name(int b)
{
    static const char *const names[B3DO_COUNT] = {
        "Up", "Down", "Left", "Right", "A", "B", "C", "L", "R", "X", "P",
    };
    return (b >= 0 && b < B3DO_COUNT) ? names[b] : "?";
}

void input_default_map(int map[B3DO_COUNT])
{
    /* SDL names follow the Nintendo labels on the Wii U, so SDL "A" is the right-hand face button.
     * The layout asked for by the person this was built for: the 3DO's three action buttons sit where the thumb
     * already is (A and B on the Wii U's B and A, C on ZL), the 3DO's shoulder buttons move to the face buttons
     * (L on Y) and to ZR (R), and the two system buttons take X and +. That leaves the Wii U's own L and R
     * shoulders free, which is what the L + R menu shortcut needs. */
    map[B3DO_UP] = SDL_CONTROLLER_BUTTON_DPAD_UP;
    map[B3DO_DOWN] = SDL_CONTROLLER_BUTTON_DPAD_DOWN;
    map[B3DO_LEFT] = SDL_CONTROLLER_BUTTON_DPAD_LEFT;
    map[B3DO_RIGHT] = SDL_CONTROLLER_BUTTON_DPAD_RIGHT;
    map[B3DO_A] = SDL_CONTROLLER_BUTTON_B;
    map[B3DO_B] = SDL_CONTROLLER_BUTTON_A;
    map[B3DO_C] = PBTN_LTRIG;  /* ZL */
    map[B3DO_L] = SDL_CONTROLLER_BUTTON_Y;
    map[B3DO_R] = PBTN_RTRIG;  /* ZR */
    map[B3DO_P] = SDL_CONTROLLER_BUTTON_X;
    map[B3DO_X] = SDL_CONTROLLER_BUTTON_START; /* + */
}

/* ------------------------------------------------------------- pad slots */

static void rebuild_info(void)
{
    int n = 0;
    memset(g_info, 0, sizeof(g_info));
    for (int i = 0; i < MAX_PADS; i++) {
        if (!g_pads[i].gc)
            continue;
        g_info[n].connected = true;
        str_copy(g_info[n].name, g_pads[i].name, sizeof(g_info[n].name));
        g_info[n].port = g_pads[i].port;
        n++;
    }
    g_npads = n;
}

static bool port_in_use(int port)
{
    for (int i = 0; i < MAX_PADS; i++)
        if (g_pads[i].gc && g_pads[i].port == port)
            return true;
    return false;
}

static void pad_add(int device_index)
{
    SDL_GameController *gc;
    SDL_JoystickID id;
    int slot = -1;

    if (!SDL_IsGameController(device_index))
        return;
    id = SDL_JoystickGetDeviceInstanceID(device_index);
    for (int i = 0; i < MAX_PADS; i++)
        if (g_pads[i].gc && g_pads[i].id == id)
            return; /* already open */
    for (int i = 0; i < MAX_PADS; i++)
        if (!g_pads[i].gc) {
            slot = i;
            break;
        }
    if (slot < 0)
        return;
    gc = SDL_GameControllerOpen(device_index);
    if (!gc) {
        LOGW("cannot open controller %d: %s", device_index, SDL_GetError());
        return;
    }
    memset(&g_pads[slot], 0, sizeof(g_pads[slot]));
    g_pads[slot].gc = gc;
    g_pads[slot].id = id;
    str_copy(g_pads[slot].name, SDL_GameControllerName(gc) ? SDL_GameControllerName(gc) : "Controller",
             sizeof(g_pads[slot].name));
    g_pads[slot].port = -1;
    for (int p = 0; p < MAX_PADS; p++)
        if (!port_in_use(p)) {
            g_pads[slot].port = p;
            break;
        }
    LOGI("controller connected: %s (port %d)", g_pads[slot].name, g_pads[slot].port);
    rebuild_info();
}

static void pad_remove(SDL_JoystickID id)
{
    for (int i = 0; i < MAX_PADS; i++) {
        if (g_pads[i].gc && g_pads[i].id == id) {
            LOGI("controller removed: %s", g_pads[i].name);
            SDL_GameControllerClose(g_pads[i].gc);
            memset(&g_pads[i], 0, sizeof(g_pads[i]));
        }
    }
    rebuild_info();
}

void input_swap_ports(int a, int b)
{
    int ia = -1, ib = -1;

    if (a < 0 || b < 0 || a >= MAX_PADS || b >= MAX_PADS || a == b)
        return;
    for (int i = 0; i < MAX_PADS; i++) {
        if (!g_pads[i].gc)
            continue;
        if (g_pads[i].port == a)
            ia = i;
        if (g_pads[i].port == b)
            ib = i;
    }
    if (ia >= 0)
        g_pads[ia].port = b;
    if (ib >= 0)
        g_pads[ib].port = a;
    rebuild_info();
}

int input_pad_count(void) { return g_npads; }
int input_connected_count(void) { return g_npads; }

const pad_info_t *input_pad_info(int idx)
{
    return (idx >= 0 && idx < g_npads) ? &g_info[idx] : NULL;
}

/* ------------------------------------------------------------------ init */

void input_init(void)
{
    SDL_InitSubSystem(SDL_INIT_GAMECONTROLLER);
    SDL_GameControllerEventState(SDL_ENABLE);
    for (int i = 0; i < SDL_NumJoysticks(); i++)
        pad_add(i);
    g_ptr.x = g_logical_w / 2.0f;
    g_ptr.y = g_logical_h / 2.0f;
    g_swallow = true;
}

void input_shutdown(void)
{
    for (int i = 0; i < MAX_PADS; i++)
        if (g_pads[i].gc)
            SDL_GameControllerClose(g_pads[i].gc);
    memset(g_pads, 0, sizeof(g_pads));
    rebuild_info();
}

void input_set_logical_size(int w, int h)
{
    if (w > 0 && h > 0) {
        g_logical_w = w;
        g_logical_h = h;
    }
}

/* ----------------------------------------------------------------- events */

static void nav_push(nav_action_t a)
{
    int next = (g_navq_head + 1) % NAV_QUEUE;
    if (next == g_navq_tail)
        return; /* full: drop */
    g_navq[g_navq_head] = a;
    g_navq_head = next;
}

void input_debug_nav(nav_action_t a)
{
    nav_push(a);
}

static void pointer_from_norm(float nx, float ny)
{
    g_ptr_pending.x = CLAMP(nx, 0.0f, 1.0f) * (float)g_logical_w;
    g_ptr_pending.y = CLAMP(ny, 0.0f, 1.0f) * (float)g_logical_h;
}

static void pointer_from_window(const SDL_Event *ev, int x, int y)
{
    int w = 1, h = 1;
    SDL_Window *win = SDL_GetWindowFromID(ev->window.windowID);
    if (win)
        SDL_GetWindowSize(win, &w, &h);
    if (w < 1)
        w = 1;
    if (h < 1)
        h = 1;
    pointer_from_norm((float)x / (float)w, (float)y / (float)h);
}

bool input_handle_event(const SDL_Event *ev)
{
    switch (ev->type) {
    case SDL_CONTROLLERDEVICEADDED:
        pad_add(ev->cdevice.which);
        return true;
    case SDL_CONTROLLERDEVICEREMOVED:
        pad_remove(ev->cdevice.which);
        return true;

    case SDL_FINGERDOWN: {
        float ox = g_ptr_pending.x, oy = g_ptr_pending.y;
        pointer_from_norm(ev->tfinger.x, ev->tfinger.y);
        g_ptr_pending.valid = true;
        g_ptr_pending.down = true;
        g_ptr_pressed_acc = true;
        (void)ox;
        (void)oy;
        return true;
    }
    case SDL_FINGERMOTION: {
        float ox = g_ptr_pending.x, oy = g_ptr_pending.y;
        pointer_from_norm(ev->tfinger.x, ev->tfinger.y);
        g_ptr_dx_acc += g_ptr_pending.x - ox;
        g_ptr_dy_acc += g_ptr_pending.y - oy;
        return true;
    }
    case SDL_FINGERUP:
        pointer_from_norm(ev->tfinger.x, ev->tfinger.y);
        g_ptr_pending.down = false;
        g_ptr_released_acc = true;
        return true;

    /* mouse (host builds); synthesized touch-mouse events are ignored */
    case SDL_MOUSEBUTTONDOWN:
        if (ev->button.which == SDL_TOUCH_MOUSEID || ev->button.button != SDL_BUTTON_LEFT)
            return false;
        pointer_from_window(ev, ev->button.x, ev->button.y);
        g_ptr_pending.valid = true;
        g_ptr_pending.down = true;
        g_ptr_pressed_acc = true;
        return true;
    case SDL_MOUSEBUTTONUP:
        if (ev->button.which == SDL_TOUCH_MOUSEID || ev->button.button != SDL_BUTTON_LEFT)
            return false;
        pointer_from_window(ev, ev->button.x, ev->button.y);
        g_ptr_pending.down = false;
        g_ptr_released_acc = true;
        return true;
    case SDL_MOUSEMOTION:
        if (ev->motion.which == SDL_TOUCH_MOUSEID)
            return false;
        {
            float ox = g_ptr_pending.x, oy = g_ptr_pending.y;
            pointer_from_window(ev, ev->motion.x, ev->motion.y);
            g_ptr_pending.valid = true;
            g_ptr_dx_acc += g_ptr_pending.x - ox;
            g_ptr_dy_acc += g_ptr_pending.y - oy;
        }
        return true;
    case SDL_MOUSEWHEEL:
        if (!g_game_active) {
            if (ev->wheel.y > 0)
                nav_push(NAV_UP);
            else if (ev->wheel.y < 0)
                nav_push(NAV_DOWN);
        }
        return true;
    default:
        return false;
    }
}

/* ----------------------------------------------------------------- polling */

static uint32_t poll_pad(pad_t *p)
{
    uint32_t held = 0;
    int16_t lt, rt, rx;

    for (int b = 0; b < PBTN_COUNT_SDL && b < 29; b++)
        if (SDL_GameControllerGetButton(p->gc, (SDL_GameControllerButton)b))
            held |= 1u << b;
    lt = SDL_GameControllerGetAxis(p->gc, SDL_CONTROLLER_AXIS_TRIGGERLEFT);
    rt = SDL_GameControllerGetAxis(p->gc, SDL_CONTROLLER_AXIS_TRIGGERRIGHT);
    if (lt > 12000)
        held |= HELD_LTRIG;
    if (rt > 12000)
        held |= HELD_RTRIG;
    /* fast-forward: the second stick pushed to the right (ZL/ZR stay free for the game) */
    rx = SDL_GameControllerGetAxis(p->gc, SDL_CONTROLLER_AXIS_RIGHTX);
    p->ff_stick = rx > (p->ff_stick ? FF_STICK_OFF : FF_STICK_ON);
    if (p->ff_stick)
        held |= HELD_FFSTICK;
    p->lx = SDL_GameControllerGetAxis(p->gc, SDL_CONTROLLER_AXIS_LEFTX);
    p->ly = SDL_GameControllerGetAxis(p->gc, SDL_CONTROLLER_AXIS_LEFTY);
    return held;
}

static bool code_held(uint32_t held, int code)
{
    if (code == PBTN_LTRIG)
        return (held & HELD_LTRIG) != 0;
    if (code == PBTN_RTRIG)
        return (held & HELD_RTRIG) != 0;
    if (code >= 0 && code < 29)
        return (held >> code) & 1u;
    return false;
}

#define BTN(b) (1u << (b))

/* Left stick as digital directions: u, d, l, r in bits 0..3 */
static unsigned stick_dirs(const pad_t *p)
{
    int thr_pct = CLAMP(g_cfg.deadzone + 10, 20, 90);
    int thr = 32767 * thr_pct / 100;
    unsigned d = 0;
    if (p->ly < -thr) d |= 1;
    if (p->ly > thr) d |= 2;
    if (p->lx < -thr) d |= 4;
    if (p->lx > thr) d |= 8;
    return d;
}

static uint32_t build_port_mask(uint32_t held, unsigned sdirs)
{
    uint32_t m = 0;
    for (int b = 0; b < B3DO_COUNT; b++)
        if (code_held(held, g_cfg.button_map[b]))
            m |= 1u << k_retro_bit[b];
    /* the left stick always doubles as D-pad */
    if (sdirs & 1) m |= 1u << RP_UP;
    if (sdirs & 2) m |= 1u << RP_DOWN;
    if (sdirs & 4) m |= 1u << RP_LEFT;
    if (sdirs & 8) m |= 1u << RP_RIGHT;
    /* opposing directions cancel (the 3DO pad cannot report both) */
    if ((m & (1u << RP_UP)) && (m & (1u << RP_DOWN)))
        m &= ~((1u << RP_UP) | (1u << RP_DOWN));
    if ((m & (1u << RP_LEFT)) && (m & (1u << RP_RIGHT)))
        m &= ~((1u << RP_LEFT) | (1u << RP_RIGHT));
    return m;
}

static uint32_t keyboard_mask(const Uint8 *ks)
{
    uint32_t m = 0;
    if (ks[SDL_SCANCODE_UP]) m |= 1u << RP_UP;
    if (ks[SDL_SCANCODE_DOWN]) m |= 1u << RP_DOWN;
    if (ks[SDL_SCANCODE_LEFT]) m |= 1u << RP_LEFT;
    if (ks[SDL_SCANCODE_RIGHT]) m |= 1u << RP_RIGHT;
    if (ks[SDL_SCANCODE_A]) m |= 1u << RP_Y;       /* 3DO A */
    if (ks[SDL_SCANCODE_Z]) m |= 1u << RP_B;       /* 3DO B */
    if (ks[SDL_SCANCODE_X]) m |= 1u << RP_A;       /* 3DO C */
    if (ks[SDL_SCANCODE_Q]) m |= 1u << RP_L;
    if (ks[SDL_SCANCODE_W]) m |= 1u << RP_R;
    if (ks[SDL_SCANCODE_S]) m |= 1u << RP_SELECT;  /* 3DO X (stop) */
    if (ks[SDL_SCANCODE_RETURN]) m |= 1u << RP_START; /* 3DO P (play) */
    return m;
}

static void nav_update(uint64_t now_us, const bool want[NAV_MENU + 1])
{
    uint64_t now_ms = now_us / 1000;

    for (int a = NAV_UP; a <= NAV_MENU; a++) {
        bool held = want[a];
        bool repeats = (a >= NAV_UP && a <= NAV_RIGHT) || a == NAV_PAGE_UP || a == NAV_PAGE_DOWN;

        if (!held) {
            g_nav_held[a] = false;
            g_nav_blocked[a] = false;
            continue;
        }
        if (g_nav_blocked[a])
            continue;
        if (!g_nav_held[a]) {
            g_nav_held[a] = true;
            g_nav_since[a] = now_ms;
            g_nav_last[a] = now_ms;
            nav_push((nav_action_t)a);
        } else if (repeats && now_ms - g_nav_since[a] >= NAV_REPEAT_DELAY_MS &&
                   now_ms - g_nav_last[a] >= NAV_REPEAT_RATE_MS) {
            g_nav_last[a] = now_ms;
            nav_push((nav_action_t)a);
        }
    }
}

/* Hotkeys raised by one pad and whether it asks for fast-forward, from the
 * held masks of the previous and the current poll. Kept free of any state so
 * the self test can check every combination.
 *
 *   L + R pressed together ........ open / close the menu (if lr_menu)
 *   second stick pushed right ..... fast-forward while held
 *   - (minus) held + other button . +: menu, R: save state, L: load state,
 *                                   A: screenshot, Y: reset, D-pad left/right:
 *                                   slot, X (held): fast-forward as well
 *
 * ZL and ZR are never used here: they are game buttons (3DO C and R), and HOME is never used either: it belongs to
 * the console,
 * which opens its own menu with it. The app's menu is L + R (or - and + together when that shortcut is turned off). */
unsigned input_pad_hotkeys(uint32_t prev, uint32_t held, bool lr_menu, bool *ff)
{
    const uint32_t lr = BTN(SDL_CONTROLLER_BUTTON_LEFTSHOULDER) | BTN(SDL_CONTROLLER_BUTTON_RIGHTSHOULDER);
    uint32_t edge = held & ~prev;
    unsigned hk = 0;

    if (held & BTN(SDL_CONTROLLER_BUTTON_BACK)) {
        if (edge & BTN(SDL_CONTROLLER_BUTTON_START)) hk |= HK_MENU;
        if (edge & BTN(SDL_CONTROLLER_BUTTON_RIGHTSHOULDER)) hk |= HK_SAVE_STATE;
        if (edge & BTN(SDL_CONTROLLER_BUTTON_LEFTSHOULDER)) hk |= HK_LOAD_STATE;
        if (edge & BTN(SDL_CONTROLLER_BUTTON_A)) hk |= HK_SCREENSHOT;
        if (edge & BTN(SDL_CONTROLLER_BUTTON_Y)) hk |= HK_RESET;
        if (edge & BTN(SDL_CONTROLLER_BUTTON_DPAD_RIGHT)) hk |= HK_SLOT_NEXT;
        if (edge & BTN(SDL_CONTROLLER_BUTTON_DPAD_LEFT)) hk |= HK_SLOT_PREV;
        if ((held & BTN(SDL_CONTROLLER_BUTTON_X)) && ff)
            *ff = true;
    } else if (lr_menu && (held & lr) == lr && (prev & lr) != lr) {
        hk |= HK_MENU; /* the moment the second shoulder button goes down */
    }
    if ((held & HELD_FFSTICK) && ff)
        *ff = true;
    return hk;
}

void input_update(void)
{
    const Uint8 *ks = SDL_GetKeyboardState(NULL);
    uint64_t now = platform_time_us();
    uint32_t masks[MAX_PADS] = {0};
    bool want[NAV_MENU + 1] = {0};
    unsigned hk = 0;
    bool ff = false;

    /* pointer: publish edges collected from events */
    g_ptr.valid = g_ptr_pending.valid;
    g_ptr.x = g_ptr_pending.x;
    g_ptr.y = g_ptr_pending.y;
    g_ptr.down = g_ptr_pending.down;
    g_ptr.pressed = g_ptr_pressed_acc;
    g_ptr.released = g_ptr_released_acc;
    g_ptr.dx = g_ptr_dx_acc;
    g_ptr.dy = g_ptr_dy_acc;
    g_ptr_pressed_acc = g_ptr_released_acc = false;
    g_ptr_dx_acc = g_ptr_dy_acc = 0.0f;

    for (int i = 0; i < MAX_PADS; i++) {
        pad_t *p = &g_pads[i];
        uint32_t held, edge;
        unsigned sdirs;
        bool mod;

        if (!p->gc)
            continue;
        p->prev = p->held;
        p->held = held = poll_pad(p);
        edge = held & ~p->prev;
        sdirs = stick_dirs(p);
        mod = (held & BTN(SDL_CONTROLLER_BUTTON_BACK)) != 0;

        /* remapping capture: first new physical press wins */
        if (g_cap_active && !g_cap_done && edge) {
            for (int c = 0; c < 32; c++) {
                if (c == 29 || !(edge & (1u << c))) /* 29: virtual fast-forward stick, not a button */
                    continue;
                g_cap_code = (c == 30) ? PBTN_LTRIG : (c == 31) ? PBTN_RTRIG : c;
                g_cap_done = true;
                break;
            }
        }

        /* hotkeys (see input_pad_hotkeys) */
        hk |= input_pad_hotkeys(p->prev, held, g_cfg.menu_lr, &ff);

        /* game state for this pad's port (zeroed while a hotkey modifier is
         * held so the combination never leaks into the game) */
        if (p->port >= 0 && p->port < MAX_PADS && g_game_active && !mod)
            masks[p->port] |= build_port_mask(held, sdirs);

        /* menu navigation */
        want[NAV_UP] |= (held & BTN(SDL_CONTROLLER_BUTTON_DPAD_UP)) || (sdirs & 1);
        want[NAV_DOWN] |= (held & BTN(SDL_CONTROLLER_BUTTON_DPAD_DOWN)) || (sdirs & 2);
        want[NAV_LEFT] |= (held & BTN(SDL_CONTROLLER_BUTTON_DPAD_LEFT)) || (sdirs & 4);
        want[NAV_RIGHT] |= (held & BTN(SDL_CONTROLLER_BUTTON_DPAD_RIGHT)) || (sdirs & 8);
        want[NAV_ACCEPT] |= (held & BTN(SDL_CONTROLLER_BUTTON_A)) != 0;
        want[NAV_BACK] |= (held & BTN(SDL_CONTROLLER_BUTTON_B)) != 0;
        want[NAV_X] |= (held & BTN(SDL_CONTROLLER_BUTTON_X)) != 0;
        want[NAV_Y] |= (held & BTN(SDL_CONTROLLER_BUTTON_Y)) != 0;
        want[NAV_PAGE_UP] |= (held & (BTN(SDL_CONTROLLER_BUTTON_LEFTSHOULDER) | HELD_LTRIG)) != 0;
        want[NAV_PAGE_DOWN] |= (held & (BTN(SDL_CONTROLLER_BUTTON_RIGHTSHOULDER) | HELD_RTRIG)) != 0;
        want[NAV_MENU] |= (held & BTN(SDL_CONTROLLER_BUTTON_START)) != 0;
    }

    /* keyboard (always on; drives port 0 together with a pad) */
    if (g_game_active)
        masks[0] |= keyboard_mask(ks);
    {
        static bool f_prev[8];
        bool f_now[8] = {
            ks[SDL_SCANCODE_F1], ks[SDL_SCANCODE_F5], ks[SDL_SCANCODE_F7], ks[SDL_SCANCODE_F12],
            ks[SDL_SCANCODE_F9], ks[SDL_SCANCODE_RIGHTBRACKET], ks[SDL_SCANCODE_LEFTBRACKET], false,
        };
        static const unsigned hkmap[8] = {HK_MENU, HK_SAVE_STATE, HK_LOAD_STATE, HK_SCREENSHOT,
                                          HK_RESET, HK_SLOT_NEXT, HK_SLOT_PREV, 0};
        for (int i = 0; i < 8; i++) {
            if (f_now[i] && !f_prev[i])
                hk |= hkmap[i];
            f_prev[i] = f_now[i];
        }
        if (ks[SDL_SCANCODE_TAB])
            ff = true;
    }
    want[NAV_UP] |= ks[SDL_SCANCODE_UP] != 0;
    want[NAV_DOWN] |= ks[SDL_SCANCODE_DOWN] != 0;
    want[NAV_LEFT] |= ks[SDL_SCANCODE_LEFT] != 0;
    want[NAV_RIGHT] |= ks[SDL_SCANCODE_RIGHT] != 0;
    want[NAV_ACCEPT] |= ks[SDL_SCANCODE_RETURN] || ks[SDL_SCANCODE_SPACE];
    want[NAV_BACK] |= ks[SDL_SCANCODE_ESCAPE] || ks[SDL_SCANCODE_BACKSPACE];
    want[NAV_X] |= ks[SDL_SCANCODE_X] != 0;
    want[NAV_Y] |= ks[SDL_SCANCODE_Y] != 0;
    want[NAV_PAGE_UP] |= ks[SDL_SCANCODE_PAGEUP] != 0;
    want[NAV_PAGE_DOWN] |= ks[SDL_SCANCODE_PAGEDOWN] != 0;
    want[NAV_MENU] |= ks[SDL_SCANCODE_F2] != 0;

    /* After a mode switch (menu <-> game) everything currently held is ignored
     * until it is released, so the press that opened the menu does not also
     * activate its first entry. */
    if (g_swallow) {
        for (int a = NAV_UP; a <= NAV_MENU; a++)
            if (want[a]) {
                g_nav_blocked[a] = true;
                g_nav_held[a] = true;
            }
        g_swallow = false;
    }
    if (g_game_active) {
        /* nothing navigates while the game runs; keep the held state in sync */
        for (int a = NAV_UP; a <= NAV_MENU; a++) {
            g_nav_held[a] = want[a];
            g_nav_blocked[a] = want[a];
        }
        g_navq_head = g_navq_tail = 0;
    } else {
        nav_update(now, want);
    }

    /* Buttons that were already down when the game (re)gained the input -
     * typically the press that selected "Resume" - stay masked until they are
     * released, so they never leak into the game. */
    if (g_mask_block_arm) {
        for (int p = 0; p < MAX_PADS; p++)
            g_mask_block[p] = masks[p];
        g_mask_block_arm = false;
    }
    for (int p = 0; p < MAX_PADS; p++) {
        g_mask_block[p] &= masks[p];
        masks[p] &= ~g_mask_block[p];
    }

    for (int p = 0; p < MAX_PADS; p++)
        __atomic_store_n(&g_port_state[p], masks[p], __ATOMIC_RELAXED);
    __atomic_store_n(&g_ff, (uint32_t)(ff && g_game_active), __ATOMIC_RELAXED);
    if (hk)
        __atomic_fetch_or(&g_hotkeys, hk, __ATOMIC_RELAXED);
}

/* ------------------------------------------------------------ public reads */

uint32_t input_port_state(unsigned port)
{
    return port < MAX_PADS ? __atomic_load_n(&g_port_state[port], __ATOMIC_RELAXED) : 0;
}

bool input_fast_forward(void)
{
    return __atomic_load_n(&g_ff, __ATOMIC_RELAXED) != 0;
}

unsigned input_take_hotkeys(void)
{
    return __atomic_exchange_n(&g_hotkeys, 0, __ATOMIC_RELAXED);
}

nav_action_t input_next_nav(void)
{
    nav_action_t a;
    if (g_navq_tail == g_navq_head)
        return NAV_NONE;
    a = g_navq[g_navq_tail];
    g_navq_tail = (g_navq_tail + 1) % NAV_QUEUE;
    return a;
}

const pointer_t *input_pointer(void)
{
    return &g_ptr;
}

void input_set_game_active(bool active)
{
    if (g_game_active != active) {
        g_game_active = active;
        g_swallow = true;
        g_mask_block_arm = active;
        if (!active)
            for (int p = 0; p < MAX_PADS; p++) {
                g_mask_block[p] = 0;
                __atomic_store_n(&g_port_state[p], 0, __ATOMIC_RELAXED);
            }
    }
}

/* ----------------------------------------------------------------- capture */

void input_capture_begin(void)
{
    g_cap_active = true;
    g_cap_done = false;
    g_cap_code = PBTN_NONE;
}

void input_capture_cancel(void)
{
    g_cap_active = false;
    g_cap_done = false;
}

bool input_capture_active(void)
{
    return g_cap_active;
}

bool input_capture_result(int *out)
{
    if (!g_cap_active || !g_cap_done)
        return false;
    if (out)
        *out = g_cap_code;
    g_cap_active = false;
    g_cap_done = false;
    return true;
}
