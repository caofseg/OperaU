#include "flags.h"
#include "inline.h"

#include "boolean.h"

#include "opera_arm.h"
#include "opera_core.h"
#include "opera_madam.h"
#include "opera_mem.h"
#include "opera_region.h"
#include "opera_state.h"
#include "opera_vdl.h"
#include "opera_prof.h"
#include "opera_vdlp.h"
#include "opera_vdlp_i.h"

#include <assert.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

/*
  VDLP options TODO
  - interpolation
  - add pseudo random 3bit pattern for second clut bypass mode
*/

enum
  {
    VDLP_FORCE_LINE = 5,
    VDLP_PAL_FORCE_DELAY = 3
  };

typedef void(*vdlp_renderer_t)();

static vdlp_t               g_VDLP         = {0};
static void                *g_BUF          = NULL;
static void                *g_CURBUF       = NULL;
static vdlp_renderer_t      g_RENDERER     = NULL;
static uint32_t             g_FLAGS        = VDLP_FLAG_NONE;
static vdlp_pixel_format_e  g_PIXEL_FORMAT = VDLP_PIXEL_FORMAT_RGB565;

static const uint32_t PIXELS_PER_LINE_MODULO[8] =
  {320, 384, 512, 640, 1024, 320, 320, 320};

/*
  Host address of the 16-bit pixel at guest address A inside VRAM.
  On little-endian hosts VRAM keeps every guest 32-bit word byte
  reversed, so the half-word containing a guest address sits at A ^ 2.
  On big-endian hosts VRAM already is in guest byte order.
  (Local modification for OperaU, see third_party/patches/.)
*/
#if IS_BIG_ENDIAN
#define VDLP_BMP_HOST_ADDR(a_) (a_)
#else
#define VDLP_BMP_HOST_ADDR(a_) ((a_) ^ 2)
#endif

static
INLINE
bool
madam_clut_dma_enabled(void)
{
  return flag_is_set(opera_madam_mctl(),MADAM_MCTL_CLUTXEN);
}

static
INLINE
bool
madam_video_dma_enabled(void)
{
  return flag_is_set(opera_madam_mctl(),MADAM_MCTL_VSCTXEN);
}

static
INLINE
bool
bitmap_dma_enabled(void)
{
  return (madam_video_dma_enabled() && g_VDLP.clut_ctrl.cdcw.enable_dma);
}

/*
  TODO: why the "& VRAM_SIZE_MASK"?
  The addresses shouldn't be outside the RAM space but are at times.
*/
static
INLINE
uint32_t
vram_read32(const uint32_t addr_)
{
  return *(uint32_t const * const)&VRAM[addr_ & VRAM_SIZE_MASK];
}

static
INLINE
void
vram_write32(const uint32_t addr_,
             const uint32_t val_)
{
  *((uint32_t * const)&VRAM[addr_ & VRAM_SIZE_MASK]) = val_;
}

static
INLINE
uint32_t
vdl_read(const uint32_t off_)
{
  return vram_read32(g_VDLP.curr_vdl + (off_ << 2));
}

static
void
vdl_set_clut(const vdl_ctrl_word_u cmd_)
{
  switch(cmd_.cvw.rgb_enable)
    {
    case 0x0:
      g_VDLP.clut_r[cmd_.cvw.addr] = cmd_.cvw.r;
      g_VDLP.clut_b[cmd_.cvw.addr] = cmd_.cvw.b;
      g_VDLP.clut_g[cmd_.cvw.addr] = cmd_.cvw.g;
      break;
    case 0x3:
      g_VDLP.clut_r[cmd_.cvw.addr] = cmd_.cvw.r;
      break;
    case 0x1:
      g_VDLP.clut_b[cmd_.cvw.addr] = cmd_.cvw.b;
      break;
    case 0x2:
      g_VDLP.clut_g[cmd_.cvw.addr] = cmd_.cvw.g;
      break;
    }
}

static
void
vdlp_process_optional_cmds(const int ctrl_word_cnt_)
{
  int i;
  int colors_only;
  vdl_ctrl_word_u cmd;

  colors_only = 0;
  for(i = 0; i < ctrl_word_cnt_; i++)
    {
      cmd.raw = vdl_read(i);
      switch((cmd.raw & 0xE0000000) >> 29)
        {
        case 0x0:
        case 0x1:
        case 0x2:
        case 0x3:
          vdl_set_clut(cmd);
          break;
        case 0x4:
        case 0x5:
          /*
            Page 17 of US Patent 5,502,462

            If bit 31 of an optional color/control word is one, and if
            bit 30 is zero (10X), then the word contains control
            information for an audio/video output circuit 105 (not
            detailed herein) of the system. The audio/video processor
            circuitry receives this word over the S-bus 123, and
            forwards in to the audio/video output circuitry for
            processing.
          */
          break;
        case 0x6:
          if(colors_only)
            continue;
          g_VDLP.disp_ctrl.raw = cmd.raw;
          colors_only = cmd.dcw.colors_only;
          break;
        case 0x7:
          g_VDLP.bg_color.raw = cmd.raw;
          break;
        }
    }
}

static
void
vdlp_process_vdl_entry(void)
{
  uint32_t entry;
  uint32_t next_entry;
  clut_dma_ctrl_word_s *cdcw = &g_VDLP.clut_ctrl.cdcw;

  if(!g_VDLP.next_vdl)
    return;

  g_VDLP.curr_vdl = g_VDLP.next_vdl;
  entry = vram_read32(g_VDLP.curr_vdl);

  g_VDLP.clut_ctrl.raw = entry;

  if(cdcw->curr_fba_override)
    g_VDLP.curr_bmp = vdl_read(1);

  if(cdcw->prev_fba_override)
    g_VDLP.prev_bmp = vdl_read(2);

  next_entry = vdl_read(3);
  if(cdcw->next_vdl_addr_rel)
    next_entry += (g_VDLP.curr_vdl + (4 * sizeof(uint32_t)));

  g_VDLP.curr_vdl += (4 * sizeof(uint32_t));

  vdlp_process_optional_cmds(cdcw->ctrl_word_cnt);

  g_VDLP.next_vdl = next_entry;
  g_VDLP.line_cnt = cdcw->persist_len;
}

static
void
vdlp_render_line_black(const uint32_t width_,
                       const uint32_t bytes_per_pixel_)
{
  uint8_t *dst;
  uint32_t len;

  dst = g_CURBUF;
  len = (width_ * bytes_per_pixel_);

  memset(dst,0,len);

  g_CURBUF = (dst + len);
}

static
void
vdlp_render_line_black_hires(const uint32_t width_,
                             const uint32_t bytes_per_pixel_)
{
  uint8_t *dst;
  uint32_t len;

  dst = g_CURBUF;
  len = (width_ * bytes_per_pixel_ * 2 * 2);

  memset(dst,0,len);

  g_CURBUF = (dst + len);
}

static
uint16_t
fixed_clut_to_0RGB1555(const uint16_t p_)
{
  return (p_ & 0x7FFF);
}

static
uint16_t
user_clut_to_0RGB1555(const uint16_t p_)
{
  return (((g_VDLP.clut_r[(p_ >> 0xA) & 0x1F] >> 3) << 0xA) |
          ((g_VDLP.clut_g[(p_ >> 0x5) & 0x1F] >> 3) << 0x5) |
          ((g_VDLP.clut_b[(p_ >> 0x0) & 0x1F] >> 3) << 0x0));
}

static
uint16_t
background_to_0RGB1555(void)
{
  return (((g_VDLP.bg_color.bvw.r >> 3) << 0xA) |
          ((g_VDLP.bg_color.bvw.g >> 3) << 0x5) |
          ((g_VDLP.bg_color.bvw.b >> 3) << 0x0));
}

static
uint16_t
vdlp_render_pixel_0RGB1555(const uint16_t p_)
{
  if(p_ == 0)
    return background_to_0RGB1555();

  return user_clut_to_0RGB1555(p_);
}

static
uint16_t
vdlp_render_pixel_0RGB1555_bypass_clut(const uint16_t p_)
{
  if(p_ == 0)
    return background_to_0RGB1555();

  if(p_ & 0x8000)
    return fixed_clut_to_0RGB1555(p_);

  return user_clut_to_0RGB1555(p_);
}

static
void
vdlp_render_line_0RGB1555(void)
{
  int x;
  int width;
  uint32_t const *src;
  uint16_t *dst;

  width = PIXELS_PER_LINE_MODULO[g_VDLP.clut_ctrl.cdcw.fba_incr_modulo];

  if(!bitmap_dma_enabled())
    {
      vdlp_render_line_black(width,sizeof(uint16_t));
      return;
    }

  dst = g_CURBUF;
  src = (uint32_t const *)&VRAM[VDLP_BMP_HOST_ADDR(g_VDLP.curr_bmp) & VRAM_SIZE_MASK];
  if(!g_VDLP.disp_ctrl.dcw.clut_bypass)
    {
      for(x = 0; x < width; x++)
        dst[x] = vdlp_render_pixel_0RGB1555(*(uint16_t*)&src[x]);
    }
  else
    {
      for(x = 0; x < width; x++)
        dst[x] = vdlp_render_pixel_0RGB1555_bypass_clut(*(uint16_t*)&src[x]);
    }

  g_CURBUF = &dst[width];
}

static
void
vdlp_render_line_0RGB1555_bypass_clut(void)
{
  int x;
  int width;
  uint32_t *src;
  uint16_t *dst;

  width = PIXELS_PER_LINE_MODULO[g_VDLP.clut_ctrl.cdcw.fba_incr_modulo];

  if(!bitmap_dma_enabled())
    {
      vdlp_render_line_black(width,sizeof(uint16_t));
      return;
    }

  dst = g_CURBUF;
  src = (uint32_t*)&VRAM[VDLP_BMP_HOST_ADDR(g_VDLP.curr_bmp) & VRAM_SIZE_MASK];
  for(x = 0; x < width; x++)
    dst[x] = fixed_clut_to_0RGB1555(*(uint16_t*)&src[x]);

  g_CURBUF = &dst[width];
}

static
void
vdlp_render_line_0RGB1555_hires(void)
{
  int x;
  int width;
  uint16_t *dst0;
  uint16_t *dst1;
  uint32_t *src0;
  uint32_t *src1;
  uint32_t *src2;
  uint32_t *src3;

  width = PIXELS_PER_LINE_MODULO[g_VDLP.clut_ctrl.cdcw.fba_incr_modulo];

  if(!bitmap_dma_enabled())
    {
      vdlp_render_line_black(width,sizeof(uint16_t));
      return;
    }

  dst0 = g_CURBUF;
  dst1 = (dst0 + (width << 1));
  src0 = (uint32_t*)&VRAM[VDLP_BMP_HOST_ADDR(g_VDLP.curr_bmp) & VRAM_SIZE_MASK];
  src1 = &src0[VRAM_SIZE / sizeof(uint32_t)];
  src2 = &src1[VRAM_SIZE / sizeof(uint32_t)];
  src3 = &src2[VRAM_SIZE / sizeof(uint32_t)];
  if(!g_VDLP.disp_ctrl.dcw.clut_bypass)
    {
      for(x = 0; x < width; x++)
        {
          *dst0++ = vdlp_render_pixel_0RGB1555(*(uint16_t*)&src0[x]);
          *dst0++ = vdlp_render_pixel_0RGB1555(*(uint16_t*)&src1[x]);
          *dst1++ = vdlp_render_pixel_0RGB1555(*(uint16_t*)&src2[x]);
          *dst1++ = vdlp_render_pixel_0RGB1555(*(uint16_t*)&src3[x]);
        }
    }
  else
    {
      for(x = 0; x < width; x++)
        {
          *dst0++ = vdlp_render_pixel_0RGB1555_bypass_clut(*(uint16_t*)&src0[x]);
          *dst0++ = vdlp_render_pixel_0RGB1555_bypass_clut(*(uint16_t*)&src1[x]);
          *dst1++ = vdlp_render_pixel_0RGB1555_bypass_clut(*(uint16_t*)&src2[x]);
          *dst1++ = vdlp_render_pixel_0RGB1555_bypass_clut(*(uint16_t*)&src3[x]);
        }
    }

  g_CURBUF = dst1;
}

static
void
vdlp_render_line_0RGB1555_hires_bypass_clut(void)
{
  int x;
  int width;
  uint16_t *dst0;
  uint16_t *dst1;
  uint32_t *src0;
  uint32_t *src1;
  uint32_t *src2;
  uint32_t *src3;

  width = PIXELS_PER_LINE_MODULO[g_VDLP.clut_ctrl.cdcw.fba_incr_modulo];

  if(!bitmap_dma_enabled())
    {
      vdlp_render_line_black(width,sizeof(uint16_t));
      return;
    }

  dst0 = g_CURBUF;
  dst1 = &dst0[width << 1];
  src0 = (uint32_t*)&VRAM[VDLP_BMP_HOST_ADDR(g_VDLP.curr_bmp) & VRAM_SIZE_MASK];
  src1 = &src0[VRAM_SIZE / sizeof(uint32_t)];
  src2 = &src1[VRAM_SIZE / sizeof(uint32_t)];
  src3 = &src2[VRAM_SIZE / sizeof(uint32_t)];
  for(x = 0; x < width; x++)
    {
      *dst0++ = fixed_clut_to_0RGB1555(*(uint16_t*)&src0[x]);
      *dst0++ = fixed_clut_to_0RGB1555(*(uint16_t*)&src1[x]);
      *dst1++ = fixed_clut_to_0RGB1555(*(uint16_t*)&src2[x]);
      *dst1++ = fixed_clut_to_0RGB1555(*(uint16_t*)&src3[x]);
    }

  g_CURBUF = dst1;
}

static
INLINE
uint16_t
fixed_clut_to_RGB565(const uint16_t p_)
{
  return (((p_ & 0x7FE0) << 1) | (p_ & 0x001F));
}

static
INLINE
uint16_t
user_clut_to_RGB565(const uint16_t p_)
{
  return (((g_VDLP.clut_r[(p_ >> 0xA) & 0x1F] >> 3) << 0xB) |
          ((g_VDLP.clut_g[(p_ >> 0x5) & 0x1F] >> 2) << 0x5) |
          ((g_VDLP.clut_b[(p_ >> 0x0) & 0x1F] >> 3) << 0x0));
}

static
INLINE
uint16_t
background_to_RGB565(void)
{
  return (((g_VDLP.bg_color.bvw.r >> 3) << 0xB) |
          ((g_VDLP.bg_color.bvw.g >> 2) << 0x5) |
          ((g_VDLP.bg_color.bvw.b >> 3) << 0x0));
}

static
INLINE
uint16_t
vdlp_render_pixel_RGB565(const uint16_t p_)
{
  if(p_ == 0)
    return background_to_RGB565();

  return user_clut_to_RGB565(p_);
}

static
INLINE
uint16_t
vdlp_render_pixel_RGB565_bypass_clut(const uint16_t p_)
{
  if(p_ == 0)
    return background_to_RGB565();

  if(p_ & 0x8000)
    return fixed_clut_to_RGB565(p_);

  return user_clut_to_RGB565(p_);
}

static
void
vdlp_render_line_RGB565(void)
{
  int x;
  int width;
  uint32_t *src;
  uint16_t *dst;

  width = PIXELS_PER_LINE_MODULO[g_VDLP.clut_ctrl.cdcw.fba_incr_modulo];

  if(!bitmap_dma_enabled())
    {
      vdlp_render_line_black(width,sizeof(uint16_t));
      return;
    }

  dst = g_CURBUF;
  src = (uint32_t*)&VRAM[VDLP_BMP_HOST_ADDR(g_VDLP.curr_bmp) & VRAM_SIZE_MASK];
  if(!g_VDLP.disp_ctrl.dcw.clut_bypass)
    {
      for(x = 0; x < width; x++)
        dst[x] = vdlp_render_pixel_RGB565(*(uint16_t*)&src[x]);
    }
  else
    {
      for(x = 0; x < width; x++)
        dst[x] = vdlp_render_pixel_RGB565_bypass_clut(*(uint16_t*)&src[x]);
    }

  g_CURBUF = &dst[width];
}

static
void
vdlp_render_line_RGB565_bypass_clut(void)
{
  int x;
  int width;
  uint32_t *src;
  uint16_t *dst;

  width = PIXELS_PER_LINE_MODULO[g_VDLP.clut_ctrl.cdcw.fba_incr_modulo];

  if(!bitmap_dma_enabled())
    {
      vdlp_render_line_black(width,sizeof(uint16_t));
      return;
    }

  dst = g_CURBUF;
  src = (uint32_t*)&VRAM[VDLP_BMP_HOST_ADDR(g_VDLP.curr_bmp) & VRAM_SIZE_MASK];
  for(x = 0; x < width; x++)
    dst[x] = fixed_clut_to_RGB565(*(uint16_t*)&src[x]);

  g_CURBUF = &dst[width];
}

static
void
vdlp_render_line_RGB565_hires(void)
{
  int x;
  int width;
  uint16_t *dst0;
  uint16_t *dst1;
  uint32_t *src0;
  uint32_t *src1;
  uint32_t *src2;
  uint32_t *src3;

  width = PIXELS_PER_LINE_MODULO[g_VDLP.clut_ctrl.cdcw.fba_incr_modulo];

  if(!bitmap_dma_enabled())
    {
      vdlp_render_line_black_hires(width,sizeof(uint16_t));
      return;
    }

  dst0 = g_CURBUF;
  dst1 = &dst0[width << 1];
  src0 = (uint32_t*)&VRAM[VDLP_BMP_HOST_ADDR(g_VDLP.curr_bmp) & VRAM_SIZE_MASK];
  src1 = &src0[VRAM_SIZE / sizeof(uint32_t)];
  src2 = &src1[VRAM_SIZE / sizeof(uint32_t)];
  src3 = &src2[VRAM_SIZE / sizeof(uint32_t)];
  if(!g_VDLP.disp_ctrl.dcw.clut_bypass)
    {
      for(x = 0; x < width; x++)
        {
          *dst0++ = vdlp_render_pixel_RGB565(*(uint16_t*)&src0[x]);
          *dst0++ = vdlp_render_pixel_RGB565(*(uint16_t*)&src1[x]);
          *dst1++ = vdlp_render_pixel_RGB565(*(uint16_t*)&src2[x]);
          *dst1++ = vdlp_render_pixel_RGB565(*(uint16_t*)&src3[x]);
        }
    }
  else
    {
      for(x = 0; x < width; x++)
        {
          *dst0++ = vdlp_render_pixel_RGB565_bypass_clut(*(uint16_t*)&src0[x]);
          *dst0++ = vdlp_render_pixel_RGB565_bypass_clut(*(uint16_t*)&src1[x]);
          *dst1++ = vdlp_render_pixel_RGB565_bypass_clut(*(uint16_t*)&src2[x]);
          *dst1++ = vdlp_render_pixel_RGB565_bypass_clut(*(uint16_t*)&src3[x]);
        }
    }

  g_CURBUF = dst1;
}

static
void
vdlp_render_line_RGB565_hires_bypass_clut(void)
{
  int x;
  int width;
  uint16_t *dst0;
  uint16_t *dst1;
  uint32_t *src0;
  uint32_t *src1;
  uint32_t *src2;
  uint32_t *src3;

  width = PIXELS_PER_LINE_MODULO[g_VDLP.clut_ctrl.cdcw.fba_incr_modulo];

  if(!bitmap_dma_enabled())
    {
      vdlp_render_line_black_hires(width,sizeof(uint16_t));
      return;
    }

  dst0 = g_CURBUF;
  dst1 = &dst0[width << 1];
  src0 = (uint32_t*)&VRAM[VDLP_BMP_HOST_ADDR(g_VDLP.curr_bmp) & VRAM_SIZE_MASK];
  src1 = &src0[VRAM_SIZE / sizeof(uint32_t)];
  src2 = &src1[VRAM_SIZE / sizeof(uint32_t)];
  src3 = &src2[VRAM_SIZE / sizeof(uint32_t)];
  for(x = 0; x < width; x++)
    {
      *dst0++ = fixed_clut_to_RGB565(*(uint16_t*)&src0[x]);
      *dst0++ = fixed_clut_to_RGB565(*(uint16_t*)&src1[x]);
      *dst1++ = fixed_clut_to_RGB565(*(uint16_t*)&src2[x]);
      *dst1++ = fixed_clut_to_RGB565(*(uint16_t*)&src3[x]);
    }

  g_CURBUF = dst1;
}

static
INLINE
uint32_t
fixed_clut_to_XRGB8888(const uint16_t p_)
{
  return (((p_ & 0x7C00) << 0x9) |
          ((p_ & 0x03E0) << 0x6) |
          ((p_ & 0x001F) << 0x3));
}

static
INLINE
uint32_t
user_clut_to_XRGB8888(const uint16_t p_)
{
  return ((g_VDLP.clut_r[(p_ >> 0xA) & 0x1F] << 0x10) |
          (g_VDLP.clut_g[(p_ >> 0x5) & 0x1F] << 0x08) |
          (g_VDLP.clut_b[(p_ >> 0x0) & 0x1F] << 0x00));
}

static
INLINE
uint32_t
vdlp_render_pixel_XRGB8888(const uint16_t p_)
{
  if(p_ == 0)
    return g_VDLP.bg_color.raw;

  return user_clut_to_XRGB8888(p_);
}

static
INLINE
uint32_t
vdlp_render_pixel_XRGB8888_bypass_clut(const uint16_t p_)
{
  if(p_ == 0)
    return g_VDLP.bg_color.raw;

  if(p_ & 0x8000)
    return fixed_clut_to_XRGB8888(p_);

  return user_clut_to_XRGB8888(p_);
}

static
void
vdlp_render_line_XRGB8888(void)
{
  int x;
  int width;
  uint32_t *src;
  uint32_t *dst;

  width = PIXELS_PER_LINE_MODULO[g_VDLP.clut_ctrl.cdcw.fba_incr_modulo];

  if(!bitmap_dma_enabled())
    {
      vdlp_render_line_black(width,sizeof(uint32_t));
      return;
    }

  dst = g_CURBUF;
  src = (uint32_t*)&VRAM[VDLP_BMP_HOST_ADDR(g_VDLP.curr_bmp) & VRAM_SIZE_MASK];
  if(!g_VDLP.disp_ctrl.dcw.clut_bypass)
    {
      for(x = 0; x < width; x++)
        dst[x] = vdlp_render_pixel_XRGB8888(*(uint16_t*)&src[x]);
    }
  else
    {
      for(x = 0; x < width; x++)
        dst[x] = vdlp_render_pixel_XRGB8888_bypass_clut(*(uint16_t*)&src[x]);
    }

  g_CURBUF = &dst[width];
}

static
void
vdlp_render_line_XRGB8888_bypass_clut(void)
{
  int x;
  int width;
  uint32_t *src;
  uint32_t *dst;

  width = PIXELS_PER_LINE_MODULO[g_VDLP.clut_ctrl.cdcw.fba_incr_modulo];

  if(!bitmap_dma_enabled())
    {
      vdlp_render_line_black(width,sizeof(uint32_t));
      return;
    }

  dst = g_CURBUF;
  src = (uint32_t*)&VRAM[VDLP_BMP_HOST_ADDR(g_VDLP.curr_bmp) & VRAM_SIZE_MASK];
  for(x = 0; x < width; x++)
    dst[x] = fixed_clut_to_XRGB8888(*(uint16_t*)&src[x]);

  g_CURBUF = &dst[width];
}

static
void
vdlp_render_line_XRGB8888_hires(void)
{
  int x;
  int width;
  uint32_t *dst0;
  uint32_t *dst1;
  uint32_t *src0;
  uint32_t *src1;
  uint32_t *src2;
  uint32_t *src3;

  width = PIXELS_PER_LINE_MODULO[g_VDLP.clut_ctrl.cdcw.fba_incr_modulo];

  if(!bitmap_dma_enabled())
    {
      vdlp_render_line_black_hires(width,sizeof(uint32_t));
      return;
    }

  dst0 = g_CURBUF;
  dst1 = &dst0[width << 1];
  src0 = (uint32_t*)&VRAM[VDLP_BMP_HOST_ADDR(g_VDLP.curr_bmp) & VRAM_SIZE_MASK];
  src1 = &src0[VRAM_SIZE / sizeof(uint32_t)];
  src2 = &src1[VRAM_SIZE / sizeof(uint32_t)];
  src3 = &src2[VRAM_SIZE / sizeof(uint32_t)];
  if(!g_VDLP.disp_ctrl.dcw.clut_bypass)
    {
      for(x = 0; x < width; x++)
        {
          *dst0++ = vdlp_render_pixel_XRGB8888(*(uint16_t*)&src0[x]);
          *dst0++ = vdlp_render_pixel_XRGB8888(*(uint16_t*)&src1[x]);
          *dst1++ = vdlp_render_pixel_XRGB8888(*(uint16_t*)&src2[x]);
          *dst1++ = vdlp_render_pixel_XRGB8888(*(uint16_t*)&src3[x]);
        }
    }
  else
    {
      for(x = 0; x < width; x++)
        {
          *dst0++ = vdlp_render_pixel_XRGB8888_bypass_clut(*(uint16_t*)&src0[x]);
          *dst0++ = vdlp_render_pixel_XRGB8888_bypass_clut(*(uint16_t*)&src1[x]);
          *dst1++ = vdlp_render_pixel_XRGB8888_bypass_clut(*(uint16_t*)&src2[x]);
          *dst1++ = vdlp_render_pixel_XRGB8888_bypass_clut(*(uint16_t*)&src3[x]);
        }
    }

  g_CURBUF = dst1;
}

static
void
vdlp_render_line_XRGB8888_hires_bypass_clut(void)
{
  int x;
  int width;
  uint32_t *dst0;
  uint32_t *dst1;
  uint32_t *src0;
  uint32_t *src1;
  uint32_t *src2;
  uint32_t *src3;

  width = PIXELS_PER_LINE_MODULO[g_VDLP.clut_ctrl.cdcw.fba_incr_modulo];

  if(!bitmap_dma_enabled())
    {
      vdlp_render_line_black_hires(width,sizeof(uint32_t));
      return;
    }

  dst0 = g_CURBUF;
  dst1 = &dst0[width << 1];
  src0 = (uint32_t*)&VRAM[VDLP_BMP_HOST_ADDR(g_VDLP.curr_bmp) & VRAM_SIZE_MASK];
  src1 = &src0[VRAM_SIZE / sizeof(uint32_t)];
  src2 = &src1[VRAM_SIZE / sizeof(uint32_t)];
  src3 = &src2[VRAM_SIZE / sizeof(uint32_t)];
  for(x = 0; x < width; x++)
    {
      *dst0++ = fixed_clut_to_XRGB8888(*(uint16_t*)&src0[x]);
      *dst0++ = fixed_clut_to_XRGB8888(*(uint16_t*)&src1[x]);
      *dst1++ = fixed_clut_to_XRGB8888(*(uint16_t*)&src2[x]);
      *dst1++ = fixed_clut_to_XRGB8888(*(uint16_t*)&src3[x]);
    }

  g_CURBUF = dst1;
}


/* tick / increment frame buffer address */
static
INLINE
uint32_t
tick_fba(const uint32_t fba_)
{
  uint32_t modulo;

  modulo = PIXELS_PER_LINE_MODULO[g_VDLP.clut_ctrl.cdcw.fba_incr_modulo];

  return (fba_ + ((fba_ & 2) ? ((modulo << 2) - 2) : 2));
}

static
INLINE
int
visible_scanline(const int line_)
{
  return ((line_ >= opera_region_start_scanline()) &&
          (line_  < opera_region_end_scanline()));
}

static
INLINE
uint32_t
_forced_transfer_line(vdlp_t const *state_)
{
  assert(state_ != NULL);
  return (VDLP_FORCE_LINE +
          (state_->disp_ctrl.dcw.pal_ntsc ? VDLP_PAL_FORCE_DELAY : 0));
}


/*
  See ppgfldr/ggsfldr/gpgfldr/2gpgb.html for details on the frame
  buffer layout.

  320x240 by 16bit stored in "left/right" pairs. High order 16bits
  represent X,Y and low order bits represent X,Y+1. Starting from
  0,0 and going left to right and top to bottom to 319,239.
*/
void
opera_vdlp_process_line(int line_)
{
  // Model the display-effective boundary, not parity-specific DMA pipeline stages.
  // Latch PALSEL once per field; a loaded mode change applies to the next field.
  if(line_ == 0)
    g_VDLP.force_line = _forced_transfer_line(&g_VDLP);

  if(line_ < VDLP_FORCE_LINE)
    return;

  if(line_ == VDLP_FORCE_LINE)
    g_CURBUF = g_BUF;

  if(madam_clut_dma_enabled())
    {
      if(line_ == (int)g_VDLP.force_line)
        {
          vdlp_process_vdl_entry();

          /* Local modification for OperaU, see opera_prof.h: a field that starts on another frame buffer than
             the one before it is a new picture from the game. Counted, nothing else. */
          if(opera_prof_enabled)
            {
              static uint32_t shown = 0;

              if(g_VDLP.curr_bmp != shown)
                {
                  shown = g_VDLP.curr_bmp;
                  opera_prof.vdl_flips++;
                }
            }
        }
      else if((g_VDLP.line_cnt <= 0) && (g_VDLP.clut_ctrl.cdcw.persist_len != 0))
        vdlp_process_vdl_entry();
    }

  if(visible_scanline(line_))
    g_RENDERER();

  g_VDLP.prev_bmp = ((g_VDLP.clut_ctrl.cdcw.prev_fba_tick) ?
                     tick_fba(g_VDLP.prev_bmp) : g_VDLP.curr_bmp);
  g_VDLP.curr_bmp = tick_fba(g_VDLP.curr_bmp);

  g_VDLP.disp_ctrl.dcw.vi_off_1_line = 0;
  if(g_VDLP.line_cnt > 0)
    g_VDLP.line_cnt--;
}


void
opera_vdlp_init()
{
  void *buf;
  vdlp_renderer_t renderer;
  uint32_t flags;
  vdlp_pixel_format_e pixel_format;

  buf          = g_BUF;
  renderer     = g_RENDERER;
  flags        = g_FLAGS;
  pixel_format = g_PIXEL_FORMAT;

  /* The boot ROM installs the power-on VDL through MADAM CLUTMID. */
  memset(&g_VDLP,0,sizeof(g_VDLP));
  g_VDLP.force_line = VDLP_FORCE_LINE;
  g_BUF          = buf;
  g_CURBUF       = buf;
  g_RENDERER     = renderer;
  g_FLAGS        = flags;
  g_PIXEL_FORMAT = pixel_format;

  if(g_RENDERER == NULL)
    g_RENDERER = vdlp_render_line_RGB565;
}

void
opera_vdlp_set_vdl_head(const uint32_t addr_)
{
  g_VDLP.next_vdl = addr_;
}

uint32_t
opera_vdlp_state_size_v1(void)
{
  return opera_state_save_size(sizeof(g_VDLP));
}

static
bool
vdlp_state_write_payload(opera_state_writer_t *writer_,
                         vdlp_t const         *state_)
{
  return (opera_state_write_bytes(writer_,state_->clut_r,CLUT_LEN) &&
          opera_state_write_bytes(writer_,state_->clut_g,CLUT_LEN) &&
          opera_state_write_bytes(writer_,state_->clut_b,CLUT_LEN) &&
          opera_state_write_u32(writer_,state_->force_line) &&
          opera_state_write_u32(writer_,state_->curr_vdl) &&
          opera_state_write_u32(writer_,state_->next_vdl) &&
          opera_state_write_u32(writer_,state_->prev_bmp) &&
          opera_state_write_u32(writer_,state_->curr_bmp) &&
          opera_state_write_u32(writer_,state_->bg_color.raw) &&
          opera_state_write_u32(writer_,state_->clut_ctrl.raw) &&
          opera_state_write_u32(writer_,state_->disp_ctrl.raw) &&
          opera_state_write_i32(writer_,state_->line_cnt));
}

static
uint32_t
vdlp_state_payload_size(void)
{
  opera_state_writer_t writer;

  opera_state_writer_init(&writer,NULL,UINT32_MAX);
  vdlp_state_write_payload(&writer,&g_VDLP);

  return opera_state_writer_used(&writer);
}

uint32_t
opera_vdlp_state_size(void)
{
  return opera_state_chunk_size(vdlp_state_payload_size());
}

uint32_t
opera_vdlp_state_save(void *buf_)
{
  uint32_t payload_size;
  opera_state_writer_t writer;

  payload_size = vdlp_state_payload_size();
  opera_state_writer_init(&writer,buf_,opera_state_chunk_size(payload_size));
  opera_state_write_chunk_header(&writer,"VDLP",payload_size);
  vdlp_state_write_payload(&writer,&g_VDLP);

  return opera_state_writer_ok(&writer) ? opera_state_writer_used(&writer) : 0;
}

static
void
_migrate_vdlp_state(vdlp_t *state_)
{
  assert(state_ != NULL);
  if(state_->force_line != 0)
    return;

  // Old payloads stored an unused zero and the last CPU-programmed head here.
  // Restart their video traversal from that address; new states retain next_vdl.
  state_->next_vdl = state_->curr_vdl;
  state_->force_line = _forced_transfer_line(state_);
}


uint32_t
opera_vdlp_state_load_v1(const void     *buf_,
                         uint32_t const  size_)
{
  uint32_t loaded;

  loaded = opera_state_load_sized(&g_VDLP,"VDLP",buf_,size_,sizeof(g_VDLP));
  if(loaded != 0)
    _migrate_vdlp_state(&g_VDLP);
  return loaded;
}

static
bool
vdlp_state_read_payload(opera_state_reader_t *reader_,
                        vdlp_t               *state_)
{
  return (opera_state_read_bytes(reader_,state_->clut_r,CLUT_LEN) &&
          opera_state_read_bytes(reader_,state_->clut_g,CLUT_LEN) &&
          opera_state_read_bytes(reader_,state_->clut_b,CLUT_LEN) &&
          opera_state_read_u32(reader_,&state_->force_line) &&
          opera_state_read_u32(reader_,&state_->curr_vdl) &&
          opera_state_read_u32(reader_,&state_->next_vdl) &&
          opera_state_read_u32(reader_,&state_->prev_bmp) &&
          opera_state_read_u32(reader_,&state_->curr_bmp) &&
          opera_state_read_u32(reader_,&state_->bg_color.raw) &&
          opera_state_read_u32(reader_,&state_->clut_ctrl.raw) &&
          opera_state_read_u32(reader_,&state_->disp_ctrl.raw) &&
          opera_state_read_i32(reader_,&state_->line_cnt));
}

uint32_t
opera_vdlp_state_load(const void     *buf_,
                      uint32_t const  size_)
{
  vdlp_t state;
  opera_state_reader_t reader;
  opera_state_reader_t payload;

  opera_state_reader_init(&reader,buf_,size_);
  if(!opera_state_read_chunk(&reader,"VDLP",&payload) ||
     !vdlp_state_read_payload(&payload,&state) ||
     !opera_state_reader_finished(&payload))
    return 0;

  if(opera_state_validating())
    return opera_state_reader_used(&reader);

  _migrate_vdlp_state(&state);
  g_VDLP = state;

  return opera_state_reader_used(&reader);
}

/*
  Is having all these renderers nice? No. But given the performance
  sensitivy of this code and impact it can have on a lower end system
  such verbosity is necessary.
*/

#define _(X,Y) ((((uint64_t)VDLP_PIXEL_FORMAT_##X)<<32)|((Y)&VDLP_FLAGS))
void*
get_renderer(vdlp_pixel_format_e pf_,
             uint32_t            flags_)
{
  uint64_t x;

  x = ((((uint64_t)pf_) << 32) | flags_);

  switch(x)
    {
    case _(0RGB1555,VDLP_FLAG_NONE):
      return vdlp_render_line_0RGB1555;
    case _(0RGB1555,VDLP_FLAG_BYPASS_CLUT):
      return vdlp_render_line_0RGB1555_bypass_clut;
    case _(0RGB1555,VDLP_FLAG_HIRES_CEL):
      return vdlp_render_line_0RGB1555_hires;
    case _(0RGB1555,VDLP_FLAG_BYPASS_CLUT|VDLP_FLAG_HIRES_CEL):
      return vdlp_render_line_0RGB1555_hires_bypass_clut;

    case _(RGB565,VDLP_FLAG_NONE):
      return vdlp_render_line_RGB565;
    case _(RGB565,VDLP_FLAG_BYPASS_CLUT):
      return vdlp_render_line_RGB565_bypass_clut;
    case _(RGB565,VDLP_FLAG_HIRES_CEL):
      return vdlp_render_line_RGB565_hires;
    case _(RGB565,VDLP_FLAG_BYPASS_CLUT|VDLP_FLAG_HIRES_CEL):
      return vdlp_render_line_RGB565_hires_bypass_clut;

    case _(XRGB8888,VDLP_FLAG_NONE):
      return vdlp_render_line_XRGB8888;
    case _(XRGB8888,VDLP_FLAG_BYPASS_CLUT):
      return vdlp_render_line_XRGB8888_bypass_clut;
    case _(XRGB8888,VDLP_FLAG_HIRES_CEL):
      return vdlp_render_line_XRGB8888_hires;
    case _(XRGB8888,VDLP_FLAG_BYPASS_CLUT|VDLP_FLAG_HIRES_CEL):
      return vdlp_render_line_XRGB8888_hires_bypass_clut;
    }

  return NULL;
}
#undef _

int
opera_vdlp_set_video_buffer(void *buf_)
{
  g_BUF = buf_;

  return 0;
}

int
opera_vdlp_set_hires(bool const v_)
{
  uint32_t flags;
  vdlp_renderer_t new_renderer;

  flags = g_FLAGS;
  set_or_clr_flag(flags,VDLP_FLAG_HIRES_CEL,v_);

  new_renderer = get_renderer(g_PIXEL_FORMAT,flags);
  if(new_renderer == NULL)
    return -1;

  g_RENDERER = new_renderer;
  g_FLAGS    = flags;

  return 0;
}

int
opera_vdlp_set_bypass_clut(bool const v_)
{
  uint32_t flags;
  vdlp_renderer_t new_renderer;

  flags = g_FLAGS;
  set_or_clr_flag(flags,VDLP_FLAG_BYPASS_CLUT,v_);

  new_renderer = get_renderer(g_PIXEL_FORMAT,flags);
  if(new_renderer == NULL)
    return -1;

  g_RENDERER = new_renderer;
  g_FLAGS    = flags;

  return 0;
}

int
opera_vdlp_set_pixel_format(vdlp_pixel_format_e v_)
{
  vdlp_renderer_t new_renderer;

  new_renderer = get_renderer(v_,g_FLAGS);
  if(new_renderer == NULL)
    return -1;

  g_RENDERER     = new_renderer;
  g_PIXEL_FORMAT = v_;

  return 0;
}
