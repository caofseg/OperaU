/*
 * libretro host for the Opera (3DO) core.
 *
 * Threading: every function that calls into the core (core_load, core_run,
 * core_reset, core_state_*, core_unload, core_flush_nvram) must be called from
 * ONE thread at a time - the emulation thread while a game runs. Option
 * editing (core_opt_*) happens from the UI thread only while the emulation is
 * paused.
 */
#ifndef OPERAU_CORE_H
#define OPERAU_CORE_H

#include "common.h"

typedef enum {
    CORE_PF_0RGB1555 = 0,
    CORE_PF_XRGB8888 = 1,
} core_pixel_format_t;

typedef struct {
    unsigned width, height;          /* current picture */
    unsigned max_width, max_height;
    float aspect;                    /* display aspect ratio */
    double fps;
    double sample_rate;
    core_pixel_format_t format;
} core_av_t;

typedef struct {
    /* Called from the emulation thread inside core_run(). */
    void (*video)(const void *data, unsigned w, unsigned h, size_t pitch, core_pixel_format_t fmt);
    /* Returns the number of frames consumed. */
    size_t (*audio)(const int16_t *stereo_frames, size_t nframes);
} core_sink_t;

/* ---- options -------------------------------------------------------- */

typedef struct {
    char value[64];
    char label[96];
} core_opt_val_t;

typedef struct {
    char key[40];
    char desc[96];
    char info[512];
    char category[24];
    char def[64];
    core_opt_val_t *vals;
    int nvals;
} core_opt_t;

/* ---- lifecycle ------------------------------------------------------ */

bool core_init(const core_sink_t *sink);
/* Replace the audio/video sinks (only while no frame is being run). */
void core_set_sink(const core_sink_t *sink);
core_sink_t core_get_sink(void);
void core_deinit(void);

/* Diagnostic mode, for the built-in self test (coretest / diag): while on, the
 * core is told the option DEFAULTS (every user override is ignored), sees no
 * controller input, and gets `scratch_dir` as both its system and save
 * directory, so the run can neither read nor change the user's NVRAM, BIOS
 * files or settings and its result is comparable with the reference measured
 * on a PC. Switch it on before core_load() and off after core_unload();
 * never while a game is loaded. */
void core_diag_enter(const char *scratch_dir);
void core_diag_leave(void);

/* path == NULL boots the built-in BIOS without a disc. On failure returns
 * false and core_last_error() describes why. */
bool core_load(const char *path);
void core_unload(void);
bool core_is_loaded(void);
const char *core_game_path(void);   /* NULL when no content */
const char *core_last_error(void);
typedef enum {
    CORE_ERR_NONE = 0,
    CORE_ERR_NOT_READY,
    CORE_ERR_NOT_FOUND,
    CORE_ERR_OPEN_IMAGE,   /* the core rejected the disc image */
    CORE_ERR_START,        /* BIOS-only boot failed */
} core_err_t;
core_err_t core_last_error_code(void);

void core_run(void);                /* one frame */
/* Debug aid: the emulated DRAM (which == 0) or VRAM (which == 1), in the core's
 * own layout: viewed as uint32_t words every word holds the guest value, on
 * little- and big-endian hosts alike. NULL when no game is loaded. */
const void *core_memory(unsigned which, size_t *size);
void core_reset(void);

const core_av_t *core_av(void);
/* True once after the core changed geometry / timing; clears the flag. */
bool core_av_take_changed(void);
/* True if the core asked to quit (RETRO_ENVIRONMENT_SHUTDOWN). */
bool core_shutdown_requested(void);

/* Save states (blob format is the core's own; ~6.6 MB). */
size_t core_state_size(void);
bool core_state_save(void *buf, size_t size);
bool core_state_load(const void *buf, size_t size);

/* Periodic NVRAM write-back; cheap when nothing changed. */
void core_flush_nvram(void);

/* ---- options -------------------------------------------------------- */

int core_opt_count(void);
const core_opt_t *core_opt_at(int index);
const core_opt_t *core_opt_find(const char *key);
/* Value in force: per-game override, global override, or the default. */
const char *core_opt_effective(const char *key);
/* Index of the effective value in opt->vals, -1 if not listed. */
int core_opt_effective_index(const core_opt_t *opt);
/* Tells the core something changed (it re-reads options before next frame). */
void core_opts_changed(void);
/* Re-enumerate options that depend on files (BIOS / font ROMs). */
void core_opts_rescan(void);
/* Number of controllers currently connected (drives "Active Input Devices"
 * when the user did not pick a value). */
void core_set_connected_pads(int n);

/* ---- messages from the core (shown as toasts) ------------------------- */

bool core_pop_message(char *out, size_t cap);

#endif
