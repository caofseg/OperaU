#include "i18n.h"
#include "config.h"

static const char *const k_pt[] = {
#define STR(id, pt, en) pt,
#include "i18n_strings.def"
#undef STR
};

static const char *const k_en[] = {
#define STR(id, pt, en) en,
#include "i18n_strings.def"
#undef STR
};

const char *tr(str_id_t id)
{
    if ((int)id < 0 || id >= S__COUNT)
        return "?";
    return g_cfg.language == LANG_EN ? k_en[id] : k_pt[id];
}
