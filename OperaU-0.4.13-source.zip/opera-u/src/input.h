#ifndef OPERAU_INPUT_H
#define OPERAU_INPUT_H

#include "common.h"
#include "config.h"

#include <SDL.h>

#define MAX_PADS 8

/* Physical button codes stored in the configuration. Values 0..20 match
 * SDL_GameControllerButton; analog triggers get their own codes. */
#define PBTN_NONE    (-1)
#define PBTN_LTRIG   100
#define PBTN_RTRIG   101
#define PBTN_COUNT_SDL SDL_CONTROLLER_BUTTON_MAX

const char *input_button_name(int code);   /* human readable, language independent */
const char *input_3do_name(int b3do);

/* UI navigation actions derived from any controller / touch. */
typedef enum {
    NAV_NONE = 0,
    NAV_UP, NAV_DOWN, NAV_LEFT, NAV_RIGHT,
    NAV_ACCEPT, NAV_BACK, NAV_X, NAV_Y,
    NAV_PAGE_UP, NAV_PAGE_DOWN, NAV_MENU
} nav_action_t;

/* Hotkey flags (edge triggered, valid for one frame). */
enum {
    HK_MENU        = 1 << 0,
    HK_SAVE_STATE  = 1 << 1,
    HK_LOAD_STATE  = 1 << 2,
    HK_SCREENSHOT  = 1 << 3,
    HK_RESET       = 1 << 4,
    HK_SLOT_NEXT   = 1 << 5,
    HK_SLOT_PREV   = 1 << 6,
};

typedef struct {
    bool connected;
    char name[64];
    int port;               /* libretro port 0.. or -1 when unassigned */
} pad_info_t;

void input_init(void);

/* Hotkeys one pad raises between two polls (`prev` -> `held`, SDL button bits,
 * bit 29 = second stick pushed right, bit 30/31 = ZL/ZR) and whether it asks
 * for fast-forward. Pure function, used by input_update() and by the self test.
 * ZL and ZR are never hotkeys. */
unsigned input_pad_hotkeys(uint32_t prev, uint32_t held, bool lr_menu, bool *ff);
/* Bit of `held` that means "second stick pushed to the right" (fast-forward). */
#define INPUT_HELD_FFSTICK (1u << 29)
void input_shutdown(void);

/* Feed every SDL event through this (hot-plug, touch, key). Returns true when
 * the event was consumed. */
bool input_handle_event(const SDL_Event *ev);

/* Call once per main-loop iteration after events were pumped. */
void input_update(void);

/* ---- emulation side (thread safe: values are snapshotted atomically) --- */

/* RetroPad bitmask (1 << RETRO_DEVICE_ID_JOYPAD_x) for `port`. */
uint32_t input_port_state(unsigned port);
/* True while the fast-forward key is held. */
bool input_fast_forward(void);
/* Hotkeys raised since the last call (clears them). */
unsigned input_take_hotkeys(void);

/* ---- UI side ----------------------------------------------------------- */

/* Pops the next queued navigation action (auto-repeat included). */
nav_action_t input_next_nav(void);
/* Queues a navigation action as if a button had been pressed (headless tests). */
void input_debug_nav(nav_action_t a);
/* Latest pointer position in logical (1280x720) coordinates; `down` is the
 * level, `pressed`/`released` are edges since the last input_update(). */
typedef struct {
    bool valid;
    bool down, pressed, released;
    float x, y;       /* current, logical coordinates */
    float dx, dy;     /* movement since last update */
} pointer_t;
const pointer_t *input_pointer(void);
void input_set_logical_size(int w, int h);

/* Controller bookkeeping */
int input_pad_count(void);
const pad_info_t *input_pad_info(int idx);
/* Move the pad currently on `port_a` to `port_b` (swaps if occupied). */
void input_swap_ports(int port_a, int port_b);
int input_connected_count(void);

/* Remapping: while capturing, the next physical button press is stored in
 * *out_code (PBTN_*) and capture ends. */
void input_capture_begin(void);
void input_capture_cancel(void);
bool input_capture_active(void);
bool input_capture_result(int *out_code);

/* While the pause menu is up we stop feeding the game. */
void input_set_game_active(bool active);
/* Reset the default mapping to the standard layout. */
void input_default_map(int map[B3DO_COUNT]);

#endif
