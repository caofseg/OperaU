/*
 * Thin access to a few Opera internals that the libretro API does not expose.
 * Kept in its own translation unit so the rest of the frontend never includes
 * the core's headers.
 */
#ifndef OPERAU_OPERA_HOOKS_H
#define OPERAU_OPERA_HOOKS_H

#include <stdbool.h>
#include <stdint.h>

/* Remember the current NVRAM contents as "already on disk" (call after the
 * core loaded the game, and after every flush). */
void opera_hooks_nvram_baseline(void);

/* Writes the 3DO's battery-backed memory to the save file if it changed since
 * the last baseline. Opera itself only does this when a game is unloaded or
 * reset, which would lose progress on a crash or power loss. Returns true when
 * something was written. Must run on the emulation thread, between frames. */
bool opera_hooks_nvram_flush(const char *game_path);

/* True once the 3DO core finished initialising for the current content. */
bool opera_hooks_core_ready(void);

#endif
