/*
 * A running game: owns the emulation thread, the pause protocol, save states,
 * screenshots and the lifecycle (launch -> run -> close).
 *
 * Thread model
 *   UI thread   : window, input, menus, GX2 present (Wii U core 1)
 *   emu thread  : core_run() + pacing (Wii U core 2 by default)
 *   audio       : SDL audio callback (system thread)
 * Anything that touches the core from the UI thread (save state, reset,
 * unload ...) happens only while the emulation thread is parked.
 */
#ifndef OPERAU_SESSION_H
#define OPERAU_SESSION_H

#include "common.h"
#include "ui.h"

bool session_init(void);
void session_shutdown(void);

/* path == NULL boots the BIOS without a disc. On failure session_error()
 * explains why (shown to the user). */
bool session_launch(const char *path, bool resume_auto_state);
bool session_resumed(void);             /* the last launch applied the automatic state */
void session_close_game(void);          /* autosaves a state if enabled */

bool session_active(void);              /* a game (or the BIOS) is loaded */
bool session_running(void);             /* the emulation thread is running */
void session_pause(void);               /* blocks until the thread parked */
void session_resume(void);
const char *session_title(void);
const char *session_error(void);

bool session_save_state(int slot);      /* slot 0..9, requires paused */
bool session_load_state(int slot);
bool session_state_exists(int slot);
bool session_autostate_exists(const char *game_path);
bool session_screenshot(char *out_path, size_t cap);
void session_reset(void);

void session_hud(ui_hud_t *out);
/* The core asked to stop (RETRO_ENVIRONMENT_SHUTDOWN). */
bool session_core_wants_exit(void);

#endif
