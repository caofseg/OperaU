#!/bin/bash
# Builds tools/ppcsim/layout_test.c for x86 and PowerPC, runs both (PowerPC under
# qemu-ppc) and diffs the output. Usage:
#   QEMU_PPC=/path/to/qemu-ppc DEVKITPPC=/opt/devkitpro/devkitPPC tools/ppcsim/run_layout_test.sh
set -e
HERE=$(cd "$(dirname "$0")" && pwd)
ROOT=$(cd "$HERE/../.." && pwd)
OUT=${OUT:-$ROOT/build-ppcsim/layout}
DEVKITPPC=${DEVKITPPC:-/opt/devkitpro/devkitPPC}
QEMU_PPC=${QEMU_PPC:-qemu-ppc}
CORE=$ROOT/third_party/opera-libretro/libopera
mkdir -p "$OUT"

# Extract the real struct definitions from the vendored sources.
sed -n '/^struct CIFTAG_s$/,/^typedef union dsp_alu_flags_u dsp_alu_flags_t;$/p' "$CORE/opera_dsp.c" > "$OUT/gen_dsp_structs.h"
sed -n '/^struct cp1btag_s$/,/^typedef union PXC_u PXC_t;$/p' "$CORE/opera_madam.c" > "$OUT/gen_madam_structs.h"
for f in gen_dsp_structs.h gen_madam_structs.h; do
    [ -s "$OUT/$f" ] || { echo "could not extract $f"; exit 2; }
done

INC="-I$OUT -I$CORE"
PPCCC="$DEVKITPPC/bin/powerpc-eabi-gcc"
ARCH="-mcpu=750 -meabi -mhard-float"
gcc -O1 -std=gnu11 $INC -o "$OUT/layout_x86" "$HERE/layout_test.c"
# Same start-up / system-call layer as the core harness (see sys.c, crt0.S).
"$PPCCC" $ARCH -c "$HERE/crt0.S" -o "$OUT/crt0.o"
"$PPCCC" -O1 -std=gnu11 $ARCH -DMSB_FIRST -c "$HERE/sys.c" -o "$OUT/sys.o"
"$PPCCC" -O1 -std=gnu11 $ARCH -DMSB_FIRST $INC -c "$HERE/layout_test.c" -o "$OUT/layout_test_ppc.o"
"$PPCCC" $ARCH -static -nostartfiles -nodefaultlibs -Wl,--gc-sections -o "$OUT/layout_ppc.elf" \
    "$OUT/crt0.o" "$OUT/sys.o" "$OUT/layout_test_ppc.o" -Wl,--start-group -lc -lm -lgcc -lnosys -Wl,--end-group

"$OUT/layout_x86" > "$OUT/x86.txt"
timeout 600 "$QEMU_PPC" -cpu 750 "$OUT/layout_ppc.elf" > "$OUT/ppc.txt"
echo "x86: $(grep -c '^[RW] ' "$OUT/x86.txt") field checks, ppc: $(grep -c '^[RW] ' "$OUT/ppc.txt")"
if diff <(grep '^[RW] ' "$OUT/x86.txt") <(grep '^[RW] ' "$OUT/ppc.txt") > "$OUT/diff.txt" 2>/dev/null || \
   diff "$OUT/x86.txt" "$OUT/ppc.txt" > "$OUT/diff.txt"; then
    echo "layout test: PowerPC bit-field layout identical to x86"
else
    echo "layout test: DIFFERENCES"; head -40 "$OUT/diff.txt"; exit 1
fi
