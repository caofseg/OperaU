/*
 * Embeds the UI font (DejaVu Sans, Bitstream Vera license - see
 * assets/LICENSE-DejaVu.txt) into the executable. FONT_PATH is passed by the
 * Makefiles.
 */
#ifndef FONT_PATH
#error "FONT_PATH must point to assets/DejaVuSans.ttf"
#endif

__asm__(".section .rodata\n"
        ".balign 16\n"
        ".global operau_font_start\n"
        "operau_font_start:\n"
        ".incbin \"" FONT_PATH "\"\n"
        ".global operau_font_end\n"
        "operau_font_end:\n"
        ".byte 0\n"
        ".previous\n");
