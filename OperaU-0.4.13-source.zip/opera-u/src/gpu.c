/*
 * The pixel-processor probe: does the Wii U's GPU get the 3DO's arithmetic right, and what does it cost to hand a
 * frame back to the CPU?
 *
 * See src/gpu.h for why those two questions decide whether the cel engine could move to the GPU at all.
 *
 * The shader is in shaders/pprobe.frag and is a line-for-line copy of the CPU's pixel processor. It is compiled
 * here, on a PC, by CafeGLSL, and embedded in the program: the Wii U cannot compile a shader while it runs, and
 * devkitPro ships no compiler for it. shaders/build_shaders.sh rebuilds it.
 */

#include "gpu.h"

#include "common.h"
#include "log.h"
#include "platform.h"

#include <stdio.h>
#include <string.h>

#ifdef __WIIU__

#include <malloc.h>

#include <gfd.h>
#include <gx2/draw.h>
#include <gx2/enum.h>
#include <gx2/mem.h>
#include <gx2/registers.h>
#include <gx2/sampler.h>
#include <gx2/shaders.h>
#include <gx2/state.h>
#include <gx2/surface.h>
#include <gx2/texture.h>
#include <gx2/context.h>
#include <gx2/event.h>
#include <gx2/utils.h>
#include <gx2r/mem.h>
#include <gx2r/resource.h>
#include <gx2r/surface.h>

extern const uint8_t  shader_pprobe[];
extern const uint32_t shader_pprobe_size;

#define PROBE_W 320
#define PROBE_H 240

/* How the pixel processor is set up for one run of the probe. These are the values that stay fixed for a whole
   cel on the real hardware, which is exactly why the CPU can precompute a table for them - and why a shader can
   take them as uniforms. */
typedef struct {
    const char *name;
    int mode; /* 0 = the pixel processor, 1 = the source read back, 2 = the table read back, 3 = coordinates */
    int use8; /* 1 = take the pixel from the 8-bit colour texture instead of the 16-bit integer one */
    int ms, mxf, dv1, dv2, dv3, s2, av, neg, xtend, nclip;
    uint32_t pxor1, pxor2;
} probe_config_t;

/*
 * What to run. The two reads come first on purpose: if the shader does not see the numbers that were written for
 * it, nothing the arithmetic does afterwards means anything, and knowing that saves looking for a fault in the
 * sums that is really in the byte order or the surface layout.
 *
 * Then the shapes of the pixel processor. The first is the one almost every cel of a real game uses, and the rest
 * turn on the parts that are easy to get wrong somewhere else: the sign-propagating shift, the truncation to
 * eight bits, the clamping, and the table lookup indexed by the pixel itself.
 */
static const probe_config_t g_configs[] = {
    /* name           md u8 ms mxf dv1 dv2 dv3 s2  av  neg xt ncl  pxor1       pxor2 */
    { "coords",        3, 0, 0,  0,  0,  0,  0,  0,   0,  0, 0, 0,  0xFFFFFFFF, 0xFFFFFFFF },
    { "src16",         1, 0, 0,  0,  0,  0,  0,  0,   0,  0, 0, 0,  0xFFFFFFFF, 0xFFFFFFFF },
    { "src8",          1, 1, 0,  0,  0,  0,  0,  0,   0,  0, 0, 0,  0xFFFFFFFF, 0xFFFFFFFF },
    { "table",         2, 0, 0,  5,  2,  0,  0,  0,   0,  0, 0, 0,  0xFFFFFFFF, 0xFFFFFFFF },

    { "plain",         0, 0, 0,  7,  0,  0,  0,  0,   0,  0, 0, 0,  0xFFFFFFFF, 0xFFFFFFFF },
    { "colour2 av",    0, 0, 0,  3,  1,  1,  2,  1, 170,  0, 0, 0,  0xFFFFFFFF, 0xFFFFFFFF },
    { "negated",       0, 0, 0,  5,  2,  1,  1,  1,  90,  1, 0, 0,  0xFFFFFFFF, 0xFFFFFFFF },
    { "sign extend",   0, 0, 0,  6,  3,  2,  3,  3,  35,  0, 1, 0,  0xFF7FFFFF, 0xFFFFFF7F },
    { "no clip",       0, 0, 0,  7,  1,  0,  0,  1, 200,  1, 1, 1,  0xFFFFFFFF, 0xFFFFFFFF },
    { "pixel scaled",  0, 0, 2,  0,  0,  1,  2,  2,   0,  0, 0, 0,  0x7FFFFFFF, 0xFFFF7FFF },
    { "pixel mxf",     0, 0, 3,  0,  2,  1,  1,  3,  12,  0, 1, 0,  0xFFFFFFFF, 0xFFFFFFFF },
    { "masked lanes",  0, 0, 0,  4,  1,  1,  0,  1, 255,  0, 0, 0,  0x0F1F3FFF, 0xFF3F1F0F },

    /* the same eight again, reading the pixel from the 8-bit texture, so that whichever way of handing the
       numbers over works, this run also says whether the arithmetic on top of it is right */
    { "plain/8",       0, 1, 0,  7,  0,  0,  0,  0,   0,  0, 0, 0,  0xFFFFFFFF, 0xFFFFFFFF },
    { "colour2 av/8",  0, 1, 0,  3,  1,  1,  2,  1, 170,  0, 0, 0,  0xFFFFFFFF, 0xFFFFFFFF },
    { "negated/8",     0, 1, 0,  5,  2,  1,  1,  1,  90,  1, 0, 0,  0xFFFFFFFF, 0xFFFFFFFF },
    { "sign extend/8", 0, 1, 0,  6,  3,  2,  3,  3,  35,  0, 1, 0,  0xFF7FFFFF, 0xFFFFFF7F },
    { "no clip/8",     0, 1, 0,  7,  1,  0,  0,  1, 200,  1, 1, 1,  0xFFFFFFFF, 0xFFFFFFFF },
    { "pixel scaled/8",0, 1, 2,  0,  0,  1,  2,  2,   0,  0, 0, 0,  0x7FFFFFFF, 0xFFFF7FFF },
    { "pixel mxf/8",   0, 1, 3,  0,  2,  1,  1,  3,  12,  0, 1, 0,  0xFFFFFFFF, 0xFFFFFFFF },
    { "masked lanes/8",0, 1, 0,  4,  1,  1,  0,  1, 255,  0, 0, 0,  0x0F1F3FFF, 0xFF3F1F0F },
};

#define NUM_CONFIGS ((int)(sizeof(g_configs) / sizeof(g_configs[0])))

static uint8_t g_pscalar[8][4][32];

/* PDV and PSCALAR as opera_madam.c builds them. Rebuilt here from the formula rather than reached into, so that
   the probe compares two independent implementations instead of one talking to itself. */
static void build_pscalar(void)
{
    int i, j, n;

    for (i = 0; i < 32; i++)
        for (j = 0; j < 8; j++)
            for (n = 0; n < 4; n++)
                g_pscalar[j][n][i] = (uint8_t)((i * (j + 1)) >> (((n - 1) & 3) + 1));
}

static int s8(int x)
{
    return (int)(int8_t)x;
}

static int clamp_i(int v, int lo, int hi)
{
    return v < lo ? lo : (v > hi ? hi : v);
}

/* The CPU's answer for one channel. Kept in the same order and the same types as pp_build_lut_half(). */
static int cpu_channel(const probe_config_t *c, int v, int px1, int px2)
{
    int c1, c2, aop, bop, o;

    if (c->ms == 0)
        c1 = s8(g_pscalar[c->mxf & 7][c->dv1 & 3][v & 31]);
    else if (c->ms == 2)
        c1 = s8(g_pscalar[(v >> 2) & 7][v & 3][v & 31]);
    else
        c1 = s8(g_pscalar[(v >> 2) & 7][c->dv1 & 3][v & 31]);

    if (c->s2 == 0)
        c2 = 0;
    else if (c->s2 == 1)
        c2 = s8(c->av >> c->dv3);
    else
        c2 = s8(v >> c->dv3);

    aop = s8(c1 & px1);
    c1 = s8(c1 & px2);
    bop = s8(c->neg ? (c2 ^ -1) : (c2 ^ c1));

    if (c->xtend)
        bop = s8((bop << 3) >> 3);

    o = s8((aop + bop + c->neg) >> c->dv2);

    if (!c->nclip)
        o = clamp_i(o, 0, 31);

    return o & 31;
}

/* The source pixel for a column. It depends on x alone, so that however the GPU orients the target the comparison
   stays valid; 320 columns give every channel a wide spread of the 32 values that matter. */
static uint16_t probe_pixel(int x)
{
    return (uint16_t)((x * 2053 + 7) & 0xFFFF);
}

static uint32_t uniform_offset(const GX2PixelShader *ps, const char *name)
{
    uint32_t i;

    for (i = 0; i < ps->uniformVarCount; i++)
        if (ps->uniformVars[i].name && strcmp(ps->uniformVars[i].name, name) == 0)
            return ps->uniformVars[i].offset;
    return 0xFFFFFFFFu;
}

static bool sampler_location(const GX2PixelShader *ps, const char *name, uint32_t *out)
{
    uint32_t i;

    for (i = 0; i < ps->samplerVarCount; i++)
        if (ps->samplerVars[i].name && strcmp(ps->samplerVars[i].name, name) == 0) {
            *out = ps->samplerVars[i].location;
            return true;
        }
    return false;
}

static GX2VertexShader *load_vs(const void *gsh)
{
    uint32_t header, program;
    GX2VertexShader *vs;
    void *p;

    if (GFDGetVertexShaderCount(gsh) < 1)
        return NULL;
    if ((header = GFDGetVertexShaderHeaderSize(0, gsh)) == 0)
        return NULL;
    if ((program = GFDGetVertexShaderProgramSize(0, gsh)) == 0)
        return NULL;
    if (!(vs = memalign(0x40, header)))
        return NULL;

    memset(vs, 0, header);
    vs->gx2rBuffer.flags = GX2R_RESOURCE_BIND_SHADER_PROGRAM | GX2R_RESOURCE_USAGE_CPU_READ |
                           GX2R_RESOURCE_USAGE_CPU_WRITE | GX2R_RESOURCE_USAGE_GPU_READ;
    vs->gx2rBuffer.elemSize = program;
    vs->gx2rBuffer.elemCount = 1;
    vs->gx2rBuffer.buffer = NULL;
    if (!GX2RCreateBuffer(&vs->gx2rBuffer)) {
        free(vs);
        return NULL;
    }
    p = GX2RLockBufferEx(&vs->gx2rBuffer, GX2R_RESOURCE_BIND_NONE);
    if (!GFDGetVertexShader(vs, p, 0, gsh)) {
        GX2RUnlockBufferEx(&vs->gx2rBuffer,
                           GX2R_RESOURCE_DISABLE_CPU_INVALIDATE | GX2R_RESOURCE_DISABLE_GPU_INVALIDATE);
        GX2RDestroyBufferEx(&vs->gx2rBuffer, GX2R_RESOURCE_BIND_NONE);
        free(vs);
        return NULL;
    }
    GX2RUnlockBufferEx(&vs->gx2rBuffer, GX2R_RESOURCE_BIND_NONE);
    GX2Invalidate(GX2_INVALIDATE_MODE_CPU_SHADER, vs->program, vs->size);
    return vs;
}

static GX2PixelShader *load_ps(const void *gsh)
{
    uint32_t header, program;
    GX2PixelShader *ps;
    void *p;

    if (GFDGetPixelShaderCount(gsh) < 1)
        return NULL;
    if ((header = GFDGetPixelShaderHeaderSize(0, gsh)) == 0)
        return NULL;
    if ((program = GFDGetPixelShaderProgramSize(0, gsh)) == 0)
        return NULL;
    if (!(ps = memalign(0x40, header)))
        return NULL;

    memset(ps, 0, header);
    ps->gx2rBuffer.flags = GX2R_RESOURCE_BIND_SHADER_PROGRAM | GX2R_RESOURCE_USAGE_CPU_READ |
                           GX2R_RESOURCE_USAGE_CPU_WRITE | GX2R_RESOURCE_USAGE_GPU_READ;
    ps->gx2rBuffer.elemSize = program;
    ps->gx2rBuffer.elemCount = 1;
    ps->gx2rBuffer.buffer = NULL;
    if (!GX2RCreateBuffer(&ps->gx2rBuffer)) {
        free(ps);
        return NULL;
    }
    p = GX2RLockBufferEx(&ps->gx2rBuffer, GX2R_RESOURCE_BIND_NONE);
    if (!GFDGetPixelShader(ps, p, 0, gsh)) {
        GX2RUnlockBufferEx(&ps->gx2rBuffer,
                           GX2R_RESOURCE_DISABLE_CPU_INVALIDATE | GX2R_RESOURCE_DISABLE_GPU_INVALIDATE);
        GX2RDestroyBufferEx(&ps->gx2rBuffer, GX2R_RESOURCE_BIND_NONE);
        free(ps);
        return NULL;
    }
    GX2RUnlockBufferEx(&ps->gx2rBuffer, GX2R_RESOURCE_BIND_NONE);
    GX2Invalidate(GX2_INVALIDATE_MODE_CPU_SHADER, ps->program, ps->size);
    return ps;
}

/* A surface the GPU draws into and the CPU then reads. Linear so that the CPU sees rows, and marked for CPU
   reading so that GX2R puts it where both can reach it. */
static bool make_target(GX2Texture *tex, GX2ColorBuffer *cb)
{
    memset(tex, 0, sizeof(*tex));
    tex->surface.use = (GX2SurfaceUse)(GX2_SURFACE_USE_TEXTURE | GX2_SURFACE_USE_COLOR_BUFFER);
    tex->surface.dim = GX2_SURFACE_DIM_TEXTURE_2D;
    tex->surface.width = PROBE_W;
    tex->surface.height = PROBE_H;
    tex->surface.depth = 1;
    tex->surface.mipLevels = 1;
    tex->surface.format = GX2_SURFACE_FORMAT_UNORM_R8_G8_B8_A8;
    tex->surface.aa = GX2_AA_MODE1X;
    tex->surface.tileMode = GX2_TILE_MODE_LINEAR_ALIGNED;
    tex->viewNumMips = 1;
    tex->viewNumSlices = 1;
    tex->compMap = 0x00010203;
    GX2CalcSurfaceSizeAndAlignment(&tex->surface);
    GX2InitTextureRegs(tex);

    if (!GX2RCreateSurface(&tex->surface, GX2R_RESOURCE_BIND_TEXTURE | GX2R_RESOURCE_BIND_COLOR_BUFFER |
                                              GX2R_RESOURCE_USAGE_CPU_READ | GX2R_RESOURCE_USAGE_CPU_WRITE |
                                              GX2R_RESOURCE_USAGE_GPU_WRITE | GX2R_RESOURCE_USAGE_GPU_READ |
                                              GX2R_RESOURCE_USAGE_FORCE_MEM2))
        return false;

    memset(cb, 0, sizeof(*cb));
    cb->surface = tex->surface;
    cb->viewNumSlices = 1;
    GX2InitColorBufferRegs(cb);
    return true;
}

/* A texture of plain numbers: a 16-bit unsigned integer per texel, read with texelFetch and never filtered, so
   nothing between the value written here and the value the shader works on. */
static bool make_source(GX2Texture *tex, int w, int h, GX2SurfaceFormat fmt)
{
    memset(tex, 0, sizeof(*tex));
    tex->surface.use = GX2_SURFACE_USE_TEXTURE;
    tex->surface.dim = GX2_SURFACE_DIM_TEXTURE_2D;
    tex->surface.width = (uint32_t)w;
    tex->surface.height = (uint32_t)h;
    tex->surface.depth = 1;
    tex->surface.mipLevels = 1;
    tex->surface.format = fmt;
    tex->surface.aa = GX2_AA_MODE1X;
    tex->surface.tileMode = GX2_TILE_MODE_LINEAR_ALIGNED;
    tex->viewNumMips = 1;
    tex->viewNumSlices = 1;
    /*
     * A one-channel format tells the other three components to read 0, 0 and 1 rather than pointing at channels
     * the format does not have (4 means zero and 5 means one in a component map). A four-channel one must not:
     * giving the 8-bit colour texture the single-channel map is what made its green always read as zero, while
     * the table texture, which really is one channel, read perfectly with it.
     */
    tex->compMap = (fmt == GX2_SURFACE_FORMAT_UNORM_R8_G8_B8_A8) ? 0x00010203 : 0x00040405;
    GX2CalcSurfaceSizeAndAlignment(&tex->surface);
    GX2InitTextureRegs(tex);

    return GX2RCreateSurface(&tex->surface, GX2R_RESOURCE_BIND_TEXTURE | GX2R_RESOURCE_USAGE_CPU_WRITE |
                                                GX2R_RESOURCE_USAGE_GPU_READ |
                                                GX2R_RESOURCE_USAGE_FORCE_MEM2) != FALSE;
}

static void fail(gpu_probe_t *out, const char *why)
{
    snprintf(out->err, sizeof(out->err), "%s", why);
}

bool gpu_probe(gpu_probe_t *out)
{
    /* A triangle strip, which every path supports, rather than a quad whose winding could matter. */
    static const float quad[8] = { -1.0f, -1.0f, 1.0f, -1.0f, -1.0f, 1.0f, 1.0f, 1.0f };

    GX2VertexShader *vs = NULL;
    GX2PixelShader *ps = NULL;
    GX2ContextState *ctx = NULL;
    GX2FetchShader fs;
    void *fs_program = NULL;
    GX2AttribStream attrib;
    GX2Texture target, src, src8, lut;
    GX2Sampler sampler;
    bool have_target = false, have_src = false, have_src8 = false, have_lut = false, have_fs = false;
    uint32_t src_unit = 0, src8_unit = 0, lut_unit = 0;
    float *verts = NULL;
    uint8_t *px;
    int i, x, cfg;
    uint64_t t0;
    const int draws = 60;

    memset(out, 0, sizeof(*out));
    build_pscalar();

    /*
     * The probe works inside a context state of its own. A GX2 context state records the registers written while
     * it is active, and the renderer keeps one for itself: writing the probe's shaders and render target while
     * the renderer's context was active would store them in the renderer's own saved state, and the screen would
     * keep drawing with them afterwards. With a context of its own, nothing the probe sets is ever recorded in
     * the renderer's, and the renderer puts its context back before it draws anything (it does that right after
     * every SDL_RenderClear, which happens once a frame in src/video.c).
     */
    if (!(ctx = memalign(GX2_CONTEXT_STATE_ALIGNMENT, sizeof(GX2ContextState)))) {
        fail(out, "no room for a GX2 context state of the probe's own");
        goto done;
    }
    memset(ctx, 0, sizeof(GX2ContextState));
    GX2SetupContextStateEx(ctx, TRUE);
    GX2SetContextState(ctx);

    if (!(vs = load_vs(shader_pprobe))) {
        fail(out, "the vertex shader would not load from the embedded .gsh");
        goto done;
    }
    if (!(ps = load_ps(shader_pprobe))) {
        fail(out, "the pixel shader would not load from the embedded .gsh");
        goto done;
    }
    if (!sampler_location(ps, "u_src", &src_unit) || !sampler_location(ps, "u_pscalar", &lut_unit) ||
        !sampler_location(ps, "u_src8", &src8_unit)) {
        fail(out, "the shader does not carry the sampler names the probe sets");
        goto done;
    }

    {
        uint32_t size = GX2CalcFetchShaderSizeEx(1, GX2_FETCH_SHADER_TESSELLATION_NONE,
                                                 GX2_TESSELLATION_MODE_DISCRETE);
        if (!size || !(fs_program = memalign(GX2_SHADER_PROGRAM_ALIGNMENT, size))) {
            fail(out, "no room for the fetch shader");
            goto done;
        }
        attrib.location = 0;
        attrib.buffer = 0;
        attrib.offset = 0;
        attrib.format = GX2_ATTRIB_FORMAT_FLOAT_32_32;
        attrib.type = GX2_ATTRIB_INDEX_PER_VERTEX;
        attrib.aluDivisor = 0;
        attrib.mask = GX2_SEL_MASK(GX2_SQ_SEL_X, GX2_SQ_SEL_Y, GX2_SQ_SEL_0, GX2_SQ_SEL_1);
        attrib.endianSwap = GX2_ENDIAN_SWAP_DEFAULT;
        GX2InitFetchShaderEx(&fs, fs_program, 1, &attrib, GX2_FETCH_SHADER_TESSELLATION_NONE,
                             GX2_TESSELLATION_MODE_DISCRETE);
        GX2Invalidate(GX2_INVALIDATE_MODE_CPU_SHADER, fs_program, size);
        have_fs = true;
    }

    if (!(verts = memalign(GX2_VERTEX_BUFFER_ALIGNMENT, sizeof(quad)))) {
        fail(out, "no room for the quad");
        goto done;
    }
    memcpy(verts, quad, sizeof(quad));
    GX2Invalidate(GX2_INVALIDATE_MODE_CPU_ATTRIBUTE_BUFFER, verts, sizeof(quad));

    {
        GX2ColorBuffer cb;

        if (!make_target(&target, &cb)) {
            fail(out, "the GPU would not give a 320x240 target the CPU can read");
            goto done;
        }
        have_target = true;

        /* Full height, even though every row holds the same thing: texelFetch does not clamp, so a shader reading
           row 239 of a one-row texture reads whatever happens to follow it in memory. */
        if (!make_source(&src, PROBE_W, PROBE_H, GX2_SURFACE_FORMAT_UINT_R16)) {
            fail(out, "the source texture would not be created");
            goto done;
        }
        have_src = true;

        if (!make_source(&src8, PROBE_W, PROBE_H, GX2_SURFACE_FORMAT_UNORM_R8_G8_B8_A8)) {
            fail(out, "the 8-bit source texture would not be created");
            goto done;
        }
        have_src8 = true;

        if (!make_source(&lut, 32, 32, GX2_SURFACE_FORMAT_UINT_R8)) {
            fail(out, "the table texture would not be created");
            goto done;
        }
        have_lut = true;

        /* Fill the source. The pattern depends on the column alone, but every row gets it, so that wherever the
           target's first row came from vertically the shader read a value that was written on purpose. The stride
           between rows is the surface's pitch, which counts pixels, not bytes. */
        {
            uint8_t *base = (uint8_t *)GX2RLockSurfaceEx(&src.surface, 0, GX2R_RESOURCE_BIND_NONE);
            int row;

            if (!base) {
                fail(out, "the source texture would not lock");
                goto done;
            }
            for (row = 0; row < PROBE_H; row++) {
                uint16_t *p = (uint16_t *)(base + (size_t)row * src.surface.pitch * 2u);

                for (x = 0; x < PROBE_W; x++)
                    p[x] = probe_pixel(x);
            }
            GX2RUnlockSurfaceEx(&src.surface, 0, GX2R_RESOURCE_BIND_NONE);
            /* Say outright that the CPU wrote a texture. The unlock above is meant to do this, and if it already
               did, saying it again costs one call; if it did not, the GPU would read stale memory - which is
               exactly what zeros coming back from every read would look like. */
            GX2Invalidate(GX2_INVALIDATE_MODE_CPU_TEXTURE, src.surface.image, src.surface.imageSize);
        }

        /* The same values as plain bytes: high byte in red, low byte in green. */
        {
            uint8_t *base = (uint8_t *)GX2RLockSurfaceEx(&src8.surface, 0, GX2R_RESOURCE_BIND_NONE);
            int row;

            if (!base) {
                fail(out, "the 8-bit source texture would not lock");
                goto done;
            }
            for (row = 0; row < PROBE_H; row++) {
                uint8_t *q = base + (size_t)row * src8.surface.pitch * 4u;

                for (x = 0; x < PROBE_W; x++) {
                    uint16_t v = probe_pixel(x);

                    q[x * 4 + 0] = (uint8_t)(v >> 8);
                    q[x * 4 + 1] = (uint8_t)v;
                    q[x * 4 + 2] = 0;
                    q[x * 4 + 3] = 255;
                }
            }
            GX2RUnlockSurfaceEx(&src8.surface, 0, GX2R_RESOURCE_BIND_NONE);
            GX2Invalidate(GX2_INVALIDATE_MODE_CPU_TEXTURE, src8.surface.image, src8.surface.imageSize);
        }

        /* fill the table: index mxf<<7 | dv1<<5 | v, laid out 32 wide */
        {
            uint8_t *base = (uint8_t *)GX2RLockSurfaceEx(&lut.surface, 0, GX2R_RESOURCE_BIND_NONE);

            if (!base) {
                fail(out, "the table texture would not lock");
                goto done;
            }
            for (i = 0; i < 1024; i++) {
                int mxf = (i >> 7) & 7, dv1 = (i >> 5) & 3, v = i & 31;

                base[(i >> 5) * lut.surface.pitch + (i & 31)] = g_pscalar[mxf][dv1][v];
            }
            GX2RUnlockSurfaceEx(&lut.surface, 0, GX2R_RESOURCE_BIND_NONE);
            GX2Invalidate(GX2_INVALIDATE_MODE_CPU_TEXTURE, lut.surface.image, lut.surface.imageSize);
        }

        GX2InitSampler(&sampler, GX2_TEX_CLAMP_MODE_CLAMP, GX2_TEX_XY_FILTER_MODE_POINT);

        /* Draw into our own target rather than the screen, so nothing the probe does can be seen or can disturb
           what the renderer is drawing. */
        GX2SetColorBuffer(&cb, GX2_RENDER_TARGET_0);
        GX2SetViewport(0.0f, 0.0f, (float)PROBE_W, (float)PROBE_H, 0.0f, 1.0f);
        GX2SetScissor(0, 0, PROBE_W, PROBE_H);
        GX2SetDepthOnlyControl(FALSE, FALSE, GX2_COMPARE_FUNC_ALWAYS);
        GX2SetColorControl(GX2_LOGIC_OP_COPY, 0, FALSE, TRUE);
        /* No culling, so which way round the quad is wound cannot decide whether anything is drawn at all. */
        GX2SetCullOnlyControl(GX2_FRONT_FACE_CCW, FALSE, FALSE);
        GX2SetAlphaTest(FALSE, GX2_COMPARE_FUNC_ALWAYS, 0.0f);
        /*
         * Choose how uniforms are passed, before anything is drawn. GX2 uses one mode for the vertex and the
         * pixel shader of a draw, and the shader was compiled to read its uniforms from registers, so that mode
         * has to be selected or every register written here is ignored and the shader sees zeros. Missing this
         * call is what made the probe report that the GPU's arithmetic differed: it was not computing the wrong
         * answer, it was computing with nothing - all 20 shapes it tried came out identically zero, which
         * matched the CPU exactly in the two cases where the CPU's answer is zero as well.
         */
        GX2SetShaderMode(GX2_SHADER_MODE_UNIFORM_REGISTER);
        GX2SetFetchShader(&fs);
        GX2SetVertexShader(vs);
        GX2SetPixelShader(ps);
        GX2SetAttribBuffer(0, sizeof(quad), 2 * sizeof(float), verts);
        GX2SetPixelTexture(&src, src_unit);
        GX2SetPixelSampler(&sampler, src_unit);
        GX2SetPixelTexture(&src8, src8_unit);
        GX2SetPixelSampler(&sampler, src8_unit);
        GX2SetPixelTexture(&lut, lut_unit);
        GX2SetPixelSampler(&sampler, lut_unit);

        /*
         * ---- which way of writing a uniform actually reaches the shader ----
         *
         * Everything below this point is meaningless if uniforms do not arrive, and in three builds they did not:
         * every shape came out identically zero, which is what the shader computes when every uniform reads as
         * zero. The shader's own constant did arrive, so the shader runs and its output reaches the target; what
         * is left is the hand-over of the uniforms themselves, and the documentation does not settle which unit
         * the offset is in. So instead of guessing a fourth time, each candidate writes a different value into
         * the one uniform the shader echoes into alpha, and whichever value comes back names the winner.
         */
        {
            uint32_t off = uniform_offset(ps, "u_echo");
            int32_t vec[4];
            int v;

            for (v = 0; v < 6 && off != 0xFFFFFFFFu; v++) {
                static const char *names[6] = { "offset as given", "offset / 4",   "as given, whole reg",
                                                "/ 4, whole reg",  "vertex shader", "offset * 4" };
                int32_t value = 0x40 + v;

                vec[0] = vec[1] = vec[2] = vec[3] = value;
                switch (v) {
                case 0: GX2SetPixelUniformReg(off, 1, &value); break;
                case 1: GX2SetPixelUniformReg(off / 4, 1, &value); break;
                case 2: GX2SetPixelUniformReg(off, 4, vec); break;
                case 3: GX2SetPixelUniformReg(off / 4, 4, vec); break;
                case 4: GX2SetVertexUniformReg(off, 1, &value); break;
                default: GX2SetPixelUniformReg(off * 4, 1, &value); break;
                }

                px = (uint8_t *)GX2RLockSurfaceEx(&target.surface, 0, GX2R_RESOURCE_BIND_NONE);
                if (px) {
                    memset(px, 0xA5, (size_t)PROBE_W * 4u);
                    GX2RUnlockSurfaceEx(&target.surface, 0, GX2R_RESOURCE_BIND_NONE);
                }
                GX2DrawEx(GX2_PRIMITIVE_MODE_TRIANGLE_STRIP, 4, 0, 1);
                GX2DrawDone();
                GX2RInvalidateSurface(&target.surface, 0, GX2R_RESOURCE_BIND_TEXTURE);
                px = (uint8_t *)GX2RLockSurfaceEx(&target.surface, 0, GX2R_RESOURCE_LOCKED_READ_ONLY);
                if (px && out->uni_n < (int)(sizeof(out->uni) / sizeof(out->uni[0]))) {
                    out->uni[out->uni_n].name = names[v];
                    out->uni[out->uni_n].want = (uint8_t)value;
                    out->uni[out->uni_n].got = px[3]; /* alpha, where the shader echoes it */
                    out->uni_n++;
                }
                if (px)
                    GX2RUnlockSurfaceEx(&target.surface, 0, GX2R_RESOURCE_LOCKED_READ_ONLY);
            }
            /* put it back to zero by whichever way works, so the shapes below keep the plain constant in alpha */
            {
                int32_t zero = 0;
                int32_t zv[4] = { 0, 0, 0, 0 };

                if (off != 0xFFFFFFFFu) {
                    GX2SetPixelUniformReg(off, 1, &zero);
                    GX2SetPixelUniformReg(off / 4, 1, &zero);
                    GX2SetPixelUniformReg(off, 4, zv);
                    GX2SetPixelUniformReg(off / 4, 4, zv);
                    GX2SetVertexUniformReg(off, 1, &zero);
                    GX2SetPixelUniformReg(off * 4, 1, &zero);
                }
            }
        }

        /* ---- exactness, one pixel-processor shape at a time ---- */
        for (cfg = 0; cfg < NUM_CONFIGS; cfg++) {
            const probe_config_t *c = &g_configs[cfg];
            struct {
                const char *name;
                int value;
            } u[] = {
                { "u_ms", c->ms },         { "u_mxf", c->mxf },     { "u_dv1", c->dv1 },
                { "u_dv2", c->dv2 },       { "u_dv3", c->dv3 },     { "u_s2", c->s2 },
                { "u_av", c->av },         { "u_neg", c->neg },     { "u_xtend", c->xtend },
                { "u_nclip", c->nclip },   { "u_pxor1", (int)c->pxor1 }, { "u_pxor2", (int)c->pxor2 },
                { "u_mode", c->mode },     { "u_use8", c->use8 },
            };
            uint32_t wrong_here = 0;

            for (i = 0; i < (int)(sizeof(u) / sizeof(u[0])); i++) {
                uint32_t off = uniform_offset(ps, u[i].name);
                int32_t v = u[i].value;

                int32_t v4[4];

                if (off == 0xFFFFFFFFu) {
                    fail(out, "the shader does not carry the uniform names the probe sets");
                    goto done;
                }
                /*
                 * A whole register, four words, even though each of these uniforms is one int. Writing one word
                 * does nothing at all: the six-way trial above measured it on the console - the two routes that
                 * passed a vec4 arrived, and every route that passed a single word left the shader reading zero.
                 * The count is in words and the hardware takes whole registers, so a count of 1 rounds down to
                 * nothing. Each uniform owns its own register here (the compiled offsets are 0, 4, 8 ... 52), so
                 * filling all four components is harmless; the shader reads x.
                 */
                v4[0] = v4[1] = v4[2] = v4[3] = v;
                GX2SetPixelUniformReg(off, 4, v4);
            }

            /*
             * Put a mark in the row that will be read, before the draw. If it is still there afterwards, the
             * draw never covered the target, and no amount of staring at the arithmetic would have found that.
             */
            px = (uint8_t *)GX2RLockSurfaceEx(&target.surface, 0, GX2R_RESOURCE_BIND_NONE);
            if (!px) {
                fail(out, "the target would not lock for writing the mark");
                goto done;
            }
            memset(px, 0xA5, (size_t)PROBE_W * 4u);
            GX2RUnlockSurfaceEx(&target.surface, 0, GX2R_RESOURCE_BIND_NONE);

            GX2DrawEx(GX2_PRIMITIVE_MODE_TRIANGLE_STRIP, 4, 0, 1);
            GX2DrawDone();
            GX2RInvalidateSurface(&target.surface, 0, GX2R_RESOURCE_BIND_TEXTURE);

            px = (uint8_t *)GX2RLockSurfaceEx(&target.surface, 0, GX2R_RESOURCE_LOCKED_READ_ONLY);
            if (!px) {
                fail(out, "the target would not lock for reading");
                goto done;
            }
            /*
             * The first row is the one compared. Every row of the source holds the same values, so whichever row
             * of the target came from wherever vertically, the answers for a column are the same - and reading
             * one row keeps the comparison clear of the padding at the end of a row. 320 columns give each
             * channel a wide spread of the 32 values it can take.
             */
            for (x = 0; x < PROBE_W; x++) {
                uint16_t p = probe_pixel(x);
                int want_r, want_g, want_b;

                if (c->mode == 3) {
                    want_r = x & 255;
                    want_g = 0; /* the first row: the shader puts gl_FragCoord.y here, which is 0 there */
                    want_b = 0x5A;
                } else if (c->mode == 1) {
                    want_r = (p >> 8) & 255;
                    want_g = p & 255;
                    want_b = x & 255;
                } else if (c->mode == 2) {
                    want_r = g_pscalar[c->mxf & 7][c->dv1 & 3][x & 31];
                    want_g = x & 31;
                    want_b = 0;
                } else {
                    want_r = cpu_channel(c, (p >> 10) & 31, s8((int)c->pxor1), s8((int)c->pxor2));
                    want_g = cpu_channel(c, (p >> 5) & 31, s8((int)(c->pxor1 >> 16)), s8((int)(c->pxor2 >> 16)));
                    want_b = cpu_channel(c, p & 31, s8((int)(c->pxor1 >> 8)), s8((int)(c->pxor2 >> 8)));
                }

                if (px[x * 4 + 0] == 0xA5 && px[x * 4 + 1] == 0xA5 && px[x * 4 + 2] == 0xA5)
                    out->untouched++;
                /* alpha carries a constant the shader writes without reading a uniform or a texture */
                if (px[x * 4 + 3] != 195)
                    out->beacon_wrong++;
                out->beacon_pixels++;

                if (px[x * 4 + 0] != (uint8_t)want_r || px[x * 4 + 1] != (uint8_t)want_g ||
                    px[x * 4 + 2] != (uint8_t)want_b) {
                    if (!out->sample[0])
                        snprintf(out->sample, sizeof(out->sample),
                                 "%s x=%d src=%04x got %02x %02x %02x want %02x %02x %02x", c->name, x,
                                 (unsigned)p, px[x * 4 + 0], px[x * 4 + 1], px[x * 4 + 2], (unsigned)want_r,
                                 (unsigned)want_g, (unsigned)want_b);
                    wrong_here++;
                }
                if (c->mode == 1)
                    out->src_pixels++;
                else if (c->mode == 2)
                    out->lut_pixels++;
                else if (c->mode == 0)
                    out->math_pixels++;
                out->pixels++;
            }
            GX2RUnlockSurfaceEx(&target.surface, 0, GX2R_RESOURCE_LOCKED_READ_ONLY);

            if (c->mode == 1)
                out->src_wrong += wrong_here;
            else if (c->mode == 2)
                out->lut_wrong += wrong_here;
            else if (c->mode == 0)
                out->math_wrong += wrong_here;

            if (out->per_n < (int)(sizeof(out->per) / sizeof(out->per[0]))) {
                out->per[out->per_n].name = c->name;
                out->per[out->per_n].wrong = wrong_here;
                out->per_n++;
            }
            out->wrong += wrong_here;
            out->configs++;
            if (wrong_here)
                LOGI("gpu: '%s': %u of %d differ from the CPU", c->name, (unsigned)wrong_here, PROBE_W);
        }
        out->exact = (out->wrong == 0);

        /* ---- what a frame's worth of cel-shaped draws costs ---- */
        {
            static const struct { const char *name; int draws, side; } shapes[] = {
                { "11 x 90x90 (Yu Yu)",  11, 90 },
                { "353 x 16x16 (SSF2T)", 353, 16 },
                { "64 x 48x48",          64, 48 },
                { "512 x 16x16",         512, 16 },
            };
            uint32_t uoff = uniform_offset(ps, "u_av");
            int k;

            for (k = 0; k < (int)(sizeof(shapes) / sizeof(shapes[0])); k++) {
                int i;

                GX2DrawEx(GX2_PRIMITIVE_MODE_TRIANGLE_STRIP, 4, 0, 1); /* warm up */
                GX2DrawDone();

                t0 = platform_time_us();
                for (i = 0; i < shapes[k].draws; i++) {
                    int32_t v4[4];
                    int sx = (i * 37) % (PROBE_W - shapes[k].side);
                    int sy = (i * 53) % (PROBE_H - shapes[k].side);

                    /* each cel carries its own pixel-processor settings, so a register goes with every draw */
                    v4[0] = v4[1] = v4[2] = v4[3] = i & 255;
                    if (uoff != 0xFFFFFFFFu)
                        GX2SetPixelUniformReg(uoff, 4, v4);
                    GX2SetScissor((uint32_t)sx, (uint32_t)sy, (uint32_t)shapes[k].side, (uint32_t)shapes[k].side);
                    GX2DrawEx(GX2_PRIMITIVE_MODE_TRIANGLE_STRIP, 4, 0, 1);
                }
                GX2DrawDone();

                if (out->shape_n < (int)(sizeof(out->shape) / sizeof(out->shape[0]))) {
                    out->shape[out->shape_n].name = shapes[k].name;
                    out->shape[out->shape_n].draws = shapes[k].draws;
                    out->shape[out->shape_n].side = shapes[k].side;
                    out->shape[out->shape_n].ms = (double)(platform_time_us() - t0) / 1000.0;
                    out->shape_n++;
                }
            }
            GX2SetScissor(0, 0, PROBE_W, PROBE_H);
        }

        /* ---- what a draw costs, and what the hand-off costs on top of it ---- */
        GX2DrawEx(GX2_PRIMITIVE_MODE_TRIANGLE_STRIP, 4, 0, 1); /* warm up: the first draw pays for the state above */
        GX2DrawDone();

        t0 = platform_time_us();
        for (i = 0; i < draws; i++)
            GX2DrawEx(GX2_PRIMITIVE_MODE_TRIANGLE_STRIP, 4, 0, 1);
        GX2DrawDone();
        out->draw_ms = (double)(platform_time_us() - t0) / 1000.0 / (double)draws;

        t0 = platform_time_us();
        for (i = 0; i < draws; i++) {
            GX2DrawEx(GX2_PRIMITIVE_MODE_TRIANGLE_STRIP, 4, 0, 1);
            GX2DrawDone();
            GX2RInvalidateSurface(&target.surface, 0, GX2R_RESOURCE_BIND_TEXTURE);
            px = (uint8_t *)GX2RLockSurfaceEx(&target.surface, 0, GX2R_RESOURCE_LOCKED_READ_ONLY);
            if (px) {
                /* touch both ends of the image, so the wait is for pixels the CPU really reads */
                volatile uint8_t sink = px[0];
                sink = px[target.surface.imageSize - 1];
                (void)sink;
                GX2RUnlockSurfaceEx(&target.surface, 0, GX2R_RESOURCE_LOCKED_READ_ONLY);
            }
        }
        out->trip_ms = (double)(platform_time_us() - t0) / 1000.0 / (double)draws;

        out->pitch = target.surface.pitch;
        out->image_size = target.surface.imageSize;
        out->ran = true;
        LOGI("gpu: probe: %u shapes, %u pixels, %u wrong | draw %.3f ms | draw + hand-off %.3f ms",
             (unsigned)out->configs, (unsigned)out->pixels, (unsigned)out->wrong, out->draw_ms, out->trip_ms);
    }

done:
    /* Leave no context of ours selected: the renderer puts its own back before it draws, and a freed context must
       not be the one GX2 is holding. */
    GX2SetContextState(NULL);
    if (have_lut)
        GX2RDestroySurfaceEx(&lut.surface, GX2R_RESOURCE_BIND_NONE);
    if (have_src8)
        GX2RDestroySurfaceEx(&src8.surface, GX2R_RESOURCE_BIND_NONE);
    if (have_src)
        GX2RDestroySurfaceEx(&src.surface, GX2R_RESOURCE_BIND_NONE);
    if (have_target)
        GX2RDestroySurfaceEx(&target.surface, GX2R_RESOURCE_BIND_NONE);
    if (verts)
        free(verts);
    if (have_fs && fs_program)
        free(fs_program);
    if (ps) {
        GX2RDestroyBufferEx(&ps->gx2rBuffer, GX2R_RESOURCE_BIND_NONE);
        free(ps);
    }
    if (vs) {
        GX2RDestroyBufferEx(&vs->gx2rBuffer, GX2R_RESOURCE_BIND_NONE);
        free(vs);
    }
    if (ctx)
        free(ctx);
    if (!out->ran && !out->err[0])
        fail(out, "the probe stopped before it measured anything");
    return out->ran;
}

#else /* not the console */

bool gpu_probe(gpu_probe_t *out)
{
    memset(out, 0, sizeof(*out));
    snprintf(out->err, sizeof(out->err), "there is no Wii U GPU here");
    return false;
}

#endif
