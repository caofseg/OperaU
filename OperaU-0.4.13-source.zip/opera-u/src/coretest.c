#include "coretest.h"
#include "core.h"
#include "log.h"
#include "platform.h"

typedef struct {
    uint32_t va, vb;      /* video: FNV-1a lane + position-weighted sum lane */
    uint32_t aa, ab;      /* audio, same two lanes */
    uint32_t vi, ai;      /* running indices so every value is position tagged */
    uint64_t nonzero;
    unsigned frames, aframes, w, h;
} acc_t;

static acc_t g_acc;

/* lane B: position-tagged multiplicative mix (32-bit ops only: cheap on PowerPC) */
static inline uint32_t mix_b(uint32_t h, uint32_t v, uint32_t idx)
{
    h = (h ^ (v + idx * 0x9e3779b9u)) * 0x85ebca6bu;
    return h ^ (h >> 13);
}
static bool g_null_sink; /* speed pass: touch nothing */

static void acc_reset(void)
{
    memset(&g_acc, 0, sizeof(g_acc));
    g_acc.va = g_acc.aa = 2166136261u;
}

static uint64_t acc_video(void)
{
    return ((uint64_t)g_acc.va << 32) | g_acc.vb;
}

static uint64_t acc_audio(void)
{
    return ((uint64_t)g_acc.aa << 32) | g_acc.ab;
}

static void t_video(const void *data, unsigned w, unsigned h, size_t pitch, core_pixel_format_t fmt)
{
    g_acc.frames++;
    if (g_null_sink || !data)
        return;
    g_acc.w = w;
    g_acc.h = h;
    for (unsigned y = 0; y < h; y++) {
        const uint8_t *row = (const uint8_t *)data + (size_t)y * pitch;
        if (fmt == CORE_PF_XRGB8888) {
            const uint32_t *p = (const uint32_t *)row;
            for (unsigned x = 0; x < w; x++) {
                uint32_t v = p[x] & 0x00ffffffu;
                g_acc.va = (g_acc.va ^ v) * 16777619u;
                g_acc.vb = mix_b(g_acc.vb, v, g_acc.vi++);
                g_acc.nonzero += v != 0;
            }
        } else {
            const uint16_t *p = (const uint16_t *)row;
            for (unsigned x = 0; x < w; x++) {
                uint32_t v = p[x];
                g_acc.va = (g_acc.va ^ v) * 16777619u;
                g_acc.vb = mix_b(g_acc.vb, v, g_acc.vi++);
                g_acc.nonzero += v != 0;
            }
        }
    }
}

static size_t t_audio(const int16_t *f, size_t n)
{
    g_acc.aframes += (unsigned)n;
    if (g_null_sink)
        return n;
    for (size_t i = 0; i < n * 2; i++) {
        uint32_t v = (uint16_t)f[i];
        g_acc.aa = (g_acc.aa ^ v) * 16777619u;
        g_acc.ab = mix_b(g_acc.ab, v, g_acc.ai++);
    }
    return n;
}

/* Progress / cancel for a coretest_run() that executes on a worker thread. */
static uint32_t g_prog_done, g_prog_total, g_cancel;

void coretest_progress(int *done, int *total)
{
    *done = (int)__atomic_load_n(&g_prog_done, __ATOMIC_RELAXED);
    *total = (int)__atomic_load_n(&g_prog_total, __ATOMIC_RELAXED);
}

void coretest_cancel(void)
{
    __atomic_store_n(&g_cancel, 1, __ATOMIC_RELEASE);
}

/* Returns false when the run was cancelled in the middle. */
static bool run_frames(int n)
{
    for (int i = 0; i < n; i++) {
        if (__atomic_load_n(&g_cancel, __ATOMIC_ACQUIRE))
            return false;
        core_run();
        __atomic_fetch_add(&g_prog_done, 1, __ATOMIC_RELAXED);
    }
    return true;
}

bool coretest_run(const char *image, int frames, coretest_result_t *r)
{
    core_sink_t mine = {t_video, t_audio};
    core_sink_t saved = core_get_sink();
    void *buf = NULL;
    size_t size;
    uint64_t v1, a1;

    memset(r, 0, sizeof(*r));
    r->frames = frames;
    __atomic_store_n(&g_cancel, 0, __ATOMIC_RELEASE);
    __atomic_store_n(&g_prog_done, 0, __ATOMIC_RELAXED);
    __atomic_store_n(&g_prog_total, (uint32_t)(frames + 60 + 60 + 120), __ATOMIC_RELAXED);
    core_set_sink(&mine);

    if (!core_load(image)) {
        snprintf(r->error, sizeof(r->error), "core_load: %s", core_last_error());
        core_set_sink(&saved);
        return false;
    }
    r->loaded = true;
    r->sample_rate = core_av()->sample_rate;
    r->fps = core_av()->fps;

    /* 1. boot and hash */
    g_null_sink = false;
    acc_reset();
    if (!run_frames(frames))
        goto cancelled;
    r->video_hash = acc_video();
    r->audio_hash = acc_audio();
    r->nonzero_pixels = g_acc.nonzero;
    r->width = g_acc.w;
    r->height = g_acc.h;
    r->audio_frames = g_acc.aframes;

    /* 2. a state must replay bit-exactly */
    size = core_state_size();
    r->state_size = size;
    buf = size ? malloc(size) : NULL;
    if (buf && core_state_save(buf, size)) {
        acc_reset();
        if (!run_frames(60))
            goto cancelled;
        v1 = acc_video();
        a1 = acc_audio();
        if (core_state_load(buf, size)) {
            r->state_ok = true;
            acc_reset();
            if (!run_frames(60))
                goto cancelled;
            r->replay_video_hash = acc_video();
            r->replay_audio_hash = acc_audio();
            r->deterministic = r->replay_video_hash == v1 && r->replay_audio_hash == a1;
        }
    }
    free(buf);
    buf = NULL;

    /* 3. raw speed: same work without the hashing */
    g_null_sink = true;
    {
        uint64_t t0 = platform_time_us();
        if (!run_frames(120))
            goto cancelled;
        r->ms_per_frame = (double)(platform_time_us() - t0) / 1000.0 / 120.0;
    }
    g_null_sink = false;

    core_unload();
    core_set_sink(&saved);
    return true;

cancelled:
    free(buf);
    g_null_sink = false;
    r->cancelled = true;
    snprintf(r->error, sizeof(r->error), "cancelled");
    core_unload();
    core_set_sink(&saved);
    return false;
}

bool coretest_matches_reference(const coretest_result_t *r)
{
    if (CORETEST_REF_VIDEO_HASH == 0 || r->frames != CORETEST_REF_FRAMES)
        return false;
    return r->video_hash == CORETEST_REF_VIDEO_HASH && r->audio_hash == CORETEST_REF_AUDIO_HASH;
}

/* ---- frame dump (debug) ---- */

static uint8_t *g_last;
static size_t g_last_len;
static unsigned g_last_w, g_last_h, g_last_bpp;

static void d_video(const void *data, unsigned w, unsigned h, size_t pitch, core_pixel_format_t fmt)
{
    size_t bpp = fmt == CORE_PF_XRGB8888 ? 4 : 2;
    if (!data)
        return;
    if (g_last_len != (size_t)w * h * bpp) {
        free(g_last);
        g_last_len = (size_t)w * h * bpp;
        g_last = (uint8_t *)malloc(g_last_len);
    }
    for (unsigned y = 0; y < h; y++)
        memcpy(g_last + (size_t)y * w * bpp, (const uint8_t *)data + (size_t)y * pitch, (size_t)w * bpp);
    g_last_w = w;
    g_last_h = h;
    g_last_bpp = (unsigned)bpp;
}

static size_t d_audio(const int16_t *f, size_t n)
{
    (void)f;
    return n;
}

bool coretest_dump_frame(const char *image, int frames, const char *path)
{
    core_sink_t mine = {d_video, d_audio};
    core_sink_t saved = core_get_sink();
    char txt[1100];
    FILE *f;

    core_set_sink(&mine);
    if (!core_load(image)) {
        core_set_sink(&saved);
        return false;
    }
    run_frames(frames);
    core_unload();
    core_set_sink(&saved);
    if (!g_last)
        return false;
    f = fopen(path, "wb");
    if (!f)
        return false;
    fwrite(g_last, 1, g_last_len, f);
    fclose(f);
    snprintf(txt, sizeof(txt), "%s.txt", path);
    f = fopen(txt, "w");
    if (f) {
        fprintf(f, "%u %u %u\n", g_last_w, g_last_h, g_last_bpp);
        fclose(f);
    }
    return true;
}

/* ----------------------------------------------------------------- trace */

static uint64_t hash_words(const void *mem, size_t bytes)
{
    const uint32_t *w = (const uint32_t *)mem;
    size_t n = bytes / 4;
    uint32_t a = 2166136261u, b = 0;

    for (size_t i = 0; i < n; i++) {
        a = (a ^ w[i]) * 16777619u;
        b = mix_b(b, w[i], (uint32_t)i);
    }
    return ((uint64_t)a << 32) | b;
}

bool coretest_trace(const char *image, int frames, const char *path)
{
    core_sink_t mine = {t_video, t_audio};
    core_sink_t saved = core_get_sink();
    FILE *f = fopen(path, "w");

    if (!f)
        return false;
    core_set_sink(&mine);
    if (!core_load(image)) {
        core_set_sink(&saved);
        fclose(f);
        return false;
    }
    for (int i = 0; i < frames; i++) {
        size_t dsz = 0, vsz = 0;
        const void *dram, *vram;

        acc_reset();
        core_run();
        dram = core_memory(0, &dsz);
        vram = core_memory(1, &vsz);
        fprintf(f, "%4d V %016llx nz %6llu A %016llx D %016llx R %016llx\n", i, (unsigned long long)acc_video(),
                (unsigned long long)g_acc.nonzero, (unsigned long long)acc_audio(),
                (unsigned long long)(dram ? hash_words(dram, dsz) : 0),
                (unsigned long long)(vram ? hash_words(vram, vsz) : 0));
    }
    fclose(f);
    core_unload();
    core_set_sink(&saved);
    return true;
}

static bool write_words_le(const char *path, const char *ext, const void *mem, size_t bytes)
{
    char name[1100];
    const uint32_t *w = (const uint32_t *)mem;
    FILE *f;

    snprintf(name, sizeof(name), "%s.%s", path, ext);
    f = fopen(name, "wb");
    if (!f)
        return false;
    for (size_t i = 0; i < bytes / 4; i++) {
        uint8_t b[4] = {(uint8_t)w[i], (uint8_t)(w[i] >> 8), (uint8_t)(w[i] >> 16), (uint8_t)(w[i] >> 24)};
        fwrite(b, 1, 4, f);
    }
    fclose(f);
    return true;
}

bool coretest_dump_mem(const char *image, int frames, const char *path)
{
    core_sink_t mine = {t_video, t_audio};
    core_sink_t saved = core_get_sink();
    size_t dsz = 0, vsz = 0;
    const void *dram, *vram;
    bool ok;

    core_set_sink(&mine);
    if (!core_load(image)) {
        core_set_sink(&saved);
        return false;
    }
    run_frames(frames);
    dram = core_memory(0, &dsz);
    vram = core_memory(1, &vsz);
    ok = dram && vram && write_words_le(path, "dram", dram, dsz) && write_words_le(path, "vram", vram, vsz);
    core_unload();
    core_set_sink(&saved);
    return ok;
}

#ifdef OPERA_ARM_TRACE
extern void (*opera_arm_trace_cb)(uint32_t pc, uint32_t op, uint32_t const *regs, uint32_t cpsr);

static FILE *g_armtrace;

static void arm_cb(uint32_t pc, uint32_t op, uint32_t const *regs, uint32_t cpsr)
{
    uint32_t h = 0;

    for (int i = 0; i < 15; i++)
        h = mix_b(h, regs[i], (uint32_t)i);
    fprintf(g_armtrace, "%06x %08x %08x %08x\n", pc, op, cpsr, h);
}

bool coretest_armtrace(const char *image, int from, int to, const char *path)
{
    core_sink_t mine = {t_video, t_audio};
    core_sink_t saved = core_get_sink();

    g_armtrace = fopen(path, "w");
    if (!g_armtrace)
        return false;
    g_null_sink = true;
    core_set_sink(&mine);
    if (!core_load(image)) {
        core_set_sink(&saved);
        fclose(g_armtrace);
        return false;
    }
    for (int i = 0; i < to; i++) {
        opera_arm_trace_cb = (i >= from) ? arm_cb : NULL;
        core_run();
    }
    opera_arm_trace_cb = NULL;
    fclose(g_armtrace);
    core_unload();
    core_set_sink(&saved);
    g_null_sink = false;
    return true;
}
#endif
