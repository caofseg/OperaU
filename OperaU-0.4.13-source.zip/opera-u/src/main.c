/*
 * Opera U - 3DO emulator for the Nintendo Wii U (Aroma / WUHB)
 * Entry point. Everything interesting lives in app.c.
 */
#include "app.h"
#include "log.h"

#ifdef OPERAU_HOST
#include "selftest.h"
#endif

int main(int argc, char **argv)
{
    int rc = 0;

#ifdef OPERAU_HOST
    rc = selftest_main(argc, argv);
    if (rc >= 0)
        return rc;
    rc = 0;
#else
    (void)argc;
    (void)argv;
#endif

    if (!app_init()) {
        LOGE("start-up failed");
        rc = 1;
    } else {
        while (app_frame()) {
        }
    }
    app_shutdown();
    return rc;
}
