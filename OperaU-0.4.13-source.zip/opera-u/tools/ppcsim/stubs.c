/* Frontend pieces the core test does not need, stubbed for the harness. */
#include <stdint.h>
#include "input.h"

uint32_t input_port_state(unsigned port) { (void)port; return 0; }
bool input_fast_forward(void) { return false; }
void input_default_map(int map[B3DO_COUNT]) { (void)map; }
