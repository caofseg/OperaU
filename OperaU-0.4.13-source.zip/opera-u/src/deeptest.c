#include "deeptest.h"

#include "core.h"
#include "platform.h"

#include "opera_arm.h"
#include "opera_clio.h"
#include "opera_clock.h"
#include "opera_dsp.h"
#include "opera_lr_dsp.h"
#include "opera_madam.h"
#include "opera_mem.h"
#include "opera_prof.h"
#include "opera_sport.h"
#include "opera_vdlp.h"
#include "opera_state.h"
#include "opera_xbus.h"
#include "prng16.h"
#include "prng32.h"

#include <stdarg.h>

/* Output of the command line tools; the on-console diagnostic runs the same workloads quietly. */
static bool g_quiet;
static uint64_t g_last_total; /* the final hash of the workload that ran last */

static void say(const char *fmt, ...)
{
    va_list ap;

    if (g_quiet)
        return;
    va_start(ap, fmt);
    vprintf(fmt, ap);
    va_end(ap);
}

/* ---------------------------------------------------------------- helpers */

typedef struct {
    uint32_t s;
} rng_t;

static uint32_t rnd(rng_t *r)
{
    uint32_t x = r->s;

    x ^= x << 13;
    x ^= x >> 17;
    x ^= x << 5;
    return r->s = x;
}

static uint32_t rnd_n(rng_t *r, uint32_t n)
{
    return rnd(r) % n;
}

static uint64_t hmix(uint64_t h, uint32_t v)
{
    h ^= v;
    h *= 1099511628211ull;
    h ^= h >> 29;
    return h;
}

static uint64_t hbytes(uint64_t h, const uint8_t *p, size_t n)
{
    for (size_t i = 0; i < n; i++) {
        h ^= p[i];
        h *= 1099511628211ull;
    }
    return h;
}

/* hash `words` guest 32-bit words starting at guest address `addr` */
static uint64_t hmem(uint64_t h, uint32_t addr, uint32_t words)
{
    for (uint32_t i = 0; i < words; i++)
        h = hmix(h, opera_mem_read32(addr + i * 4));
    return h;
}

static void null_video(const void *d, unsigned w, unsigned h, size_t p, core_pixel_format_t f)
{
    (void)d; (void)w; (void)h; (void)p; (void)f;
}

static size_t null_audio(const int16_t *f, size_t n)
{
    (void)f;
    return n;
}

#define INIT_HASH 1469598103934665603ull

/* -------------------------------------------------------------------- ARM */

#define ARM_BASE    0x00100000u
#define ARM_SCRATCH 0x00190000u /* r12 points here; +-8 KB around it is random data */
#define ARM_WIN     0x2000u
#define ARM_INSNS   48
#define ARM_PAD     16

static uint32_t arm_cond(rng_t *r)
{
    return (rnd_n(r, 10) < 7) ? 0xE : rnd_n(r, 14);
}

static uint32_t arm_gen(rng_t *r)
{
    uint32_t cond = arm_cond(r);
    uint32_t kind = rnd_n(r, 100);

    if (kind < 60) { /* data processing */
        uint32_t op = rnd_n(r, 16);
        uint32_t s = rnd_n(r, 2);
        uint32_t i = (rnd_n(r, 3) == 0);
        uint32_t rn = rnd_n(r, 15);
        uint32_t rd = rnd_n(r, 11); /* never r11 / r12: they are the memory base registers */
        uint32_t o2;

        if (op >= 8 && op <= 11) { /* TST/TEQ/CMP/CMN: S must be set (else PSR transfer) */
            s = 1;
            rd = 0;
        }
        /*
         * Every random draw sits in its own statement: C leaves the order in which the
         * operands of `|` are evaluated unspecified, and GCC picks a different one for x86
         * and for PowerPC, which would make the two hosts test different programs.
         */
        if (i) {
            uint32_t rot = rnd_n(r, 16);
            uint32_t imm = rnd_n(r, 256);

            o2 = (rot << 8) | imm;
        } else if (rnd_n(r, 2)) {
            uint32_t amount = rnd_n(r, 32);
            uint32_t type = rnd_n(r, 4);
            uint32_t rm = rnd_n(r, 15);

            o2 = (amount << 7) | (type << 5) | rm;
        } else {
            uint32_t rs = rnd_n(r, 15);
            uint32_t type = rnd_n(r, 4);
            uint32_t rm = rnd_n(r, 15);

            o2 = (rs << 8) | (type << 5) | (1u << 4) | rm;
        }
        return (cond << 28) | (i << 25) | (op << 21) | (s << 20) | (rn << 16) | (rd << 12) | o2;
    }
    if (kind < 68) { /* MUL / MLA */
        uint32_t rd = rnd_n(r, 11), rm = rnd_n(r, 13);

        if (rd == rm)
            rm = (rm + 1) % 13;
        uint32_t acc = rnd_n(r, 2);
        uint32_t sbit = rnd_n(r, 2);
        uint32_t rn = rnd_n(r, 13);
        uint32_t rs = rnd_n(r, 13);

        return (cond << 28) | (acc << 21) | (sbit << 20) | (rd << 16) | (rn << 12) | (rs << 8) | 0x90u | rm;
    }
    if (kind < 82) { /* LDR / STR / LDRB / STRB, immediate offset */
        uint32_t p = rnd_n(r, 2), u = rnd_n(r, 2), b = rnd_n(r, 2), w = rnd_n(r, 2), l = rnd_n(r, 2);
        uint32_t rn = 12;

        if (l && rnd_n(r, 3) == 0) { /* read the boot ROM */
            rn = 11;
            p = 1;
        }
        if (!p || rn == 11)
            w = 0;
        uint32_t rd = rnd_n(r, 11);
        uint32_t off = rnd_n(r, 0x80);

        return (cond << 28) | (1u << 26) | (p << 24) | (u << 23) | (b << 22) | (w << 21) | (l << 20) | (rn << 16) |
               (rd << 12) | off;
    }
    if (kind < 90) { /* LDM / STM */
        uint32_t list = rnd(r) & 0x7FF;

        if (!list)
            list = 1;
        uint32_t pbit = rnd_n(r, 2);
        uint32_t ubit = rnd_n(r, 2);
        uint32_t wbit = rnd_n(r, 2);
        uint32_t lbit = rnd_n(r, 2);

        return (cond << 28) | (4u << 25) | (pbit << 24) | (ubit << 23) | (wbit << 21) | (lbit << 20) | (12u << 16) |
               list;
    }
    if (kind < 93) { /* SWP / SWPB */
        uint32_t bbit = rnd_n(r, 2);
        uint32_t rd = rnd_n(r, 11);
        uint32_t rm = rnd_n(r, 11);

        return (cond << 28) | 0x01000090u | (bbit << 22) | (12u << 16) | (rd << 12) | rm;
    }
    {
        /* B / BL, a few instructions forward */
        uint32_t link = rnd_n(r, 2);
        uint32_t off = rnd_n(r, 4);

        return (cond << 28) | (5u << 25) | (link << 24) | off;
    }
}

static uint32_t arm_edge_value(rng_t *r)
{
    static const uint32_t v[] = {0, 1, 2, 31, 32, 33, 63, 64, 255, 256, 0x7FFFFFFFu, 0x80000000u, 0x80000001u,
                                 0xFFFFFFFFu, 0xFFFFFFFEu, 0x0000FFFFu, 0xFFFF0000u};
    return v[rnd_n(r, sizeof(v) / sizeof(v[0]))];
}

static uint32_t rd_le32(const uint8_t *p)
{
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}

/* print the user registers and CPSR out of a serialised ARM chunk (little endian on every host) */
static void arm_dump(const char *tag, int idx, uint32_t pc, uint32_t insn, const uint8_t *st)
{
    const uint8_t *p = st + opera_state_chunk_size(0);

    say("  %s%02d pc=%08x op=%08x |", tag, idx, pc, insn);
    for (int i = 0; i < 15; i++)
        say(" %08x", rd_le32(p + 4 * i));
    say(" | next=%08x cpsr=%08x\n", rd_le32(p + 15 * 4), rd_le32(p + 44 * 4));
}

/* `detail`: print the registers after every instruction of the last trial */
static bool deeptest_arm(uint32_t seed, int trials, bool detail)
{
    rng_t r = {seed ? seed : 1};
    uint64_t total = INIT_HASH;
    uint32_t payload = 44 * 4 + 4 + 4; /* USER..SPSR (44 words), CPSR, 4 flag bytes */
    uint32_t size = opera_state_chunk_size(payload);
    uint8_t *st = (uint8_t *)malloc(size > opera_arm_state_size() ? size : opera_arm_state_size());

    if (!st)
        return false;
    if (opera_arm_state_size() != size) {
        say("arm: unexpected state size %u (expected %u)\n", opera_arm_state_size(), size);
        free(st);
        return false;
    }
    for (int t = 0; t < trials; t++) {
        uint32_t user[16], zero[7] = {0};
        uint32_t cpsr = (rnd(&r) & 0xF0000000u) | 0xD3u;
        opera_state_writer_t w;
        uint64_t h = INIT_HASH;
        bool edge = rnd_n(&r, 4) == 0;

        for (int i = 0; i < 11; i++)
            user[i] = edge ? arm_edge_value(&r) : rnd(&r);
        user[11] = 0x03000000u + (rnd(&r) & 0x1FFC0u);
        user[12] = ARM_SCRATCH;
        user[13] = rnd(&r);
        user[14] = rnd(&r);
        user[15] = ARM_BASE;

        for (uint32_t a = ARM_SCRATCH - ARM_WIN; a < ARM_SCRATCH + ARM_WIN; a += 4)
            opera_mem_write32(a, rnd(&r));
        for (int i = 0; i < ARM_INSNS; i++)
            opera_mem_write32(ARM_BASE + 4u * i, arm_gen(&r));
        for (int i = 0; i < ARM_PAD; i++)
            opera_mem_write32(ARM_BASE + 4u * (ARM_INSNS + i), 0xE1A00000u); /* mov r0, r0 */

        opera_state_writer_init(&w, st, size);
        opera_state_write_chunk_header(&w, "ARM", payload);
        opera_state_write_u32_array(&w, user, 16);
        opera_state_write_u32_array(&w, zero, 7);  /* CASH */
        opera_state_write_u32_array(&w, zero, 2);  /* SVC */
        opera_state_write_u32_array(&w, zero, 2);  /* ABT */
        opera_state_write_u32_array(&w, zero, 7);  /* FIQ */
        opera_state_write_u32_array(&w, zero, 2);  /* IRQ */
        opera_state_write_u32_array(&w, zero, 2);  /* UND */
        opera_state_write_u32_array(&w, zero, 6);  /* SPSR */
        opera_state_write_u32(&w, cpsr);
        opera_state_write_u8(&w, 0); /* nFIQ */
        opera_state_write_u8(&w, 0); /* MAS_Access_Exept */
        opera_state_write_u8(&w, 0); /* soft reset pending */
        opera_state_write_u8(&w, 0); /* ROM overlay off: execute from DRAM */
        if (!opera_state_writer_ok(&w) || !opera_arm_state_load(st, opera_state_writer_used(&w))) {
            say("arm: state load failed\n");
            free(st);
            return false;
        }

        for (int i = 0; i < ARM_INSNS; i++) {
            if (detail && t == trials - 1) {
                uint32_t pc, insn;

                opera_arm_state_save(st);
                pc = rd_le32(st + opera_state_chunk_size(0) + 15 * 4);
                insn = opera_mem_read32(pc);
                if (i == 0)
                    arm_dump("init", 0, pc, insn, st);
                opera_arm_execute();
                opera_arm_state_save(st);
                arm_dump("i", i, pc, insn, st);
            } else {
                opera_arm_execute();
            }
        }

        {
            uint32_t n = opera_arm_state_save(st);
            h = hbytes(h, st, n);
        }
        h = hmem(h, ARM_SCRATCH - ARM_WIN, (2 * ARM_WIN) / 4);
        total = hmix(total, (uint32_t)h);
        total = hmix(total, (uint32_t)(h >> 32));
        if ((t % 250) == 249 || t == trials - 1 || trials <= 64)
            say("arm %5d %016llx\n", t + 1, (unsigned long long)total);
    }
    free(st);
    g_last_total = total;
    return true;
}

/* ------------------------------------------------------------------- ARMX */

/*
 * Extended ARM test: every instruction class (data processing with all three operand forms, PSR transfers,
 * multiply, single and block transfers, swap, branches, SWI, coprocessor and undefined encodings), all six
 * processor modes with their banked registers, SPSR traffic, loads and stores through the program counter, user
 * mode transfers, FIQ entry, data aborts from the xbus window, a software reset through the CLIO, the one
 * instruction the core skips on purpose, and all condition codes.
 *
 * Like the other workloads it does not compare against a model: it only has to give the same hash on every build.
 * The expected value is what the interpreter printed before it was optimised, so a faster interpreter must
 * reproduce the old one down to the last flag, cycle count and byte of memory.
 *
 * Operands of a multi-draw expression are always drawn in separate statements (see arm_gen above).
 */

#define AX_BASE    0x00100000u /* the instructions */
#define AX_SCRATCH 0x00190000u /* data window: +-8 KB around it is random */
#define AX_WIN     0x2000u
#define AX_AREA    0x1000u     /* random data around the code as well, for loads and stores relative to the PC */
#define AX_INSNS   56
#define AX_PAD     8
#define AX_RUN     72          /* instructions executed per trial */
#define AX_NOP     0xE1A00000u /* mov r0, r0 */

static uint32_t ax_edge(rng_t *r)
{
    static const uint32_t v[] = {0,          1,          2,          3,          4,          7,
                                 8,          31,         32,         33,         255,        256,
                                 0xFFFFu,    0x10000u,   0x7FFFFFFFu, 0x80000000u, 0x80000001u, 0xFFFFFFFFu,
                                 0xFFFFFFFEu, 0xFFFF0000u, 0x55555555u, 0xAAAAAAAAu};
    return v[rnd_n(r, sizeof(v) / sizeof(v[0]))];
}

/* an address inside the data window, now and then one of the two special device addresses */
static uint32_t ax_ptr(rng_t *r)
{
    uint32_t k = rnd_n(r, 100);
    uint32_t off = rnd_n(r, 0x1000u);
    uint32_t w = rnd_n(r, 0x40u);
    uint32_t a;

    if (k < 2) /* xbus window: aborted when no device answers */
        return 0x03400540u + (w << 2);
    if (k < 3) /* CLIO status register: a write with bit 4 set is a software reset */
        return 0x03400028u;
    a = AX_SCRATCH + off - 0x800u;
    if (k < 70)
        a &= ~3u;
    return a;
}

static uint32_t ax_val(rng_t *r)
{
    uint32_t k = rnd_n(r, 100);

    if (k < 30)
        return ax_ptr(r);
    if (k < 50)
        return ax_edge(r);
    if (k < 62)
        return rnd_n(r, 256);
    return rnd(r);
}

/* a processor status value that is safe to load (valid mode) */
static uint32_t ax_psr_val(rng_t *r)
{
    static const uint8_t modes[] = {0x10, 0x11, 0x12, 0x13, 0x13, 0x13, 0x17, 0x1B};
    uint32_t flags = rnd(r) & 0xF0000000u;
    uint32_t m = modes[rnd_n(r, sizeof(modes))];
    uint32_t i = rnd_n(r, 2) ? 0x80u : 0u;
    uint32_t f = rnd_n(r, 3) ? 0x40u : 0u;

    return flags | m | i | f;
}

static uint32_t ax_cond(rng_t *r)
{
    uint32_t k = rnd_n(r, 100);
    uint32_t c = rnd_n(r, 14);

    if (k < 70)
        return 0xE;
    if (k < 98)
        return c;
    return 0xF;
}

/* any register; the program counter now and then */
static uint32_t ax_reg(rng_t *r)
{
    uint32_t k = rnd_n(r, 100);
    uint32_t x = rnd_n(r, 15);

    return k < 7 ? 15u : x;
}

/* destination register: mostly r0..r10 so that the pointer registers stay pointers */
static uint32_t ax_dest(rng_t *r)
{
    uint32_t k = rnd_n(r, 100);
    uint32_t x = rnd_n(r, 11);
    uint32_t y = rnd_n(r, 4);

    if (k < 2)
        return 15;
    if (k < 5)
        return 11 + y;
    return x;
}

/* base register of a memory instruction */
static uint32_t ax_base(rng_t *r)
{
    uint32_t k = rnd_n(r, 100);
    uint32_t x = rnd_n(r, 11);

    if (k < 42)
        return 12;
    if (k < 57)
        return 13;
    if (k < 64)
        return 15;
    if (k < 70)
        return 11;
    return x;
}

static uint32_t ax_dp(rng_t *r, uint32_t cond)
{
    uint32_t op = rnd_n(r, 16);
    uint32_t s = rnd_n(r, 2);
    uint32_t form = rnd_n(r, 100);
    uint32_t rn = ax_reg(r);
    uint32_t rd = ax_dest(r);
    uint32_t i = 0;
    uint32_t o2;

    if (op >= 8 && op <= 11) { /* TST/TEQ/CMP/CMN: without S they would be PSR transfers (ax_psr) */
        uint32_t any = rnd_n(r, 16);

        s = 1;
        rd = any; /* the destination field is ignored */
    }
    if (form < 35) { /* rotated immediate */
        uint32_t rot = rnd_n(r, 16);
        uint32_t small = rnd_n(r, 3);
        uint32_t imm = rnd_n(r, 256);

        if (small == 0)
            imm &= 15;
        i = 1;
        o2 = (rot << 8) | imm;
    } else if (form < 70) { /* register, shifted by an immediate amount */
        uint32_t pick = rnd_n(r, 6);
        uint32_t amount = rnd_n(r, 32);
        uint32_t type = rnd_n(r, 4);
        uint32_t rm = ax_reg(r);

        if (pick == 0)
            amount = 0;
        else if (pick == 1)
            amount = 31;
        o2 = (amount << 7) | (type << 5) | rm;
    } else { /* register, shifted by the bottom byte of a register */
        uint32_t rs = rnd_n(r, 15);
        uint32_t type = rnd_n(r, 4);
        uint32_t rm = ax_reg(r);

        o2 = (rs << 8) | (type << 5) | (1u << 4) | rm;
    }
    return (cond << 28) | (i << 25) | (op << 21) | (s << 20) | (rn << 16) | (rd << 12) | o2;
}

/* MRS / MSR; the whole-register form only ever loads a valid mode */
static uint32_t ax_psr(rng_t *r, uint32_t cond)
{
    uint32_t k = rnd_n(r, 5);
    uint32_t spsr = rnd_n(r, 2) << 22;

    if (k == 0) {
        uint32_t rd = rnd_n(r, 15);

        return (cond << 28) | 0x010F0000u | spsr | (rd << 12);
    }
    if (k == 1) { /* flags only, from a register */
        uint32_t rm = ax_reg(r);

        return (cond << 28) | 0x0128F000u | spsr | rm;
    }
    if (k == 2) { /* flags only, immediate */
        uint32_t rot = rnd_n(r, 16);
        uint32_t imm = rnd_n(r, 256);

        return (cond << 28) | 0x0328F000u | spsr | (rot << 8) | imm;
    }
    {
        uint32_t v = ax_psr_val(r) & 0xFFu;

        return (cond << 28) | 0x0329F000u | spsr | v;
    }
}

static uint32_t ax_mul(rng_t *r, uint32_t cond)
{
    uint32_t acc = rnd_n(r, 2);
    uint32_t s = rnd_n(r, 2);
    uint32_t rd = ax_reg(r);
    uint32_t rn = ax_reg(r);
    uint32_t rs = ax_reg(r);
    uint32_t rm = ax_reg(r);

    return (cond << 28) | (acc << 21) | (s << 20) | (rd << 16) | (rn << 12) | (rs << 8) | 0x90u | rm;
}

static uint32_t ax_ldst(rng_t *r, uint32_t cond)
{
    uint32_t l = rnd_n(r, 2);
    uint32_t b = rnd_n(r, 10) < 3;
    uint32_t p = rnd_n(r, 3) != 0;
    uint32_t u = rnd_n(r, 2);
    uint32_t w = rnd_n(r, 3) == 0;
    uint32_t reg = rnd_n(r, 4) == 0;
    uint32_t rn = ax_base(r);
    uint32_t rd_ld = ax_dest(r);
    uint32_t rd_st = ax_reg(r);
    uint32_t rd = l ? rd_ld : rd_st;
    uint32_t off;

    if (reg) {
        uint32_t amount = rnd_n(r, 32);
        uint32_t type = rnd_n(r, 4);
        uint32_t rm = ax_reg(r);
        uint32_t und = rnd_n(r, 12) == 0; /* bit 4 set: undefined instruction */

        off = (amount << 7) | (type << 5) | (und ? 0x10u : 0u) | rm;
    } else {
        uint32_t k = rnd_n(r, 10);
        uint32_t v = rnd_n(r, 0x1000u);

        off = k < 4 ? (v & 0x3Fu) : k < 7 ? (v & 0xFFCu) : v;
    }
    return (cond << 28) | (1u << 26) | (reg << 25) | (p << 24) | (u << 23) | (b << 22) | (w << 21) | (l << 20) |
           (rn << 16) | (rd << 12) | off;
}

static uint32_t ax_bdt(rng_t *r, uint32_t cond)
{
    uint32_t k = rnd_n(r, 100);
    uint32_t x = rnd_n(r, 11);
    uint32_t rn = k < 50 ? 12 : k < 80 ? 13 : k < 85 ? 11 : k < 88 ? 15 : x;
    uint32_t shape = rnd_n(r, 5);
    uint32_t a = rnd(r);
    uint32_t b = rnd(r);
    uint32_t bit = rnd_n(r, 16);
    uint32_t keep = rnd_n(r, 50);
    uint32_t list;
    uint32_t p = rnd_n(r, 2);
    uint32_t u = rnd_n(r, 2);
    uint32_t sbit = rnd_n(r, 4) == 0;
    uint32_t w = rnd_n(r, 2);
    uint32_t l = rnd_n(r, 2);

    switch (shape) {
    case 0: list = 1u << bit; break;
    case 1: list = a & b & 0xFFFFu; break;
    case 2: list = (a | b) & 0xFFFFu; break;
    case 3: list = a & 0xFFFFu; break;
    default: list = a & 0x7FFFu; break;
    }
    if (!list && keep)
        list = 1u << bit; /* an empty list only now and then */
    return (cond << 28) | (4u << 25) | (p << 24) | (u << 23) | (sbit << 22) | (w << 21) | (l << 20) | (rn << 16) |
           list;
}

static uint32_t ax_swp(rng_t *r, uint32_t cond)
{
    uint32_t b = rnd_n(r, 2);
    uint32_t k = rnd_n(r, 10);
    uint32_t x = rnd_n(r, 13);
    uint32_t rn = k < 7 ? 12 : x;
    uint32_t rd = ax_reg(r);
    uint32_t rm = ax_reg(r);

    return (cond << 28) | 0x01000090u | (b << 22) | (rn << 16) | (rd << 12) | rm;
}

static uint32_t ax_branch(rng_t *r, uint32_t cond)
{
    uint32_t link = rnd_n(r, 2);
    uint32_t k = rnd_n(r, 10);
    uint32_t d = rnd_n(r, 24);
    uint32_t any = rnd(r) & 0xFFFFFFu;
    uint32_t off = k < 8 ? ((d - 8u) & 0xFFFFFFu) : any; /* mostly -8..+15 words: stays in the code */

    return (cond << 28) | (5u << 25) | (link << 24) | off;
}

static uint32_t ax_other(rng_t *r, uint32_t cond)
{
    uint32_t k = rnd_n(r, 4);
    uint32_t v = rnd(r) & 0xFFFFFFu;
    uint32_t c = 0xC + rnd_n(r, 3);
    uint32_t hi = rnd_n(r, 2) << 24;

    if (k == 0)
        return (cond << 28) | 0x0F000000u | v; /* SWI */
    if (k == 1)
        return (cond << 28) | (c << 24) | v; /* coprocessor */
    if (k == 2)
        return (cond << 28) | 0x06000010u | hi | (v & 0xFFFFEFu); /* undefined */
    return 0xE5101810u;                                           /* ldr r1, [r0, #-0x810]: skipped in one state */
}

static uint32_t ax_gen(rng_t *r)
{
    uint32_t cond = ax_cond(r);
    uint32_t kind = rnd_n(r, 100);

    if (kind < 38)
        return ax_dp(r, cond);
    if (kind < 43)
        return ax_psr(r, cond);
    if (kind < 49)
        return ax_mul(r, cond);
    if (kind < 71)
        return ax_ldst(r, cond);
    if (kind < 80)
        return ax_bdt(r, cond);
    if (kind < 83)
        return ax_swp(r, cond);
    if (kind < 92)
        return ax_branch(r, cond);
    return ax_other(r, cond);
}

/* `detail`: print the registers after every instruction of the last trial */
static bool deeptest_armx(uint32_t seed, int trials, bool detail)
{
    rng_t r = {seed ? seed : 1};
    uint64_t total = INIT_HASH;
    uint32_t payload = 44 * 4 + 4 + 4;
    uint32_t size = opera_state_chunk_size(payload);
    uint8_t *st = (uint8_t *)malloc(size > opera_arm_state_size() ? size : opera_arm_state_size());
    int swi_hle = opera_arm_swi_hle_get();

    if (!st)
        return false;
    if (opera_arm_state_size() != size) {
        say("armx: unexpected state size %u (expected %u)\n", opera_arm_state_size(), size);
        free(st);
        return false;
    }
    opera_arm_swi_hle_set(0);
    for (int t = 0; t < trials; t++) {
        uint32_t user[16], cash[7], svc[2], abt[2], fiq[7], irq[2], und[2], spsr[6];
        uint32_t cpsr;
        opera_state_writer_t w;
        uint64_t h = INIT_HASH;
        int32_t cnt = 0;
        uint32_t mask;
        uint32_t what;
        bool exc = (rnd_n(&r, 33) == 0);

        for (int i = 0; i < 11; i++)
            user[i] = ax_val(&r);
        user[11] = 0x03000000u + (rnd(&r) & 0x1FFC0u); /* boot ROM */
        user[12] = AX_SCRATCH;
        user[13] = ax_ptr(&r) & ~3u;
        user[14] = ax_val(&r);
        user[15] = AX_BASE;
        for (int i = 0; i < 7; i++)
            cash[i] = ax_val(&r);
        for (int i = 0; i < 7; i++)
            fiq[i] = ax_val(&r);
        for (int i = 0; i < 2; i++) {
            svc[i] = ax_val(&r);
            abt[i] = ax_val(&r);
            irq[i] = ax_val(&r);
            und[i] = ax_val(&r);
        }
        cash[4] = fiq[4] = AX_SCRATCH; /* r12 stays the data pointer in every mode */
        cash[5] = ax_ptr(&r) & ~3u;
        fiq[5] = ax_ptr(&r) & ~3u;
        svc[0] = ax_ptr(&r) & ~3u;
        abt[0] = ax_ptr(&r) & ~3u;
        irq[0] = ax_ptr(&r) & ~3u;
        und[0] = ax_ptr(&r) & ~3u;
        for (int i = 0; i < 6; i++)
            spsr[i] = ax_psr_val(&r);
        cpsr = ax_psr_val(&r);
        if (exc)
            cpsr = 0x80000093u;

        for (uint32_t a = AX_SCRATCH - AX_WIN; a < AX_SCRATCH + AX_WIN; a += 4)
            opera_mem_write32(a, rnd(&r));
        for (uint32_t a = AX_BASE - AX_AREA; a < AX_BASE + AX_AREA + 0x100u; a += 4)
            opera_mem_write32(a, rnd(&r));
        for (int i = 0; i < 8; i++)
            opera_mem_write32(4u * i, ax_gen(&r)); /* exception vectors */
        for (int i = 0; i < AX_INSNS; i++)
            opera_mem_write32(AX_BASE + 4u * i, ax_gen(&r));
        for (int i = 0; i < AX_PAD; i++)
            opera_mem_write32(AX_BASE + 4u * (AX_INSNS + i), AX_NOP);
        if (exc)
            opera_mem_write32(AX_BASE, 0xE5101810u);

        /* interrupt lines: none, or one enabled source that is pending (a FIQ whenever the F flag allows) */
        opera_clio_poke(0x44, 0xFFFFFFFFu);
        opera_clio_poke(0x4C, 0xFFFFFFFFu);
        opera_clio_poke(0x64, 0xFFFFFFFFu);
        opera_clio_poke(0x6C, 0xFFFFFFFFu);
        what = rnd_n(&r, 8);
        mask = 1u << rnd_n(&r, 16);
        if (what == 0) {
            opera_clio_poke(0x48, mask);
            opera_clio_poke(0x40, mask);
        } else if (what == 1) {
            opera_clio_poke(0x68, mask);
            opera_clio_poke(0x60, mask);
        }

        opera_state_writer_init(&w, st, size);
        opera_state_write_chunk_header(&w, "ARM", payload);
        opera_state_write_u32_array(&w, user, 16);
        opera_state_write_u32_array(&w, cash, 7);
        opera_state_write_u32_array(&w, svc, 2);
        opera_state_write_u32_array(&w, abt, 2);
        opera_state_write_u32_array(&w, fiq, 7);
        opera_state_write_u32_array(&w, irq, 2);
        opera_state_write_u32_array(&w, und, 2);
        opera_state_write_u32_array(&w, spsr, 6);
        opera_state_write_u32(&w, cpsr);
        opera_state_write_u8(&w, 0); /* nFIQ */
        opera_state_write_u8(&w, 0); /* MAS_Access_Exept */
        opera_state_write_u8(&w, 0); /* soft reset pending */
        opera_state_write_u8(&w, 0); /* ROM overlay off: execute from DRAM */
        if (!opera_state_writer_ok(&w) || !opera_arm_state_load(st, opera_state_writer_used(&w))) {
            say("armx: state load failed\n");
            opera_arm_swi_hle_set(swi_hle);
            free(st);
            return false;
        }

        for (int i = 0; i < AX_RUN; i++) {
            if (detail && t == trials - 1) {
                uint32_t pc, insn;

                opera_arm_state_save(st);
                pc = rd_le32(st + opera_state_chunk_size(0) + 15 * 4);
                insn = (pc & ~3u) < 0x300000u ? opera_mem_read32(pc & ~3u) : 0xBADACCE5u; /* the PC may be anywhere */
                if (i == 0)
                    arm_dump("init", 0, pc, insn, st);
                cnt += opera_arm_execute();
                opera_arm_state_save(st);
                arm_dump("i", i, pc, insn, st);
            } else {
                cnt += opera_arm_execute();
            }
        }

        {
            uint32_t n = opera_arm_state_save(st);

            h = hmix(h, (uint32_t)cnt);
            h = hbytes(h, st, n);
        }
        h = hmem(h, AX_SCRATCH - AX_WIN, (2 * AX_WIN) / 4);
        h = hmem(h, AX_BASE - AX_AREA, (2 * AX_AREA + 0x100u) / 4);
        h = hmem(h, 0, 8);
        total = hmix(total, (uint32_t)h);
        total = hmix(total, (uint32_t)(h >> 32));
        if ((t % 250) == 249 || t == trials - 1 || trials <= 64)
            say("armx %5d %016llx\n", t + 1, (unsigned long long)total);
    }
    opera_arm_swi_hle_set(swi_hle);
    free(st);
    g_last_total = total;
    return true;
}

/* -------------------------------------------------------------------- DSP */

static uint16_t dsp_gen(rng_t *r)
{
    if (rnd_n(r, 100) < 70)
        return (uint16_t)(rnd(r) & 0x7FFF); /* arithmetic instruction */
    {
        /* control instruction that cannot change the program counter */
        static const uint8_t ops[] = {0, 2, 3, 5, 6};
        uint32_t op = (rnd_n(r, 3) == 0) ? ops[rnd_n(r, sizeof(ops))] : 32 + rnd_n(r, 32);

        return (uint16_t)(0x8000u | (op << 7) | (rnd(r) & 0x7F));
    }
}

#ifdef OPERA_DSP_TRACE /* debug builds only: see tools/ppcsim/README.md */
extern void (*opera_dsp_trace_cb)(uint32_t pc, uint32_t op, uint32_t y, uint32_t aop, uint32_t bop, uint32_t flags,
                                  uint32_t wb, uint32_t m1, uint32_t m2, uint32_t a1, uint32_t a2, uint32_t bs);

static void dsp_trace_print(uint32_t pc, uint32_t op, uint32_t y, uint32_t aop, uint32_t bop, uint32_t flags,
                            uint32_t wb, uint32_t m1, uint32_t m2, uint32_t a1, uint32_t a2, uint32_t bs)
{
    say("  t pc=%04x op=%04x y=%08x a=%08x b=%08x f=%08x wb=%04x m=%04x,%04x al=%04x,%04x bs=%x\n", pc, op, y, aop,
           bop, flags, wb, m1, m2, a1, a2, bs);
}
#endif

/* `detail`: print the loop results and the whole serialised DSP state of the last trial */
static bool deeptest_dsp(uint32_t seed, int trials, bool detail)
{
    rng_t r = {seed ? seed : 1};
    uint64_t total = INIT_HASH;
    uint32_t ssize = opera_dsp_state_size();
    uint8_t *st = (uint8_t *)malloc(ssize);

    if (!st)
        return false;
    for (int t = 0; t < trials; t++) {
        uint64_t h = INIT_HASH;
        uint32_t len = 24 + rnd_n(&r, 200);

        opera_dsp_reset();
        /* DSP reads of 0xEA return the core's PRNG, which retro_init() seeds from the clock */
        prng16_seed(rnd(&r));
        for (uint32_t a = 0; a < 0x400; a++)
            opera_dsp_mem_write((uint16_t)a, (uint16_t)rnd(&r));
        for (uint32_t a = 0; a < len; a++)
            opera_dsp_mem_write((uint16_t)a, dsp_gen(&r));
        for (uint32_t a = len; a < 0x400 && a < len + 160; a++) /* `sleep`: always terminates */
            opera_dsp_mem_write((uint16_t)a, 0x8380);
        for (uint32_t a = 0; a < 0x70; a++)
            opera_dsp_imem_write((uint16_t)a, (uint16_t)rnd(&r));
        opera_dsp_set_running(1);
        for (int k = 0; k < 3; k++) {
            uint32_t res;

#ifdef OPERA_DSP_TRACE
            opera_dsp_trace_cb = (detail && t == trials - 1) ? dsp_trace_print : NULL;
#endif
            res = opera_dsp_loop();

            if (detail && t == trials - 1)
                say("  loop %d -> %08x\n", k, res);
            h = hmix(h, res);
        }
        {
            uint32_t n = opera_dsp_state_save(st);

            if (detail && t == trials - 1) {
                say("  len %u, state %u bytes\n", len, n);
                for (uint32_t o = 0; o < n; o += 16) {
                    say("  s%04x:", o);
                    for (uint32_t i = o; i < o + 16 && i < n; i++)
                        say(" %02x", st[i]);
                    say("\n");
                }
            }
            h = hbytes(h, st, n);
        }
        total = hmix(total, (uint32_t)h);
        total = hmix(total, (uint32_t)(h >> 32));
        if ((t % 250) == 249 || t == trials - 1 || trials <= 64)
            say("dsp %5d %016llx\n", t + 1, (unsigned long long)total);
    }
    free(st);
    g_last_total = total;
    return true;
}

/*
 * DSP programs that never reach a sleep. A real DSP is started again at the top of its program by every sample
 * tick, so a program that loops, or runs off the end of its memory, costs it one tick and nothing more; the
 * interpreter has to give up on such a run too, or whatever called it never comes back. The sound code of a
 * game does not write programs like these, but it rewrites its program while the DSP runs, and a DSP on a
 * thread of its own can be caught in the middle of that - which is how a game came to stop at a black screen
 * with the DSP thread stuck. Each trial: one of four programs that cannot end, run for three ticks, then an
 * ordinary program over the wreckage, run for three more.
 */
static bool deeptest_dspr(uint32_t seed, int trials)
{
    rng_t r = {seed ? seed : 1};
    uint64_t total = INIT_HASH;
    uint32_t ssize = opera_dsp_state_size();
    uint8_t *st = (uint8_t *)malloc(ssize);

    if (!st)
        return false;
    for (int t = 0; t < trials; t++) {
        uint64_t h = INIT_HASH;
        uint32_t kind = rnd_n(&r, 4);
        uint32_t a0 = 1 + rnd_n(&r, 1022);
        uint32_t a1 = 1 + rnd_n(&r, 1022);
        uint32_t len = 24 + rnd_n(&r, 200);

        opera_dsp_reset();
        prng16_seed(rnd(&r));
        for (uint32_t a = 0; a < 0x70; a++)
            opera_dsp_imem_write((uint16_t)a, (uint16_t)rnd(&r));
        switch (kind) {
        case 0: /* a jump to itself, first thing */
            for (uint32_t a = 0; a < 0x400; a++)
                opera_dsp_mem_write((uint16_t)a, 0x8380);
            opera_dsp_mem_write(0, 0x8400);
            break;
        case 1: /* nothing but no-ops, to the end of the memory and past it */
            for (uint32_t a = 0; a < 0x400; a++)
                opera_dsp_mem_write((uint16_t)a, 0x8000);
            break;
        case 2: /* arithmetic and moves with their operands, and no sleep anywhere */
            for (uint32_t a = 0; a < 0x400; a++)
                opera_dsp_mem_write((uint16_t)a, dsp_gen(&r));
            break;
        default: /* two jumps that point at each other, somewhere in the middle */
            for (uint32_t a = 0; a < 0x400; a++)
                opera_dsp_mem_write((uint16_t)a, 0x8380);
            opera_dsp_mem_write(0, (uint16_t)(0x8400 | a0));
            opera_dsp_mem_write((uint16_t)a0, (uint16_t)(0x8400 | a1));
            opera_dsp_mem_write((uint16_t)a1, (uint16_t)(0x8400 | a0));
            break;
        }
        opera_dsp_set_running(1);
        for (int k = 0; k < 3; k++)
            h = hmix(h, opera_dsp_loop());

        /* and now a program that does end, as the sound code leaves it once it has finished rewriting */
        for (uint32_t a = 0; a < len; a++)
            opera_dsp_mem_write((uint16_t)a, dsp_gen(&r));
        for (uint32_t a = len; a < 0x400; a++)
            opera_dsp_mem_write((uint16_t)a, 0x8380);
        for (int k = 0; k < 3; k++)
            h = hmix(h, opera_dsp_loop());
        h = hbytes(h, st, opera_dsp_state_save(st));

        total = hmix(total, (uint32_t)h);
        total = hmix(total, (uint32_t)(h >> 32));
        if ((t % 100) == 99 || t == trials - 1 || trials <= 64)
            say("dspr %5d %016llx\n", t + 1, (unsigned long long)total);
    }
    free(st);
    g_last_total = total;
    return true;
}

/*
 * The DSP on a thread of its own against the DSP inside the frame.
 *
 * The same script is played twice on a freshly loaded machine: ticks of the DSP, and between them what a game's
 * sound code does to it through the CPU's ports - rewriting its program, starting, stopping and resetting it,
 * setting up, enabling, disabling and clearing the audio FIFOs it reads from and writes to, the semaphore, knob
 * values, and now and then leaving it alone for a long stretch - with the rest of the machine setting and
 * answering interrupts of its own all the while. The first
 * time the DSP runs each tick as it is handed over; the second time a thread runs them when it gets to them.
 *
 * With every one of those writes landing between the same two ticks either way, the DSP does exactly the same
 * work: every sample it puts out is compared, and its state, the CLIO's (FIFOs and interrupt words), the memory
 * it wrote to and what the CPU read back. This is what the thread could not promise before the writes were made
 * to wait for it. The first run is also the same on every machine, so it has an x86 reference like the other
 * workloads; the second needs a build with threads (the PC and the console, not the PowerPC simulator).
 */
#define DSPT_DATA 0x00140000u /* what the FIFOs feed the DSP: 16 KB of noise */
#define DSPT_OUT  0x00150000u /* where the DSP's own FIFOs write */

static uint64_t g_dspt_audio;
static uint64_t g_dspt_samples;
static uint64_t g_dspt_irq[3]; /* interrupts the DSP raised: its own, end of a FIFO it reads, end of one it writes */

/* Only while the DSP runs inside the frame, where it raises its interrupts itself: the same, and counted. */
static void dspt_fiq_counted(uint32_t reason1)
{
    g_dspt_irq[reason1 == 0x800 ? 0 : reason1 >= 0x10000 ? 1 : 2]++;
    opera_clio_fiq_generate(reason1, 0);
}

static size_t dspt_audio(const int16_t *f, size_t n)
{
    for (size_t i = 0; i < n; i++) /* by value, so that the byte order of the machine does not come into it */
        g_dspt_audio = hmix(g_dspt_audio, ((uint32_t)(uint16_t)f[i * 2] << 16) | (uint16_t)f[i * 2 + 1]);
    g_dspt_samples += n;
    return n;
}

static void dspt_prog(uint32_t addr, uint16_t word)
{
    opera_clio_poke(0x2000 + ((addr & 0x3FF) << 2), word); /* the port a game writes one program word through */
}

/* Time passes: ticks of the DSP, and once a frame's worth of them has gone by the sound is handed over. */
static void dspt_ticks(uint32_t ticks, uint32_t *since)
{
    for (uint32_t i = 0; i < ticks; i++) {
        opera_lr_dsp_process();
        if (++*since >= 736) {
            opera_lr_dsp_upload();
            *since = 0;
        }
    }
}

/*
 * A random program touches a FIFO or the semaphore only by chance, and what it reads there seldom changes what
 * it puts out. So every script's program opens with seven instructions that do, each adding two operands and
 * writing the sum back to the second:
 *   three add the next word of a FIFO the DSP reads to a word of its memory (0x110 to 0x112),
 *   one adds the first of those sums to what it writes into a FIFO the DSP fills,
 *   one adds the semaphore's data to a word of its memory (0x114),
 *   one writes that sum to the semaphore,
 *   and one writes it to a spare word - or, in one opening out of three, to the register that raises the DSP's
 *   own interrupt, on every tick.
 * A FIFO fed a tick early or late, a channel switched on or off on the wrong side of the end of a FIFO, a
 * semaphore written or read a tick out: each now changes those sums, and with them the DSP's state, the sound
 * and what the CPU reads back.
 */
#define DSPT_OPENING 21

static void dspt_opening(rng_t *r, uint32_t in_ch[3], uint32_t *out_ch)
{
    for (uint32_t i = 0; i < 3; i++) {
        in_ch[i] = rnd_n(r, 13);
        dspt_prog(i * 3, 0x4620);
        dspt_prog(i * 3 + 1, (uint16_t)(0x8000u | (0xF0u + in_ch[i])));
        dspt_prog(i * 3 + 2, (uint16_t)(0x8800u | (0x110u + i)));
    }
    *out_ch = rnd_n(r, 4);
    dspt_prog(9, 0x4620);
    dspt_prog(10, 0x8000u | 0x110u);
    dspt_prog(11, (uint16_t)(0x8800u | (0x3F0u + *out_ch)));
    dspt_prog(12, 0x4620);
    dspt_prog(13, 0x8000u | 0xEDu);
    dspt_prog(14, 0x8800u | 0x114u);
    dspt_prog(15, 0x4620);
    dspt_prog(16, 0x8000u | 0x114u);
    dspt_prog(17, 0x8800u | 0x3EDu);
    dspt_prog(18, 0x4620);
    dspt_prog(19, 0x8000u | 0x114u);
    dspt_prog(20, (uint16_t)(0x8800u | (rnd_n(r, 3) == 0 ? 0x3EEu : 0x115u)));
}

/* What a run of a script cost. The waits are the CPU's, for the thread to catch up before one of its writes. */
typedef struct {
    uint64_t us;
    uint64_t waits, gave_up;
    double wait_us;
} dspt_cost_t;

enum { DSPT_FAILED, DSPT_DONE, DSPT_CUT_SHORT, DSPT_NO_THREAD };

/*
 * Plays script `seed`. `limit_us` (0: none) is how long it may take: a thread that the CPU has to give up waiting
 * for every time would otherwise turn a second into a minute. Returns DSPT_FAILED if the machine would not load,
 * DSPT_NO_THREAD if a thread was asked for and this build or this machine has none to give, DSPT_CUT_SHORT if the
 * limit ran out, DSPT_DONE otherwise - and only then is `out` the whole result.
 */
static int dspt_once(uint32_t seed, int steps, bool threaded, uint64_t limit_us, uint64_t out[5], uint64_t *samples,
                     dspt_cost_t *cost)
{
    core_sink_t sink = {null_video, dspt_audio};
    core_sink_t saved = core_get_sink();
    rng_t r = {seed ? seed : 1};
    uint32_t len = DSPT_OPENING + 60 + rnd_n(&r, 180);
    uint32_t since = 0;
    uint64_t seen = INIT_HASH; /* what the CPU read back along the way */
    uint32_t in_ch[3], out_ch; /* the FIFOs the opening of the program uses */
    opera_lr_dsp_thread_stats_t ts0, ts1;
    uint64_t t0, c0;
    int rc = DSPT_DONE;
    uint8_t *st;
    uint32_t n;

    memset(cost, 0, sizeof(*cost));
    core_set_sink(&sink);
    if (!core_load(NULL)) {
        core_set_sink(&saved);
        return DSPT_FAILED;
    }
    prng16_seed(0x13579BDFu);
    prng32_seed(0x2468ACE1u);
    opera_lr_dsp_init(threaded);
    if (threaded && !opera_lr_dsp_is_threaded()) {
        core_unload();
        core_set_sink(&saved);
        return DSPT_NO_THREAD;
    }
    if (!threaded) {
        memset(g_dspt_irq, 0, sizeof(g_dspt_irq));
        opera_clio_fiq_from_dsp_hook = dspt_fiq_counted;
    }
    opera_lr_dsp_thread_stats(&ts0);
    g_dspt_audio = INIT_HASH;
    g_dspt_samples = 0;
    t0 = platform_time_us();
    c0 = opera_prof_clock64();

    for (uint32_t i = 0; i < 0x4000 / 4; i++)
        opera_mem_write32(DSPT_DATA + i * 4, rnd(&r));
    for (uint32_t i = 0; i < 0x4000 / 4; i++)
        opera_mem_write32(DSPT_OUT + i * 4, 0);
    opera_clio_poke(0x17FC, 0);
    for (uint32_t a = 0; a < 0x400; a++)
        dspt_prog(a, a < len ? dsp_gen(&r) : 0x8380);
    dspt_opening(&r, in_ch, &out_ch);
    for (uint32_t a = 0; a < 0x70; a++)
        opera_clio_poke(0x3400 + (a << 2), rnd(&r) & 0xFFFF);
    opera_clio_poke(0x17FC, 1);

    for (int k = 0; k < steps; k++) {
        uint32_t op = rnd_n(&r, 100);
        uint32_t a = rnd(&r);
        uint32_t b = rnd(&r);
        uint32_t c = rnd(&r);

        if (limit_us && (k & 31) == 31 && platform_time_us() - t0 > limit_us) {
            rc = DSPT_CUT_SHORT;
            break;
        }
        if (op < 48) {
            /* Time passes. Once in a while a great deal of it, with the CPU not touching the DSP at all: sixteen
               frames of ticks handed over as fast as they can be, which is what a game left on fast forward
               does. A thread allowed to fall that far behind loses sound when it catches up. */
            dspt_ticks((a >> 8) % 256 == 0 ? 12000 : 1 + (a % 150), &since);
        } else if (op < 58) { /* a few words of the program rewritten */
            uint32_t words = 1 + (a % 8);
            uint32_t at = DSPT_OPENING + b % (len - DSPT_OPENING);

            for (uint32_t i = 0; i < words && at + i < len; i++)
                dspt_prog(at + i, dsp_gen(&r));
        } else if (op < 60) { /* its opening too, for other FIFOs */
            dspt_opening(&r, in_ch, &out_ch);
        } else if (op < 67) { /* a FIFO the DSP reads from is pointed at some data, and at what comes after it */
            uint32_t ch = (a & 0x300) ? in_ch[(a >> 4) % 3] : a % 13;
            uint32_t base = 0x400 + (ch << 4);

            opera_clio_fifo_write(base + 0x00, DSPT_DATA + ((b % 0x3F00) & ~3u));
            opera_clio_fifo_write(base + 0x04, 4 + ((c % 40) & ~3u));
            if (c & 0x300) {
                opera_clio_fifo_write(base + 0x08, DSPT_DATA + (((b >> 12) % 0x3F00) & ~3u));
                opera_clio_fifo_write(base + 0x0C, 4 + (((c >> 10) % 40) & ~3u));
            }
        } else if (op < 70) { /* and one it writes to */
            uint32_t ch = (a & 0x300) ? out_ch : a % 4;
            uint32_t base = 0x500 + (ch << 4);

            opera_clio_fifo_write(base + 0x00, DSPT_OUT + ((b % 0x3F00) & ~3u));
            opera_clio_fifo_write(base + 0x04, 4 + ((c % 40) & ~3u));
            if (c & 0x300) {
                opera_clio_fifo_write(base + 0x08, DSPT_OUT + (((b >> 12) % 0x3F00) & ~3u));
                opera_clio_fifo_write(base + 0x0C, 4 + (((c >> 10) % 40) & ~3u));
            }
        } else if (op < 74) { /* channels enabled (most often), disabled, cleared */
            uint32_t ch = (a & 0x300) ? in_ch[(a >> 4) % 3] : a % 13;
            uint32_t och = (a & 0xC00) ? out_ch : (a >> 12) % 4;
            uint32_t bits = (b & 3) == 0 ? (1u << (16 + och)) : (b & 3) == 1 ? ((1u << ch) | (1u << (16 + och))) : (1u << ch);

            opera_clio_poke((c % 6) == 0 ? 0x300 : (c % 6) == 1 ? 0x308 : 0x304, bits);
        } else if (op < 82) {
            /* A sound played the way a game plays one, with the DSP running all the while: the channel made quiet,
               its FIFO pointed at the sound and at what follows it, the channel switched on - and, half the
               time, told a little later to stop at the end of what it is playing. */
            uint32_t ch = in_ch[a % 3];
            uint32_t base = 0x400 + (ch << 4);

            opera_clio_poke((a & 0x10) ? 0x300 : 0x308, 1u << ch);
            dspt_ticks((a >> 8) % 24, &since);
            opera_clio_fifo_write(base + 0x00, DSPT_DATA + ((b % 0x3F00) & ~3u));
            opera_clio_fifo_write(base + 0x04, 4 + ((c % 40) & ~3u));
            opera_clio_fifo_write(base + 0x08, DSPT_DATA + (((b >> 12) % 0x3F00) & ~3u));
            opera_clio_fifo_write(base + 0x0C, 4 + (((c >> 10) % 40) & ~3u));
            dspt_ticks((b >> 26) % 24, &since);
            opera_clio_poke(0x304, 1u << ch);
            dspt_ticks((c >> 20) % 64, &since);
            if (c & 0x80000000u)
                opera_clio_poke(0x308, 1u << ch);
        } else if (op < 85) { /* stopped or started */
            opera_clio_poke(0x17FC, a & 1);
        } else if (op < 86) {
            opera_clio_poke(0x17E8, 0);
        } else if (op < 90) { /* the semaphore: written, or read back */
            if (a & 1)
                opera_clio_poke(0x17D0, b);
            else
                seen = hmix(seen, opera_clio_peek(0x17D0));
        } else if (op < 92) { /* a value handed straight to one of the DSP's input ports */
            opera_clio_poke(0x3400 + ((0x70 + ((a & 0x300) ? in_ch[(a >> 4) % 3] : a % 13)) << 2), b & 0xFFFF);
        } else if (op < 95) { /* the rest of the machine at the interrupt word: its own bits set, then answered */
            opera_clio_fiq_generate(a & 0x7FF, 0);
            opera_clio_poke(0x44, b & 0x7FF);
        } else if (op < 98) {
            /* The CPU answers the DSP's interrupts and looks at where its FIFOs have got to. Neither waits for the
               DSP of itself, so the script does: a game sees these a few dozen ticks late with the thread, which
               is harmless, but not something two runs can be compared on. */
            opera_dsp_arm_write_sync();
            seen = hmix(seen, opera_clio_peek(0x40));
            opera_clio_poke(0x44, b & 0x1FFFF800u);
            seen = hmix(seen, opera_clio_fifo_read(0x400 + (in_ch[a % 3] << 4) + ((c & 1) ? 0x04 : 0x00)));
            seen = hmix(seen, opera_clio_peek(0x3C00 + (((b >> 20) & 0xFF) << 2)));
        } else { /* knob values: one word each, and the same holds for them */
            opera_dsp_arm_write_sync();
            for (uint32_t i = 0; i < 4; i++)
                opera_clio_poke(0x3400 + (((a >> (i * 7)) % 0x70) << 2), (b >> i) & 0xFFFF);
        }
    }
    opera_lr_dsp_drain();
    opera_lr_dsp_upload();
    opera_lr_dsp_drain();
    opera_lr_dsp_upload();

    /* the thread has nothing left to do, so its counts stand still while they are read */
    opera_lr_dsp_thread_stats(&ts1);
    cost->us = platform_time_us() - t0;
    cost->waits = ts1.waits - ts0.waits;
    cost->gave_up = ts1.wait_gave_up - ts0.wait_gave_up;
    {
        uint64_t dc = opera_prof_clock64() - c0; /* the waits are counted in the profiler's clock: what is a tick? */

        cost->wait_us = dc ? (double)(ts1.wait_ticks - ts0.wait_ticks) * (double)cost->us / (double)dc : 0.0;
    }

    out[0] = g_dspt_audio;
    *samples = g_dspt_samples;
    st = (uint8_t *)malloc(opera_dsp_state_size() + opera_clio_state_size());
    if (st) {
        n = opera_dsp_state_save(st);
        out[1] = hbytes(INIT_HASH, st, n);
        n = opera_clio_state_save(st);
        out[2] = hbytes(INIT_HASH, st, n);
        free(st);
    } else {
        rc = DSPT_FAILED;
    }
    out[3] = hmem(INIT_HASH, DSPT_OUT, 0x4000 / 4);
    out[4] = seen;

    opera_clio_fiq_from_dsp_hook = NULL;
    opera_lr_dsp_init(false);
    core_unload();
    core_set_sink(&saved);
    return rc;
}

/* The five results of a script and its count of samples, as one number. */
static uint64_t dspt_fold(const uint64_t out[5], uint64_t samples)
{
    uint64_t h = INIT_HASH;

    for (int i = 0; i < 5; i++) {
        h = hmix(h, (uint32_t)out[i]);
        h = hmix(h, (uint32_t)(out[i] >> 32));
    }
    h = hmix(h, (uint32_t)samples);
    return h;
}

/*
 * The four scripts the on-console diagnostic plays, and what each leaves behind with the DSP inside the frame, as
 * measured on x86-64. Shorter than the ones "dspt" plays on the PC: the console has to run them between a boot
 * test and a table of timings, and a thread that got something wrong there would get it wrong all the time.
 */
#define DSPT_CONSOLE_SEED 20261113u
#define DSPT_CONSOLE_STEPS 2000
static const uint64_t dspt_console_expect[DEEPTEST_DSPTHREAD_SCRIPTS] = {0xdb782bfb45f90484ull, 0x6d6b0841458313d5ull,
                                                                          0x72a1ea6c6ba94557ull, 0xe69769b285b9d168ull};

uint64_t deeptest_dspthread_expect(int index)
{
    return index >= 0 && index < DEEPTEST_DSPTHREAD_SCRIPTS ? dspt_console_expect[index] : 0;
}

/* One script both ways. False only if the machine would not load; the row says the rest. */
static bool dspt_pair(uint32_t seed, int steps, deeptest_dspthread_row_t *row)
{
    uint64_t in[5] = {0, 0, 0, 0, 0}, th[5] = {0, 0, 0, 0, 0}, n_in = 0, n_th = 0, limit;
    dspt_cost_t c;
    int rc;

    memset(row, 0, sizeof(*row));
    if (dspt_once(seed, steps, false, 0, in, &n_in, &c) != DSPT_DONE)
        return false;
    row->ran = true;
    row->hash[0] = dspt_fold(in, n_in);
    row->ms[0] = (double)c.us / 1000.0;
    row->samples = n_in;
    for (int i = 0; i < 3; i++)
        row->irq[i] = g_dspt_irq[i];
    for (int i = 0; i < 5; i++)
        row->part[i] = in[i];

    limit = c.us * 6 > 3000000u ? c.us * 6 : 3000000u;
    rc = dspt_once(seed, steps, true, limit, th, &n_th, &c);
    if (rc == DSPT_FAILED)
        return false;
    if (rc == DSPT_NO_THREAD)
        return true;
    row->threaded = true;
    row->complete = rc == DSPT_DONE;
    row->hash[1] = dspt_fold(th, n_th);
    row->ms[1] = (double)c.us / 1000.0;
    row->waits = c.waits;
    row->gave_up = c.gave_up;
    row->wait_ms = c.wait_us / 1000.0;
    row->same = row->complete && row->hash[0] == row->hash[1];
    for (int i = 0; i < 5; i++)
        row->differs[i] = in[i] != th[i];
    return true;
}

bool deeptest_dspthread_script(int index, deeptest_dspthread_row_t *row)
{
    if (index < 0 || index >= DEEPTEST_DSPTHREAD_SCRIPTS) {
        memset(row, 0, sizeof(*row));
        return false;
    }
    return dspt_pair(DSPT_CONSOLE_SEED + (uint32_t)index, DSPT_CONSOLE_STEPS, row);
}

/*
 * What a wait costs. With the DSP on a thread, the CPU's writes to its program and its FIFOs wait until the
 * thread has caught up; how long that takes on this machine decides how the thread should be woken, and whether
 * a game that writes there all the time is better off without it. Measured on a running program of the size a
 * game's is: one tick with the DSP inside the frame; one tick handed to the thread and waited for at once, tick
 * after tick, so the thread has only just stopped; and the same after a pause, so the thread is asleep.
 */
bool deeptest_dspwait(deeptest_dspwait_t *out)
{
    core_sink_t sink = {null_video, null_audio};
    core_sink_t saved = core_get_sink();
    rng_t r = {DSPT_CONSOLE_SEED};
    uint32_t in_ch[3], out_ch, since = 0;
    uint64_t t0, cold = 0;

    memset(out, 0, sizeof(*out));
    core_set_sink(&sink);
    if (!core_load(NULL)) {
        core_set_sink(&saved);
        return false;
    }
    prng16_seed(0x13579BDFu);
    prng32_seed(0x2468ACE1u);
    opera_lr_dsp_init(false);
    opera_clio_poke(0x17FC, 0);
    for (uint32_t a = 0; a < 0x400; a++)
        dspt_prog(a, a < DSPT_OPENING + 150 ? dsp_gen(&r) : 0x8380);
    dspt_opening(&r, in_ch, &out_ch);
    opera_clio_poke(0x17FC, 1);

    dspt_ticks(200, &since); /* warm */
    t0 = platform_time_us();
    dspt_ticks(DEEPTEST_DSPWAIT_TICKS, &since);
    out->frame_us = (double)(platform_time_us() - t0) / DEEPTEST_DSPWAIT_TICKS;
    out->ran = true;

    opera_lr_dsp_init(true);
    if (opera_lr_dsp_is_threaded()) {
        opera_lr_dsp_thread_stats_t ts0, ts1;

        uint32_t done;

        /* Each loop stops after a second and a half whatever happens: a thread that is never there to be waited
           for makes every wait as long as the CPU is prepared to wait, and there are two thousand of them. */
        for (uint32_t i = 0; i < 200; i++) {
            dspt_ticks(1, &since);
            opera_dsp_arm_write_sync();
        }
        opera_lr_dsp_drain();
        opera_lr_dsp_thread_stats(&ts0);
        t0 = platform_time_us();
        for (done = 0; done < DEEPTEST_DSPWAIT_TICKS; done++) {
            if ((done & 15) == 15 && platform_time_us() - t0 > 1500000u)
                break;
            dspt_ticks(1, &since);
            opera_dsp_arm_write_sync();
        }
        out->hot_us = done ? (double)(platform_time_us() - t0) / done : 0.0;
        t0 = platform_time_us();
        for (done = 0; done < DEEPTEST_DSPWAIT_SLEEPS; done++) {
            uint64_t t;

            if (platform_time_us() - t0 > 1500000u)
                break;
            platform_sleep_ms(2);
            t = platform_time_us();
            dspt_ticks(1, &since);
            opera_dsp_arm_write_sync();
            cold += platform_time_us() - t;
        }
        out->cold_us = done ? (double)cold / done : 0.0;
        opera_lr_dsp_drain();
        opera_lr_dsp_thread_stats(&ts1);
        out->gave_up = ts1.wait_gave_up - ts0.wait_gave_up;
        out->threaded = true;
    }
    opera_lr_dsp_init(false);
    core_unload();
    core_set_sink(&saved);
    return true;
}

static const char *dspt_what_differs(const deeptest_dspthread_row_t *row, char *buf, size_t cap)
{
    static const char *const names[5] = {"the sound", "the DSP's state", "the CLIO's state", "the memory it wrote",
                                         "what the CPU read back"};

    buf[0] = '\0';
    for (int i = 0; i < 5; i++)
        if (row->differs[i]) {
            if (buf[0])
                strncat(buf, ", ", cap - strlen(buf) - 1);
            strncat(buf, names[i], cap - strlen(buf) - 1);
        }
    return buf;
}

static void dspt_say_row(const char *name, int number, const deeptest_dspthread_row_t *row)
{
    char what[160];

    if (!row->threaded) {
        say("%s %5d %016llx (%llu samples; no thread in this build, so only the DSP inside the frame ran)\n", name,
            number, (unsigned long long)row->hash[0], (unsigned long long)row->samples);
        return;
    }
    if (!row->complete)
        say("%s %5d CUT SHORT: with the thread it took too long (%.0f ms against %.0f ms; the CPU waited %llu times "
            "and gave up %llu)\n",
            name, number, row->ms[1], row->ms[0], (unsigned long long)row->waits, (unsigned long long)row->gave_up);
    else if (!row->same)
        say("%s %5d DIFFERS: %016llx inside the frame, %016llx on the thread; different: %s (the CPU gave up waiting "
            "%llu times)\n",
            name, number, (unsigned long long)row->hash[0], (unsigned long long)row->hash[1],
            dspt_what_differs(row, what, sizeof(what)), (unsigned long long)row->gave_up);
    say("%s %5d %016llx (%llu samples; the DSP raised %llu interrupts of its own, %llu for the end of a FIFO it "
        "reads, %llu for one it writes; %.1f ms inside the frame, %.1f ms on the thread; the CPU waited for the "
        "thread %llu times, %.1f ms in all, and gave up %llu)\n",
        name, number, (unsigned long long)row->hash[0], (unsigned long long)row->samples,
        (unsigned long long)row->irq[0], (unsigned long long)row->irq[1], (unsigned long long)row->irq[2], row->ms[0],
        row->ms[1], (unsigned long long)row->waits, row->wait_ms, (unsigned long long)row->gave_up);
}

/* "dspt": `trials` long scripts, seeds `seed` onwards. For the PC, where there is time for them. */
static bool deeptest_dspt(uint32_t seed, int trials)
{
    bool ok = true;
    int same = 0, threaded = 0;

    for (int t = 0; t < trials; t++) {
        deeptest_dspthread_row_t row;

        if (!dspt_pair(seed + (uint32_t)t, 4000, &row))
            return false;
        threaded += row.threaded ? 1 : 0;
        same += row.same ? 1 : 0;
        ok = ok && (!row.threaded || row.same);
        if (t == trials - 1 || trials <= 16 || (row.threaded && !row.same))
            dspt_say_row("dspt", t + 1, &row);
    }
    if (threaded)
        say("dspt: the DSP on a thread did what the DSP inside the frame did in %d of %d scripts\n", same, trials);
    else
        say("dspt: no thread in this build\n");
    return ok;
}

/* "dspc": the four scripts of the on-console diagnostic against their references, and what a wait costs. */
static bool deeptest_dspc(void)
{
    deeptest_dspwait_t w;
    bool ok = true;
    int same = 0, threaded = 0, equal = 0;

    for (int i = 0; i < DEEPTEST_DSPTHREAD_SCRIPTS; i++) {
        deeptest_dspthread_row_t row;
        uint64_t want = deeptest_dspthread_expect(i);

        if (!deeptest_dspthread_script(i, &row))
            return false;
        dspt_say_row("dspc", i + 1, &row);
        say("dspc %5d inside the frame %016llx expected %016llx %s\n", i + 1, (unsigned long long)row.hash[0],
            (unsigned long long)want, !want ? "(no reference)" : row.hash[0] == want ? "ok" : "DIFFERS");
        say("dspc %5d made of: sound %016llx, DSP %016llx, CLIO %016llx, memory %016llx, read back %016llx\n", i + 1,
            (unsigned long long)row.part[0], (unsigned long long)row.part[1], (unsigned long long)row.part[2],
            (unsigned long long)row.part[3], (unsigned long long)row.part[4]);
        equal += want && row.hash[0] == want ? 1 : 0;
        threaded += row.threaded ? 1 : 0;
        same += row.same ? 1 : 0;
        ok = ok && (!want || row.hash[0] == want) && (!row.threaded || row.same);
    }
    say("dspc: %d of %d equal to the x86 reference inside the frame; on a thread %d of %d the same%s\n", equal,
        DEEPTEST_DSPTHREAD_SCRIPTS, same, DEEPTEST_DSPTHREAD_SCRIPTS, threaded ? "" : " (no thread in this build)");
    if (!deeptest_dspwait(&w))
        return false;
    if (w.threaded)
        say("dspc: one tick %.2f us inside the frame; handed to the thread and waited for, %.2f us just after it "
            "ran and %.2f us from asleep (gave up %llu times)\n",
            w.frame_us, w.hot_us, w.cold_us, (unsigned long long)w.gave_up);
    else
        say("dspc: one tick %.2f us inside the frame\n", w.frame_us);
    return ok;
}

/* ------------------------------------------------------------- cel engine */

#define CEL_CCB  0x00100000u
#define CEL_DATA 0x00110000u
#define CEL_PLUT 0x00120000u
#define CEL_FB   0x00200000u
#define CEL_FBW  320
#define CEL_FBH  240
#define CEL_FB_WORDS ((CEL_FBW * CEL_FBH * 2) / 4)

/* ACSC ALSC ACW ACCW TWD LCE ACE, MARIA PXOR USEAV, POVER PLUTPOS BGND NOBLK PLUTA */
#define CEL_RANDOM_FLAGS (0x00800000u | 0x001FC000u | 0x00001000u | 0x00000800u | 0x00000400u | 0x00000180u | \
                          0x00000040u | 0x00000020u | 0x00000010u | 0x0000000Fu)

enum {
    F_LAST = 0x40000000, F_NPABS = 0x20000000, F_SPABS = 0x10000000, F_PPABS = 0x08000000, F_LDSIZE = 0x04000000,
    F_LDPRS = 0x02000000, F_LDPPMP = 0x01000000, F_LDPLUT = 0x00800000, F_CCBPRE = 0x00400000, F_YOXY = 0x00200000,
    F_PACKED = 0x00000200
};

static uint32_t g_fb_before[CEL_FB_WORDS];

/* `detail`: print the CCB and every frame buffer word the last cel changed */
/*
 * A PIXC the way a real game sets it: colour 1 taken from the source pixel (s1 = 0) and scaled by the plain
 * table (ms = 0), with colour 2 from anywhere but the frame buffer (s2 != 2). Measured over 1.7 million cels of
 * a running game, that is how 98% of them are set up, while the generator above produces that shape for only
 * about 5% of pixels - so without this the fast path in the pixel processor would hardly be exercised at all.
 * The field positions are the same on both architectures; see pixctag_s in opera_madam.c.
 */
static uint32_t pixc_game_half(rng_t *r)
{
    uint32_t dv2 = rnd_n(r, 2);  /* one draw per statement, see the note in arm_gen() */
    uint32_t av = rnd_n(r, 32);
    uint32_t s2 = rnd_n(r, 3);
    uint32_t dv1 = rnd_n(r, 4);
    uint32_t mxf = rnd_n(r, 8);

    if (s2 == 2)
        s2 = 3; /* 2 means "from the frame buffer", which is the one shape this battery leaves out */
    return (dv2 | (av << 1) | (s2 << 6) | (dv1 << 8) | (mxf << 10));
}

static uint32_t pixc_game(rng_t *r)
{
    uint32_t lo = pixc_game_half(r);
    uint32_t hi = (rnd_n(r, 4) == 0) ? pixc_game_half(r) : lo; /* a quarter of real cels have two halves */

    return ((hi << 16) | lo);
}

/*
 * Which cels a battery makes. The first two only differ in PIXC. The third is there for what they leave out: they
 * put every cel at a fractional position inside the screen, and the engine only takes its line path - the one for
 * a cel drawn at its own size, which is most of what a 2D game draws - when the position is a whole pixel. So
 * that path was never reached by them, and neither were cels hanging off the top or the left of the screen. Nor
 * does any of their cels have anything in common with the one before, which leaves untested whatever the engine
 * keeps from one cel to the next.
 */
enum { CEL_SHAPE_RANDOM, CEL_SHAPE_GAME, CEL_SHAPE_EDGE };

#define CEL_PIXC_POOL 24
static uint32_t g_cel_pixc_pool[CEL_PIXC_POOL];

static const char *const cel_shape_name[] = {"cel", "celg", "celu"};

static bool deeptest_cel_ex(uint32_t seed, int trials, bool detail, int shape)
{
    const bool game_shape = shape == CEL_SHAPE_GAME;
    const char *const name = cel_shape_name[shape];
    rng_t r = {seed ? seed : 1};
    uint64_t total = INIT_HASH;
    int changed = 0;
    uint64_t prev_fb = 0;
    uint32_t ssize = shape == CEL_SHAPE_EDGE ? opera_madam_state_size() : 0;
    uint8_t *st = ssize ? (uint8_t *)malloc(ssize) : NULL;

    if (ssize && !st)
        return false;

    opera_madam_poke(0x130, 0x1414);                           /* REGCTL0: 320 pixel wide read / write buffers */
    opera_madam_poke(0x134, ((uint32_t)CEL_FBH << 16) | CEL_FBW); /* REGCTL1: clip box */
    opera_madam_poke(0x138, CEL_FB);                           /* REGCTL2: source (blend) buffer */
    opera_madam_poke(0x13C, CEL_FB);                           /* REGCTL3: destination buffer */

    for (uint32_t i = 0; i < CEL_FB_WORDS; i++)
        opera_mem_write32(CEL_FB + i * 4, rnd(&r));
    prev_fb = hmem(INIT_HASH, CEL_FB, CEL_FB_WORDS);
    for (uint32_t i = 0; i < 0x10000 / 4; i++)
        opera_mem_write32(CEL_DATA + i * 4, rnd(&r));
    for (uint32_t i = 0; i < 0x1000 / 4; i++)
        opera_mem_write32(CEL_PLUT + i * 4, rnd(&r));
    if (shape == CEL_SHAPE_EDGE) {
        /*
         * Two things a game does and noise does not. It mixes cels into the picture in a handful of ways that it
         * keeps coming back to, where a random PIXC is never seen twice: so a pool of them, most of the kind
         * that reads the frame buffer, which cels below draw from with whatever flags they happen to have. And
         * its pictures repeat their colours: so the last fifth of the source data is made of sixteen words.
         */
        uint32_t few[16];

        for (int i = 0; i < CEL_PIXC_POOL; i++) {
            uint32_t w = rnd(&r);

            if (i < 16) /* lower half: colour 1 from the source, colour 2 from the frame buffer */
                w = (w & ~0x000080C0u) | 0x00000080u;
            if (i < 8) /* and the upper half the same as the lower */
                w = (w & 0xFFFFu) * 0x10001u;
            g_cel_pixc_pool[i] = w;
        }
        for (int i = 0; i < 16; i++)
            few[i] = rnd(&r);
        for (uint32_t i = 0xC000 / 4; i < 0x10000 / 4; i++) {
            uint32_t k = rnd_n(&r, 16);

            opera_mem_write32(CEL_DATA + i * 4, few[k]);
        }
    }

    for (int t = 0; t < trials; t++) {
        uint32_t ccb = CEL_CCB + (uint32_t)(t & 63) * 0x80;
        uint32_t flags = F_LAST | F_NPABS | F_SPABS | F_PPABS | F_LDSIZE | F_LDPRS | F_LDPPMP | F_YOXY | F_CCBPRE;
        uint32_t bpp = 1 + rnd_n(&r, 6);                 /* 1, 2, 4, 6, 8, 16 bits per pixel */
        uint32_t pre0, pre1 = 0, a = ccb;
        uint32_t hdx[] = {0x100000, 0x080000, 0x200000, 0x180000, 0xFFF00000u, 0x0C0000};
        uint64_t h = INIT_HASH;

        /* CCB_USEAV (0x400) is never set by the games measured, and the fast path only applies without it */
        flags |= rnd(&r) & (game_shape ? (CEL_RANDOM_FLAGS & ~0x00000400u) : CEL_RANDOM_FLAGS);
        if (rnd_n(&r, 3) == 0)
            flags |= F_PACKED;

        { /* one draw per statement, see the note in arm_gen() */
            uint32_t p0 = rnd_n(&r, 2);
            uint32_t p1 = rnd_n(&r, 2);
            uint32_t p2 = rnd_n(&r, 3);
            uint32_t p3 = rnd_n(&r, 14);
            uint32_t p4 = rnd_n(&r, 2);
            uint32_t p5 = rnd_n(&r, 2);
            uint32_t q0 = rnd_n(&r, 16);
            uint32_t q1 = rnd_n(&r, 16);
            uint32_t q2 = rnd_n(&r, 4);
            uint32_t q3 = rnd_n(&r, 2);
            uint32_t q4 = rnd_n(&r, 3);
            uint32_t q5 = rnd_n(&r, 32);

            pre0 = (p0 ? 0x80000000u : 0) | (p1 ? 0x40000000u : 0) | (p2 << 24) | (p3 << 6) | (p4 << 4) | (p5 << 3) |
                   bpp;
            pre1 = (q0 << 24) | (q1 << 16) | (q2 << 12) | (q3 << 14) | (q4 == 0 ? 0x800u : 0) | q5;
        }

        opera_mem_write32(a + 0x00, flags);
        opera_mem_write32(a + 0x04, CEL_CCB + 0x7000);                /* next (absolute, unused: LAST) */
        opera_mem_write32(a + 0x08, CEL_DATA + (rnd_n(&r, 60) << 10)); /* source data */
        opera_mem_write32(a + 0x0C, CEL_PLUT + (rnd_n(&r, 60) << 6));  /* PLUT */
        if (shape == CEL_SHAPE_EDGE) {
            /* 12.20, as the CCB holds HDX and HDY, and 16.16, as it holds VDX and VDY */
            static const uint32_t along_step[6] = {0x100000, 0x080000, 0x200000, 0x180000, 0x0C0000, 0x300000};
            static const uint32_t down_step[4] = {0x10000, 0x20000, 0x8000, 0x18000};
            uint32_t kind = rnd_n(&r, 20); /* 0-10 own size on whole pixels, 11-17 scaled, 18-19 slanted */
            uint32_t xi = rnd_n(&r, 400);  /* one draw per statement, see the note in arm_gen() */
            uint32_t xf = rnd(&r) & 0xFFFF;
            uint32_t yi = rnd_n(&r, 304);
            uint32_t yf = rnd(&r) & 0xFFFF;
            uint32_t orient = rnd_n(&r, 8);
            uint32_t along = rnd_n(&r, 6);
            uint32_t down = rnd_n(&r, 4);
            uint32_t both = rnd_n(&r, 3);
            uint32_t how = rnd_n(&r, 4); /* PIXC: 0-1 as a game sets it, 2 anything, 3 one of the pool */
            uint32_t which = rnd_n(&r, CEL_PIXC_POOL);
            uint32_t box = rnd_n(&r, 4);
            uint32_t boxw = rnd_n(&r, 257);
            uint32_t boxh = rnd_n(&r, 193);
            uint32_t e0 = rnd(&r);
            uint32_t e1 = rnd(&r);
            uint32_t e2 = rnd(&r);
            uint32_t e3 = rnd(&r);
            uint32_t tinted = rnd_n(&r, 16); /* 0: see below */
            uint32_t tint = rnd_n(&r, 2);
            uint32_t tdata = rnd_n(&r, 8);
            uint32_t sa = kind <= 10 ? 0x100000u : along_step[along];
            uint32_t sd = kind <= 10 ? 0x10000u : down_step[down];
            uint32_t g_hdx, g_hdy, g_vdx, g_vdy, g_hddx = 0, g_hddy = 0;
            uint32_t pixc;

            if (orient & 1)
                sa = 0u - sa;
            if (orient & 2)
                sd = 0u - sd;
            if (orient & 4) { /* turned a quarter: the rows run down the screen */
                g_hdx = 0;
                g_hdy = sa;
                g_vdx = sd;
                g_vdy = 0;
            } else {
                g_hdx = sa;
                g_hdy = 0;
                g_vdx = 0;
                g_vdy = sd;
            }
            if (kind >= 18) { /* neither a line nor a rectangle any more: the arbitrary path */
                g_hdy += (e0 & 0xFFFFF) - 0x80000;
                g_vdx += (e1 & 0x7FFF) - 0x4000;
                g_hddx = (e2 & 0x1FFF) - 0x1000;
                g_hddy = (e3 & 0x1FFF) - 0x1000;
            }
            /* from 48 pixels left of the screen to 32 right of it, and from 40 above it to 24 below */
            opera_mem_write32(a + 0x10, ((xi - 48u) << 16) | (kind <= 10 ? 0 : xf));
            opera_mem_write32(a + 0x14, ((yi - 40u) << 16) | (kind <= 10 ? 0 : yf));
            opera_mem_write32(a + 0x18, g_hdx);
            opera_mem_write32(a + 0x1C, g_hdy);
            opera_mem_write32(a + 0x20, g_vdx);
            opera_mem_write32(a + 0x24, g_vdy);
            opera_mem_write32(a + 0x28, g_hddx);
            opera_mem_write32(a + 0x2C, g_hddy);
            if (both) /* ACW and ACCW: drawn whichever way round it winds */
                opera_mem_write32(a + 0x00, flags | 0x00040000u | 0x00020000u);
            pixc = how < 2 ? pixc_game(&r) : how == 2 ? rnd(&r) : g_cel_pixc_pool[which];
            if (tinted == 0) {
                /*
                 * One cel in sixteen is the hardest case for the tables the engine keeps: a 16-bit coded cel,
                 * whose every texel brings its own multiplier for each of the three channels, mixed with the
                 * frame buffer. Two ways of mixing only, and source data of few values, so that the same tables
                 * are asked for again and again - with whatever flags the cel happens to have.
                 */
                static const uint32_t mix[2] = {0x23812381u, 0xA1C1A1C1u};

                pre0 = (pre0 & ~0x17u) | 6u; /* 16 bits per pixel, through the PLUT */
                opera_mem_write32(a + 0x08, CEL_DATA + 0xC000 + (tdata << 10));
                pixc = mix[tint];
            }
            opera_mem_write32(a + 0x30, pixc);
            /* A clip box smaller than the buffer one time in four: a pixel written past it then lands in what is
               hashed, where past the bottom of the full box it would not. */
            opera_madam_poke(0x134, box ? ((((uint32_t)CEL_FBH - 1) << 16) | (CEL_FBW - 1))
                                        : (((47 + boxh) << 16) | (63 + boxw)));
        } else {
            {
                uint32_t xi = rnd_n(&r, 300);
                uint32_t xf = rnd(&r) & 0xFFFF;
                uint32_t yi = rnd_n(&r, 220);
                uint32_t yf = rnd(&r) & 0xFFFF;

                opera_mem_write32(a + 0x10, (xi << 16) | xf); /* x */
                opera_mem_write32(a + 0x14, (yi << 16) | yf); /* y */
            }
            opera_mem_write32(a + 0x18, hdx[rnd_n(&r, 6)]);
            opera_mem_write32(a + 0x1C, rnd_n(&r, 3) ? 0 : (rnd(&r) & 0x1FFFF) - 0x10000);
            opera_mem_write32(a + 0x20, rnd_n(&r, 3) ? 0 : (rnd(&r) & 0x7FFF) - 0x4000);
            opera_mem_write32(a + 0x24, rnd_n(&r, 2) ? 0x10000 : 0x20000);
            opera_mem_write32(a + 0x28, rnd_n(&r, 4) ? 0 : (rnd(&r) & 0x1FFF) - 0x1000);
            opera_mem_write32(a + 0x2C, rnd_n(&r, 4) ? 0 : (rnd(&r) & 0x1FFF) - 0x1000);
            {
                uint32_t pixc = game_shape ? pixc_game(&r) : rnd(&r);

                opera_mem_write32(a + 0x30, pixc); /* PIXC */
            }
        }
        opera_mem_write32(a + 0x34, pre0);
        opera_mem_write32(a + 0x38, pre1);

        if (detail && t == trials - 1) {
            say("  ccb:");
            for (uint32_t o = 0; o < 0x3C; o += 4)
                say(" %08x", opera_mem_read32(a + o));
            say("\n");
            for (uint32_t i = 0; i < CEL_FB_WORDS; i++)
                g_fb_before[i] = opera_mem_read32(CEL_FB + i * 4);
        }

        opera_madam_poke(0x5A4, a); /* NEXTCCB */
        opera_madam_cel_handle();

        if (detail && t == trials - 1) {
            int shown = 0;

            for (uint32_t i = 0; i < CEL_FB_WORDS; i++) {
                uint32_t v = opera_mem_read32(CEL_FB + i * 4);

                if (v != g_fb_before[i] && shown++ < 4000)
                    say("  fb %06x %08x -> %08x\n", i * 4, g_fb_before[i], v);
            }
            say("  fb words changed: %d\n", shown);
            for (uint32_t i = 0; i < 0x20; i++)
                say("  reg %03x %08x\n", 0x130 + i * 4, opera_madam_registers()[0x130 / 4 + i]);
        }

        h = hmem(h, CEL_FB, CEL_FB_WORDS);
        if (h != prev_fb)
            changed++;
        prev_fb = h;
        for (uint32_t i = 0; i < 0x20; i++)
            h = hmix(h, opera_madam_registers()[0x130 / 4 + i]); /* a window of the control registers */
        if (st) {
            /* The engine's saved state carries how long it stays busy, which is worked out from the number of
               pixels it wrote and texels it walked: a wrong count shows here even when the picture is right. */
            uint32_t n = opera_madam_state_save(st);

            h = hbytes(h, st, n);
        }
        total = hmix(total, (uint32_t)h);
        total = hmix(total, (uint32_t)(h >> 32));
        if ((t % 100) == 99 || t == trials - 1 || trials <= 64)
            say("%s %5d %016llx\n", name, t + 1, (unsigned long long)total);
    }
    say("%s: frame buffer changed by %d of %d cels\n", name, changed, trials);
    if (shape == CEL_SHAPE_EDGE) /* the next battery, or the boot that follows, expects the full box */
        opera_madam_poke(0x134, ((uint32_t)CEL_FBH << 16) | CEL_FBW);
    free(st);
    g_last_total = total;
    return true;
}

static bool deeptest_cel(uint32_t seed, int trials, bool detail)
{
    return deeptest_cel_ex(seed, trials, detail, CEL_SHAPE_RANDOM);
}

/* The same cels, set up the way a running game sets them; see pixc_game(). */
static bool deeptest_celg(uint32_t seed, int trials, bool detail)
{
    return deeptest_cel_ex(seed, trials, detail, CEL_SHAPE_GAME);
}

/* Cels at their own size on whole pixels, and cels hanging off every edge of the screen; see CEL_SHAPE_EDGE. */
static bool deeptest_celu(uint32_t seed, int trials, bool detail)
{
    return deeptest_cel_ex(seed, trials, detail, CEL_SHAPE_EDGE);
}

/* --------------------------------------------- the cel engine, timed on sprites */

/*
 * The batteries above draw random cels, which is right for finding where two builds differ and wrong for saying
 * how fast a game will run: their source data is noise, so nearly every texel is a value of its own, and two in
 * three of them take the path for slanted cels. A game draws sprites: a few colours, runs of one colour, whole
 * pixels, their own size. These are eight shapes of that kind. Each is drawn many times over the same background
 * and timed twice - with the engine's table of finished pixels switched off and on - and the two pictures are
 * compared. The result is a time per pixel written, on whatever machine this runs on.
 */
typedef struct {
    const char *name;
    uint32_t bpp_code; /* the BPP field of PRE0: 3 = 4 bits, 4 = 6, 5 = 8, 6 = 16 */
    bool packed;
    bool linear; /* the pixel is the colour itself, not an index into the PLUT */
    bool lrform; /* stored as a frame buffer is: two lines to a row of words */
    bool solid;  /* a full rectangle of many colours, not a silhouette of a few */
    uint32_t w, h;
    uint32_t hdx, hdy, vdx, vdy; /* as the CCB holds them: 12.20 and 16.16 */
    uint32_t pixc;
    uint32_t x, y; /* 16.16 */
    int reps;
} celbench_shape_t;

#define PIXC_COPY  0x1F001F00u /* the source pixel as it is */
#define PIXC_SHADE 0x23002300u /* the source pixel scaled by the multiplier that comes with each texel (ms 1) */
#define PIXC_MIX   0x1F811F81u /* half the source pixel plus half of what is on the screen: reads the frame buffer */

static const celbench_shape_t celbench_shapes[DEEPTEST_CELBENCH_ROWS] = {
    {"4-bit packed sprite, own size", 3, true, false, false, false, 64, 96, 0x100000, 0, 0, 0x10000, PIXC_COPY,
     100u << 16, 60u << 16, 100},
    {"6-bit packed sprite, own size", 4, true, false, false, false, 64, 96, 0x100000, 0, 0, 0x10000, PIXC_COPY,
     100u << 16, 60u << 16, 100},
    {"8-bit sprite, shaded per texel", 5, false, false, false, false, 96, 96, 0x100000, 0, 0, 0x10000, PIXC_SHADE,
     100u << 16, 60u << 16, 80},
    {"16-bit picture, own size", 6, false, true, false, true, 160, 100, 0x100000, 0, 0, 0x10000, PIXC_COPY,
     80u << 16, 70u << 16, 30},
    {"16-bit picture in screen layout", 6, false, true, true, true, 160, 100, 0x100000, 0, 0, 0x10000, PIXC_COPY,
     80u << 16, 70u << 16, 30},
    {"6-bit packed sprite, 1.5 x size", 4, true, false, false, false, 64, 96, 0x180000, 0, 0, 0x18000, PIXC_COPY,
     (100u << 16) | 0x8000, (40u << 16) | 0x8000, 50},
    {"6-bit packed sprite, turned", 4, true, false, false, false, 64, 96, 0x0F0904, 0x0578EE, 0xFFFFA872u, 0xF090,
     PIXC_COPY, (140u << 16) | 0x8000, (60u << 16) | 0x8000, 30},
    {"6-bit packed sprite, mixed in", 4, true, false, false, false, 64, 96, 0x100000, 0, 0, 0x10000, PIXC_MIX,
     100u << 16, 60u << 16, 100},
};

/* what the x86-64 build draws; see deeptest_specs below for why this holds on any correct build */
#define CELBENCH_EXPECT 0x38d447dbe65f1629ull

typedef struct {
    uint32_t base; /* guest address of the first byte */
    uint32_t bit;  /* bits written so far */
} bitw_t;

static void bw_put(bitw_t *w, uint32_t v, uint32_t n)
{
    for (uint32_t i = 0; i < n; i++) {
        uint32_t a = w->base + (w->bit >> 3);
        uint32_t m = 0x80u >> (w->bit & 7);
        uint32_t b = opera_mem_read8(a);

        b = ((v >> (n - 1 - i)) & 1) ? (b | m) : (b & ~m);
        opera_mem_write8(a, (uint8_t)b);
        w->bit++;
    }
}

static uint16_t g_bench_img[160 * 128];

/* The picture a shape draws, as source values: 0 is "nothing here" for the silhouettes. */
static void celbench_image(const celbench_shape_t *sh, rng_t *r)
{
    static const uint32_t bits[8] = {1, 1, 2, 4, 6, 8, 16, 1};
    uint32_t ncol = bits[sh->bpp_code] >= 5 ? 32 : (1u << bits[sh->bpp_code]);

    for (uint32_t y = 0; y < sh->h; y++) {
        uint16_t *row = &g_bench_img[y * sh->w];

        if (sh->solid) { /* a shaded picture: thousands of colours, none of them black */
            for (uint32_t x = 0; x < sh->w; x++) {
                uint32_t n = rnd_n(r, 3);
                uint32_t red = (x * 31) / (sh->w - 1);
                uint32_t green = (y * 31) / (sh->h - 1);
                uint32_t blue = 1 + (((x + y) >> 2) + n) % 30;

                row[x] = (uint16_t)((red << 10) | (green << 5) | blue);
            }
            continue;
        }
        { /* an oval, filled with runs of one colour and stretches of two */
            int32_t dy = 2 * (int32_t)y - ((int32_t)sh->h - 1);
            uint32_t r2 = sh->h * sh->h - (uint32_t)(dy * dy);
            uint32_t root = 0;
            uint32_t half, x0, x1, x;

            while ((root + 1) * (root + 1) <= r2)
                root++;
            half = (root * sh->w) / (2 * sh->h);
            x0 = sh->w / 2 - half;
            x1 = sh->w / 2 + half;
            for (x = 0; x < sh->w; x++)
                row[x] = 0;
            for (x = x0; x < x1;) {
                uint32_t len = 1 + rnd_n(r, 10);
                uint32_t flat = rnd_n(r, 2);
                uint32_t col = 1 + rnd_n(r, ncol - 2);
                uint32_t shade = sh->bpp_code == 5 ? (((y * 8) / sh->h) << 5) : 0; /* the 8-bit form carries it */

                for (uint32_t i = 0; i < len && x < x1; i++, x++) {
                    uint32_t two = rnd_n(r, 2);

                    row[x] = (uint16_t)(shade | (flat ? col : col + two));
                }
            }
        }
    }
}

/* Writes the picture as cel data at CEL_DATA and its CCB at CEL_CCB. */
static void celbench_build(const celbench_shape_t *sh)
{
    static const uint32_t bits[8] = {1, 1, 2, 4, 6, 8, 16, 1};
    uint32_t bpp = bits[sh->bpp_code];
    uint32_t flags = F_LAST | F_NPABS | F_SPABS | F_PPABS | F_LDSIZE | F_LDPRS | F_LDPPMP | F_LDPLUT | F_CCBPRE |
                     F_YOXY | 0x00040000u | 0x00020000u; /* ACW and ACCW */
    uint32_t pre0 = ((sh->h - 1) << 6) | (sh->linear ? 0x10u : 0) | sh->bpp_code;
    uint32_t pre1 = 0;
    uint32_t a = CEL_CCB;

    for (uint32_t i = 0; i < 0x10000 / 4; i++)
        opera_mem_write32(CEL_DATA + i * 4, 0);
    if (sh->lrform) {
        /* a row of words holds one pixel of each of two lines, as in a frame buffer */
        for (uint32_t y = 0; y < sh->h; y++)
            for (uint32_t x = 0; x < sh->w; x++)
                opera_mem_write16(CEL_DATA + (y >> 1) * (sh->w * 4) + ((y & 1) << 1) + (x << 2),
                                  g_bench_img[y * sh->w + x]);
        pre0 = ((sh->h / 2 - 1) << 6) | 0x10u | sh->bpp_code;
        pre1 = ((sh->w - 2) << 16) | 0x800u | (sh->w - 1);
    } else if (!sh->packed) {
        uint32_t words = (sh->w * bpp + 31) / 32;

        if (words < 2)
            words = 2;
        for (uint32_t y = 0; y < sh->h; y++) {
            bitw_t w = {CEL_DATA + y * words * 4, 0};

            for (uint32_t x = 0; x < sh->w; x++)
                bw_put(&w, g_bench_img[y * sh->w + x], bpp);
        }
        pre1 = ((words - 2) << (bpp < 8 ? 24 : 16)) | (sh->w - 1);
    } else {
        uint32_t at = CEL_DATA;

        flags |= F_PACKED;
        for (uint32_t y = 0; y < sh->h; y++) {
            const uint16_t *row = &g_bench_img[y * sh->w];
            bitw_t w = {at, 0};
            uint32_t words, x = 0, end = sh->w;

            while (end > 0 && row[end - 1] == 0)
                end--; /* nothing is stored for the empty right side of a row */
            bw_put(&w, 0, bpp < 8 ? 8 : 16); /* the distance to the next row, filled in below */
            while (x < end) {
                uint32_t n = 1;

                while (x + n < end && n < 64 && row[x + n] == row[x])
                    n++;
                if (row[x] == 0) { /* a stretch of nothing */
                    bw_put(&w, 2, 2);
                    bw_put(&w, n - 1, 6);
                } else if (n >= 3) { /* one colour repeated */
                    bw_put(&w, 3, 2);
                    bw_put(&w, n - 1, 6);
                    bw_put(&w, row[x], bpp);
                } else { /* pixels one by one, up to the next stretch worth packing */
                    uint32_t m = 0;

                    while (x + m < end && m < 64 && row[x + m] != 0 &&
                           !(x + m + 2 < end && row[x + m] == row[x + m + 1] && row[x + m] == row[x + m + 2]))
                        m++;
                    n = m;
                    bw_put(&w, 1, 2);
                    bw_put(&w, n - 1, 6);
                    for (uint32_t i = 0; i < n; i++)
                        bw_put(&w, row[x + i], bpp);
                }
                x += n;
            }
            bw_put(&w, 0, 8); /* end of the row */
            words = (w.bit + 31) / 32;
            if (words < 2)
                words = 2;
            {
                bitw_t o = {at, 0};

                bw_put(&o, words - 2, bpp < 8 ? 8 : 16);
            }
            at += words * 4;
        }
    }

    /* 32 colours, none of them black except the first, which is how a sprite says "nothing here" */
    for (uint32_t i = 0; i < 32; i++)
        opera_mem_write16(CEL_PLUT + i * 2, (uint16_t)(i == 0 ? 0 : (((i * 7 + 3) & 31) << 10) |
                                                                    (((i * 13 + 5) & 31) << 5) | (1 + (i * 11) % 31)));

    opera_mem_write32(a + 0x00, flags);
    opera_mem_write32(a + 0x04, CEL_CCB + 0x7000);
    opera_mem_write32(a + 0x08, CEL_DATA);
    opera_mem_write32(a + 0x0C, CEL_PLUT);
    opera_mem_write32(a + 0x10, sh->x);
    opera_mem_write32(a + 0x14, sh->y);
    opera_mem_write32(a + 0x18, sh->hdx);
    opera_mem_write32(a + 0x1C, sh->hdy);
    opera_mem_write32(a + 0x20, sh->vdx);
    opera_mem_write32(a + 0x24, sh->vdy);
    opera_mem_write32(a + 0x28, 0);
    opera_mem_write32(a + 0x2C, 0);
    opera_mem_write32(a + 0x30, sh->pixc);
    opera_mem_write32(a + 0x34, pre0);
    opera_mem_write32(a + 0x38, pre1);
}

/* Needs a loaded core. `scale` divides the repeat counts (the PowerPC simulator is a hundred times slower);
 * `only` is 0 for every shape or the number of the one to run, counted from 1 (for a profiler). */
static bool celbench_run(deeptest_celbench_row_t rows[DEEPTEST_CELBENCH_ROWS], uint64_t *hash, uint32_t seed,
                         int scale, int only)
{
    uint64_t total = INIT_HASH;

    opera_madam_poke(0x130, 0x1414);
    opera_madam_poke(0x134, (((uint32_t)CEL_FBH - 1) << 16) | (CEL_FBW - 1));
    opera_madam_poke(0x138, CEL_FB);
    opera_madam_poke(0x13C, CEL_FB);

    for (int i = 0; i < DEEPTEST_CELBENCH_ROWS; i++) {
        const celbench_shape_t *sh = &celbench_shapes[i];
        rng_t r = {seed + 977u * (uint32_t)(i + 1)};
        int reps = sh->reps / (scale > 0 ? scale : 1);
        uint64_t h[2] = {0, 0};

        if (reps < 2)
            reps = 2;
        rows[i].name = sh->name;
        rows[i].draws = reps;
        rows[i].pixels = 0;
        rows[i].us[0] = rows[i].us[1] = 0;
        rows[i].same = true;
        if (only && only != i + 1)
            continue;
        celbench_image(sh, &r);
        celbench_build(sh);
        /* Three passes of each, keeping the quickest: one pass is at the mercy of whatever else the machine did
           in that moment. Off and on take turns so that neither always runs on a warmer machine. */
        for (int pass = 0; pass < 6; pass++) {
            int mode = pass & 1;
            rng_t bg = {seed + 31u * (uint32_t)(i + 1)};
            uint64_t t0, px = 0;
            uint32_t us;

            for (uint32_t k = 0; k < CEL_FB_WORDS; k++) /* the same detailed background every time */
                opera_mem_write32(CEL_FB + k * 4, rnd(&bg));
            opera_madam_cel_value_cache(mode);
            t0 = platform_time_us();
            for (int k = 0; k < reps; k++) {
                opera_madam_poke(0x5A4, CEL_CCB);
                opera_madam_cel_handle();
            }
            us = (uint32_t)(platform_time_us() - t0);
            if (pass < 2 || us < rows[i].us[mode])
                rows[i].us[mode] = us;
            opera_madam_cel_last_work(&px, NULL);
            rows[i].pixels = px;
            h[mode] = hmem(INIT_HASH, CEL_FB, CEL_FB_WORDS);
        }
        opera_madam_cel_value_cache(1);
        rows[i].same = h[0] == h[1];
        total = hmix(total, (uint32_t)h[1]);
        total = hmix(total, (uint32_t)(h[1] >> 32));
        total = hmix(total, (uint32_t)rows[i].pixels);
    }
    if (hash)
        *hash = total;
    return true;
}

uint64_t deeptest_celbench_expect(void)
{
    return CELBENCH_EXPECT;
}

bool deeptest_celbench(deeptest_celbench_row_t rows[DEEPTEST_CELBENCH_ROWS], uint64_t *hash)
{
    core_sink_t sink = {null_video, null_audio};
    core_sink_t saved = core_get_sink();
    bool ok;

    core_set_sink(&sink);
    if (!core_load(NULL)) {
        core_set_sink(&saved);
        return false;
    }
    prng16_seed(0x13579BDFu);
    prng32_seed(0x2468ACE1u);
    ok = celbench_run(rows, hash, 20261113u, 1, 0);
    core_unload();
    core_set_sink(&saved);
    return ok;
}

static bool deeptest_celb(uint32_t seed, int trials)
{
    deeptest_celbench_row_t rows[DEEPTEST_CELBENCH_ROWS];
    uint64_t hash = 0;
    bool same = true;

    /* the shapes are fixed - the point is to compare one build, or one machine, with another - so the seed is
       free to mean something else: 1 to 8 runs that shape alone, for a profiler */
    if (!celbench_run(rows, &hash, 20261113u, trials > 0 ? trials : 1,
                      seed >= 1 && seed <= DEEPTEST_CELBENCH_ROWS ? (int)seed : 0))
        return false;
    say("celb: time per pixel written, with the table of finished pixels off and on\n");
    for (int i = 0; i < DEEPTEST_CELBENCH_ROWS; i++) {
        double px = (double)rows[i].pixels * (double)rows[i].draws;

        say("celb %-34s %6llu px x %3d  off %7.1f ns  on %7.1f ns  %s\n", rows[i].name,
            (unsigned long long)rows[i].pixels, rows[i].draws, px > 0 ? rows[i].us[0] * 1000.0 / px : 0.0,
            px > 0 ? rows[i].us[1] * 1000.0 / px : 0.0, rows[i].same ? "same picture" : "PICTURES DIFFER");
        same = same && rows[i].same;
    }
    say("celb 1 %016llx\n", (unsigned long long)hash);
    g_last_total = hash;
    return same;
}

/*
 * "celt": how long the cel engine says it is busy.
 *
 * The engine draws a list at once and then reports itself busy (SPRON in STATBITS) for a time that depends on how
 * much it drew: that is what a game waits for before it draws the next thing, and so what decides how many
 * pictures a second a game that draws a lot can show. The speed behind that time can be set
 * (opera_madam_cel_rate_set(): pixels a second, 0 for an engine that is never busy), and the busy time is counted
 * for the performance report (opera_prof.cel_busy).
 *
 * For each shape of the benchmark and each speed, the list is started through the registers a game uses, the
 * clock is stepped eight cycles at a time, and the cycles until the engine goes idle are counted. They must be
 * what the rule gives - the pixels (or the texels, if more) times the CPU's frequency over the speed, plus 64
 * cycles a cel - the count kept for the report must be exactly that, and the picture must be the same at every
 * speed: the speed changes when, never what.
 */
static bool deeptest_celt(uint32_t seed)
{
    static const uint32_t rates[4] = {9000000u, 12000000u, 16000000u, 0u};
    uint64_t total = INIT_HASH;
    uint32_t stock = opera_madam_cel_rate_get();
    int was_profiling = opera_prof_enabled;
    bool ok = true;

    opera_madam_poke(0x130, 0x1414);
    opera_madam_poke(0x134, (((uint32_t)CEL_FBH - 1) << 16) | (CEL_FBW - 1));
    opera_madam_poke(0x138, CEL_FB);
    opera_madam_poke(0x13C, CEL_FB);
    opera_prof_enabled = 1;

    for (int i = 0; i < DEEPTEST_CELBENCH_ROWS; i++) {
        const celbench_shape_t *sh = &celbench_shapes[i];
        rng_t r = {seed + 977u * (uint32_t)(i + 1)};
        uint64_t first = 0;

        celbench_image(sh, &r);
        celbench_build(sh);
        for (int k = 0; k < 4; k++) {
            rng_t bg = {seed + 31u * (uint32_t)(i + 1)};
            uint64_t px = 0, tx = 0, work, want, waited = 0, counted, h;

            for (uint32_t w = 0; w < CEL_FB_WORDS; w++)
                opera_mem_write32(CEL_FB + w * 4, rnd(&bg));
            opera_madam_cel_rate_set(rates[k]);
            counted = opera_prof.cel_busy;
            opera_madam_poke(0x5A4, CEL_CCB);
            opera_madam_poke(0x100, 0); /* SPRSTRT */
            opera_madam_cel_tick();     /* the list is drawn here, and the engine starts being busy */
            opera_madam_cel_last_work(&px, &tx);
            while ((opera_madam_peek(0x28) & 0x10) && waited < 100000000u) { /* SPRON in STATBITS */
                opera_clock_push_cycles(8);
                opera_madam_cel_tick();
                waited += 8;
            }
            counted = opera_prof.cel_busy - counted;
            work = tx > px ? tx : px;
            want = rates[k] ? work * (uint64_t)opera_clock_cpu_get_freq() / rates[k] + 64 : 0;
            h = hmem(INIT_HASH, CEL_FB, CEL_FB_WORDS);
            if (k == 0)
                first = h;
            say("celt %-34s %8u px/s: %6llu pixels, busy %7llu cycles (rule %7llu, counted %7llu)%s%s%s\n", sh->name,
                (unsigned)rates[k], (unsigned long long)work, (unsigned long long)waited, (unsigned long long)want,
                (unsigned long long)counted,
                waited == (want < 8 ? 8 : (want + 7) / 8 * 8) ? "" : "  BUSY TIME IS NOT THE RULE'S",
                counted == want ? "" : "  THE COUNT IS NOT THE RULE'S", h == first ? "" : "  PICTURE DIFFERS");
            ok = ok && waited == (want < 8 ? 8 : (want + 7) / 8 * 8) && counted == want && h == first;
            total = hmix(total, (uint32_t)work);
            total = hmix(total, (uint32_t)waited);
            total = hmix(total, (uint32_t)h);
            total = hmix(total, (uint32_t)(h >> 32));
        }
    }
    opera_madam_cel_rate_set(stock);
    opera_prof_enabled = was_profiling;
    say("celt 1 %016llx\n", (unsigned long long)total);
    g_last_total = total;
    return ok;
}

/* ------------------------------------------------------- CLIO audio FIFOs */

/*
 * The DSP reads audio samples that the CLIO fetches from DRAM as 16 bit values and writes its output
 * the same way (opera_mem_read16 / write16 in opera_clio.c). This drives those paths directly.
 */
static bool deeptest_fifo(uint32_t seed, int trials)
{
    rng_t r = {seed ? seed : 1};
    uint64_t total = INIT_HASH;

    for (int t = 0; t < trials; t++) {
        uint64_t h = INIT_HASH;
        uint32_t base = 0x00100000u + (rnd_n(&r, 64) << 8);
        uint32_t ich = rnd_n(&r, 13);
        uint32_t och = rnd_n(&r, 4);
        uint32_t ilen = 8 + 2 * rnd_n(&r, 24);
        uint32_t olen = 8 + 2 * rnd_n(&r, 24);
        uint32_t ireads = ilen / 2 + 2;
        uint32_t oreads = olen / 2 + 2;

        for (uint32_t i = 0; i < 0x500 / 4; i++)
            opera_mem_write32(base - 0x100 + i * 4, rnd(&r));

        opera_clio_fifo_write(0x400u | (ich << 4) | 0x0, base);
        opera_clio_fifo_write(0x400u | (ich << 4) | 0x4, ilen - 4);
        opera_clio_fifo_write(0x400u | (ich << 4) | 0x8, base + 0x80);
        opera_clio_fifo_write(0x400u | (ich << 4) | 0xC, 12);
        for (uint32_t i = 0; i < ireads; i++)
            h = hmix(h, opera_clio_fifo_ei((uint16_t)ich));
        h = hmix(h, opera_clio_fifo_ei_status((uint8_t)ich));
        h = hmix(h, opera_clio_fifo_read(0x400u | (ich << 4) | 0x0));
        h = hmix(h, opera_clio_fifo_read(0x400u | (ich << 4) | 0x4));

        opera_clio_fifo_write(0x500u | (och << 4) | 0x0, base + 0x200);
        opera_clio_fifo_write(0x500u | (och << 4) | 0x4, olen - 4);
        for (uint32_t i = 0; i < oreads; i++) {
            uint32_t v = rnd(&r) & 0xFFFF;

            opera_clio_fifo_eo((uint16_t)och, (uint16_t)v);
        }
        h = hmix(h, opera_clio_fifo_eo_status((uint8_t)och));
        h = hmix(h, opera_clio_fifo_read(0x500u | (och << 4) | 0x0));
        h = hmem(h, base + 0x1F0, 0x40 / 4);
        total = hmix(total, (uint32_t)h);
        total = hmix(total, (uint32_t)(h >> 32));
        if ((t % 250) == 249 || t == trials - 1 || trials <= 64)
            say("fifo %5d %016llx\n", t + 1, (unsigned long long)total);
    }
    g_last_total = total;
    return true;
}

/* ------------------------------------------------------------ matrix engine */

/* 16.16 fixed point test values: mostly modest numbers (as a game would use), with the odd extreme one. */
static uint32_t mat_value(rng_t *r, uint32_t kind)
{
    uint32_t v = rnd(r);

    switch (kind) {
    case 0:
        return (v & 0x3FFFFu) - 0x20000u;  /* +-2.0 */
    case 1:
        return (v & 0x3FFFFFu) - 0x200000u; /* +-32 */
    case 2:
        return rnd_n(r, 8) == 0 ? v : (v & 0xFFFFFu) - 0x80000u;
    default:
        return rnd_n(r, 4) == 0 ? 0x10000u : (v & 0x1FFFFu) - 0x10000u; /* around the identity */
    }
}

/*
 * The MADAM matrix engine (4x4 / 3x3 / 3x3 with perspective divide) works on 64 bit integers, so it
 * should not care about the host. It is what 3D games run all the time, and nothing else drives it.
 */
static bool deeptest_mat(uint32_t seed, int trials)
{
    rng_t r = {seed ? seed : 1};
    uint64_t total = INIT_HASH;

    for (int t = 0; t < trials; t++) {
        uint64_t h = INIT_HASH;
        uint32_t kind = rnd_n(&r, 4);

        for (uint32_t i = 0; i < 16; i++) {
            uint32_t v = mat_value(&r, kind);

            opera_madam_poke(0x600 + i * 4, v); /* input matrix, row major, rows 0x10 apart */
        }
        for (uint32_t i = 0; i < 4; i++) {
            uint32_t v = mat_value(&r, kind);

            opera_madam_poke(0x640 + i * 4, v); /* vector */
        }
        {
            uint32_t hi = rnd_n(&r, 4) == 0 ? 0 : rnd_n(&r, 256);
            uint32_t lo = rnd(&r);

            opera_madam_poke(0x680, hi); /* N (fraction) for the perspective divide */
            opera_madam_poke(0x684, lo);
        }
        for (int k = 0; k < 4; k++) {
            uint32_t cmd = rnd_n(&r, 5); /* 0 copy, 1 4x4, 2 3x3, 3 3x3 + divide, 4: invalid */

            opera_madam_poke(0x7FC, cmd);
            for (uint32_t i = 0; i < 4; i++)
                h = hmix(h, opera_madam_peek(0x660 + i * 4));
            if (rnd_n(&r, 2)) { /* change the vector between commands: the outputs are pipelined */
                uint32_t v = mat_value(&r, kind);

                opera_madam_poke(0x640 + rnd_n(&r, 4) * 4, v);
            }
        }
        total = hmix(total, (uint32_t)h);
        total = hmix(total, (uint32_t)(h >> 32));
        if ((t % 500) == 499 || t == trials - 1 || trials <= 64)
            say("mat %5d %016llx\n", t + 1, (unsigned long long)total);
    }
    g_last_total = total;
    return true;
}

/* ------------------------------------------------------------------- SPORT */

/*
 * The SPORT copies and flash-fills whole VRAM pages (screen clears, double buffering).
 * Pages are 2 KB; the page index goes in bits 0-12 of the address, the operation in 13-15.
 */
static bool deeptest_sport(uint32_t seed, int trials)
{
    rng_t r = {seed ? seed : 1};
    uint64_t total = INIT_HASH;

    for (uint32_t i = 0; i < 0x40000; i++)
        opera_mem_write32(0x00200000u + i * 4, rnd(&r));
    for (int t = 0; t < trials; t++) {
        uint64_t h = INIT_HASH;
        uint32_t src = rnd_n(&r, 400) << 2;
        uint32_t dst = rnd_n(&r, 400) << 2;
        uint32_t color = rnd(&r);
        uint32_t mask = rnd_n(&r, 3) == 0 ? 0xFFFFFFFFu : rnd(&r);
        uint32_t op = rnd_n(&r, 4);

        opera_sport_set_source(src);
        opera_sport_write_access(0x2000, color); /* colour register */
        if (op == 0)
            opera_sport_write_access(dst, mask);          /* copy a page */
        else if (op == 1)
            opera_sport_write_access(0x4000 | dst, mask); /* flash write */
        else if (op == 2)
            opera_sport_write_access(0x6000 | dst, mask); /* the "other" opcodes copy as well */
        else
            opera_sport_write_access(0x4000 | dst, 0xFFFFFFFFu);
        h = hmem(h, 0x00200000u + ((dst << 9) & 0xFFFFFu), 512);
        h = hmem(h, 0x00200000u + ((src << 9) & 0xFFFFFu), 512);
        total = hmix(total, (uint32_t)h);
        total = hmix(total, (uint32_t)(h >> 32));
        if ((t % 500) == 499 || t == trials - 1 || trials <= 64)
            say("sport %5d %016llx\n", t + 1, (unsigned long long)total);
    }
    g_last_total = total;
    return true;
}

/* -------------------------------------------------------------------- VDLP */

#define VDL_VRAM   0x00200000u /* guest address of VRAM */
#define VDL_BUF_PX (1024u * 288u)

/* Builds a chain of 1-3 video display list entries at VRAM offset `at` and returns its head. */
static uint32_t vdl_build(rng_t *r, uint32_t at)
{
    uint32_t head = at;
    uint32_t entries = 1 + rnd_n(r, 3);
    uint32_t modulo = rnd_n(r, 5); /* 320, 384, 512, 640 or 1024 pixels per line */
    uint32_t bmp = rnd_n(r, 0x10000) << 2;

    for (uint32_t e = 0; e < entries; e++) {
        bool last = e == entries - 1;
        uint32_t persist = last ? 300 : 30 + rnd_n(r, 100);
        uint32_t nctl = rnd_n(r, 24);
        uint32_t next_abs = at + (4 + nctl) * 4;
        uint32_t rel = last ? 0 : rnd_n(r, 2);
        uint32_t w0 = persist | (nctl << 9) | (rnd_n(r, 2) << 15) | ((e == 0 ? 1 : rnd_n(r, 2)) << 16) |
                      (rnd_n(r, 2) << 17) | (rel << 18) | (rnd_n(r, 8) ? (1u << 21) : 0) | (modulo << 23);
        uint32_t w1 = bmp + (rnd_n(r, 2) ? 2 : 0);
        uint32_t w2 = rnd_n(r, 0x10000) << 2;
        uint32_t w3 = last ? 0 : (rel ? nctl * 4 : next_abs);

        opera_mem_write32(VDL_VRAM + at + 0, w0);
        opera_mem_write32(VDL_VRAM + at + 4, w1);
        opera_mem_write32(VDL_VRAM + at + 8, w2);
        opera_mem_write32(VDL_VRAM + at + 12, w3);
        for (uint32_t i = 0; i < nctl; i++) {
            uint32_t kind = rnd_n(r, 10);
            uint32_t v = rnd(r) & 0x1FFFFFFFu;
            uint32_t w;

            if (kind < 5)
                w = v | (rnd_n(r, 4) << 29); /* palette entry, all four component selections */
            else if (kind < 7)
                w = 0xC0000000u | (v & ~0x08000000u); /* display control word (always NTSC) */
            else if (kind < 8)
                w = 0xE0000000u | (v & 0x00FFFFFFu); /* background colour */
            else
                w = 0x80000000u | v;                 /* audio / video control: ignored */
            opera_mem_write32(VDL_VRAM + at + 16 + i * 4, w);
        }
        at = next_abs;
        bmp += 0x4000;
    }
    return head;
}

static uint64_t hbuf(uint64_t h, const void *buf, bool wide)
{
    if (wide) {
        const uint32_t *p = (const uint32_t *)buf;

        for (uint32_t i = 0; i < VDL_BUF_PX; i++)
            h = hmix(h, p[i]);
    } else {
        const uint16_t *p = (const uint16_t *)buf;

        for (uint32_t i = 0; i < VDL_BUF_PX; i++)
            h = hmix(h, p[i]);
    }
    return h;
}

/*
 * The video display list processor turns the frame buffer in VRAM into the picture: every pixel pair is
 * read as 16 bit halves of 32 bit words, which is where byte order bites. All three output formats, with
 * and without the colour table, with random display lists (modulo, palette writes, control words).
 */
static bool deeptest_vdl(uint32_t seed, int trials)
{
    rng_t r = {seed ? seed : 1};
    uint64_t total = INIT_HASH;
    uint32_t *buf = (uint32_t *)malloc(VDL_BUF_PX * 4 + 4096);

    if (!buf)
        return false;
    opera_madam_poke(0x008, opera_madam_mctl() | MADAM_MCTL_CLUTXEN | MADAM_MCTL_VSCTXEN);
    for (int t = 0; t < trials; t++) {
        static const vdlp_pixel_format_e fmts[3] = {VDLP_PIXEL_FORMAT_0RGB1555, VDLP_PIXEL_FORMAT_XRGB8888,
                                                    VDLP_PIXEL_FORMAT_RGB565};
        vdlp_pixel_format_e fmt = fmts[t % 3];
        bool wide = fmt == VDLP_PIXEL_FORMAT_XRGB8888;
        bool bypass = ((t / 3) & 1) != 0;
        uint64_t h = INIT_HASH;
        uint32_t head;

        for (uint32_t i = 0; i < 0x40000; i++)
            opera_mem_write32(VDL_VRAM + i * 4, rnd(&r));
        head = vdl_build(&r, 0x000F0000u + (rnd_n(&r, 8) << 9));
        memset(buf, 0xA5, VDL_BUF_PX * 4 + 4096);

        opera_vdlp_init();
        opera_vdlp_set_video_buffer(buf);
        opera_vdlp_set_hires(false);
        opera_vdlp_set_pixel_format(fmt);
        opera_vdlp_set_bypass_clut(bypass);
        opera_vdlp_set_vdl_head(head);
        for (int line = 0; line < 300; line++)
            opera_vdlp_process_line(line);
        h = hbuf(h, buf, wide);
        total = hmix(total, (uint32_t)h);
        total = hmix(total, (uint32_t)(h >> 32));
        if ((t % 10) == 9 || t == trials - 1 || trials <= 64)
            say("vdl %5d %016llx\n", t + 1, (unsigned long long)total);
    }
    free(buf);
    g_last_total = total;
    return true;
}

/* ------------------------------------------------------------- ARM speed */

/*
 * Short loops of the kind games run (a copy loop, shifted arithmetic, block moves, calls with a stack frame)
 * executed in chunks of 32 CPU cycles, the way the frame loop drives the CPU. Not a pass/fail test of the
 * instruction set (the "arm" workload does that); it prints a hash of where each loop ended up, which
 * must not change when the interpreter is made faster, and it gives a fixed amount of work to time
 * (see tools/ppcsim/README.md).
 */
#define ABENCH_DATA      0x00180000u
#define ABENCH_DATA_SIZE 0x00040000u /* 256 KB, room for what the loops touch in ABENCH_CYCLES */
#define ABENCH_STACK     0x001F0000u
#define ABENCH_CYCLES    400000

static const uint32_t abench_copy[] = {
    0xE4903004u, /* loop: ldr r3,[r0],#4   */
    0xE4813004u, /*       str r3,[r1],#4   */
    0xE2522001u, /*       subs r2,r2,#1    */
    0x1AFFFFFBu, /*       bne loop         */
    0xEAFFFFFEu, /*       b .              */
};
static const uint32_t abench_alu[] = {
    0xE0844105u, /* loop: add r4,r4,r5,lsl #2 */
    0xE02551A4u, /*       eor r5,r5,r4,lsr #3 */
    0xE08662C4u, /*       add r6,r6,r4,asr #5 */
    0xE20570FFu, /*       and r7,r5,#0xff     */
    0xE18773E6u, /*       orr r7,r7,r6,ror #7 */
    0xE3170001u, /*       tst r7,#1           */
    0x12844003u, /*       addne r4,r4,#3      */
    0xE2588001u, /*       subs r8,r8,#1       */
    0x1AFFFFF6u, /*       bne loop            */
    0xEAFFFFFEu, /*       b .                 */
};
static const uint32_t abench_block[] = {
    0xE8B007F8u, /* loop: ldmia r0!,{r3-r10} */
    0xE8A107F8u, /*       stmia r1!,{r3-r10} */
    0xE2522001u, /*       subs r2,r2,#1      */
    0x1AFFFFFBu, /*       bne loop           */
    0xEAFFFFFEu, /*       b .                */
};
static const uint32_t abench_call[] = {
    0xEB000002u, /* loop: bl func            */
    0xE2522001u, /*       subs r2,r2,#1      */
    0x1AFFFFFCu, /*       bne loop           */
    0xEAFFFFFEu, /*       b .                */
    0xE92D4010u, /* func: stmfd sp!,{r4,lr}  */
    0xE2844001u, /*       add r4,r4,#1       */
    0xE59D3000u, /*       ldr r3,[sp]        */
    0xE0844003u, /*       add r4,r4,r3       */
    0xE8BD8010u, /*       ldmfd sp!,{r4,pc}  */
};

static bool deeptest_abench(uint32_t seed, int trials)
{
    static const struct {
        const char *name;
        const uint32_t *code;
        int n;
    } k[] = {
        {"copy", abench_copy, (int)(sizeof(abench_copy) / 4)},
        {"alu", abench_alu, (int)(sizeof(abench_alu) / 4)},
        {"block", abench_block, (int)(sizeof(abench_block) / 4)},
        {"call", abench_call, (int)(sizeof(abench_call) / 4)},
    };
    rng_t r = {seed ? seed : 1};
    uint64_t total = INIT_HASH;
    uint32_t payload = 44 * 4 + 4 + 4;
    uint32_t size = opera_state_chunk_size(payload);
    uint8_t st[512];

    if (opera_arm_state_size() != size || size > sizeof(st)) {
        say("abench: unexpected state size %u (expected %u)\n", opera_arm_state_size(), size);
        return false;
    }
    for (int t = 0; t < trials; t++) {
        /* one random data window per trial; the loops below read and write it and leave their marks in it */
        for (uint32_t a = ABENCH_DATA; a < ABENCH_DATA + ABENCH_DATA_SIZE; a += 4)
            opera_mem_write32(a, rnd(&r));
        for (size_t i = 0; i < sizeof(k) / sizeof(k[0]); i++) {
            uint32_t user[16], zero[7] = {0};
            uint64_t h = INIT_HASH;
            opera_state_writer_t w;
            int32_t cycles = 0;
            uint32_t insns = 0;

            for (int j = 0; j < k[i].n; j++)
                opera_mem_write32(ARM_BASE + 4u * (uint32_t)j, k[i].code[j]);
            for (int j = 0; j < 16; j++)
                user[j] = rnd(&r);
            user[0] = ABENCH_DATA;
            user[1] = ABENCH_DATA + ABENCH_DATA_SIZE / 2u;
            user[2] = 1u << 30; /* far more iterations than the cycles below allow */
            user[13] = ABENCH_STACK;
            user[15] = ARM_BASE;
            opera_state_writer_init(&w, st, size);
            opera_state_write_chunk_header(&w, "ARM", payload);
            opera_state_write_u32_array(&w, user, 16);
            opera_state_write_u32_array(&w, zero, 7);
            opera_state_write_u32_array(&w, zero, 2);
            opera_state_write_u32_array(&w, zero, 2);
            opera_state_write_u32_array(&w, zero, 7);
            opera_state_write_u32_array(&w, zero, 2);
            opera_state_write_u32_array(&w, zero, 2);
            opera_state_write_u32_array(&w, zero, 6);
            opera_state_write_u32(&w, 0x10u); /* user mode, interrupts on: like a running game */
            opera_state_write_u8(&w, 0);
            opera_state_write_u8(&w, 0);
            opera_state_write_u8(&w, 0);
            opera_state_write_u8(&w, 0);
            if (!opera_state_writer_ok(&w) || !opera_arm_state_load(st, opera_state_writer_used(&w))) {
                say("abench: state load failed\n");
                return false;
            }
            while (cycles < ABENCH_CYCLES) {
                int32_t c = 0;

                do {
                    c += opera_arm_execute();
                    insns++;
                } while (c < 32);
                cycles += c;
            }
            {
                uint32_t n = opera_arm_state_save(st);

                h = hbytes(h, st, n);
            }
            h = hmem(h, ABENCH_DATA, ABENCH_DATA_SIZE / 4u);
            h = hmem(h, ABENCH_STACK - 0x100u, 0x200u / 4u);
            total = hmix(total, (uint32_t)h);
            total = hmix(total, (uint32_t)(h >> 32));
            if (trials <= 4)
                say("abench %-6s cycles %d instructions %u hash %016llx\n", k[i].name, cycles, insns, (unsigned long long)h);
        }
        if ((t % 10) == 9 || t == trials - 1)
            say("abench %5d %016llx\n", t + 1, (unsigned long long)total);
    }
    g_last_total = total;
    return true;
}

/* ------------------------------------------------------------------ timers */

/*
 * The 16 CLIO timers and the clock that paces them, driven the way the frame loop drives them: CPU time is
 * pushed in steps of 32 cycles (sometimes much more) and every timer slot that has come due runs. Random
 * control, counter, reload, interrupt-mask and slack values, with random register writes in between. The
 * walk over the slots runs about 100000 times a second, so it is the part of the core that was tuned
 * for speed and this workload pins down that it still does exactly what it did.
 */
static uint64_t tmr_hash_state(uint64_t h)
{
    uint8_t buf[160];
    uint32_t n = opera_clock_state_size();

    h = hmix(h, opera_clio_peek(0x40));
    h = hmix(h, opera_clio_peek(0x48));
    h = hmix(h, opera_clio_peek(0x60));
    h = hmix(h, opera_clio_peek(0x68));
    h = hmix(h, (uint32_t)opera_clio_fiq_needed());
    h = hmix(h, opera_clio_peek(0x204));
    h = hmix(h, opera_clio_peek(0x20C));
    for (uint32_t k = 0; k < 16; k++) {
        h = hmix(h, opera_clio_peek(0x100 + 8 * k));
        h = hmix(h, opera_clio_peek(0x104 + 8 * k));
    }
    if (n && n <= sizeof(buf) && opera_clock_state_save(buf) == n)
        h = hbytes(h, buf, n);
    else
        h = hmix(h, 0xBADu);
    return h;
}

static bool deeptest_tmr(uint32_t seed, int trials)
{
    rng_t r = {seed ? seed : 1};
    uint64_t total = INIT_HASH;

    for (int t = 0; t < trials; t++) {
        uint64_t h = INIT_HASH;
        uint32_t lo, hi, mask, kind;
        int steps;

        opera_clio_poke(0x204, 0xFFFFFFFFu); /* every timer off */
        opera_clio_poke(0x20C, 0xFFFFFFFFu);
        opera_clio_poke(0x44, 0xFFFFFFFFu);  /* nothing pending */
        opera_clio_poke(0x64, 0xFFFFFFFFu);
        opera_clio_poke(0x4C, 0xFFFFFFFFu);  /* nothing enabled ... */
        mask = rnd(&r);
        opera_clio_poke(0x48, mask);         /* ... except a random few */
        kind = rnd_n(&r, 4); /* 0: few timers on, 1: many, 2: all, 3: none (the idle case) */
        lo = rnd(&r);
        hi = rnd(&r);
        if (kind == 0) {
            lo &= 0x00000F00u;
            hi &= 0x0000F000u;
        } else if (kind == 1) {
            lo &= 0x77777777u;
            hi &= 0x77777777u;
        } else if (kind == 2) {
            lo = 0x33333333u | (lo & 0x44444444u);
            hi = 0x11111111u | (hi & 0x66666666u);
        } else {
            lo = hi = 0;
        }
        for (uint32_t k = 0; k < 16; k++) {
            uint32_t cnt, rel;

            cnt = rnd_n(&r, 4) ? rnd_n(&r, 24) : rnd(&r);
            rel = rnd_n(&r, 4) ? rnd_n(&r, 24) : rnd(&r);
            opera_clio_poke(0x100 + 8 * k, cnt);
            opera_clio_poke(0x104 + 8 * k, rel);
        }
        opera_clio_poke(0x200, lo);
        opera_clio_poke(0x208, hi);
        if (rnd_n(&r, 4) == 0) {
            uint32_t slack = rnd_n(&r, 1024);

            opera_clio_poke(0x220, slack);
        }
        steps = 24 + (int)rnd_n(&r, 64);
        for (int s = 0; s < steps; s++) {
            uint32_t push = 32;

            if (rnd_n(&r, 8) == 0) {
                uint32_t extra = rnd_n(&r, 400);

                push = 1 + extra;
            }
            opera_clock_push_cycles(push);
            opera_clio_timers_run();
            opera_xbus_tick();
            h = tmr_hash_state(h);
            if (rnd_n(&r, 5) == 0) {
                uint32_t what = rnd_n(&r, 6);
                uint32_t v = rnd(&r);

                switch (what) {
                case 0: opera_clio_poke(0x44, v); break;                       /* clear pending bits */
                case 1: opera_clio_poke(0x200, v & 0x77777777u); break;        /* more control bits on */
                case 2: opera_clio_poke(0x204, v); break;                      /* control bits off */
                case 3: opera_clio_poke(0x208, v & 0x77777777u); break;
                case 4: opera_clio_poke(0x20C, v); break;
                default: {
                    uint32_t k = v & 15;
                    uint32_t cnt = rnd_n(&r, 20);

                    opera_clio_poke(0x100 + 8 * k, cnt);                       /* reload a counter */
                    break;
                }
                }
            }
        }
        total = hmix(total, (uint32_t)h);
        total = hmix(total, (uint32_t)(h >> 32));
        if ((t % 100) == 99 || t == trials - 1 || trials <= 64)
            say("tmr %5d %016llx\n", t + 1, (unsigned long long)total);
    }
    g_last_total = total;
    return true;
}

/* ------------------------------------------------- the fixed workloads */

/*
 * The workloads of the on-console diagnostic. The expected values are what the x86-64 build prints
 * (and what the PowerPC build under qemu-ppc prints: tools/ppcsim/run_deep_tests.sh). They only depend
 * on values, never on byte order, so a correct Wii U build must reproduce them exactly.
 *
 * The three cel workloads, and the sprites of deeptest_celbench(), were also run through the cel engine as it
 * comes from upstream, with none of this project's changes to it: the values are the same.
 */
const deeptest_spec_t deeptest_specs[] = {
    {"arm", 12345u, 3000, 0x650cbf0f4a0ffc22ull},
    {"dsp", 1u, 3000, 0x7bf7462577b39da0ull},
    {"cel", 12345u, 1000, 0x4d445932a0b3cee4ull},
    {"celg", 777u, 1500, 0x6324d3238de7e212ull},
    {"celu", 4242u, 2000, 0x93f328ec38ffcd24ull},
    {"fifo", 1u, 3000, 0xfc42984d6fd477e0ull},
    {"mat", 5u, 20000, 0x9221064066805b4cull},
    {"sport", 5u, 6000, 0x0a8ba66366a970d6ull},
    {"vdl", 5u, 30, 0x338c03e946f305dbull},
    {"tmr", 7u, 400, 0x8cf1afc8c4b3900full},
    {"abench", 5u, 8, 0x6b7872709ce4812bull},
    {"armx", 3u, 4000, 0xe76d92b306cf9aa0ull},
    {"dspr", 1u, 1500, 0x95ece2d46c438a52ull},
};
const int deeptest_spec_count = (int)(sizeof(deeptest_specs) / sizeof(deeptest_specs[0]));

/* Runs one workload on a freshly loaded core with silent sinks. */
static bool run_workload(const char *what, uint32_t seed, int trials, bool quiet, uint64_t *hash)
{
    core_sink_t sink = {null_video, null_audio};
    core_sink_t saved = core_get_sink();
    bool ok = true;

    g_quiet = quiet;
    g_last_total = 0;
    core_set_sink(&sink);
    if (!core_load(NULL)) {
        say("deeptest: core_load failed\n");
        core_set_sink(&saved);
        g_quiet = false;
        return false;
    }
    prng16_seed(0x13579BDFu); /* retro_init() seeds both from the clock */
    prng32_seed(0x2468ACE1u);
    if (!strcmp(what, "arm"))
        ok = deeptest_arm(seed, trials, false);
    else if (!strcmp(what, "dsp"))
        ok = deeptest_dsp(seed, trials, false);
    else if (!strcmp(what, "dspr"))
        ok = deeptest_dspr(seed, trials);
    else if (!strcmp(what, "cel"))
        ok = deeptest_cel(seed, trials, false);
    else if (!strcmp(what, "celg"))
        ok = deeptest_celg(seed, trials, false);
    else if (!strcmp(what, "celu"))
        ok = deeptest_celu(seed, trials, false);
    else if (!strcmp(what, "fifo"))
        ok = deeptest_fifo(seed, trials);
    else if (!strcmp(what, "mat"))
        ok = deeptest_mat(seed, trials);
    else if (!strcmp(what, "sport"))
        ok = deeptest_sport(seed, trials);
    else if (!strcmp(what, "vdl"))
        ok = deeptest_vdl(seed, trials);
    else if (!strcmp(what, "tmr"))
        ok = deeptest_tmr(seed, trials);
    else if (!strcmp(what, "abench"))
        ok = deeptest_abench(seed, trials);
    else if (!strcmp(what, "armx"))
        ok = deeptest_armx(seed, trials, false);
    else
        ok = false;
    core_unload();
    core_set_sink(&saved);
    g_quiet = false;
    if (hash)
        *hash = g_last_total;
    return ok;
}

bool deeptest_hash(const deeptest_spec_t *spec, uint64_t *hash)
{
    return run_workload(spec->name, spec->seed, spec->trials, true, hash);
}

/* ------------------------------------------------------------------ entry */

bool deeptest_run(const char *what, uint32_t seed, int trials)
{
    core_sink_t sink = {null_video, null_audio};
    bool all = !strcmp(what, "all");
    bool ok = true;

    if (!strcmp(what, "dspt")) /* these two load the machine themselves, twice per script */
        return deeptest_dspt(seed, trials);
    if (!strcmp(what, "dspc"))
        return deeptest_dspc();
    if (!strcmp(what, "specs")) { /* the fixed workloads of the on-console diagnostic, against their references */
        for (int i = 0; i < deeptest_spec_count; i++) {
            const deeptest_spec_t *sp = &deeptest_specs[i];
            uint64_t h = 0;
            bool ran = deeptest_hash(sp, &h);

            printf("spec %-5s trials %6d seed %6u hash %016llx %s\n", sp->name, sp->trials, (unsigned)sp->seed,
                   (unsigned long long)h,
                   !ran ? "FAILED TO RUN" : !sp->expect ? "(no reference)" : h == sp->expect ? "ok" : "DIFFERS");
            ok = ran && (!sp->expect || h == sp->expect) && ok;
        }
        return ok;
    }

    core_set_sink(&sink);
    if (!core_load(NULL)) {
        say("deeptest: core_load failed\n");
        return false;
    }
    prng16_seed(0x13579BDFu); /* retro_init() seeds both from the clock */
    prng32_seed(0x2468ACE1u);
    if (all || !strcmp(what, "arm"))
        ok = deeptest_arm(seed, trials, false) && ok;
    if (!strcmp(what, "armd")) /* dump every instruction of trial number `trials` */
        ok = deeptest_arm(seed, trials, true) && ok;
    if (all || !strcmp(what, "dsp"))
        ok = deeptest_dsp(seed, trials, false) && ok;
    if (!strcmp(what, "dspd")) /* dump the state after DSP program number `trials` */
        ok = deeptest_dsp(seed, trials, true) && ok;
    if (all || !strcmp(what, "dspr"))
        ok = deeptest_dspr(seed, trials) && ok;
    if (all || !strcmp(what, "fifo"))
        ok = deeptest_fifo(seed, trials) && ok;
    if (all || !strcmp(what, "cel"))
        ok = deeptest_cel(seed, trials, false) && ok;
    if (all || !strcmp(what, "celg"))
        ok = deeptest_celg(seed, trials, false) && ok;
    if (all || !strcmp(what, "celu"))
        ok = deeptest_celu(seed, trials, false) && ok;
    if (all || !strcmp(what, "mat"))
        ok = deeptest_mat(seed, trials) && ok;
    if (all || !strcmp(what, "sport"))
        ok = deeptest_sport(seed, trials) && ok;
    if (all || !strcmp(what, "vdl"))
        ok = deeptest_vdl(seed, trials) && ok;
    if (all || !strcmp(what, "tmr"))
        ok = deeptest_tmr(seed, trials) && ok;
    if (all || !strcmp(what, "abench"))
        ok = deeptest_abench(seed, trials) && ok;
    if (all || !strcmp(what, "armx")) /* last: it resets and pokes the devices */
        ok = deeptest_armx(seed, trials, false) && ok;
    if (!strcmp(what, "armxd")) /* dump every instruction of trial number `trials` */
        ok = deeptest_armx(seed, trials, true) && ok;
    if (!strcmp(what, "celd")) /* dump the CCB and the frame buffer changes of cel number `trials` */
        ok = deeptest_cel(seed, trials, true) && ok;
    if (!strcmp(what, "celud")) /* the same for the edge battery */
        ok = deeptest_celu(seed, trials, true) && ok;
    if (!strcmp(what, "celb")) /* sprites, timed; `trials` divides the repeat counts */
        ok = deeptest_celb(seed, trials) && ok;
    if (!strcmp(what, "celt")) /* how long the engine stays busy, at each speed it can be set to */
        ok = deeptest_celt(seed ? seed : 20261113u) && ok;
    core_unload();
    return ok;
}
