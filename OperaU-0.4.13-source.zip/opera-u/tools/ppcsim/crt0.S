/* Minimal Linux/PPC32 start-up for the simulation harness (runs under qemu-ppc). */
    .section .text
    .globl  _start
    .type   _start, @function
_start:
    lwz     3, 0(1)                 /* argc */
    addi    4, 1, 4                 /* argv */
    lis     2, _SDA2_BASE_@ha
    addi    2, 2, _SDA2_BASE_@l
    lis     13, _SDA_BASE_@ha
    addi    13, 13, _SDA_BASE_@l
    rlwinm  1, 1, 0, 0, 27          /* 16 byte aligned stack */
    li      0, 0
    stwu    1, -32(1)
    stw     0, 4(1)
    bl      main
    bl      exit
1:  b       1b
