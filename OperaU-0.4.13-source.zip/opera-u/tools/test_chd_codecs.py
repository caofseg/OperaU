#!/usr/bin/env python3
"""Builds compressed CHD v5 test images and checks the core reads them back
bit for bit, on x86 and (under qemu-ppc) on big-endian PowerPC.

No chdman is needed: this writes the container itself, with the same codecs
chdman uses for CD images (cdlz, cdzl, cdzs plus the plain lzma, zlib, zstd),
a Huffman+RLE compressed map, "self" references, stored hunks and the ECC
stripping chdman applies to every sector that carries valid parity.

For each image the tool prints the FNV-1a hashes of what the reader must
return, then runs `cdhash` (src/cdtest.c) through every binary given and
compares. The synthetic disc mixes text, code-like words, noise, runs, audio
and blank gaps so each decoder meets literals, short and long matches, stored
blocks and Huffman/FSE coded streams.

usage:
  test_chd_codecs.py --out DIR [--host BIN] [--ppc HARNESS --qemu QEMU]
                     [--sectors N] [--only NAME[,NAME...]] [--keep]

zstd needs libzstd.so.1 (loaded with ctypes) and is skipped when it is missing.
"""
import argparse
import ctypes
import ctypes.util
import hashlib
import heapq
import lzma
import os
import random
import struct
import subprocess
import sys
import zlib

FRAME = 2448
SECTOR = 2352
SYNC = b"\x00" + b"\xff" * 10 + b"\x00"
M64 = (1 << 64) - 1


def fnv(h, data):
    for b in data:
        h = ((h ^ b) * 0x100000001B3) & M64
    return h


FNV0 = 0xCBF29CE484222325

# ------------------------------------------------------------------ ECC / EDC

ECC_F = [0] * 256
ECC_B = [0] * 256
for _i in range(256):
    _j = ((_i << 1) ^ (0x11D if _i & 0x80 else 0)) & 0xFF
    ECC_F[_i] = _j
    ECC_B[_i ^ _j] = _i

EDC_T = []
for _i in range(256):
    _e = _i
    for _ in range(8):
        _e = (_e >> 1) ^ (0xD8018001 if _e & 1 else 0)
    EDC_T.append(_e)


def edc(data):
    c = 0
    for b in data:
        c = (c >> 8) ^ EDC_T[(c ^ b) & 0xFF]
    return c


def ecc_block(sec, major_count, minor_count, major_mult, minor_inc, dest):
    size = major_count * minor_count
    for major in range(major_count):
        index = (major >> 1) * major_mult + (major & 1)
        a = b = 0
        for _ in range(minor_count):
            t = sec[0xC + index]
            index += minor_inc
            if index >= size:
                index -= size
            a ^= t
            b ^= t
            a = ECC_F[a]
        a = ECC_B[ECC_F[a] ^ b]
        sec[dest + major] = a
        sec[dest + major + major_count] = a ^ b


def ecc_generate(sec):
    ecc_block(sec, 86, 24, 2, 86, 0x81C)
    ecc_block(sec, 52, 43, 86, 88, 0x8C8)


def bcd(v):
    return ((v // 10) << 4) | (v % 10)


def mode1_sector(lba, user, corrupt_ecc=False):
    """A complete MODE1 raw sector: sync, header, data, EDC, parity."""
    m, s, f = (lba + 150) // 4500, ((lba + 150) // 75) % 60, (lba + 150) % 75
    sec = bytearray(SECTOR)
    sec[0:12] = SYNC
    sec[12:16] = bytes([bcd(m), bcd(s), bcd(f), 1])
    sec[16:16 + 2048] = user
    sec[0x810:0x814] = struct.pack("<I", edc(sec[0:0x810]))
    ecc_generate(sec)
    if corrupt_ecc:
        sec[0x900] ^= 0x5A
    return bytes(sec)


_ecc_cache = {}


def ecc_valid(sec):
    """True when the sector has the sync pattern and parity chdman would strip."""
    sec = bytes(sec)
    if sec[:12] != SYNC:
        return False
    hit = _ecc_cache.get(sec)
    if hit is None:
        t = bytearray(sec)
        ecc_generate(t)
        hit = _ecc_cache[sec] = bytes(t[0x81C:0x930]) == sec[0x81C:0x930]
    return hit


# ----------------------------------------------------------- synthetic payload

SYL = ["ka", "to", "ri", "mu", "sen", "dor", "al", "ex", "vi", "on", "bar", "li", "ne", "qua", "zu", "th", "ro", "pel"]


def make_words(rng, n=300):
    return ["".join(rng.choice(SYL) for _ in range(rng.randint(1, 4))) for _ in range(n)]


def sector_text(rng, words):
    out = bytearray()
    while len(out) < 2048:
        w = words[min(int(rng.paretovariate(0.9)) - 1, len(words) - 1)] if rng.random() < 0.8 else rng.choice(words)
        out += w.encode() + (b"\n" if rng.random() < 0.08 else b" ")
    return bytes(out[:2048])


def sector_code(rng):
    out = bytearray()
    base = rng.getrandbits(32) & 0xFFFFF000
    while len(out) < 2048:
        r = rng.random()
        if r < 0.5:
            out += struct.pack(">I", (base + rng.randrange(0, 4096)) & 0xFFFFFFFF)
        elif r < 0.8:
            out += struct.pack(">I", 0x60000000 | rng.randrange(0, 1 << 16))
        else:
            out += struct.pack(">I", rng.getrandbits(32))
    return bytes(out[:2048])


def sector_pattern(rng):
    pat = bytearray(rng.randbytes(rng.choice([4, 16, 64, 100])))
    out = bytearray()
    while len(out) < 2048:
        out += pat
    out = bytearray(out[:2048])
    for _ in range(rng.randrange(0, 12)):
        out[rng.randrange(2048)] = rng.randrange(256)
    return bytes(out)


def sector_audio(rng):
    import math
    f1, f2 = rng.uniform(0.01, 0.2), rng.uniform(0.2, 0.5)
    out = bytearray()
    for i in range(512):
        v = int(9000 * math.sin(i * f1) + 3000 * math.sin(i * f2 + 1.0))
        out += struct.pack(">hh", v, -v // 2)
    return bytes(out)


def make_user_data(sectors, seed=2024):
    rng = random.Random(seed)
    words = make_words(rng)
    label = b"\x01ZZZZZ\x01\x00" + b"OPERAU TEST DISC".ljust(32, b"\x00") + b"\x00" * 8
    kinds = ["text", "code", "random", "zero", "pattern", "audio", "mix"]
    data = []
    while len(data) < sectors:
        kind = rng.choice(kinds)
        run = rng.randint(3, 40)
        for _ in range(run):
            if len(data) >= sectors:
                break
            if kind == "text":
                data.append(sector_text(rng, words))
            elif kind == "code":
                data.append(sector_code(rng))
            elif kind == "random":
                data.append(rng.randbytes(2048))
            elif kind == "zero":
                data.append(bytes(2048))
            elif kind == "pattern":
                data.append(sector_pattern(rng))
            elif kind == "audio":
                data.append(sector_audio(rng))
            else:
                data.append(rng.choice([sector_text(rng, words), sector_code(rng), sector_pattern(rng)]))
    data[0] = (label + bytes(2048))[:2048]
    return data


# ------------------------------------------------------------------ codecs

_zstd = None


def zstd_lib():
    global _zstd
    if _zstd is None:
        path = ctypes.util.find_library("zstd") or "libzstd.so.1"
        try:
            _zstd = ctypes.CDLL(path)
            _zstd.ZSTD_compress.restype = ctypes.c_size_t
            _zstd.ZSTD_compressBound.restype = ctypes.c_size_t
            _zstd.ZSTD_isError.restype = ctypes.c_uint
        except OSError:
            _zstd = False
    return _zstd or None


def c_zstd(data):
    z = zstd_lib()
    cap = z.ZSTD_compressBound(ctypes.c_size_t(len(data)))
    dst = ctypes.create_string_buffer(cap)
    n = z.ZSTD_compress(dst, ctypes.c_size_t(cap), data, ctypes.c_size_t(len(data)), 19)
    if z.ZSTD_isError(ctypes.c_size_t(n)):
        raise RuntimeError("ZSTD_compress failed")
    return dst.raw[:n]


def c_zlib(data):
    c = zlib.compressobj(9, zlib.DEFLATED, -15)
    return c.compress(data) + c.flush()


def lzma_dict(hunk_bytes):
    d = 1 << 11
    while d < hunk_bytes and d < (1 << 30):
        d <<= 1
    return d


def c_lzma(data, hunk_bytes):
    f = [{"id": lzma.FILTER_LZMA1, "dict_size": lzma_dict(hunk_bytes), "lc": 3, "lp": 0, "pb": 2, "preset": 9}]
    c = lzma.LZMACompressor(format=lzma.FORMAT_RAW, filters=f)
    return c.compress(data) + c.flush()


TAGS = {"cdlz": b"cdlz", "cdzl": b"cdzl", "cdzs": b"cdzs", "lzma": b"lzma", "zlib": b"zlib", "zstd": b"zstd"}


def compress_hunk(codec, hunk, hunk_bytes, strip_ecc):
    if codec in ("lzma", "zlib", "zstd"):
        if codec == "lzma":
            return c_lzma(hunk, hunk_bytes)
        return c_zlib(hunk) if codec == "zlib" else c_zstd(hunk)
    frames = [hunk[i:i + FRAME] for i in range(0, len(hunk), FRAME)]
    bitmap = bytearray((len(frames) + 7) // 8)
    secs, subs = bytearray(), bytearray()
    for i, f in enumerate(frames):
        sec = bytearray(f[:SECTOR])
        if strip_ecc and ecc_valid(sec):
            bitmap[i >> 3] |= 1 << (i & 7)
            sec[0:12] = bytes(12)
            sec[0x81C:0x930] = bytes(0x930 - 0x81C)
        secs += sec
        subs += f[SECTOR:]
    if codec == "cdlz":
        base, sub = c_lzma(bytes(secs), hunk_bytes), c_zlib(bytes(subs))
    elif codec == "cdzl":
        base, sub = c_zlib(bytes(secs)), c_zlib(bytes(subs))
    else:
        base, sub = c_zstd(bytes(secs)), c_zstd(bytes(subs))
    lenbits = 3 if hunk_bytes >= 65536 else 2
    return bytes(bitmap) + len(base).to_bytes(lenbits, "big") + base + sub


# ----------------------------------------------------------- CHD v5 container


class Bits:
    def __init__(self):
        self.acc = 0
        self.n = 0

    def put(self, value, nbits):
        assert 0 <= value < (1 << nbits) or nbits == 0
        self.acc = (self.acc << nbits) | value
        self.n += nbits

    def bytes(self):
        pad = (-self.n) % 8
        return (self.acc << pad).to_bytes((self.n + pad) // 8, "big")


def crc16(data, crc=0xFFFF):
    for b in data:
        crc ^= b << 8
        for _ in range(8):
            crc = ((crc << 1) ^ 0x1021) if crc & 0x8000 else (crc << 1)
            crc &= 0xFFFF
    return crc


def huffman_lengths(freq, maxbits=8):
    freq = [f for f in freq]
    while True:
        heap = [(f, i, None) for i, f in enumerate(freq) if f > 0]
        heapq.heapify(heap)
        n = len(heap)
        ctr = len(freq)
        nodes = {}
        while len(heap) > 1:
            f1, i1, _ = heapq.heappop(heap)
            f2, i2, _ = heapq.heappop(heap)
            nodes[ctr] = (i1, i2)
            heapq.heappush(heap, (f1 + f2, ctr, None))
            ctr += 1
        lens = [0] * len(freq)
        if heap:
            root = heap[0][1]
            stack = [(root, 0)]
            while stack:
                node, d = stack.pop()
                if node in nodes:
                    stack.append((nodes[node][0], d + 1))
                    stack.append((nodes[node][1], d + 1))
                else:
                    lens[node] = max(d, 1)
        if max(lens) <= maxbits:
            return lens
        freq = [(f + 1) // 2 + 1 if f > 0 else 0 for f in freq]


def canonical_codes(lens):
    maxlen = max(lens)
    histo = [0] * (maxlen + 2)
    for l in lens:
        if l:
            histo[l] += 1
    start = 0
    firsts = [0] * (maxlen + 2)
    for l in range(maxlen, 0, -1):
        nxt = (start + histo[l]) >> 1
        if l != 1:
            assert nxt * 2 == start + histo[l], "incomplete code"
        firsts[l] = start
        start = nxt
    codes = [0] * len(lens)
    for sym, l in enumerate(lens):
        if l:
            codes[sym] = firsts[l]
            firsts[l] += 1
    return codes


def write_tree_rle(bits, lens):
    """MAME's import_tree_rle in reverse: 4 bit fields for a 16 symbol, 8 bit tree."""
    i = 0
    while i < len(lens):
        v = lens[i]
        run = 1
        while i + run < len(lens) and lens[i + run] == v:
            run += 1
        if v != 1 and run >= 3:
            n = min(run, 18)
            bits.put(1, 4)
            bits.put(v, 4)
            bits.put(n - 3, 4)
            i += n
        elif v == 1:
            bits.put(1, 4)
            bits.put(1, 4)
            i += 1
        else:
            bits.put(v, 4)
            i += 1


# map codes
T_NONE, T_SELF, T_PARENT, T_RLE_S, T_RLE_L, T_SELF0, T_SELF1 = 4, 5, 6, 7, 8, 9, 10


def rle_symbols(codes):
    out = []
    last = 0
    i = 0
    n = len(codes)
    while i < n:
        c = codes[i]
        out.append(c)
        last = c
        i += 1
        run = 0
        while i + run < n and codes[i + run] == last:
            run += 1
        while run >= 3:
            if run >= 19:
                total = min(run, 274)
                v = total - 19
                out += [T_RLE_L, v >> 4, v & 15]
            else:
                total = min(run, 18)
                out += [T_RLE_S, total - 3]
            i += total
            run -= total
    return out


def build_map(entries, hunk_bytes, first_offset, codec_count):
    """entries: list of dicts {code, data|ref}. Returns (map bytes, offsets per hunk)."""
    codes = [e["code"] for e in entries]
    syms = rle_symbols(codes)
    freq = [0] * 16
    for s in syms:
        freq[s] += 1
    for s in (0, T_NONE):  # keep at least two live symbols so the tree is complete
        freq[s] += 1
    lens = huffman_lengths(freq)
    hcodes = canonical_codes(lens)
    complens = [len(e["data"]) for e in entries if "data" in e and e["code"] != T_NONE]
    lengthbits = max(max(complens).bit_length() if complens else 1, 1)
    selfbits = max((len(entries)).bit_length(), 1)

    bits = Bits()
    write_tree_rle(bits, lens)
    for s in syms:
        bits.put(hcodes[s], lens[s])

    cur = first_offset
    packed = bytearray()
    for e in entries:
        c = e["code"]
        length, crc, offset = 0, 0, cur
        base = c
        if c in (0, 1, 2, 3):
            length = len(e["data"])
            crc = crc16(e["data"])
            bits.put(length, lengthbits)
            bits.put(crc, 16)
            cur += length
        elif c == T_NONE:
            length = hunk_bytes
            crc = crc16(e["data"])
            bits.put(crc, 16)
            cur += length
        elif c == T_SELF:
            offset = e["ref"]
            bits.put(offset, selfbits)
            base = T_SELF
        elif c in (T_SELF0, T_SELF1):
            offset = e["ref"]
            base = T_SELF
        e["offset"] = offset
        packed += bytes([base]) + length.to_bytes(3, "big") + offset.to_bytes(6, "big") + struct.pack(">H", crc)
    stream = bits.bytes()
    header = struct.pack(">I", len(stream)) + first_offset.to_bytes(6, "big") + struct.pack(">H", crc16(bytes(packed)))
    header += bytes([lengthbits, selfbits, 0, 0])
    return header + stream


def write_chd(path, frames, sectors, codecs, hunk_frames, subtype, mixed, strip_ecc):
    hunk_bytes = FRAME * hunk_frames
    frames = list(frames)
    while len(frames) % hunk_frames:
        frames.append(bytes(FRAME))
    hunks = [b"".join(frames[i:i + hunk_frames]) for i in range(0, len(frames), hunk_frames)]
    body = b"".join(hunks)

    entries = []
    seen = {}
    last_self = None
    for idx, h in enumerate(hunks):
        if h in seen and (idx % 2 == 0 or not mixed):
            ref = seen[h]
            if mixed and last_self is not None and ref == last_self:
                entries.append({"code": T_SELF0, "ref": ref})
            elif mixed and last_self is not None and ref == last_self + 1:
                entries.append({"code": T_SELF1, "ref": ref})
            else:
                entries.append({"code": T_SELF, "ref": ref})
            last_self = ref
            continue
        seen.setdefault(h, idx)
        slot = (idx // 3 if mixed else 0) % max(len(codecs), 1)
        if not codecs or (mixed and idx % 11 == 5):
            entries.append({"code": T_NONE, "data": h})
            continue
        data = compress_hunk(codecs[slot], h, hunk_bytes, strip_ecc)
        if len(data) >= hunk_bytes:
            entries.append({"code": T_NONE, "data": h})
        else:
            entries.append({"code": slot, "data": data})

    meta_text = ("TRACK:1 TYPE:MODE1_RAW SUBTYPE:%s FRAMES:%d PREGAP:0 PGTYPE:MODE1_RAW PGSUB:NONE POSTGAP:0\0"
                 % (subtype, sectors)).encode()
    meta = b"CHT2" + bytes([1]) + len(meta_text).to_bytes(3, "big") + struct.pack(">Q", 0) + meta_text
    meta_off = 124
    map_off = meta_off + len(meta)

    # the map's size does not depend on the offsets only through lengthbits, so build it twice
    first = map_off
    for _ in range(2):
        m = build_map(entries, hunk_bytes, first, len(codecs))
        first = map_off + len(m)
    m = build_map(entries, hunk_bytes, first, len(codecs))

    comp = b"".join(TAGS[c] for c in codecs[:4]).ljust(16, b"\x00")
    raw_sha = hashlib.sha1(body).digest()
    header = b"MComprHD" + struct.pack(">II", 124, 5) + comp
    header += struct.pack(">QQQ", len(body), map_off, meta_off)
    header += struct.pack(">II", hunk_bytes, FRAME)
    header += raw_sha + raw_sha + bytes(20)
    assert len(header) == 124

    out = bytearray(header)
    out += bytes(meta_off - len(out))
    out += meta
    out += m
    assert len(out) == first
    for e in entries:
        if e["code"] in (0, 1, 2, 3, T_NONE):
            out += e["data"]
    open(path, "wb").write(out)
    counts = {}
    for e in entries:
        counts[e["code"]] = counts.get(e["code"], 0) + 1
    return len(hunks), len(out), counts


# --------------------------------------------------------------------- driver

VARIANTS = [
    # name, codecs, hunk_frames, subtype, mixed, strip_ecc
    ("cdlz", ["cdlz"], 8, "NONE", False, True),
    ("cdzl", ["cdzl"], 8, "NONE", False, True),
    ("cdzs", ["cdzs"], 8, "NONE", False, True),
    ("mixed", ["cdlz", "cdzl", "cdzs"], 8, "NONE", True, True),
    ("lzma", ["lzma"], 8, "NONE", False, False),
    ("zlib", ["zlib"], 8, "NONE", False, False),
    ("zstd", ["zstd"], 8, "NONE", False, False),
    ("cdlz-noecc", ["cdlz"], 8, "NONE", False, False),
    ("cdlz-h32", ["cdlz"], 32, "NONE", False, True),
    ("cdzs-sub", ["cdzs"], 8, "RW_RAW", False, True),
    ("cdzl-sub", ["cdzl"], 8, "RW_RAW", False, True),
]


def run(cmd):
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=1800)
    for line in (r.stdout + r.stderr).splitlines():
        if line.startswith("cdhash"):
            return line.strip()
    return "NO cdhash line: " + (r.stdout + r.stderr).strip()[-200:]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True)
    ap.add_argument("--host")
    ap.add_argument("--ppc")
    ap.add_argument("--qemu")
    ap.add_argument("--sectors", type=int, default=1536)
    ap.add_argument("--only")
    ap.add_argument("--seed", type=int, default=2024)
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)
    only = set(args.only.split(",")) if args.only else None

    users = make_user_data(args.sectors, args.seed)
    rng = random.Random(args.seed + 1)
    # a blank gap in the middle (no sync pattern: stored as zero frames, collapsing to "self" hunks)
    gap_at, gap_len = args.sectors // 2 & ~7, 24
    base_frames, raw_secs = [], []
    for lba, u in enumerate(users):
        if gap_at <= lba < gap_at + gap_len:
            raw = bytes(SECTOR)
            users[lba] = bytes(2048)
        else:
            raw = mode1_sector(lba, u, corrupt_ecc=(rng.random() < 0.03))
        raw_secs.append(raw)
    # the reader returns the data bytes of a raw sector, which for a corrupted-ECC one is still `u`
    sub_rng = random.Random(args.seed + 2)

    iso = b"".join(users)
    iso_path = os.path.join(args.out, "stress.iso")
    open(iso_path, "wb").write(iso)

    results = []
    images = [("iso", iso_path, "NONE")]

    # BIN+CUE, both flavours: 2352 byte raw sectors and 2048 byte cooked sectors
    for tag, mode, payload in (("2352", "MODE1/2352", b"".join(raw_secs)), ("2048", "MODE1/2048", iso)):
        binname = "bincue%s.bin" % tag
        open(os.path.join(args.out, binname), "wb").write(payload)
        cue_path = os.path.join(args.out, "bincue%s.cue" % tag)
        open(cue_path, "w").write('FILE "%s" BINARY\n  TRACK 01 %s\n    INDEX 01 00:00:00\n' % (binname, mode))
        images.append(("bincue-" + tag, cue_path, "NONE", raw_secs if tag == "2352" else None))
    for name, codecs, hf, sub, mixed, strip in VARIANTS:
        if only and name not in only:
            continue
        if any(c in ("zstd", "cdzs") for c in codecs) and not zstd_lib():
            print("skip %s: libzstd not found" % name)
            continue
        if sub == "RW_RAW":
            frames = [r + sub_rng.randbytes(96) for r in raw_secs]
        else:
            frames = [r + bytes(96) for r in raw_secs]
        path = os.path.join(args.out, name + ".chd")
        nh, size, counts = write_chd(path, frames, len(frames), codecs, hf, sub, mixed, strip)
        print("built %-11s %4d hunks, %8d bytes, map codes %s" % (name, nh, size, dict(sorted(counts.items()))))
        images.append((name, path, sub, frames))

    # expected hashes
    def expect(frames, sub, is_iso):
        hu = hf = FNV0
        total = 0
        for i, u in enumerate(users):
            hu = fnv(hu, u)
            if is_iso:
                chunk = u
            else:
                chunk = frames[i][:SECTOR]  # the reader hands out the 2352 byte sector, never the subcode
            hf = fnv(hf, chunk)
            total += len(chunk)
        return "cdhash blocks %d user %016x full %016x bytes %d" % (len(users), hu, hf, total)

    bad = 0
    for item in images:
        name, path, sub = item[0], item[1], item[2]
        cooked = name in ("iso", "bincue-2048")  # 2048 byte sectors: user data is all there is
        exp = expect(None if cooked else item[3], sub, cooked)
        line = [("expected", exp)]
        if args.host:
            line.append(("x86", run([args.host, "--selftest-core", "--cdhash", path])))
        if args.ppc and args.qemu:
            line.append(("ppc", run([args.qemu, "-cpu", "750", args.ppc, "cdhash", path])))
        ok = all(v == exp for _, v in line[1:]) and len(line) > 1
        bad += not ok
        print("%-5s %s" % ("PASS" if ok else "FAIL", name))
        if not ok:
            for k, v in line:
                print("      %-8s %s" % (k, v))
    print("%d image(s), %d failure(s)" % (len(images), bad))
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
