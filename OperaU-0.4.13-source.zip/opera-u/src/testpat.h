/*
 * Picture test (Settings > Video > Picture test).
 *
 * Synthetic pictures sent through exactly the path the pictures of a game take
 * (video_submit -> expansion to 32 bits -> texture -> screen), with swatches
 * drawn directly by the interface next to them. A wrong colour order, a swapped
 * channel, a flipped or cut-off picture shows at a glance, on the console itself,
 * without a game or a disc. While the test is open, X cycles the colour channel
 * order (Settings > Video keeps the choice) and Y the image filter.
 */
#ifndef OPERAU_TESTPAT_H
#define OPERAU_TESTPAT_H

#include "common.h"
#include "core.h"
#include "input.h"

#define TESTPAT_PAGES 4
#define TESTPAT_MAX_W 640
#define TESTPAT_MAX_H 480

/* The eight colour bars at the top of the colour pages, as 0xRRGGBB. */
#define TESTPAT_BARS 8
extern const uint32_t testpat_bar_rgb[TESTPAT_BARS];

/* Shows the first page (sends its picture to the video module). */
void testpat_enter(void);
/* Drops the picture again. */
void testpat_leave(void);
/* One navigation action; returns false when the test should close. */
bool testpat_nav(nav_action_t a);
/* Draws the whole screen (picture, swatches, texts). */
void testpat_draw(void);

/* Page content without any screen involved (used by testpat_enter() and by the self test). Fills `rgb` with
 * w * h pixels as 0x00RRGGBB, tightly packed, and tells the format the page is sent in. Returns false for a
 * page number out of range. */
bool testpat_render(int page, uint32_t *rgb, unsigned *w, unsigned *h, core_pixel_format_t *fmt);
int testpat_page(void);

#endif
