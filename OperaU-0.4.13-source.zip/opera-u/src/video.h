/*
 * Video output: one SDL window/renderer (TV + GamePad mirror on the Wii U),
 * a lock-free triple buffer between the emulation thread and the UI thread,
 * and the aspect / filter handling for the game picture.
 */
#ifndef OPERAU_VIDEO_H
#define OPERAU_VIDEO_H

#include "common.h"
#include "core.h"

#include <SDL.h>

#define LOGICAL_W 1280
#define LOGICAL_H 720

bool video_init(void);
void video_shutdown(void);
SDL_Renderer *video_renderer(void);

/* Emulation thread: copies the picture into the triple buffer. */
void video_submit(const void *data, unsigned w, unsigned h, size_t pitch, core_pixel_format_t fmt);

/* UI thread -------------------------------------------------------------- */
void video_begin_frame(void);                    /* clears the backbuffer */
/* Uploads the newest game frame (if any) and draws it with the current
 * aspect/filter settings. Returns true if a frame has ever been received. */
bool video_draw_game(void);
void video_end_frame(void);                      /* presents */
/* Dim the whole screen (used behind the pause menu). */
void video_draw_dim(int alpha);

/* Same, into a given rectangle of the 1280x720 screen (the picture test). */
bool video_draw_game_rect(const SDL_Rect *r);

/* Drops the cached frame (call when a new game starts). */
void video_reset(void);
void video_apply_settings(void);                 /* aspect, filter, vsync, colour order */
/* Colour orders the picture can be shown in (g_cfg.color_order): 0 is the normal one. */
#define VIDEO_COLOR_ORDERS 6
const char *video_color_order_name(int order);   /* "RGB", "BGR", ... */
void video_set_game_aspect(float aspect);        /* from the core */

/* Stats */
float video_present_fps(void);
unsigned long video_frames_submitted(void);

/* Saves the last game frame (native resolution, as the core produced it) as a PNG. */
bool video_save_game_frame_png(const char *path);
/* Saves everything on screen (after the last draw, before present) - used by
 * the headless test mode to inspect the UI. */
bool video_save_screen_bmp(const char *path);
/* One pixel of what is on screen after the last draw, before present (headless tests). */
bool video_read_pixel(int x, int y, uint8_t rgb[3]);

#endif
