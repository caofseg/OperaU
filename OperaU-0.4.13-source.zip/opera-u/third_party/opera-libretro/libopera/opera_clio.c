/*
  www.freedo.org
  The first working 3DO multiplayer emulator.

  The FreeDO licensed under modified GNU LGPL, with following notes:

  *   The owners and original authors of the FreeDO have full right to
  *   develop closed source derivative work.

  *   Any non-commercial uses of the FreeDO sources or any knowledge
  *   obtained by studying or reverse engineering of the sources, or
  *   any other material published by FreeDO have to be accompanied
  *   with full credits.

  *   Any commercial uses of FreeDO sources or any knowledge obtained
  *   by studying or reverse engineering of the sources, or any other
  *   material published by FreeDO is strictly forbidden without
  *   owners approval.

  The above notes are taking precedence over GNU LGPL in conflicting
  situations.

  Project authors:
  *  Alexander Troosh
  *  Maxim Grishin
  *  Allen Wright
  *  John Sammons
  *  Felix Lazarev
*/

#include "opera_arm.h"
#include "opera_clio.h"
#include "opera_clock.h"
#include "opera_dsp.h"
#include "opera_madam.h"
#include "opera_mem.h"
#include "opera_state.h"
#include "opera_xbus.h"

#include "boolean.h"
#include "prng32.h"

#include <assert.h>
#include <string.h>

#define DECREMENT    0x1
#define RELOAD       0x2
#define CASCADE      0x4
#define FLABLODE     0x8
#define RELOAD_VAL   0x10

#define VINT_MASK    0x7FF
#define HCNT_MASK    0x7FF
#define VCNT_MASK    0x7FF
#define VCNT_FIELD   0x800

#define CSTAT_PON         0x01
#define CSTAT_ROLLOVER    0x02
#define CSTAT_WDOG_MASK   0x0C
#define CSTAT_DIPIR_RESET 0x40
#define CSTAT_CLEAR_ON_ZERO_MASK \
  (CSTAT_PON | CSTAT_ROLLOVER | CSTAT_DIPIR_RESET)

#define XBUS_DIPIR1_ADDR        0x410
#define XBUS_DIPIR2_ADDR        0x414
#define XBUS_DIPIR_DEVICE_MASK  0x00FF
#define XBUS_DIPIR_BEFORE_RESET 0x4000
#define XBUS_DIPIR_CURRENT      0x8000
#define XBUS_DMA_ENABLE_MASK    0x00100000
#define CLIO_INT0_SECONDARY     0x80000000
#define CLIO_INT1_DIPIR         0x00000002

#define WDOG_RESTART      0x0B

struct fifo_s
{
  uint32_t addr;
  int32_t  len;
};

typedef struct fifo_s fifo_t;

struct clio_fifo_s
{
  int32_t idx;
  fifo_t  start;
  fifo_t  next;
};

typedef struct clio_fifo_s clio_fifo_t;

struct clio_s
{
  uint32_t    regs[65536];
  int32_t     dsp_word1;
  int32_t     dsp_word2;
  int32_t     dsp_address;
  clio_fifo_t fifo_i[13];
  clio_fifo_t fifo_o[4];
};

typedef struct clio_s clio_t;

int flagtime;
int TIMER_VAL = 0; //0x415

static uint32_t *MADAM_REGS;
static clio_t    CLIO = {0};
static uint32_t  TIMER_CARRY = 0;

static
bool
clio_timer_reg_addr(uint32_t addr_)
{
  return ((addr_ >= 0x100) && (addr_ <= 0x17C) && !(addr_ & 3));
}

static
uint32_t
timer_control_shift(const uint32_t timer_)
{
  return ((timer_ & 7) << 2);
}

static
void
clio_timer_regs_mask(void)
{
  uint32_t addr;

  for(addr = 0x100; addr <= 0x17C; addr += 4)
    CLIO.regs[addr] &= 0xFFFF;
}

static
void
opera_clio_set_rom()
{
  opera_mem_rom_select((CLIO.regs[0x84] & ADBIO_OTHERROM) ? ROM2 : ROM1);
}

uint32_t
opera_clio_state_size_v1(void)
{
  return opera_state_save_size(sizeof(clio_t));
}

static
bool
clio_state_write_fifo(opera_state_writer_t *writer_,
                      clio_fifo_t const    *fifo_)
{
  return (opera_state_write_i32(writer_,fifo_->idx) &&
          opera_state_write_u32(writer_,fifo_->start.addr) &&
          opera_state_write_i32(writer_,fifo_->start.len) &&
          opera_state_write_u32(writer_,fifo_->next.addr) &&
          opera_state_write_i32(writer_,fifo_->next.len));
}

static
bool
clio_state_write_payload(opera_state_writer_t *writer_,
                         clio_t const         *state_)
{
  uint32_t i;

  if(!opera_state_write_u32_array(writer_,state_->regs,65536) ||
     !opera_state_write_i32(writer_,state_->dsp_word1) ||
     !opera_state_write_i32(writer_,state_->dsp_word2) ||
     !opera_state_write_i32(writer_,state_->dsp_address))
    return false;

  for(i = 0; i < 13; i++)
    if(!clio_state_write_fifo(writer_,&state_->fifo_i[i]))
      return false;
  for(i = 0; i < 4; i++)
    if(!clio_state_write_fifo(writer_,&state_->fifo_o[i]))
      return false;

  return (opera_state_write_i32(writer_,flagtime) &&
          opera_state_write_i32(writer_,TIMER_VAL) &&
          opera_state_write_u32(writer_,TIMER_CARRY));
}

static
uint32_t
clio_state_payload_size(void)
{
  opera_state_writer_t writer;

  opera_state_writer_init(&writer,NULL,UINT32_MAX);
  clio_state_write_payload(&writer,&CLIO);

  return opera_state_writer_used(&writer);
}

uint32_t
opera_clio_state_size(void)
{
  return opera_state_chunk_size(clio_state_payload_size());
}

uint32_t
opera_clio_state_save(void *buf_)
{
  uint32_t payload_size;
  opera_state_writer_t writer;

  payload_size = clio_state_payload_size();
  opera_state_writer_init(&writer,buf_,opera_state_chunk_size(payload_size));
  opera_state_write_chunk_header(&writer,"CLIO",payload_size);
  clio_state_write_payload(&writer,&CLIO);

  return opera_state_writer_ok(&writer) ? opera_state_writer_used(&writer) : 0;
}

uint32_t
opera_clio_state_load_v1(const void     *buf_,
                         uint32_t const  size_)
{
  uint32_t rv;

  rv = opera_state_load_sized(&CLIO,"CLIO",buf_,size_,sizeof(CLIO));
  if(rv != 0)
    {
      TIMER_VAL = 0;
      flagtime = 0;
      TIMER_CARRY = 0;
      opera_clio_set_rom();
    }

  return rv;
}

static
bool
clio_state_read_fifo(opera_state_reader_t *reader_,
                     clio_fifo_t          *fifo_)
{
  return (opera_state_read_i32(reader_,&fifo_->idx) &&
          opera_state_read_u32(reader_,&fifo_->start.addr) &&
          opera_state_read_i32(reader_,&fifo_->start.len) &&
          opera_state_read_u32(reader_,&fifo_->next.addr) &&
          opera_state_read_i32(reader_,&fifo_->next.len));
}

static
bool
clio_state_read_payload(opera_state_reader_t *reader_,
                        clio_t               *state_,
                        int32_t              *flagtime_state_,
                        int32_t              *timer_val_state_,
                        uint32_t             *timer_carry_state_)
{
  uint32_t i;

  if(!opera_state_read_u32_array(reader_,state_->regs,65536) ||
     !opera_state_read_i32(reader_,&state_->dsp_word1) ||
     !opera_state_read_i32(reader_,&state_->dsp_word2) ||
     !opera_state_read_i32(reader_,&state_->dsp_address))
    return false;

  for(i = 0; i < 13; i++)
    if(!clio_state_read_fifo(reader_,&state_->fifo_i[i]))
      return false;
  for(i = 0; i < 4; i++)
    if(!clio_state_read_fifo(reader_,&state_->fifo_o[i]))
      return false;

  if(!opera_state_read_i32(reader_,flagtime_state_) ||
     !opera_state_read_i32(reader_,timer_val_state_) ||
     !opera_state_read_u32(reader_,timer_carry_state_))
    return false;

  return true;
}

uint32_t
opera_clio_state_load(const void     *buf_,
                      uint32_t const  size_)
{
  clio_t state;
  int32_t flagtime_state;
  int32_t timer_val_state;
  uint32_t timer_carry_state;
  opera_state_reader_t reader;
  opera_state_reader_t payload;

  opera_state_reader_init(&reader,buf_,size_);
  if(!opera_state_read_chunk(&reader,"CLIO",&payload) ||
     !clio_state_read_payload(&payload,
                              &state,
                              &flagtime_state,
                              &timer_val_state,
                              &timer_carry_state) ||
     !opera_state_reader_finished(&payload))
    return 0;

  if(opera_state_validating())
    return opera_state_reader_used(&reader);

  CLIO = state;
  flagtime = flagtime_state;
  TIMER_VAL = timer_val_state;
  TIMER_CARRY = timer_carry_state;
  opera_clio_set_rom();

  return opera_state_reader_used(&reader);
}

#define CURADR MADAM_REGS[base+0x00]
#define CURLEN MADAM_REGS[base+0x04]
#define RLDADR MADAM_REGS[base+0x08]
#define RLDLEN MADAM_REGS[base+0x0C]

void
opera_clio_timer_set(uint32_t v200_,
                     uint32_t v208_)
{
  (void) v200_;
  (void) v208_;
}

void
opera_clio_timer_clear(uint32_t v204_,
                       uint32_t v20C_)
{
  (void) v204_;
  (void) v20C_;
}

uint32_t
opera_clio_line_vint0(void)
{
  return (CLIO.regs[8] & VINT_MASK);
}

uint32_t
opera_clio_line_vint1(void)
{
  return (CLIO.regs[12] & VINT_MASK);
}

int
opera_clio_fiq_needed(void)
{
  /* Green CLIO's INT0 summary reflects enabled sources in INT1. */
  return (((CLIO.regs[0x40] & CLIO.regs[0x48]) &
           ~CLIO_INT0_SECONDARY) ||
          (CLIO.regs[0x60] & CLIO.regs[0x68]));
}

void
opera_clio_fiq_generate(uint32_t reason1_,
                        uint32_t reason2_)
{
  CLIO.regs[0x40] |= (reason1_ & ~CLIO_INT0_SECONDARY);
  CLIO.regs[0x60] |= reason2_;
}

/* Local modification for OperaU, see opera_clio.h. */
void (*opera_clio_fiq_from_dsp_hook)(uint32_t reason1_) = NULL;

void
opera_clio_fiq_generate_from_dsp(uint32_t reason1_)
{
  if(opera_clio_fiq_from_dsp_hook)
    (*opera_clio_fiq_from_dsp_hook)(reason1_);
  else
    opera_clio_fiq_generate(reason1_,0);
}

/*
  Documentation:
  * https://github.com/trapexit/portfolio_os/blob/master/src/kernel/includes/clio.h

  | Register | Description
  |----------|------------
  | 0x0300   | FIFO init group masks
  |          | DMA->DSPP   = 0x00001FFF [0:12]
  |          | AudIn->DSPP = 0x00006000 [L:R]
  |          | DSPP->DMA   = 0x000F0000 [0:3]
  | 0x0304   | enable DMA
  |          | DMA to DSPP      = 0x00001FFF
  |          | DMA to UNCLE     = 0x00002000
  |          | DMA to EXTERNAL  = 0x00004000
  |          | DMA to DSPP PROG = 0x00008000
  |          | DSPP to DMA MAKS = 0x000F0000
  |          | DMA to/from XBUS = 0x00100000
  |          | UNCLE to DMA     = 0x20000000
  |          | EXTERNAL to DMA  = 0x40000000
  | 0x0308   | disable / clear DMA
  |          | bits same as above
 */
static
void
clio_handle_dma(uint32_t val_)
{
  CLIO.regs[0x304] |= val_;

  if(val_ & XBUS_DMA_ENABLE_MASK)
    {
      int len;
      unsigned trg;
      uint8_t b0,b1,b2,b3;

      /* A DIPIR-protected XBus DMA remains enabled but makes no progress. */
      if(opera_clio_xbus_access_aborts(opera_xbus_selected_device_address(),
                                       0x5C0))
        return;

      trg = opera_madam_peek(0x540);
      len = opera_madam_peek(0x544);
      CLIO.regs[0x304] &= ~XBUS_DMA_ENABLE_MASK;
      CLIO.regs[0x400] &= ~0x80;

      if(CLIO.regs[0x404] & 0x200)
        {
          while(len >= 0)
            {
              b3 = opera_xbus_fifo_get_data();
              b2 = opera_xbus_fifo_get_data();
              b1 = opera_xbus_fifo_get_data();
              b0 = opera_xbus_fifo_get_data();

              opera_mem_write8(trg+0,b3);
              opera_mem_write8(trg+1,b2);
              opera_mem_write8(trg+2,b1);
              opera_mem_write8(trg+3,b0);

              trg += 4;
              len -= 4;
            }

          CLIO.regs[0x400] |= 0x80;
        }
      else
        {
          while(len >= 0)
            {
              b3 = opera_xbus_fifo_get_data();
              b2 = opera_xbus_fifo_get_data();
              b1 = opera_xbus_fifo_get_data();
              b0 = opera_xbus_fifo_get_data();

              opera_mem_write8(trg+0,b3);
              opera_mem_write8(trg+1,b2);
              opera_mem_write8(trg+2,b1);
              opera_mem_write8(trg+3,b0);

              trg += 4;
              len -= 4;
            }

          CLIO.regs[0x400] |= 0x80;
        }

      opera_madam_poke(0x544,0xFFFFFFFC);
      opera_clio_fiq_generate(1<<29,0);
    }
}


void
opera_clio_xbus_dma_execute(void)
{
  if((CLIO.regs[0x304] & XBUS_DMA_ENABLE_MASK) == 0)
    return;

  clio_handle_dma(XBUS_DMA_ENABLE_MASK);
}


static
void
adbio_set(uint32_t *output_,
          uint32_t  val_,
          uint32_t  bit_)
{
  uint32_t mask;

  mask = (1 << bit_);

  if((val_ & mask) == 0)
    *output_ &= ~mask;
  else if(val_ & (mask | (mask << 4)))
    *output_ |= mask;
}

int
opera_clio_poke(uint32_t addr_,
                uint32_t val_)
{
  int base;
  int i;

  if(!flagtime)
    TIMER_VAL = 0;

  /* 0x40..0x4C, 0x60..0x6C case */
  if((addr_ & ~0x2C) == 0x40)
    {
      if(addr_ == 0x40)
        {
          CLIO.regs[0x40] |= (val_ & ~CLIO_INT0_SECONDARY);
          /*
            if(CLIO.regs[0x40]&CLIO.regs[0x48])
            _arm_SetFIQ();
          */
          return 0;
        }
      else if(addr_ == 0x44)
        {
          CLIO.regs[0x40] &= ~val_;
          return 0;
        }
      else if(addr_ == 0x48)
        {
          CLIO.regs[0x48] |= (val_ & ~CLIO_INT0_SECONDARY);
          /*
            if(CLIO.regs[0x40] & CLIO.regs[0x48])
            _arm_SetFIQ();
          */
          return 0;
        }
      else if(addr_ == 0x4C)
        {
          CLIO.regs[0x48] &= ~val_;
          CLIO.regs[0x48] &= ~CLIO_INT0_SECONDARY;
          return 0;
        }
#if 0
      else if(addr_ == 0x50)
        {
          CLIO.regs[0x50] |= (val_ & 0x3FFF0000);
          return 0;
        }
      else if(addr_ == 0x54)
        {
          CLIO.regs[0x50] &= ~val;
          return 0;
        }
#endif
      else if(addr_ == 0x60)
        {
          CLIO.regs[0x60] |= val_;
          /*
            if(CLIO.regs[0x60] & CLIO.regs[0x68])
            _arm_SetFIQ();
          */
          return 0;
        }
      else if(addr_ == 0x64)
        {
          CLIO.regs[0x60] &= ~val_;
          return 0;
        }
      else if(addr_ == 0x68)
        {
          CLIO.regs[0x68] |= val_;
          /*
            if(CLIO.regs[0x60] & CLIO.regs[0x68])
            _arm_SetFIQ();
          */
          return 0;
        }
      else if(addr_ == 0x6C)
        {
          CLIO.regs[0x68] &= ~val_;
          return 0;
        }
    }
  else if(addr_ == 0x84)
    {
      adbio_set(&CLIO.regs[0x84],val_,0);
      adbio_set(&CLIO.regs[0x84],val_,1);
      adbio_set(&CLIO.regs[0x84],val_,2);
      adbio_set(&CLIO.regs[0x84],val_,3);

      opera_clio_set_rom();

      return 0;
    }
  else if(addr_ == 0x0300)
    {
      /* clear down the fifos and stop them */
      base = 0;
      opera_dsp_arm_write_sync(); /* Local modification for OperaU, see opera_dsp.h */
      CLIO.regs[0x304] &= ~val_;

      for(i = 0; i < 13; i++)
        {
          if(val_ & (1 << i))
            {
              base = (0x400 + (i << 4));
              RLDADR = CURADR = 0;
              RLDLEN = CURLEN = 0;
              opera_clio_fifo_write(base + 0x00,0);
              opera_clio_fifo_write(base + 0x04,0);
              opera_clio_fifo_write(base + 0x08,0);
              opera_clio_fifo_write(base + 0x0C,0);
              val_ &= ~(1 << i);
              CLIO.fifo_i[i].idx = 0;
            }
        }

      for(i = 0; i < 4; i++)
        {
          if(val_ & (1 << (i + 16)))
            {
              base = (0x500 + (i << 4));
              RLDADR = CURADR = 0;
              RLDLEN = CURLEN = 0;
              opera_clio_fifo_write(base + 0x00,0);
              opera_clio_fifo_write(base + 0x04,0);
              opera_clio_fifo_write(base + 0x08,0);
              opera_clio_fifo_write(base + 0x0C,0);
              val_ &= ~(1 << (i + 16));
              CLIO.fifo_o[i].idx = 0;
            }
        }

      return 0;
    }
  else if(addr_ == 0x304) /* DMA enable */
    {
      /* Local modification for OperaU, see opera_dsp.h: only for the audio channels, which the DSP looks at when
         a FIFO runs out; a disc transfer is none of its business and happens far too often to wait for it. */
      if(val_ & ~XBUS_DMA_ENABLE_MASK)
        opera_dsp_arm_write_sync();
      clio_handle_dma(val_);

      /* TODO: looks hacky, needs to be investigated */
      switch(val_)
        {
        case 0x100000:
          if(TIMER_VAL < 5800)
            TIMER_VAL += 0x33;
          flagtime = (opera_clock_cpu_get_freq() / 2000000);
          break;
        default:
          if(!CLIO.regs[0x304])
            TIMER_VAL = 0;
          break;
        }
      return 0;
    }
  else if(addr_ == 0x308) /* DMA clear / disable */
    {
      if(val_ & ~XBUS_DMA_ENABLE_MASK)
        opera_dsp_arm_write_sync(); /* Local modification for OperaU, see opera_dsp.h */
      CLIO.regs[0x304] &= ~val_;
      return 0;
    }
  else if(addr_ == 0x400) /* XBUS direction */
    {
      if(val_ & 0x800)
        return 0;

      CLIO.regs[0x400] = val_;
      return 0;
    }
  else if((addr_ == XBUS_DIPIR1_ADDR) || (addr_ == XBUS_DIPIR2_ADDR))
    {
      // DIPIR status is read-only; media access and reset own these latches.
      return 0;
    }
  else if((addr_ >= 0x500) && (addr_ < 0x540))
    {
      opera_xbus_set_sel(val_);
      return 0;
    }
  else if((addr_ >= 0x540) && (addr_ < 0x580))
    {
      opera_xbus_set_poll(val_);
      return 0;
    }
  else if((addr_ >= 0x580) && (addr_ < 0x5C0))
    {
      /* on FIFO Filled execute the command */
      opera_xbus_fifo_set_cmd(val_);
      return 0;
    }
  else if((addr_ >= 0x5c0) && (addr_ < 0x600))
    {
      /* on FIFO Filled execute the command */
      opera_xbus_fifo_set_data(val_);
      return 0;
    }
  else if(addr_ == 0x28)
    {
      uint32_t cstat;

      cstat = (val_ & ~(OPERA_CLIO_RESET_SOFT |
                        OPERA_CLIO_RESET_CLEAR_DIPIR |
                        CSTAT_CLEAR_ON_ZERO_MASK |
                        CSTAT_WDOG_MASK));
      cstat |= (CLIO.regs[addr_] & CSTAT_WDOG_MASK);
      cstat |= (CLIO.regs[addr_] & val_ & CSTAT_CLEAR_ON_ZERO_MASK);

      if((val_ & (OPERA_CLIO_RESET_SOFT |
                  OPERA_CLIO_RESET_CLEAR_DIPIR)) ==
         (OPERA_CLIO_RESET_SOFT | OPERA_CLIO_RESET_CLEAR_DIPIR))
        cstat |= CSTAT_DIPIR_RESET;

      CLIO.regs[addr_] = cstat;
      if(val_ & OPERA_CLIO_RESET_SOFT)
        return (val_ & (OPERA_CLIO_RESET_SOFT |
                        OPERA_CLIO_RESET_CLEAR_DIPIR));
      return 0;
    }
  else if(addr_ == 0x2C)
    {
      if((val_ & 0x0F) == WDOG_RESTART)
        CLIO.regs[addr_] = WDOG_RESTART;
      return 0;
    }
  else if((addr_ == 0x08) || (addr_ == 0x0C))
    {
      CLIO.regs[addr_] = (val_ & VINT_MASK);
      return 0;
    }
  else if(addr_ == 0x30)
    {
      CLIO.regs[addr_] = (val_ & HCNT_MASK);
      return 0;
    }
  else if(addr_ == 0x34)
    {
      CLIO.regs[addr_] = (val_ & (VCNT_MASK | VCNT_FIELD));
      return 0;
    }
  else if((addr_ >= 0x1800) && (addr_ <= 0x1FFF))
    {
      addr_ &= ~0x400; /* mirrors */
      CLIO.dsp_word1   = (val_ >> 16);
      CLIO.dsp_word2   = (val_ & 0xFFFF);
      CLIO.dsp_address = ((addr_ - 0x1800) >> 1);
      opera_dsp_mem_write(CLIO.dsp_address+0,CLIO.dsp_word1);
      opera_dsp_mem_write(CLIO.dsp_address+1,CLIO.dsp_word2);
      return 0;
      /* DSPNRAMWrite 2 DSPW per 1ARMW */
    }
  else if((addr_ >= 0x2000) && (addr_ <= 0x2FFF))
    {
      addr_ &= ~0x800; /* mirrors */
      CLIO.dsp_word1   = (val_ & 0xFFFF);
      CLIO.dsp_address = ((addr_ - 0x2000) >> 2);
      opera_dsp_mem_write(CLIO.dsp_address,CLIO.dsp_word1);
      return 0;
    }
  else if((addr_ >= 0x3000) && (addr_ <= 0x33FF))
    {
      CLIO.dsp_address  = ((addr_ - 0x3000) >> 1);
      CLIO.dsp_address &= 0xFF;
      CLIO.dsp_word1    = (val_ >> 16);
      CLIO.dsp_word2    = (val_ & 0xFFFF);
      opera_dsp_imem_write(CLIO.dsp_address+0,CLIO.dsp_word1);
      opera_dsp_imem_write(CLIO.dsp_address+1,CLIO.dsp_word2);
      return 0;
    }
  else if((addr_ >= 0x3400) && (addr_ <= 0x37FF))
    {
      CLIO.dsp_address  = ((addr_ - 0x3400) >> 2);
      CLIO.dsp_address &= 0xFF;
      CLIO.dsp_word1    = (val_ & 0xFFFF);
      opera_dsp_imem_write(CLIO.dsp_address,CLIO.dsp_word1);
      return 0;
    }
  else if(addr_ == 0x17E8) /* Reset */
    {
      opera_dsp_arm_write_sync(); /* Local modification for OperaU, see opera_dsp.h */
      opera_dsp_reset();
      return 0;
    }
  else if(addr_ == 0x17D0) /* Write DSP/ARM Semaphore */
    {
      opera_dsp_arm_semaphore_write(val_);
      return 0;
    }
  else if(addr_ == 0x17FC) /* start / stop */
    {
      opera_dsp_set_running(val_ > 0);
      return 0;
    }
  else if(addr_ == 0x200)
    {
      CLIO.regs[0x200] |= val_;
      opera_clio_timer_set(val_,0);
      return 0;
    }
  else if(addr_ == 0x204)
    {
      CLIO.regs[0x200] &= ~val_;
      opera_clio_timer_clear(val_,0);
      return 0;
    }
  else if(addr_ == 0x208)
    {
      CLIO.regs[0x208] |= val_;
      opera_clio_timer_set(0,val_);
      return 0;
    }
  else if(addr_ == 0x20C)
    {
      CLIO.regs[0x208] &= ~val_;
      opera_clio_timer_clear(0,val_);
      return 0;
    }
  else if(addr_ == 0x220)
    {
      CLIO.regs[addr_] = (val_ & 0x3FF);
      opera_clock_timer_set_delay(CLIO.regs[addr_]);
      return 0;
    }
  else if(clio_timer_reg_addr(addr_))
    {
      CLIO.regs[addr_] = (val_ & 0xFFFF);
      return 0;
    }

  CLIO.regs[addr_] = val_;

  return 0;
}

uint32_t
opera_clio_peek(uint32_t addr_)
{
  /* 0x40..0x4C, 0x60..0x6C case */
  if((addr_ & ~0x2C) == 0x40)
    {
      /* By read 40 and 44, 48 and 4c, 60 and 64, 68 and 6c same */
      addr_ &= ~4;
      if(addr_ == 0x40)
        return ((CLIO.regs[0x40] & ~CLIO_INT0_SECONDARY) |
                ((CLIO.regs[0x60] & CLIO.regs[0x68]) ?
                 CLIO_INT0_SECONDARY : 0));
      else if(addr_ == 0x48)
        return (CLIO.regs[0x48] | CLIO_INT0_SECONDARY);
      else if(addr_ == 0x60)
        return CLIO.regs[0x60];
      else if(addr_ == 0x68)
        return CLIO.regs[0x68];
      return 0;
    }
  else if(addr_ == 0x3C) // RandSample
    return prng32();
  else if(addr_ == 0x2C)
    return 0;
  else if(addr_ == 0x204)
    return CLIO.regs[0x200];
  else if(addr_ == 0x20C)
    return CLIO.regs[0x208];
  else if(addr_ == 0x308) /* Using the enable DMA register to store state */
    return CLIO.regs[0x304];
  else if((addr_ >= 0x500) && (addr_ < 0x540))
    return opera_xbus_get_res();
  else if((addr_ >= 0x540) && (addr_ < 0x580))
    return opera_xbus_get_poll();
  else if((addr_ >= 0x580) && (addr_ < 0x5C0))
    return opera_xbus_fifo_get_status();
  else if((addr_ >= 0x5C0) && (addr_ < 0x600))
    return opera_xbus_fifo_get_data();
  else if(addr_ == 0x0)
    return 0x02020000;
  else if((addr_ == 0x08) || (addr_ == 0x0C))
    return (CLIO.regs[addr_] & VINT_MASK);
  else if(addr_ == 0x30)
    return (CLIO.regs[addr_] & HCNT_MASK);
  else if(addr_ == 0x34)
    return (CLIO.regs[addr_] & (VCNT_MASK | VCNT_FIELD));
  else if((addr_ >= 0x3800) && (addr_ <= 0x3BFF))
    {
      /* 2DSPW per 1ARMW */
      CLIO.dsp_address  = ((addr_ - 0x3800) >> 1);
      CLIO.dsp_address &= 0xFF;
      CLIO.dsp_address += 0x300;
      CLIO.dsp_word1    = opera_dsp_imem_read(CLIO.dsp_address+0);
      CLIO.dsp_word2    = opera_dsp_imem_read(CLIO.dsp_address+1);
      return ((CLIO.dsp_word1 << 16) | CLIO.dsp_word2);
    }
  else if((addr_ >= 0x3C00) && (addr_ <= 0x3FFF))
    {
      CLIO.dsp_address  = ((addr_ - 0x3C00) >> 2);
      CLIO.dsp_address &= 0xFF;
      CLIO.dsp_address += 0x300;
      return opera_dsp_imem_read(CLIO.dsp_address);
    }
  else if(addr_ == 0x17F0) // DSP NOISE
    return prng32();
  else if(addr_ == 0x17D0) /* read DSP/ARM semaphore */
    return opera_dsp_arm_semaphore_read();
  else if(clio_timer_reg_addr(addr_))
    return (CLIO.regs[addr_] & 0xFFFF);

  return CLIO.regs[addr_];
}

void
opera_clio_vcnt_update(int line_,
                       int field_)
{
  CLIO.regs[0x34] = (((field_ << 11) & VCNT_FIELD) |
                     ((uint32_t)line_ & VCNT_MASK));
}

static
uint32_t
timer_flags(const uint32_t timer_)
{
  return ((CLIO.regs[((timer_ < 8) ? 0x200 : 0x208)] >> timer_control_shift(timer_)) & 0xF);
}

static
void
timer_disable(const uint32_t timer_)
{
  CLIO.regs[((timer_ < 8) ? 0x200 : 0x208)] &= ~(DECREMENT << timer_control_shift(timer_));
}

/*
  One timer slot comes due (timer_ is 0..15): count it down, cascade it
  and raise its interrupt when it underflows.
*/
static
INLINE
void
timer_execute(const uint32_t timer_)
{
  uint32_t *reg;
  uint32_t  count;
  uint32_t  flags;
  uint32_t  underflow;

  if(timer_ == 0)
    TIMER_CARRY = 0;

  underflow = 0;
  flags = timer_flags(timer_);
  if(flags & DECREMENT)
    {
      if((flags & CASCADE) && !TIMER_CARRY)
        {
          TIMER_CARRY = 0;
          return;
        }

      reg   = &CLIO.regs[(0x100 + (timer_ << 3))];
      count = (reg[0] & 0xFFFF);
      if(count == 0)
        {
          underflow = 1;
          if(timer_ & 1)
            opera_clio_fiq_generate(1<<(10-(timer_>>1)),0);
          if(flags & RELOAD)
            reg[0] = (reg[4] & 0xFFFF);
          else
            {
              reg[0] = 0xFFFF;
              timer_disable(timer_);
            }
        }
      else
        {
          reg[0] = (count - 1);
        }
    }

  TIMER_CARRY = underflow;
}

void
opera_clio_timer_execute(uint32_t timer_)
{
  timer_execute(timer_ & 0x0F);
}

/*
  Bit n is set while timer n counts down (the DECREMENT bit of its nibble in
  registers 0x200 and 0x208).
*/
static
INLINE
uint32_t
timers_decrementing(void)
{
  uint32_t lo;
  uint32_t hi;

  lo = (CLIO.regs[0x200] & 0x11111111);
  hi = (CLIO.regs[0x208] & 0x11111111);

  lo = ((lo | (lo >>  3)) & 0x03030303);
  hi = ((hi | (hi >>  3)) & 0x03030303);
  lo = ((lo | (lo >>  6)) & 0x000F000F);
  hi = ((hi | (hi >>  6)) & 0x000F000F);
  lo = ((lo | (lo >> 12)) & 0x000000FF);
  hi = ((hi | (hi >> 12)) & 0x000000FF);

  return (lo | (hi << 8));
}

/*
  Runs every timer slot that has come due. Same result as asking the clock
  for each due slot and running it, but a slot whose timer is not counting
  down only has to clear the carry, so it is not worth a function call, and
  neither is asking the clock again and again.
  (Local modification for OperaU, see third_party/patches/.)
*/
void
opera_clio_timers_run(void)
{
  opera_clock_timers_t *t;
  uint32_t              active;
  uint32_t              slot;

  t = opera_clock_timers();
  if(t->acc < t->until)
    return;

  active = timers_decrementing();
  do
    {
      t->acc -= t->until;
      slot    = t->slot;

      t->slot++;
      if(t->slot >= 16)
        {
          t->slot   = 0;
          t->in_gap = 1;
          t->until  = t->gap_cycles;
        }
      else
        {
          t->in_gap = 0;
          t->until  = t->slot_cycles;
        }

      if((active >> slot) & 1)
        {
          timer_execute(slot);
          /* an underflow without reload switches the timer off */
          active = timers_decrementing();
        }
      else
        {
          TIMER_CARRY = 0;
        }
    }
  while(t->acc >= t->until);
}

uint32_t
opera_clio_timer_get_delay(void)
{
  return CLIO.regs[0x220];
}

void opera_clio_init(int reason_)
{
  memset(&CLIO,0,sizeof(CLIO));

  //CLIO.regs[8]=240;

  CLIO.regs[0x0028] = reason_;
  CLIO.regs[0x0400] = 0x80;
  CLIO.regs[0x0220] = 64;
  opera_clock_timer_set_delay(CLIO.regs[0x220]);
  MADAM_REGS = opera_madam_registers();
  TIMER_VAL  = 0;
  flagtime   = 0;
  TIMER_CARRY = 0;
}

static
uint32_t
clio_dipir_latch_after_reset(uint32_t latch_)
{
  uint32_t rv;
  uint32_t field;
  uint32_t shift;

  rv = 0;
  for(shift = 0; shift <= 16; shift += 16)
    {
      field = ((latch_ >> shift) & 0xFFFF);
      if(field & XBUS_DIPIR_CURRENT)
        rv |= ((XBUS_DIPIR_BEFORE_RESET |
                (field & XBUS_DIPIR_DEVICE_MASK)) << shift);
    }

  return rv;
}

void
opera_clio_soft_reset(int clear_dipir_)
{
  uint32_t dipir1;
  uint32_t dipir2;

  if(!clear_dipir_)
    return;

  dipir1 = CLIO.regs[XBUS_DIPIR1_ADDR];
  dipir2 = CLIO.regs[XBUS_DIPIR2_ADDR];
  CLIO.regs[XBUS_DIPIR1_ADDR] = clio_dipir_latch_after_reset(dipir1);
  CLIO.regs[XBUS_DIPIR2_ADDR] = clio_dipir_latch_after_reset(dipir2);
}

void
opera_clio_xbus_media_access(uint32_t unit_)
{
  uint32_t dipir1;
  uint32_t dipir2;
  uint32_t latch;

  latch = (XBUS_DIPIR_CURRENT | (unit_ & XBUS_DIPIR_DEVICE_MASK));
  dipir1 = CLIO.regs[XBUS_DIPIR1_ADDR];
  dipir2 = CLIO.regs[XBUS_DIPIR2_ADDR];

  if(((dipir1 & XBUS_DIPIR_CURRENT) &&
      ((dipir1 & XBUS_DIPIR_DEVICE_MASK) ==
       (latch & XBUS_DIPIR_DEVICE_MASK))) ||
     ((dipir2 & XBUS_DIPIR_CURRENT) &&
      ((dipir2 & XBUS_DIPIR_DEVICE_MASK) ==
       (latch & XBUS_DIPIR_DEVICE_MASK))))
    return;

  /* Green CLIO records the first two distinct devices in separate latches. */
  if(!(dipir1 & XBUS_DIPIR_CURRENT))
    {
      CLIO.regs[XBUS_DIPIR1_ADDR] = latch;
      opera_clio_fiq_generate(0,CLIO_INT1_DIPIR);
    }
  else if(!(dipir2 & XBUS_DIPIR_CURRENT))
    CLIO.regs[XBUS_DIPIR2_ADDR] = latch;
  else
    return;
}

int
opera_clio_xbus_access_aborts(uint32_t unit_,
                              uint32_t addr_)
{
  uint32_t current1;
  uint32_t current2;
  bool is_poll;

  current1 = CLIO.regs[XBUS_DIPIR1_ADDR];
  current2 = CLIO.regs[XBUS_DIPIR2_ADDR];
  if(!(current1 & XBUS_DIPIR_CURRENT) &&
     !(current2 & XBUS_DIPIR_CURRENT))
    return 0;

  is_poll = ((addr_ >= 0x540) && (addr_ < 0x580));
  unit_ &= XBUS_DIPIR_DEVICE_MASK;

  if((current1 & XBUS_DIPIR_CURRENT) &&
     !(current2 & XBUS_DIPIR_CURRENT))
    {
      if(is_poll)
        return 0;
      return ((current1 & XBUS_DIPIR_DEVICE_MASK) == unit_);
    }

  if((current2 & XBUS_DIPIR_CURRENT) &&
     !(current1 & XBUS_DIPIR_CURRENT))
    {
      if(is_poll)
        return 0;
      return ((current2 & XBUS_DIPIR_DEVICE_MASK) == unit_);
    }

  if(!is_poll)
    return 1;

  return (((current1 & XBUS_DIPIR_DEVICE_MASK) != unit_) &&
          ((current2 & XBUS_DIPIR_DEVICE_MASK) != unit_));
}

void
opera_clio_reset(void)
{
  memset(&CLIO,0,sizeof(CLIO));
  TIMER_CARRY = 0;
}

uint16_t
opera_clio_fifo_ei_read(uint16_t channel_)
{
  return opera_mem_read16(((CLIO.fifo_i[channel_].start.addr + CLIO.fifo_i[channel_].idx)));
}

static
void
opera_clio_fifo_eo_write(uint16_t channel_,
                         uint16_t val_)
{
  opera_mem_write16(((CLIO.fifo_o[channel_].start.addr + CLIO.fifo_o[channel_].idx)),val_);
}

static
INLINE
bool
dma_channel_enabled(uint32_t const channel_)
{
  return (CLIO.regs[0x304] & (1 << channel_));
}

static
void
_clio_fifo_ei_complete(uint16_t channel_)
{
  clio_fifo_t *fifo = &CLIO.fifo_i[channel_];

  assert(fifo->idx >= fifo->start.len);
  fifo->idx = 0;
  opera_clio_fiq_generate_from_dsp((1U << (channel_ + 16)));
  // Reload is enabled by the channel request bit (WO1994010641A1, p. 49).
  if((fifo->next.addr != 0) && dma_channel_enabled(channel_))
    fifo->start = fifo->next;
  else
    fifo->start.addr = 0;
}


uint16_t
opera_clio_fifo_ei(uint16_t channel_)
{
  uint16_t val;
  clio_fifo_t *fifo;

  assert(channel_ < (sizeof(CLIO.fifo_i) / sizeof(CLIO.fifo_i[0])));
  fifo = &CLIO.fifo_i[channel_];
  // A restored state can still have completion waiting on the next DSP read.
  if((fifo->start.addr != 0) && (fifo->idx >= fifo->start.len))
    _clio_fifo_ei_complete(channel_);

  if(fifo->start.addr == 0)
    return 0;

  val = opera_clio_fifo_ei_read(channel_);
  fifo->idx += sizeof(uint16_t);

  // Complete before the CPU can observe the end address and detach the sample.
  if(fifo->idx >= fifo->start.len)
    _clio_fifo_ei_complete(channel_);

  return val;
}


void
opera_clio_fifo_eo(uint16_t channel_,
                   uint16_t val_)
{
  if(CLIO.fifo_o[channel_].start.addr == 0)
    return;

  if((CLIO.fifo_o[channel_].start.len - CLIO.fifo_o[channel_].idx) > 0)
    {
      opera_clio_fifo_eo_write(channel_,val_);
      CLIO.fifo_o[channel_].idx += 2;
    }
  else
    {
      CLIO.fifo_o[channel_].idx = 0;
      opera_clio_fiq_generate_from_dsp(1<<(channel_+12));

      /* reload enabled? */
      if((CLIO.fifo_o[channel_].next.addr != 0) && dma_channel_enabled(channel_))
        {
          CLIO.fifo_o[channel_].start.addr = CLIO.fifo_o[channel_].next.addr;
          CLIO.fifo_o[channel_].start.len  = CLIO.fifo_o[channel_].next.len;
        }
      else
        {
          CLIO.fifo_o[channel_].start.addr = 0;
        }
    }
}

uint16_t
opera_clio_fifo_ei_status(uint8_t channel_)
{
  if(CLIO.fifo_i[channel_].start.addr != 0)
    return 2; /* fixme */

  return 0;
}

uint16_t
opera_clio_fifo_eo_status(uint8_t channel_)
{
  if(CLIO.fifo_o[channel_].start.addr != 0)
    return 1;
  return 0;
}

uint32_t
opera_clio_fifo_read(uint32_t addr_)
{
  if((addr_ & 0x500) == 0x400)
    {
      switch(addr_ & 0x0F)
        {
        case 0x00:
          return CLIO.fifo_i[(addr_>>4) & 0xF].start.addr + CLIO.fifo_i[(addr_>>4)&0xF].idx;
        case 0x04:
          return CLIO.fifo_i[(addr_>>4) & 0xF].start.len - CLIO.fifo_i[(addr_>>4)&0xF].idx;
        case 0x08:
          return CLIO.fifo_i[(addr_>>4) & 0xF].next.addr;
        case 0x0C:
          return CLIO.fifo_i[(addr_>>4) & 0xF].next.len;
        }
    }

  switch(addr_ & 0xF)
    {
    case 0x00:
      return CLIO.fifo_o[(addr_>>4)&0xF].start.addr + CLIO.fifo_o[(addr_>>4)&0xF].idx;
    case 0x04:
      return CLIO.fifo_o[(addr_>>4)&0xF].start.len - CLIO.fifo_o[(addr_>>4)&0xF].idx;
    case 0x08:
      return CLIO.fifo_o[(addr_>>4)&0xF].next.addr;
    case 0x0C:
      return CLIO.fifo_o[(addr_>>4)&0xF].next.len;
    }

  return 0;
}

void
opera_clio_fifo_write(uint32_t addr_, uint32_t val_)
{
  /* Local modification for OperaU, see opera_dsp.h: the DSP reads these, so they change between two of its ticks. */
  opera_dsp_arm_write_sync();

  if((addr_& 0x500) == 0x400)
    {
      switch(addr_ & 0x0F)
        {
        case 0x00:
          /* see patent WO09410641A1, 46.25 */
          CLIO.fifo_i[(addr_>>4)&0xF].start.addr = val_;
          // A new current address replaces the previous transfer's memory cursor.
          CLIO.fifo_i[(addr_>>4)&0xF].idx = 0;
          CLIO.fifo_i[(addr_>>4)&0xF].next.addr  = 0;
          break;
        case 0x04:
          if(val_ != 0)
            CLIO.fifo_i[(addr_>>4)&0xF].start.len = (val_ + 4);
          else
            CLIO.fifo_i[(addr_>>4)&0xF].start.len = 0;

          /* see patent WO09410641A1, 46.25 */
          CLIO.fifo_i[(addr_>>4)&0xF].next.len = 0;
          break;
        case 0x08:
          CLIO.fifo_i[(addr_>>4)&0xF].next.addr = val_;
          break;
        case 0x0C:
          if(val_ != 0)
            CLIO.fifo_i[(addr_>>4)&0xF].next.len = (val_ + 4);
          else
            CLIO.fifo_i[(addr_>>4)&0xF].next.len = 0;
          break;
        }
    }
  else
    {
      switch (addr_ & 0xF)
        {
        case 0x00:
          CLIO.fifo_o[(addr_>>4)&0xF].start.addr = val_;
          break;
        case 0x04:
          CLIO.fifo_o[(addr_>>4)&0xF].start.len  = (val_ + 4);
          break;
        case 0x08:
          CLIO.fifo_o[(addr_>>4)&0xF].next.addr  = val_;
          break;
        case 0x0C:
          CLIO.fifo_o[(addr_>>4)&0xF].next.len   = (val_ + 4);
          break;
        }
    }
}
